package client.netheritefinder;

import net.minecraft.client.Minecraft;
import net.minecraft.core.*;
import net.minecraft.network.chat.Component;
import net.minecraft.util.Mth;
import net.minecraft.world.InteractionHand;
import net.minecraft.world.entity.item.ItemEntity;
import net.minecraft.world.item.*;
import net.minecraft.world.level.*;
import net.minecraft.world.level.block.Blocks;
import net.minecraft.world.phys.*;
import java.util.*;

public final class MiningEngine {
    final Minecraft mc=Minecraft.getInstance();
    final InventoryActions inventory=new InventoryActions();
    final MiningTerrain terrain=new MiningTerrain();
    final DebrisScanner scanner=new DebrisScanner();
    final StorageTask storage=new StorageTask(this);
    final LavaPlugs plugs=new LavaPlugs(this);
    private boolean enabled,repairing,sawTotem;
    private String status="Off — press F7 for controls";
    private RouteSearch search;private List<RouteSearch.Cell> route=List.of();private int waypoint;
    private BlockPos ore,goal,mining,collect;private boolean expectingOre,exploring;
    private long tick,miningSince,collectUntil,lastBottle,lastDrop;private int countBeforeCollect,missedPickups;
    private final Map<BlockPos,Long> avoid=new HashMap<>();
    private int exploreDirection,failures;private Vec3 progress=Vec3.ZERO;private long progressTick;
    private int repairDamage,repairBottles;private long bottleReturnTick;
    private BlockPos pendingDebris;private int pendingCount;private UUID pickupEntity;private PickupProgress pickupProgress;
    public int stored,thrownBottles,discarded;
    public boolean enabled(){return enabled;}
    public String status(){return status;}
    public long ticks(){return tick;}
    public BlockPos target(){return ore;}
    public void status(String value){status=value;}
    public void toggle(){setEnabled(!enabled);}
    public void setEnabled(boolean on){
        release();enabled=on;resetRoute();ore=goal=mining=collect=pendingDebris=null;pickupEntity=null;pickupProgress=null;bottleReturnTick=0;expectingOre=repairing=false;storage.reset();plugs.reset();avoid.clear();failures=missedPickups=0;
        if(on){sawTotem=mc.player!=null&&mc.player.getOffhandItem().is(Items.TOTEM_OF_UNDYING);exploreDirection=mc.player==null?0:Math.floorMod(Math.round(mc.player.getYRot()/90f),4);status="Ready — close the menu to start";}
        else{scanner.clear();status="Off";}
    }
    public void stop(String reason){setEnabled(false);status=reason;if(mc.player!=null)mc.player.displayClientMessage(Component.literal("Netherite Finder: "+reason),false);}
    public void disconnect(){setEnabled(false);status="Disconnected — automation is off";}
    public void menuOpened(){release();if(mc.player!=null&&mc.player.containerMenu!=mc.player.inventoryMenu)mc.player.closeContainer();storage.reset();resetRoute();}
    public void release(){
        mc.options.keyUp.setDown(false);mc.options.keyDown.setDown(false);mc.options.keyLeft.setDown(false);mc.options.keyRight.setDown(false);mc.options.keyJump.setDown(false);mc.options.keySprint.setDown(false);mc.options.keyShift.setDown(false);
        mc.options.keyAttack.setDown(false);
        if(mc.gameMode!=null)mc.gameMode.stopDestroyBlock();mining=null;
    }
    private void clearMovement(){mc.options.keyUp.setDown(false);mc.options.keyDown.setDown(false);mc.options.keyLeft.setDown(false);mc.options.keyRight.setDown(false);mc.options.keyShift.setDown(false);mc.options.keyJump.setDown(false);mc.options.keySprint.setDown(false);}
    void stopMining(){mc.options.keyAttack.setDown(false);if(mining!=null&&mc.gameMode!=null)mc.gameMode.stopDestroyBlock();mining=null;}
    void resetRoute(){search=null;route=List.of();waypoint=0;goal=null;}
    public void tick(){
        tick++;
        if(!enabled)return;
        if(mc.player==null||mc.level==null||mc.gameMode==null){setEnabled(false);return;}
        clearMovement();
        if(!mc.level.dimension().equals(Level.NETHER)){stopMining();status="Waiting for the Nether";scanner.clear();return;}
        if(!mc.player.isAlive()){stop("Player is not alive");return;}
        for(var player:mc.level.players())if(player!=mc.player&&!player.isSpectator()&&Math.hypot(player.getX()-mc.player.getX(),player.getZ()-mc.player.getZ())<=128){
            String name=player.getName().getString();stop("Nearby player: "+name+" — logging out");var connection=mc.getConnection();if(connection!=null)connection.getConnection().disconnect(Component.literal("Netherite Finder: player "+name+" detected within 8 chunks."));return;
        }
        scanner.tick();avoid.entrySet().removeIf(e->e.getValue()<=tick);
        if(mc.gameMode.isSpectator()){stop("Spectator mode cannot mine");return;}
        if(!mc.player.getOffhandItem().is(Items.TOTEM_OF_UNDYING)){
            if(inventory.count(Items.TOTEM_OF_UNDYING)>0){stopMining();status="Equipping a spare totem";inventory.refillTotem(tick);sawTotem=true;return;}
            if(sawTotem){stop("Totem used — no spare totems remain");return;}
        }else sawTotem=true;
        if(mc.player.isInLava()||mc.player.fallDistance>3){stop("Unsafe lava or fall — stopped");return;}
        if(mc.screen!=null&&!storage.running()){stopMining();if(pickupProgress!=null)pickupProgress.touch(tick);status="Paused while a menu is open — auto totem active";return;}
        if(storage.running()){storage.tick();return;}
        if(inventory.bestPick()<0){stopMining();status="Need a usable diamond or netherite pickaxe";return;}
        if(bottleReturnTick>0){if(tick>=bottleReturnTick&&inventory.equipPick(tick))bottleReturnTick=0;status="Repairing: collecting XP";return;}
        if(plugs.tickPending())return;
        if(pendingDebris!=null&&!mc.level.getBlockState(pendingDebris).is(Blocks.ANCIENT_DEBRIS))beginCollect(pendingDebris,pendingCount);
        if(collect==null){var dropped=nearestDrop();if(dropped!=null)beginCollect(dropped.blockPosition(),inventory.count(Items.ANCIENT_DEBRIS));}
        // Secure a full stack before waiting for repair supplies.
        if(inventory.count(Items.ANCIENT_DEBRIS)>=64){if(pickupProgress!=null)observePickup();stopMining();resetRoute();storage.start();storage.tick();return;}
        if(collect!=null){collect();return;}
        int best=inventory.bestPick();var pick=mc.player.getInventory().getItem(best);double damage=InventoryActions.damage(pick);
        if(damage>=.30&&InventoryActions.mending(pick)){
            if(!repairing){repairing=true;repairDamage=pick.getDamageValue();repairBottles=0;resetRoute();}
        }
        if(repairing){
            stopMining();if(damage<=.08){repairing=false;inventory.equipPick(tick);}else{repair(pick);return;}
        }
        if(pick.isDamageableItem()&&pick.getMaxDamage()-pick.getDamageValue()<64){stopMining();status="Pickaxe nearly broken — need Mending and XP bottles";return;}
        if(ore!=null&&!mc.level.getBlockState(ore).is(Blocks.ANCIENT_DEBRIS)){ore=null;resetRoute();}
        if(ore==null){
            ore=scanner.positions().stream().filter(p->!avoid.containsKey(p)&&p.distSqr(mc.player.blockPosition())<48*48&&Math.abs(p.getY()-mc.player.getY())<=22).min(Comparator.comparingDouble(p->p.distToCenterSqr(mc.player.position()))).orElse(null);
            if(ore!=null){resetRoute();exploring=false;}
        }
        if(ore!=null){
            if(reachable(ore)&&terrain.safeBreakDirect(ore)&&visibleFirst(ore).equals(ore)){expectingOre=true;mine(ore,false);return;}
            planOrFollow(ore,true);return;
        }
        // Continue safe branch tunnelling near Y15 to reveal more loaded terrain.
        if(goal==null){int[][] dirs={{0,1},{-1,0},{0,-1},{1,0}};int[] d=dirs[exploreDirection];var feet=mc.player.blockPosition();goal=feet.offset(d[0]*10,Mth.clamp(15-feet.getY(),-3,3),d[1]*10);exploring=true;}
        planOrFollow(goal,false);
    }
    private void repair(ItemStack pick){
        status="Repairing pickaxe with XP bottles";int bottles=inventory.find(s->s.is(Items.EXPERIENCE_BOTTLE));
        if(bottles<0){status="Repair paused — add XP bottles to inventory";return;}
        if(!InventoryActions.mending(pick)){repairing=false;return;}
        if(repairBottles>=24&&pick.getDamageValue()>=repairDamage){stop("No repair progress — check Mending and other damaged gear");return;}
        if(tick-lastBottle<20){inventory.equipPick(tick);return;}
        if(!inventory.equip(bottles,tick))return;
        if(!aim(mc.player.getEyePosition().add(0,-4,.10),4))return;
        mc.gameMode.useItem(mc.player,InteractionHand.MAIN_HAND);mc.player.swing(InteractionHand.MAIN_HAND);lastBottle=tick;bottleReturnTick=tick+1;repairBottles++;thrownBottles++;
    }
    private ItemEntity nearestDrop(){
        return mc.level.getEntitiesOfClass(ItemEntity.class,mc.player.getBoundingBox().inflate(12),e->e.isAlive()&&e.getItem().is(Items.ANCIENT_DEBRIS)).stream().min(Comparator.comparingDouble(e->e.distanceToSqr(mc.player))).orElse(null);
    }
    private void beginCollect(BlockPos source,int before){
        stopMining();collect=source.immutable();pendingDebris=null;ore=null;pickupEntity=null;resetRoute();
        countBeforeCollect=before;pickupProgress=new PickupProgress(before,mc.player.getX(),mc.player.getY(),mc.player.getZ(),tick);exploring=false;
    }
    private void observePickup(){pickupProgress.observe(inventory.count(Items.ANCIENT_DEBRIS),mc.player.getX(),mc.player.getY(),mc.player.getZ(),tick);}
    private void collect(){
        stopMining();status="Walking to the dropped ancient debris";observePickup();
        var items=mc.level.getEntitiesOfClass(ItemEntity.class,mc.player.getBoundingBox().inflate(16),e->e.isAlive()&&e.getItem().is(Items.ANCIENT_DEBRIS));
        ItemEntity item=pickupEntity==null?null:items.stream().filter(e->e.getUUID().equals(pickupEntity)).findFirst().orElse(null);
        if(item==null&&pickupProgress.received()){
            collect=null;pickupEntity=null;pickupProgress=null;missedPickups=failures=0;resetRoute();return;
        }
        if(item==null)item=items.stream().min(Comparator.comparingDouble(e->e.distanceToSqr(mc.player))).orElse(null);
        if(item!=null){pickupEntity=item.getUUID();collect=item.blockPosition();}
        if(!inventory.hasPickupReserve()){
            status="Making room for debris — plain mining blocks only";pickupProgress.touch(tick);
            if(inventory.find(InventoryActions::disposable)<0){status="Inventory full — remove items manually";return;}
            if(tick-lastDrop>=20&&inventory.discardOne(tick)){lastDrop=tick;discarded++;}return;
        }
        if(pickupProgress.stalled(tick)){stop("Debris not collected — paused at the drop instead of leaving it");return;}
        Vec3 point=item==null?Vec3.atCenterOf(collect):item.position();
        BlockPos stand=pickupStand(point);
        if(stand==null){status="Debris is not on a reachable supported spot";return;}
        if(item!=null&&mc.player.getBoundingBox().inflate(.8,0,.8).intersects(item.getBoundingBox())){status="Waiting for debris pickup confirmation";return;}
        planOrFollow(stand,false);
    }
    private BlockPos pickupStand(Vec3 item){
        BlockPos best=null;double score=Double.MAX_VALUE;var base=BlockPos.containing(item);
        for(int y=1;y>=-1;y--)for(int x=-1;x<=1;x++)for(int z=-1;z<=1;z++){
            var p=base.offset(x,y,z);if(!terrain.solidFloorDirect(p.below()))continue;
            if(!terrain.clear(p)&&!terrain.safeBreakDirect(p)||!terrain.clear(p.above())&&!terrain.safeBreakDirect(p.above()))continue;
            double horizontal=Math.hypot(p.getX()+.5-item.x,p.getZ()+.5-item.z);if(horizontal>1.15||item.y<p.getY()-.15||item.y>p.getY()+1.8)continue;
            double candidate=p.distToCenterSqr(mc.player.position())+horizontal*4+(terrain.clear(p)&&terrain.clear(p.above())?0:8);
            if(candidate<score){best=p.immutable();score=candidate;}
        }
        return best;
    }
    private void planOrFollow(BlockPos target,boolean adjacent){
        goal=target;var feet=mc.player.blockPosition();
        var next=MiningTerrain.pos(DirectSteps.next(MiningTerrain.cell(feet),MiningTerrain.cell(target)));route=List.of(MiningTerrain.cell(next));waypoint=0;
        if(!terrain.loaded(next)||!terrain.loaded(next.above())){stopMining();status="Waiting for the next chunk";return;}
        var lava=plugs.encountered(next);
        if(lava!=null){if(!plugs.fill(lava,true))inventory.equipPick(tick);return;}
        if(!terrain.solidFloorDirect(next.below())){
            if(terrain.clear(next.below())&&plugs.fill(next.below(),false))return;
            status="Direct path needs a solid floor";stopMining();return;
        }
        if(next.getY()>feet.getY()&&!terrain.clear(feet.above(2))){mine(feet.above(2),false);return;}
        if(!terrain.clear(next.above())){mine(next.above(),false);return;}
        if(!terrain.clear(next)){mine(next,false);return;}
        stopMining();status=collect!=null?"Walking to the dropped ancient debris":exploring?"Tunnelling toward Y15":"Heading directly toward ancient debris";
        if(!terrain.walkableDirect(next)){status="Direct approach is blocked";return;}
        double horizontal=Math.hypot(mc.player.getX()-(next.getX()+.5),mc.player.getZ()-(next.getZ()+.5));
        if(next.equals(feet)&&horizontal<.08)return;
        if(aim(new Vec3(next.getX()+.5,mc.player.getEyeY(),next.getZ()+.5),12)){
            mc.options.keyUp.setDown(true);mc.options.keyJump.setDown(next.getY()>mc.player.getY()+.4&&horizontal<1.1);
        }
    }
    private void failedRoute(BlockPos target){
        stopMining();clearMovement();if(ore!=null){avoid.put(ore,tick+600);ore=null;expectingOre=false;}resetRoute();exploreDirection=(exploreDirection+1)%4;status="Route blocked — trying another tunnel";
        if(++failures>20){stop("No safe route — move to solid ground and enable again");}
    }
    boolean reachable(BlockPos target){return target.distToCenterSqr(mc.player.getEyePosition())<Math.pow(Math.min(4.2,mc.player.blockInteractionRange()-.2),2);}
    BlockPos visibleFirst(BlockPos target){return mc.level.clip(new ClipContext(mc.player.getEyePosition(),Vec3.atCenterOf(target),ClipContext.Block.COLLIDER,ClipContext.Fluid.NONE,mc.player)).getBlockPos();}
    boolean aim(Vec3 point,float tolerance){
        var delta=point.subtract(mc.player.getEyePosition());float yaw=(float)Math.toDegrees(Math.atan2(delta.z,delta.x))-90,pitch=(float)-Math.toDegrees(Math.atan2(delta.y,Math.hypot(delta.x,delta.z)));
        float dy=Mth.wrapDegrees(yaw-mc.player.getYRot()),dp=pitch-mc.player.getXRot();mc.player.setYRot(mc.player.getYRot()+Mth.clamp(dy,-12,12));mc.player.setXRot(Mth.clamp(mc.player.getXRot()+Mth.clamp(dp,-10,10),-89.5f,89.5f));
        return Math.abs(dy)<tolerance&&Math.abs(dp)<tolerance;
    }
    void mine(BlockPos target,boolean recoverChest){
        if(!reachable(target)){resetRoute();return;}
        BlockPos first=visibleFirst(target);
        if(!first.equals(target)){if(terrain.safeBreakDirect(first)&&reachable(first))target=first;else{failedRoute(target);return;}}
        if(recoverChest?terrain.danger(target):!terrain.safeBreakDirect(target)){failedRoute(target);return;}
        if(!inventory.equipPick(tick)){status="Moving pickaxe into the hotbar";return;}
        if(!aim(Vec3.atCenterOf(target),5)){stopMining();return;}
        if(!(mc.hitResult instanceof BlockHitResult crosshair)||!crosshair.getBlockPos().equals(target)){stopMining();return;}
        if(!target.equals(mining)){stopMining();mining=target;miningSince=tick;}
        if(tick-miningSince>240){failedRoute(target);return;}
        if(mc.level.getBlockState(target).is(Blocks.ANCIENT_DEBRIS)&&!target.equals(pendingDebris)){
            pendingDebris=target.immutable();pendingCount=inventory.count(Items.ANCIENT_DEBRIS);
        }
        // Hold the native attack input; Minecraft performs one normal mining update.
        mc.options.keyAttack.setDown(true);status=recoverChest?"Recovering the ender chest":"Mining "+(mc.level.getBlockState(target).is(Blocks.ANCIENT_DEBRIS)?"ancient debris":"a clear tunnel");
    }
}
