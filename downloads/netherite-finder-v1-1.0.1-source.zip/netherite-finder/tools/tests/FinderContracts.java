package client.netheritefinder;

import java.util.*;

public final class FinderContracts {
    private static void check(boolean value,String message){if(!value)throw new AssertionError(message);}
    public static void main(String[] args){
        var start=new RouteSearch.Cell(0,15,0);var goal=new RouteSearch.Cell(8,15,0);
        Set<RouteSearch.Cell> lava=new HashSet<>();for(int z=-1;z<=1;z++)lava.add(new RouteSearch.Cell(4,15,z));
        var search=new RouteSearch((from,to)->to.y()!=15||lava.contains(to)?Double.POSITIVE_INFINITY:1,start,goal,false);
        int ticks=0;while(!search.step(2)){check(search.expanded()<=6000,"Bound search work");check(++ticks<3000,"Search terminates");}
        check(!search.route().isEmpty()&&search.route().getLast().equals(goal),"Find reachable route around lava");
        check(search.route().stream().noneMatch(lava::contains),"Never use a rejected lava cell");
        var blocked=new RouteSearch((a,b)->Double.POSITIVE_INFINITY,start,goal,false);check(blocked.step(160)&&blocked.route().isEmpty(),"Blocked start fails without moving");
        var underfoot=new RouteSearch((a,b)->b.y()==15||b.y()==14?1:Double.POSITIVE_INFINITY,start,new RouteSearch.Cell(0,14,0),true);
        while(!underfoot.step(160)){}check(!underfoot.route().isEmpty(),"Do not treat the ore directly under the player as a finished route");
        var bounded=new RouteSearch((a,b)->1,start,new RouteSearch.Cell(1000,15,1000),false);while(!bounded.step(160)){}check(bounded.route().isEmpty()&&bounded.expanded()<=6000,"Unreachable distant route has bounded CPU/memory");
        net.minecraft.SharedConstants.tryDetectVersion();net.minecraft.server.Bootstrap.bootStrap();
        var junk=new net.minecraft.world.item.ItemStack(net.minecraft.world.item.Items.NETHERRACK);
        check(InventoryActions.disposable(junk),"Plain netherrack remains discardable despite empty default lore");
        junk.set(net.minecraft.core.component.DataComponents.CUSTOM_NAME,net.minecraft.network.chat.Component.literal("Keep me"));
        check(!InventoryActions.disposable(junk),"Named mining blocks are protected");
        check(!InventoryActions.disposable(new net.minecraft.world.item.ItemStack(net.minecraft.world.item.Items.EXPERIENCE_BOTTLE)),"Never discard XP supplies");
        check(DirectSteps.next(start,goal).equals(start.add(1,0,0)),"Take an immediate direct step toward ore");
        check(DirectSteps.next(start,start.add(0,-2,0)).equals(start.add(1,-1,0)),"Descend by a side step instead of removing the player's floor");
        var pickup=new PickupProgress(0,0,15,0,0);
        for(int t=20;t<=400;t+=20)pickup.observe(0,t/20d,15,0,t);
        check(!pickup.stalled(400)&&!pickup.received(),"Continue pickup beyond the old timeout while making progress");
        pickup.observe(1,20,15,0,401);check(pickup.received(),"Confirm collection from a real inventory increase");
        pickup.observe(0,20,15,0,402);check(pickup.received(),"A later bank deposit does not erase pickup confirmation");
        var missing=new PickupProgress(0,0,15,0,0);check(missing.stalled(301)&&!missing.received(),"A timeout never reports a successful pickup");
        System.out.println("PASS incremental routes avoid lava, reject blocked starts/underfoot goals and bound distant searches.");
    }
}
