package client.netheritefinder;

import net.minecraft.client.gui.GuiGraphics;
import net.minecraft.client.gui.navigation.ScreenRectangle;
import net.minecraft.client.gui.render.state.GuiElementRenderState;
import net.minecraft.client.gui.render.TextureSetup;
import net.minecraft.client.renderer.RenderPipelines;
import org.joml.Matrix3x2f;
import com.mojang.blaze3d.vertex.VertexConsumer;

final class FinderUi {
    static void round(GuiGraphics g,int x,int y,int w,int h,int radius,int color){var pose=new Matrix3x2f(g.pose()).translate(x,y);var area=new ScreenRectangle(0,0,w,h).transformMaxBounds(pose);var clip=g.scissorStack.peek();g.guiRenderState.submitGuiElement(new Rounded(pose,w,h,Math.clamp(radius,0,Math.min(w,h)/2),color,clip,clip==null?area:clip.intersection(area)));}
    private record Rounded(Matrix3x2f pose,int w,int h,int r,int color,ScreenRectangle scissorArea,ScreenRectangle bounds) implements GuiElementRenderState {
        private static final float[] X=new float[36],Y=new float[36];static{for(int c=0;c<4;c++)for(int i=0;i<9;i++){double a=-Math.PI/2-c*Math.PI/2-i*Math.PI/16;X[c*9+i]=(float)Math.cos(a);Y[c*9+i]=(float)Math.sin(a);}}
        public com.mojang.blaze3d.pipeline.RenderPipeline pipeline(){return RenderPipelines.GUI;}
        public TextureSetup textureSetup(){return TextureSetup.noTexture();}
        float x(int i){int c=i/9;return(c==0||c==1?r:w-r)+X[i]*r;}float y(int i){int c=i/9;return(c==0||c==3?r:h-r)+Y[i]*r;}
        public void buildVertices(VertexConsumer v){for(int i=0;i<36;i++){int n=(i+1)%36;v.addVertexWith2DPose(pose,w/2f,h/2f).setColor(color);v.addVertexWith2DPose(pose,x(i),y(i)).setColor(color);v.addVertexWith2DPose(pose,x(n),y(n)).setColor(color);v.addVertexWith2DPose(pose,x(n),y(n)).setColor(color);}}
    }
}
