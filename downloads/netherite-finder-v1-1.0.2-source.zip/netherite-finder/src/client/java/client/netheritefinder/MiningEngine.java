package client.netheritefinder;

import net.minecraft.client.Minecraft;
import net.minecraft.core.*;
import net.minecraft.network.chat.Component;
import net.minecraft.util.Mth;
import net.minecraft.world.InteractionHand;
import net.minecraft.world.entity.item.ItemEntity;
import net.minecraft.world.item.*;
import net.minecraft.world.level.*;
import net.minecraft.world.level.block.Blocks;
import net.minecraft.world.phys.*;
import java.util.*;

public final class MiningEngine {
    final Minecraft mc=Minecraft.getInstance();
    final InventoryActions inventory=new InventoryActions();
    final MiningTerrain terrain=new MiningTerrain();
    final DebrisScanner scanner=new DebrisScanner();
    final StorageTask storage=new StorageTask(this);
    final LavaPlugs plugs=new LavaPlugs(this);
    private final SmoothLook look=new SmoothLook();
    private final TravelProgress travelProgress=new TravelProgress();
    private final ArrayDeque<BlockPos> detour=new ArrayDeque<>();
    private final Map<BlockPos,Long> blockedSteps=new HashMap<>();
    private BlockPos travelGoal,heldStep;private int recoveryAttempts;private Vec3 recoveryAnchor=Vec3.ZERO;
    private double recoveryDistance;
    private int destroyStage;private long destroyProgressTick;
    private boolean enabled,repairing,sawTotem;
    private String status="Off — press F7 for controls";
    private RouteSearch search;private List<RouteSearch.Cell> route=List.of();private int waypoint;
    private BlockPos ore,goal,mining,collect;private boolean expectingOre,exploring;
    private long tick,miningSince,collectUntil,lastBottle,lastDrop;private int countBeforeCollect,missedPickups;
    private final Map<BlockPos,Long> avoid=new HashMap<>();
    private int exploreDirection,failures;private Vec3 progress=Vec3.ZERO;private long progressTick;
    private int repairDamage,repairBottles;private long bottleReturnTick;
    private BlockPos pendingDebris;private int pendingCount;private UUID pickupEntity;private PickupProgress pickupProgress;
    public int stored,thrownBottles,discarded;
    public boolean enabled(){return enabled;}
    public String status(){return status;}
    public long ticks(){return tick;}
    public BlockPos target(){return ore;}
    public void status(String value){status=value;}
    public void toggle(){setEnabled(!enabled);}
    public void setEnabled(boolean on){
        release();enabled=on;resetRoute();ore=goal=mining=collect=pendingDebris=null;pickupEntity=null;pickupProgress=null;bottleReturnTick=0;expectingOre=repairing=false;storage.reset();plugs.reset();avoid.clear();failures=missedPickups=0;
        if(on){sawTotem=mc.player!=null&&mc.player.getOffhandItem().is(Items.TOTEM_OF_UNDYING);exploreDirection=mc.player==null?0:Math.floorMod(Math.round(mc.player.getYRot()/90f),4);status="Ready — close the menu to start";}
        else{scanner.clear();status="Off";}
    }
    public void stop(String reason){setEnabled(false);status=reason;if(mc.player!=null)mc.player.displayClientMessage(Component.literal("Netherite Finder: "+reason),false);}
    public void disconnect(){setEnabled(false);status="Disconnected — automation is off";}
    public void menuOpened(){release();if(mc.player!=null&&mc.player.containerMenu!=mc.player.inventoryMenu)mc.player.closeContainer();storage.reset();resetRoute();}
    public void release(){
        mc.options.keyUp.setDown(false);mc.options.keyDown.setDown(false);mc.options.keyLeft.setDown(false);mc.options.keyRight.setDown(false);mc.options.keyJump.setDown(false);mc.options.keySprint.setDown(false);mc.options.keyShift.setDown(false);
        mc.options.keyAttack.setDown(false);
        if(mc.gameMode!=null)mc.gameMode.stopDestroyBlock();mining=null;look.reset();
    }
    private void clearMovement(){mc.options.keyUp.setDown(false);mc.options.keyDown.setDown(false);mc.options.keyLeft.setDown(false);mc.options.keyRight.setDown(false);mc.options.keyShift.setDown(false);mc.options.keyJump.setDown(false);mc.options.keySprint.setDown(false);}
    void stopMining(){mc.options.keyAttack.setDown(false);if(mining!=null&&mc.gameMode!=null)mc.gameMode.stopDestroyBlock();mining=null;}
    void resetRoute(){search=null;route=List.of();waypoint=0;goal=null;travelGoal=heldStep=null;detour.clear();blockedSteps.clear();recoveryAttempts=0;travelProgress.reset();}
    public void tick(){
        tick++;
        if(!enabled)return;
        if(mc.player==null||mc.level==null||mc.gameMode==null){setEnabled(false);return;}
        clearMovement();
        if(!mc.level.dimension().equals(Level.NETHER)){stopMining();status="Waiting for the Nether";scanner.clear();return;}
        if(!mc.player.isAlive()){stop("Player is not alive");return;}
        for(var player:mc.level.players())if(player!=mc.player&&!player.isSpectator()&&Math.hypot(player.getX()-mc.player.getX(),player.getZ()-mc.player.getZ())<=128){
            String name=player.getName().getString();stop("Nearby player: "+name+" — logging out");var connection=mc.getConnection();if(connection!=null)connection.getConnection().disconnect(Component.literal("Netherite Finder: player "+name+" detected within 8 chunks."));return;
        }
        scanner.tick();avoid.entrySet().removeIf(e->e.getValue()<=tick);
        if(mc.gameMode.isSpectator()){stop("Spectator mode cannot mine");return;}
        if(!mc.player.getOffhandItem().is(Items.TOTEM_OF_UNDYING)){
            if(inventory.count(Items.TOTEM_OF_UNDYING)>0){stopMining();status="Equipping a spare totem";inventory.refillTotem(tick);sawTotem=true;return;}
            if(sawTotem){stop("Totem used — no spare totems remain");return;}
        }else sawTotem=true;
        if(mc.player.isInLava()||mc.player.fallDistance>3){stop("Unsafe lava or fall — stopped");return;}
        if(mc.screen!=null&&!storage.running()){stopMining();travelProgress.pause(tick);if(pickupProgress!=null)pickupProgress.touch(tick);status="Paused while a menu is open — auto totem active";return;}
        if(storage.running()){storage.tick();return;}
        if(inventory.bestPick()<0){stopMining();travelProgress.pause(tick);status="Need a usable diamond or netherite pickaxe";return;}
        if(bottleReturnTick>0){if(tick>=bottleReturnTick&&inventory.equipPick(tick))bottleReturnTick=0;status="Repairing: collecting XP";return;}
        if(plugs.tickPending()){travelProgress.pause(tick);return;}
        if(pendingDebris!=null&&!mc.level.getBlockState(pendingDebris).is(Blocks.ANCIENT_DEBRIS))beginCollect(pendingDebris,pendingCount);
        if(collect==null){var dropped=nearestDrop();if(dropped!=null)beginCollect(dropped.blockPosition(),inventory.count(Items.ANCIENT_DEBRIS));}
        // Secure a full stack before waiting for repair supplies.
        if(inventory.count(Items.ANCIENT_DEBRIS)>=64){if(pickupProgress!=null)observePickup();stopMining();resetRoute();storage.start();storage.tick();return;}
        if(collect!=null){collect();return;}
        int best=inventory.bestPick();var pick=mc.player.getInventory().getItem(best);double damage=InventoryActions.damage(pick);
        if(damage>=.30&&InventoryActions.mending(pick)){
            if(!repairing){repairing=true;repairDamage=pick.getDamageValue();repairBottles=0;resetRoute();}
        }
        if(repairing){
            stopMining();if(damage<=.08){repairing=false;inventory.equipPick(tick);}else{repair(pick);return;}
        }
        if(pick.isDamageableItem()&&pick.getMaxDamage()-pick.getDamageValue()<64){stopMining();status="Pickaxe nearly broken — need Mending and XP bottles";return;}
        if(ore!=null&&!mc.level.getBlockState(ore).is(Blocks.ANCIENT_DEBRIS)){ore=null;resetRoute();}
        if(ore==null){
            ore=scanner.positions().stream().filter(p->!avoid.containsKey(p)&&p.distSqr(mc.player.blockPosition())<48*48&&Math.abs(p.getY()-mc.player.getY())<=22).min(Comparator.comparingDouble(p->p.distToCenterSqr(mc.player.position()))).orElse(null);
            if(ore!=null){resetRoute();exploring=false;}
        }
        if(ore!=null){
            if(detour.isEmpty()&&reachable(ore)&&terrain.safeBreakDirect(ore)&&visibleFirst(ore).equals(ore)){expectingOre=true;mine(ore,false);return;}
            planOrFollow(ore,true);return;
        }
        // Continue safe branch tunnelling near Y15 to reveal more loaded terrain.
        if(goal==null){int[][] dirs={{0,1},{-1,0},{0,-1},{1,0}};int[] d=dirs[exploreDirection];var feet=mc.player.blockPosition();goal=feet.offset(d[0]*10,Mth.clamp(15-feet.getY(),-3,3),d[1]*10);exploring=true;}
        planOrFollow(goal,false);
    }
    private void repair(ItemStack pick){
        status="Repairing pickaxe with XP bottles";int bottles=inventory.find(s->s.is(Items.EXPERIENCE_BOTTLE));
        if(bottles<0){status="Repair paused — add XP bottles to inventory";return;}
        if(!InventoryActions.mending(pick)){repairing=false;return;}
        if(repairBottles>=24&&pick.getDamageValue()>=repairDamage){stop("No repair progress — check Mending and other damaged gear");return;}
        if(tick-lastBottle<20){inventory.equipPick(tick);return;}
        if(!inventory.equip(bottles,tick))return;
        if(!aim(mc.player.getEyePosition().add(0,-4,.10),4))return;
        mc.gameMode.useItem(mc.player,InteractionHand.MAIN_HAND);mc.player.swing(InteractionHand.MAIN_HAND);lastBottle=tick;bottleReturnTick=tick+1;repairBottles++;thrownBottles++;
    }
    private ItemEntity nearestDrop(){
        return mc.level.getEntitiesOfClass(ItemEntity.class,mc.player.getBoundingBox().inflate(12),e->e.isAlive()&&e.getItem().is(Items.ANCIENT_DEBRIS)).stream().min(Comparator.comparingDouble(e->e.distanceToSqr(mc.player))).orElse(null);
    }
    private void beginCollect(BlockPos source,int before){
        stopMining();collect=source.immutable();pendingDebris=null;ore=null;pickupEntity=null;resetRoute();
        countBeforeCollect=before;pickupProgress=new PickupProgress(before,mc.player.getX(),mc.player.getY(),mc.player.getZ(),tick);exploring=false;
    }
    private void observePickup(){pickupProgress.observe(inventory.count(Items.ANCIENT_DEBRIS),mc.player.getX(),mc.player.getY(),mc.player.getZ(),tick);}
    private void collect(){
        stopMining();status="Walking to the dropped ancient debris";observePickup();
        var items=mc.level.getEntitiesOfClass(ItemEntity.class,mc.player.getBoundingBox().inflate(16),e->e.isAlive()&&e.getItem().is(Items.ANCIENT_DEBRIS));
        ItemEntity item=pickupEntity==null?null:items.stream().filter(e->e.getUUID().equals(pickupEntity)).findFirst().orElse(null);
        if(item==null&&pickupProgress.received()){
            collect=null;pickupEntity=null;pickupProgress=null;missedPickups=failures=0;resetRoute();return;
        }
        if(item==null)item=items.stream().min(Comparator.comparingDouble(e->e.distanceToSqr(mc.player))).orElse(null);
        if(item!=null){pickupEntity=item.getUUID();collect=item.blockPosition();}
        if(!inventory.hasPickupReserve()){
            status="Making room for debris — plain mining blocks only";pickupProgress.touch(tick);
            if(inventory.find(InventoryActions::disposable)<0){status="Inventory full — remove items manually";return;}
            if(tick-lastDrop>=20&&inventory.discardOne(tick)){lastDrop=tick;discarded++;}return;
        }
        if(pickupProgress.stalled(tick)){stop("Debris not collected — paused at the drop instead of leaving it");return;}
        Vec3 point=item==null?Vec3.atCenterOf(collect):item.position();
        BlockPos stand=pickupStand(point);
        if(stand==null){status="Debris is not on a reachable supported spot";return;}
        if(item!=null&&mc.player.getBoundingBox().inflate(.8,0,.8).intersects(item.getBoundingBox())){status="Waiting for debris pickup confirmation";return;}
        planOrFollow(stand,false);
    }
    private BlockPos pickupStand(Vec3 item){
        BlockPos best=null;double score=Double.MAX_VALUE;var base=BlockPos.containing(item);
        for(int y=1;y>=-1;y--)for(int x=-1;x<=1;x++)for(int z=-1;z<=1;z++){
            var p=base.offset(x,y,z);if(!terrain.solidFloorDirect(p.below()))continue;
            if(!terrain.clear(p)&&!terrain.safeBreakDirect(p)||!terrain.clear(p.above())&&!terrain.safeBreakDirect(p.above()))continue;
            double horizontal=Math.hypot(p.getX()+.5-item.x,p.getZ()+.5-item.z);if(horizontal>1.15||item.y<p.getY()-.15||item.y>p.getY()+1.8)continue;
            double candidate=p.distToCenterSqr(mc.player.position())+horizontal*4+(terrain.clear(p)&&terrain.clear(p.above())?0:8);
            if(candidate<score){best=p.immutable();score=candidate;}
        }
        return best;
    }
    private boolean arrived(BlockPos step){return Math.hypot(mc.player.getX()-step.getX()-.5,mc.player.getZ()-step.getZ()-.5)<.13&&Math.abs(mc.player.getY()-step.getY())<.55;}
    private void planOrFollow(BlockPos target,boolean adjacent){
        if(!target.equals(travelGoal)){heldStep=null;detour.clear();travelProgress.reset();blockedSteps.clear();recoveryAttempts=0;travelGoal=target;}
        goal=target;var feet=mc.player.blockPosition();blockedSteps.entrySet().removeIf(e->e.getValue()<=tick);
        if(heldStep!=null&&arrived(heldStep)){
            if(!detour.isEmpty()&&detour.peekFirst().equals(heldStep))detour.removeFirst();
            heldStep=null;travelProgress.reset();
        }
        if(heldStep==null){
            if(!detour.isEmpty())heldStep=detour.peekFirst();
            else{
                heldStep=MiningTerrain.pos(DirectSteps.next(MiningTerrain.cell(feet),MiningTerrain.cell(target)));
                int dx=Integer.compare(target.getX(),feet.getX()),dz=Integer.compare(target.getZ(),feet.getZ());
                if(target.getY()==feet.getY()&&dx!=0&&dz!=0&&clearTravel(feet.offset(dx,0,0))&&clearTravel(feet.offset(0,0,dz))&&clearTravel(feet.offset(dx,0,dz)))heldStep=feet.offset(dx,0,dz);
            }
        }
        var next=heldStep;route=detour.isEmpty()?List.of(MiningTerrain.cell(next)):detour.stream().map(MiningTerrain::cell).toList();waypoint=0;
        if(detour.isEmpty()&&blockedSteps.containsKey(next)&&!next.equals(feet)){recover(target,next);return;}
        if(!terrain.loaded(next)||!terrain.loaded(next.above())){stopMining();status="Waiting for the next chunk";travelProgress.pause(tick);return;}
        var lava=plugs.encountered(next);
        if(lava!=null){
            boolean waiting=plugs.fill(lava,true);travelProgress.pause(tick);
            if(waiting&&plugs.geometryBlocked())recover(target,next);else if(!waiting)inventory.equipPick(tick);return;
        }
        if(!terrain.solidFloorDirect(next.below())){
            if(terrain.clear(next.below())){boolean waiting=plugs.fill(next.below(),false);travelProgress.pause(tick);if(waiting&&plugs.geometryBlocked())recover(target,next);return;}
            recover(target,next);return;
        }
        if(next.getY()>feet.getY()&&!terrain.clear(feet.above(2))){if(terrain.safeBreakDirect(feet.above(2)))mine(feet.above(2),false);else recover(target,next);return;}
        if(!terrain.clear(next.above())){if(terrain.safeBreakDirect(next.above()))mine(next.above(),false);else recover(target,next);return;}
        if(!terrain.clear(next)){if(terrain.safeBreakDirect(next))mine(next,false);else recover(target,next);return;}
        stopMining();status=!detour.isEmpty()?"Stepping around an obstruction":collect!=null?"Walking to the dropped ancient debris":exploring?"Tunnelling toward Y15":"Heading directly toward ancient debris";
        if(!terrain.walkableDirect(next)){recover(target,next);return;}
        double horizontal=Math.hypot(mc.player.getX()-(next.getX()+.5),mc.player.getZ()-(next.getZ()+.5));
        double remaining=horizontal+Math.abs(mc.player.getY()-next.getY())*.5;
        if(next.equals(target)&&horizontal<.13&&Math.abs(mc.player.getY()-next.getY())<.55){travelProgress.pause(tick);return;}
        Vec3 aimPoint=travelAim(next,target);boolean vertical=next.getY()!=feet.getY();
        if(aim(aimPoint,vertical?12:32)){
            double yaw=Math.toRadians(mc.player.getYRot());var ahead=mc.player.position().add(-Math.sin(yaw)*.32,0,Math.cos(yaw)*.32);
            if(vertical||clearBodyAt(ahead,feet.getY())){
                mc.options.keyUp.setDown(true);mc.options.keyJump.setDown(next.getY()>mc.player.getY()+.4&&horizontal<1.1);
            }
            if(travelProgress.stalled(remaining,tick))recover(target,next);
        }else travelProgress.pause(tick);
        if(recoveryAttempts>0&&recoveryDistance-Math.sqrt(target.distToCenterSqr(mc.player.position()))>1.5)recoveryAttempts=0;
    }
    private boolean clearTravel(BlockPos cell){return terrain.walkableDirect(cell)&&plugs.encountered(cell)==null&&!blockedSteps.containsKey(cell);}
    private boolean clearBodyAt(Vec3 position,int y){
        // A remembered bad waypoint is a routing hint, not a physical wall.
        // In particular, it must never prevent stepping out of the current cell.
        for(double x:new double[]{-.28,.28})for(double z:new double[]{-.28,.28}){
            var cell=BlockPos.containing(position.x+x,y,position.z+z);
            if(!terrain.walkableDirect(cell)||plugs.encountered(cell)!=null)return false;
        }
        return true;
    }
    private Vec3 travelAim(BlockPos next,BlockPos target){
        Vec3 fallback=new Vec3(next.getX()+.5,mc.player.getEyeY(),next.getZ()+.5);
        if(next.getY()!=mc.player.blockPosition().getY()||!detour.isEmpty())return fallback;
        double dx=target.getX()+.5-mc.player.getX(),dz=target.getZ()+.5-mc.player.getZ(),length=Math.hypot(dx,dz);
        if(length<.4)return fallback;
        double distance=Math.min(2.5,length);int y=mc.player.blockPosition().getY();
        for(double d=.25;d<=distance+.01;d+=.25){var p=mc.player.position().add(dx/length*d,0,dz/length*d);if(!clearBodyAt(p,y))return fallback;}
        return new Vec3(mc.player.getX()+dx/length*distance,mc.player.getEyeY(),mc.player.getZ()+dz/length*distance);
    }
    private boolean recover(BlockPos destination,BlockPos obstruction){
        stopMining();clearMovement();travelProgress.reset();
        if(++recoveryAttempts>3){stop("Still blocked after safe recovery attempts — move clear and enable again");return false;}
        recoveryAnchor=mc.player.position();recoveryDistance=Math.sqrt(destination.distToCenterSqr(recoveryAnchor));travelGoal=destination;goal=destination;blockedSteps.put(obstruction.immutable(),tick+120);
        var avoided=new HashSet<RouteSearch.Cell>();for(var p:blockedSteps.keySet())avoided.add(MiningTerrain.cell(p));
        var escape=LocalRecovery.find(MiningTerrain.cell(mc.player.blockPosition()),MiningTerrain.cell(destination),cell->clearTravel(MiningTerrain.pos(cell)),avoided);
        if(escape.isEmpty()){stop("No safe way around this obstruction — move clear and enable again");return false;}
        plugs.reset();detour.clear();for(var cell:escape)detour.addLast(MiningTerrain.pos(cell));heldStep=null;status="Stepping around an obstruction";return true;
    }
    private void failedRoute(BlockPos obstruction){
        BlockPos destination=goal!=null?goal:ore!=null?ore:obstruction;
        recover(destination,obstruction);
    }
    boolean reachable(BlockPos target){return target.distToCenterSqr(mc.player.getEyePosition())<Math.pow(Math.min(4.2,mc.player.blockInteractionRange()-.2),2);}
    BlockPos visibleFirst(BlockPos target){return mc.level.clip(new ClipContext(mc.player.getEyePosition(),Vec3.atCenterOf(target),ClipContext.Block.COLLIDER,ClipContext.Fluid.NONE,mc.player)).getBlockPos();}
    boolean aim(Vec3 point,float tolerance){
        var delta=point.subtract(mc.player.getEyePosition());float yaw=(float)Math.toDegrees(Math.atan2(delta.z,delta.x))-90,pitch=(float)-Math.toDegrees(Math.atan2(delta.y,Math.hypot(delta.x,delta.z)));
        mc.player.setYRot(look.yaw(mc.player.getYRot(),yaw));mc.player.setXRot(look.pitch(mc.player.getXRot(),pitch));
        return Math.abs(Mth.wrapDegrees(yaw-mc.player.getYRot()))<tolerance&&Math.abs(pitch-mc.player.getXRot())<tolerance;
    }
    void mine(BlockPos target,boolean recoverChest){
        travelProgress.pause(tick);
        if(!reachable(target)){resetRoute();return;}
        BlockPos first=visibleFirst(target);
        if(!first.equals(target)){if(terrain.safeBreakDirect(first)&&reachable(first))target=first;else{failedRoute(target);return;}}
        if(recoverChest?terrain.danger(target):!terrain.safeBreakDirect(target)){failedRoute(target);return;}
        if(!inventory.equipPick(tick)){status="Moving pickaxe into the hotbar";return;}
        if(!aim(Vec3.atCenterOf(target),5)){stopMining();return;}
        if(!(mc.hitResult instanceof BlockHitResult crosshair)||!crosshair.getBlockPos().equals(target)){stopMining();return;}
        if(!target.equals(mining)){stopMining();mining=target;miningSince=destroyProgressTick=tick;destroyStage=-2;}
        int stage=mc.gameMode.getDestroyStage();if(stage!=destroyStage){destroyStage=stage;destroyProgressTick=tick;}
        if(tick-miningSince>240||tick-destroyProgressTick>80){failedRoute(target);return;}
        if(mc.level.getBlockState(target).is(Blocks.ANCIENT_DEBRIS)&&!target.equals(pendingDebris)){
            pendingDebris=target.immutable();pendingCount=inventory.count(Items.ANCIENT_DEBRIS);
        }
        // Hold the native attack input; Minecraft performs one normal mining update.
        mc.options.keyAttack.setDown(true);status=recoverChest?"Recovering the ender chest":"Mining "+(mc.level.getBlockState(target).is(Blocks.ANCIENT_DEBRIS)?"ancient debris":"a clear tunnel");
    }
}
