package client.netheritefinder;

import com.mojang.blaze3d.pipeline.*;
import com.mojang.blaze3d.platform.DepthTestFunction;
import com.mojang.blaze3d.shaders.UniformType;
import com.mojang.blaze3d.vertex.*;
import net.fabricmc.fabric.api.client.rendering.v1.world.WorldRenderEvents;
import net.minecraft.client.renderer.MultiBufferSource;
import net.minecraft.client.renderer.rendertype.*;
import net.minecraft.core.BlockPos;
import net.minecraft.resources.Identifier;
import org.joml.Matrix4f;
import java.util.*;

/** Full-bright red, depth-independent geometry. No world blocks are changed. */
final class DebrisHighlight {
    private static final RenderPipeline PIPELINE=RenderPipeline.builder()
        .withLocation(Identifier.fromNamespaceAndPath("netherite-finder","pipeline/debris"))
        .withVertexShader(Identifier.withDefaultNamespace("core/position_color"))
        .withFragmentShader(Identifier.withDefaultNamespace("core/position_color"))
        .withUniform("DynamicTransforms",UniformType.UNIFORM_BUFFER).withUniform("Projection",UniformType.UNIFORM_BUFFER)
        .withVertexFormat(DefaultVertexFormat.POSITION_COLOR,VertexFormat.Mode.QUADS)
        .withDepthTestFunction(DepthTestFunction.NO_DEPTH_TEST).withDepthWrite(false).withCull(false).withBlend(BlendFunction.TRANSLUCENT).build();
    private static final RenderType TYPE=RenderType.create("netherite_finder_debris",RenderSetup.builder(PIPELINE).bufferSize(65536).createRenderSetup());
    private static final ByteBufferBuilder MEMORY=new ByteBufferBuilder(65536);
    private static final MultiBufferSource.BufferSource BUFFERS=MultiBufferSource.immediate(MEMORY);
    private static volatile List<BlockPos> frame=List.of();
    static void initialize(MiningEngine engine){
        WorldRenderEvents.END_EXTRACTION.register(ctx->{
            if(!engine.enabled()){frame=List.of();return;}
            var camera=ctx.camera().position();frame=engine.scanner.positions().stream().sorted(Comparator.comparingDouble(p->p.distToCenterSqr(camera))).limit(64).toList();
        });
        WorldRenderEvents.END_MAIN.register(ctx->{
            var data=frame;if(data.isEmpty())return;var camera=ctx.worldState().cameraRenderState.pos;
            var vertices=BUFFERS.getBuffer(TYPE);var pose=ctx.matrices().last().pose();
            for(var p:data){float x=(float)(p.getX()-camera.x),y=(float)(p.getY()-camera.y),z=(float)(p.getZ()-camera.z);
                box(vertices,pose,x-.01f,y-.01f,z-.01f,x+1.01f,y+1.01f,z+1.01f,0x22FF253A);
                edge(vertices,pose,x,y,z,.035f,0x44FF1635);edge(vertices,pose,x,y,z,.009f,0xFFFF4155);
            }
            BUFFERS.endBatch(TYPE);
        });
    }
    private static void edge(VertexConsumer v,Matrix4f m,float x,float y,float z,float r,int color){
        for(int a=0;a<2;a++)for(int b=0;b<2;b++){
            box(v,m,x-r,y+a-r,z+b-r,x+1+r,y+a+r,z+b+r,color);
            box(v,m,x+a-r,y-r,z+b-r,x+a+r,y+1+r,z+b+r,color);
            box(v,m,x+a-r,y+b-r,z-r,x+a+r,y+b+r,z+1+r,color);
        }
    }
    private static void quad(VertexConsumer v,Matrix4f m,int c,float... p){for(int i=0;i<12;i+=3)v.addVertex(m,p[i],p[i+1],p[i+2]).setColor(c);}
    private static void box(VertexConsumer v,Matrix4f m,float x,float y,float z,float X,float Y,float Z,int c){
        quad(v,m,c,x,y,z,X,y,z,X,Y,z,x,Y,z);quad(v,m,c,x,y,Z,x,Y,Z,X,Y,Z,X,y,Z);
        quad(v,m,c,x,y,z,x,y,Z,X,y,Z,X,y,z);quad(v,m,c,x,Y,z,X,Y,z,X,Y,Z,x,Y,Z);
        quad(v,m,c,x,y,z,x,Y,z,x,Y,Z,x,y,Z);quad(v,m,c,X,y,z,X,y,Z,X,Y,Z,X,Y,z);
    }
    static void close(){frame=List.of();}
}
