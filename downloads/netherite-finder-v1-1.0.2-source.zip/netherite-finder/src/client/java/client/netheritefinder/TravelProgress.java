package client.netheritefinder;

/** Measures progress toward a held waypoint; turning/mining pauses the stall clock. */
public final class TravelProgress {
    private long lastProgress;private double best=Double.POSITIVE_INFINITY;private boolean active;
    public void reset(){active=false;best=Double.POSITIVE_INFINITY;}
    public void pause(long now){lastProgress=now;}
    public boolean stalled(double remaining,long now){
        if(!active){active=true;best=remaining;lastProgress=now;return false;}
        if(remaining<best-.04){best=remaining;lastProgress=now;}
        return now-lastProgress>=40;
    }
}
