package client.netheritefinder;

/** One direct tunnel step; no whole-region search or planning wait. */
public final class DirectSteps {
    private DirectSteps(){}
    public static RouteSearch.Cell next(RouteSearch.Cell current,RouteSearch.Cell target){
        int dx=target.x()-current.x(),dz=target.z()-current.z(),dy=Integer.compare(target.y(),current.y());
        if(dx==0&&dz==0){if(dy==0)return current;return current.add(1,dy,0);}
        return Math.abs(dx)>=Math.abs(dz)?current.add(Integer.signum(dx),dy,0):current.add(0,dy,Integer.signum(dz));
    }
}
