package client.netheritefinder;

import net.minecraft.client.Minecraft;
import net.minecraft.core.BlockPos;
import net.minecraft.world.level.block.Blocks;
import net.minecraft.world.level.Level;
import java.util.*;

/** Scan one loaded chunk per tick; palette checks skip sections without debris. */
public final class DebrisScanner {
    private final LinkedHashSet<BlockPos> found=new LinkedHashSet<>();
    private final List<int[]> offsets=new ArrayList<>();private int cursor,centerX=Integer.MIN_VALUE,centerZ;
    private List<BlockPos> snapshot=List.of();
    public DebrisScanner(){for(int x=-4;x<=4;x++)for(int z=-4;z<=4;z++)offsets.add(new int[]{x,z});offsets.sort(Comparator.comparingInt(a->a[0]*a[0]+a[1]*a[1]));}
    public void clear(){found.clear();snapshot=List.of();cursor=0;centerX=Integer.MIN_VALUE;}
    public List<BlockPos> positions(){return snapshot;}
    public void tick(){
        var mc=Minecraft.getInstance();var level=mc.level;if(level==null||mc.player==null||!level.dimension().equals(Level.NETHER)){clear();return;}
        int cx=mc.player.chunkPosition().x,cz=mc.player.chunkPosition().z;
        if(cx!=centerX||cz!=centerZ){centerX=cx;centerZ=cz;cursor=0;}
        found.removeIf(pos->Math.abs((pos.getX()>>4)-cx)>5||Math.abs((pos.getZ()>>4)-cz)>5||!level.hasChunkAt(pos)||!level.getBlockState(pos).is(Blocks.ANCIENT_DEBRIS));
        int[] offset=offsets.get(cursor++%offsets.size());int x=cx+offset[0],z=cz+offset[1];
        if(level.getChunkSource().hasChunk(x,z)){
            var chunk=level.getChunk(x,z);var sections=chunk.getSections();
            for(int s=0;s<sections.length;s++){
                var section=sections[s];if(section.hasOnlyAir()||!section.maybeHas(state->state.is(Blocks.ANCIENT_DEBRIS)))continue;
                int base=level.getMinY()+s*16;
                for(int sy=0;sy<16;sy++)for(int sx=0;sx<16;sx++)for(int sz=0;sz<16;sz++)if(section.getBlockState(sx,sy,sz).is(Blocks.ANCIENT_DEBRIS)&&found.size()<512)found.add(new BlockPos(x*16+sx,base+sy,z*16+sz));
            }
        }
        snapshot=List.copyOf(found);
    }
}
