package client.netheritefinder;

/** Pickup completes on an inventory increase, not a broken block or elapsed timer. */
public final class PickupProgress {
    private int count;private boolean received;private long activity;private double x,y,z;
    public PickupProgress(int count,double x,double y,double z,long now){this.count=count;this.x=x;this.y=y;this.z=z;activity=now;}
    public void observe(int nowCount,double nx,double ny,double nz,long now){
        if(nowCount>count){received=true;activity=now;}count=nowCount;
        if((nx-x)*(nx-x)+(ny-y)*(ny-y)+(nz-z)*(nz-z)>=.04){x=nx;y=ny;z=nz;activity=now;}
    }
    public void touch(long now){activity=now;}
    public boolean received(){return received;}
    public boolean stalled(long now){return now-activity>300;}
}
