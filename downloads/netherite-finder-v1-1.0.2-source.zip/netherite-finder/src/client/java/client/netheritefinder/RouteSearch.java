package client.netheritefinder;

import java.util.*;

/** Bounded, incremental A*. The world adapter rejects unloaded or unsafe cells. */
public final class RouteSearch {
    public record Cell(int x,int y,int z) {
        public Cell add(int dx,int dy,int dz){return new Cell(x+dx,y+dy,z+dz);}
        public int distance(Cell other){return Math.abs(x-other.x)+Math.abs(y-other.y)+Math.abs(z-other.z);}
    }
    public interface Terrain {double cost(Cell from,Cell to);}
    private record Visit(Cell cell,double cost,double total){}
    private final PriorityQueue<Visit> open=new PriorityQueue<>(Comparator.comparingDouble(Visit::total));
    private final Map<Cell,Double> scores=new HashMap<>();
    private final Map<Cell,Cell> parents=new HashMap<>();
    private final Set<Cell> closed=new HashSet<>();
    private final Terrain terrain;private final Cell start,goal;private final boolean adjacent;
    private boolean finished;private List<Cell> route=List.of();
    public RouteSearch(Terrain terrain,Cell start,Cell goal,boolean adjacent){this.terrain=terrain;this.start=start;this.goal=goal;this.adjacent=adjacent;scores.put(start,0d);open.add(new Visit(start,0,start.distance(goal)));}
    private boolean goal(Cell cell){return adjacent?cell.distance(goal)<=1&&!(cell.x==goal.x&&cell.z==goal.z&&cell.y>goal.y):cell.equals(goal);}
    public boolean step(int budget){
        while(!finished&&budget-->0){
            Visit next=open.poll();if(next==null){finished=true;break;}
            Cell current=next.cell;if(!closed.add(current))continue;
            if(goal(current)){var result=new ArrayList<Cell>();for(Cell p=current;!p.equals(start);p=parents.get(p))result.add(p);Collections.reverse(result);route=List.copyOf(result);finished=true;break;}
            if(closed.size()>=6000){finished=true;break;}
            for(int[] direction:new int[][]{{1,0},{-1,0},{0,1},{0,-1}})for(int dy:new int[]{0,1,-1}){
                Cell cell=current.add(direction[0],dy,direction[1]);
                if(closed.contains(cell)||Math.abs(cell.x-start.x)>48||Math.abs(cell.z-start.z)>48||Math.abs(cell.y-start.y)>24)continue;
                double cost=terrain.cost(current,cell);if(!Double.isFinite(cost)||cost<1)continue;
                double candidate=next.cost+cost;
                if(candidate<scores.getOrDefault(cell,Double.POSITIVE_INFINITY)){scores.put(cell,candidate);parents.put(cell,current);open.add(new Visit(cell,candidate,candidate+2.2*Math.max(0,cell.distance(goal)-(adjacent?1:0))));}
            }
        }
        return finished;
    }
    public boolean finished(){return finished;}
    public List<Cell> route(){return route;}
    public int expanded(){return closed.size();}
}
