package client.netheritefinder;

import java.util.*;
import java.util.function.Predicate;

/** Small nearby escape path, run only for an obstruction/stall, never a regional scan. */
public final class LocalRecovery {
    private record Entry(RouteSearch.Cell cell,int depth){}
    public static List<RouteSearch.Cell> find(RouteSearch.Cell start,RouteSearch.Cell goal,Predicate<RouteSearch.Cell> safe,Set<RouteSearch.Cell> blocked){
        var queue=new ArrayDeque<Entry>();var parents=new HashMap<RouteSearch.Cell,RouteSearch.Cell>();var visited=new HashSet<RouteSearch.Cell>();
        queue.add(new Entry(start,0));visited.add(start);RouteSearch.Cell best=null;double bestScore=Double.MAX_VALUE;
        int initial=start.distance(goal);
        while(!queue.isEmpty()&&visited.size()<192){
            var entry=queue.removeFirst();var current=entry.cell;
            if(entry.depth>0){
                int distance=current.distance(goal);
                if(distance<initial||entry.depth>=2&&distance<=initial+1){double score=distance+entry.depth*.2;if(score<bestScore){best=current;bestScore=score;}}
            }
            if(entry.depth>=6)continue;
            for(int[] d:new int[][]{{1,0},{-1,0},{0,1},{0,-1}})for(int dy:new int[]{0,1,-1}){
                var next=current.add(d[0],dy,d[1]);
                if(Math.abs(next.x()-start.x())>3||Math.abs(next.z()-start.z())>3||Math.abs(next.y()-start.y())>2||visited.contains(next)||blocked.contains(next)||!safe.test(next))continue;
                visited.add(next);parents.put(next,current);queue.addLast(new Entry(next,entry.depth+1));
            }
        }
        if(best==null)return List.of();var route=new ArrayList<RouteSearch.Cell>();
        for(var p=best;!p.equals(start);p=parents.get(p))route.add(p);Collections.reverse(route);return List.copyOf(route);
    }
}
