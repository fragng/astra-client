# Netherite Finder V1 / 1.0.2 validation

27 November 2026. Minecraft Java 1.21.11, Fabric Loader 0.19.3, Java 21.
Tests used an isolated local survival world, Linux/X11 and Mesa software
rendering. No public Minecraft server was connected to or changed.

The Gradle build passes. Contract checks exercise immediate direct steps,
side-step descent, collection progress across long walks, inventory-based
pickup confirmation and preservation of confirmation after bank deposits.
Legacy bounded-route checks also remain in the suite.
Minecraft's real item defaults are also used to verify that plain
netherrack is discardable, named blocks are protected and XP bottles
cannot be discarded.

The remapped release JAR was installed with its nested Fabric API and a
separate external observer. Native tests verified:

- F7 opens the controls using a new binding key so saved F8 settings from the old version cannot override the new default. ON/OFF and Instructions buttons operate.
- Red full-bright geometry is visibly drawn through Nether terrain.
- Actual survival mining and ancient-debris pickup complete in a setup
  containing lava and a full inventory. A real inventory block plugs the
  lava, the player advances directly, and plain-block cleanup frees space.
  The player remains out of lava.
- A separately broken block drops debris six blocks from the player. The
  miner walks to it and the actual inventory increases before it resumes
  mining. This covers pickup independent of the selected ore block.
- Consumed XP bottles reduce the Mending pickaxe's damage on the server.
- Real lethal damage consumes a totem while the F7 screen is open, and a
  spare is equipped without closing the screen.
- A 64-debris inventory triggers real ender-chest placement/opening and a
  server-confirmed transfer of 64 ancient debris. The test supplies the
  stack to exercise storage; it does not claim the bot mined 64 in the test.
- A simulated received remote-player entity outside 128 blocks does not
  trigger logout; one inside the radius causes an actual disconnect and
  disables automation. This tests the loaded-entity detection path, not
  detection of players hidden by a server.

Release checks verify archive integrity, Java 21 class versions, matching
original nested Fabric API bytes, and exclusion of the external observer,
test worlds, saved accounts and operating-system helpers.

ClamAV 1.5.4 scanned the final complete JAR with 0 infected files. See the
separate scan report and SHA-256 checksum for its exact identity. This is
not Windows Defender certification. Windows hardware, public-server
anti-cheat/protection rules and hidden ore/player data were not tested.
No guarantee of flag-free operation or invulnerability is made.

Version 1.0.2 additionally verifies critically damped camera turns with
bounded yaw/pitch rates, shortest-angle wraparound, actual-progress stall
detection, and bounded local recovery with no route through rejected cells.
A native survival test places an ender chest in the walking approach to a
debris item. The miner takes a safe nearby detour and still collects the
item. Its largest observed yaw change during the checked movement stays
below the configured nine-degree-per-tick limit. Camera and movement are
controlled through ordinary Minecraft rotation and movement inputs.

Held waypoints, clear-space look-ahead and checked diagonal steps reduce
premature turns at block edges. Recovery stops with a clear message when
no nearby supported route exists or attempts are exhausted. The temporary
bad-waypoint memory is used for routing, never treated as a physical wall
that prevents leaving the player's current cell.
