package client.astra.mixin;

import net.minecraft.client.KeyboardHandler;
import net.minecraft.client.input.KeyEvent;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;

@Mixin(KeyboardHandler.class)
public abstract class CreamyKeyboardMixin {
    @Inject(method="keyPress",at=@At("HEAD"))
    private void astra$keySound(long window,int action,KeyEvent event,CallbackInfo ci){client.astra.CreamyKeys.input(window,action,false);}
}
