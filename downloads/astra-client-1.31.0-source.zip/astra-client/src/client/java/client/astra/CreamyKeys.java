package client.astra;

import com.google.gson.JsonElement;
import com.google.gson.JsonObject;
import net.minecraft.client.Minecraft;
import net.minecraft.client.resources.sounds.SimpleSoundInstance;
import net.minecraft.resources.Identifier;
import net.minecraft.sounds.SoundEvent;

/** Astra's self-contained keyboard/mouse sound feature, with original local audio. */
public final class CreamyKeys {
    private static final InputSoundGate KEY_GATE=new InputSoundGate(),MOUSE_GATE=new InputSoundGate();
    private static final String[] NAMES={"Creamy","Soft","Thock"};
    private static final SoundEvent[][] SOUNDS=new SoundEvent[NAMES.length][2];
    public static boolean enabled=false,keyboard=true,mouse=true;
    public static double keyVolume=.35,mouseVolume=.25;
    public static int style;
    static {for(int i=0;i<NAMES.length;i++)for(int j=0;j<2;j++)SOUNDS[i][j]=SoundEvent.createVariableRangeEvent(Identifier.fromNamespaceAndPath(AstraClient.MOD_ID,"keys."+NAMES[i].toLowerCase(java.util.Locale.ROOT)+(j==0?".key":".mouse")));}
    private CreamyKeys(){}
    public static String styleName(){return NAMES[style];}
    public static void nextStyle(){style=(style+1)%NAMES.length;AstraConfig.changed();}
    public static void input(long window,int action,boolean isMouse){
        if(!enabled || (isMouse?!mouse:!keyboard))return;
        var mc=Minecraft.getInstance();
        if(mc.getWindow()==null || window!=mc.getWindow().handle())return;
        if(!(isMouse?MOUSE_GATE:KEY_GATE).accept(mc.isWindowActive(),action,System.nanoTime()))return;
        play(isMouse);
    }
    private static void play(boolean isMouse){
        double volume=isMouse?mouseVolume:keyVolume;if(volume<=0)return;
        var manager=Minecraft.getInstance().getSoundManager();
        // Fixed pitch: pleasant sounds without random allocation or generated audio per press.
        manager.play(SimpleSoundInstance.forUI(SOUNDS[style][isMouse?1:0],1,(float)volume));
    }
    public static void preview(boolean isMouse){play(isMouse);}
    public static void reset(){enabled=false;keyboard=mouse=true;keyVolume=.35;mouseVolume=.25;style=0;}
    public static JsonObject json(){var j=new JsonObject();j.addProperty("enabled",enabled);j.addProperty("keyboard",keyboard);j.addProperty("mouse",mouse);j.addProperty("keyVolume",keyVolume);j.addProperty("mouseVolume",mouseVolume);j.addProperty("style",style);return j;}
    public static void load(JsonElement value){
        reset();if(value==null || !value.isJsonObject())return;
        var j=value.getAsJsonObject();enabled=bool(j,"enabled",false);keyboard=bool(j,"keyboard",true);mouse=bool(j,"mouse",true);
        keyVolume=volume(j,"keyVolume",.35);mouseVolume=volume(j,"mouseVolume",.25);
        try{style=Math.clamp(j.get("style").getAsInt(),0,NAMES.length-1);}catch(RuntimeException ignored){}
    }
    private static boolean bool(JsonObject j,String key,boolean fallback){try{return j.get(key).getAsBoolean();}catch(RuntimeException e){return fallback;}}
    private static double volume(JsonObject j,String key,double fallback){try{double v=j.get(key).getAsDouble();return Double.isFinite(v)?Math.clamp(v,0,1):fallback;}catch(RuntimeException e){return fallback;}}
}
