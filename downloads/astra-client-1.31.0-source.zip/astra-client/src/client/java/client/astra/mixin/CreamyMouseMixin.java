package client.astra.mixin;

import net.minecraft.client.MouseHandler;
import net.minecraft.client.input.MouseButtonInfo;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;

@Mixin(MouseHandler.class)
public abstract class CreamyMouseMixin {
    @Inject(method="onButton",at=@At("HEAD"))
    private void astra$mouseSound(long window,MouseButtonInfo button,int action,CallbackInfo ci){client.astra.CreamyKeys.input(window,action,true);}
}
