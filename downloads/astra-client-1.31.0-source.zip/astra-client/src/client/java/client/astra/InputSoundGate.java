package client.astra;

/** Press-only, bounded sound rate. No key identities or typed text are retained. */
final class InputSoundGate {
    private long last=Long.MIN_VALUE;
    boolean accept(boolean focused,int action,long now){
        if(!focused || action!=1)return false; // GLFW_PRESS; never RELEASE or REPEAT.
        if(last!=Long.MIN_VALUE && now-last<18_000_000L)return false;
        last=now;return true;
    }
}
