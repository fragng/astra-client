"""Generate Astra's original mechanical input sounds; no sampled third-party audio.
Requires Python 3 and ffmpeg with libvorbis. Deterministic mono 44.1 kHz.
"""
from pathlib import Path
import array, math, random, subprocess, tempfile, wave
ROOT=Path(__file__).resolve().parents[1]
DEST=ROOT/'src/main/resources/assets/astra-client/sounds/keys'
DEST.mkdir(parents=True,exist_ok=True)
for style,base,decay in [('creamy',480,43),('soft',350,60),('thock',220,32)]:
 for kind in ['key','mouse']:
  rng=random.Random(style+kind);rate=44100;duration=.095 if kind=='key' else .055
  samples=[];low=0.;frequency=base*(1.65 if kind=='mouse' else 1)
  for i in range(int(rate*duration)):
   t=i/rate;noise=rng.uniform(-1,1);low=low*.7+noise*.3
   attack=min(1,t/.0008);envelope=math.exp(-t*decay)
   resonant=math.sin(math.tau*frequency*t)*.52+math.sin(math.tau*frequency*2.13*t)*.16
   click=(noise-low)*math.exp(-t*350)*.24
   sample=(resonant+low*.32)*envelope+click
   release=min(1,(duration-t)/.012)
   samples.append(sample*attack*release)
  peak=max(abs(v) for v in samples);pcm=array.array('h',(int(v/peak*.62*32767) for v in samples))
  with tempfile.TemporaryDirectory() as temp:
   wav=Path(temp)/'input.wav'
   with wave.open(str(wav),'wb') as w:w.setnchannels(1);w.setsampwidth(2);w.setframerate(rate);w.writeframes(pcm.tobytes())
   subprocess.run(['ffmpeg','-v','error','-y','-i',str(wav),'-c:a','libvorbis','-q:a','4',str(DEST/f'{style}_{kind}.ogg')],check=True)
  print(style,kind,len(pcm),'samples')
