package client.astra;

/** Prevent repeat-key audio floods and background-window capture. */
public final class InputSoundsTest {
    private static void require(boolean value,String message){if(!value)throw new AssertionError(message);}
    public static void main(String[] args){
        var gate=new InputSoundGate();long now=1_000_000_000L;
        require(!gate.accept(false,1,now),"Unfocused input must be ignored");
        require(!gate.accept(true,0,now),"Release must be silent");
        require(!gate.accept(true,2,now),"OS auto-repeat must be silent");
        require(gate.accept(true,1,now),"A real press plays immediately");
        require(!gate.accept(true,1,now+1_000_000),"Burst input must not flood audio channels");
        require(gate.accept(true,1,now+18_000_000),"Independent normal presses must play");
        int accepted=0;for(int i=0;i<10000;i++)if(gate.accept(true,1,now+20_000_000L+i*1_000_000L))accepted++;
        require(accepted<=556 && accepted>500,"Bounded allocation and sound rate under synthetic flood");
        for(int i=0;i<1000;i++)require(!gate.accept(false,1,now+20_000_000_000L+i*100_000_000L),"No global/out-of-focus keyboard audio");
        System.out.println("PASS press/release/repeat filtering, focus isolation and bounded sound rate under 10,000-event burst");
    }
}
