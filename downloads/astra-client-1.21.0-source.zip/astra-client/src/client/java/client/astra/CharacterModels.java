package client.astra;

import com.google.gson.*;
import net.minecraft.client.model.player.PlayerModel;
import net.minecraft.client.model.geom.*;
import net.minecraft.client.model.geom.builders.*;
import net.minecraft.client.renderer.entity.state.AvatarRenderState;
import java.io.*;
import java.nio.charset.StandardCharsets;
import java.util.*;

/** Cached native articulated models. Geometry is authored alongside matching 3D GUI previews. */
public final class CharacterModels {
    private static final EnumMap<CharacterStyle,PlayerModel> CACHE=new EnumMap<>(CharacterStyle.class);
    private static JsonObject definitions;
    private CharacterModels(){}
    public static PlayerModel model(CharacterStyle style){
        if(style==CharacterStyle.NONE)throw new IllegalArgumentException("Native model has no replacement");
        return CACHE.computeIfAbsent(style,CharacterModels::bake);
    }
    private static PlayerModel bake(CharacterStyle style){
        if(definitions==null){
            try(var stream=CharacterModels.class.getResourceAsStream("/assets/astra-client/characters/models.json")){
                if(stream==null)throw new FileNotFoundException("Character geometry");
                definitions=JsonParser.parseReader(new InputStreamReader(stream,StandardCharsets.UTF_8)).getAsJsonObject().getAsJsonObject("models");
            }catch(IOException e){throw new IllegalStateException("Could not load character geometry",e);}
        }
        var mesh=PlayerModel.createMesh(CubeDeformation.NONE,false);var root=mesh.getRoot();
        var parts=definitions.getAsJsonObject(style.id).getAsJsonObject("parts");
        for(var entry:parts.entrySet()){
            var spec=entry.getValue().getAsJsonObject();var p=spec.getAsJsonArray("pivot");var cubes=CubeListBuilder.create();
            for(var value:spec.getAsJsonArray("boxes")){
                var box=value.getAsJsonObject();var from=box.getAsJsonArray("from");var size=box.getAsJsonArray("size");int color=box.get("color").getAsInt();
                cubes.texOffs(color%8*64,color/8*64).addBox(from.get(0).getAsFloat(),from.get(1).getAsFloat(),from.get(2).getAsFloat(),size.get(0).getAsFloat(),size.get(1).getAsFloat(),size.get(2).getAsFloat());
            }
            var part=root.addOrReplaceChild(entry.getKey(),cubes,PartPose.offset(p.get(0).getAsFloat(),p.get(1).getAsFloat(),p.get(2).getAsFloat()));
            String overlay=switch(entry.getKey()){case "head"->"hat";case "body"->"jacket";case "right_arm"->"right_sleeve";case "left_arm"->"left_sleeve";case "right_leg"->"right_pants";default->"left_pants";};
            part.addOrReplaceChild(overlay,CubeListBuilder.create(),PartPose.ZERO);
        }
        return new CharacterPlayerModel(LayerDefinition.create(mesh,512,512).bakeRoot());
    }
    private static final class CharacterPlayerModel extends PlayerModel {
        private final float armRadius;
        CharacterPlayerModel(ModelPart root){super(root,false);armRadius=Math.abs(rightArm.getInitialPose().x());}
        @Override public void setupAnim(AvatarRenderState state){
            super.setupAnim(state);
            // Vanilla attack poses use a five-unit arm radius; keep wider cartoon shoulders joined.
            if(state.attackTime>0 && armRadius!=5){rightArm.x*=armRadius/5;leftArm.x*=armRadius/5;}
        }
    }
}
