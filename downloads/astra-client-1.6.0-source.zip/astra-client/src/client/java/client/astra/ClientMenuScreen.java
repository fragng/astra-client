package client.astra;

import net.minecraft.client.gui.GuiGraphics;
import net.minecraft.client.gui.screens.Screen;
import net.minecraft.client.input.KeyEvent;
import net.minecraft.client.input.MouseButtonEvent;
import net.minecraft.network.chat.Component;
import net.minecraft.sounds.SoundSource;
import net.fabricmc.loader.api.FabricLoader;
import org.lwjgl.glfw.GLFW;
import java.util.function.*;

public final class ClientMenuScreen extends Screen {
    private static final int W=640,H=400,X=142,CW=484;
    private static final String[] TABS={"Visuals","Settings","Jamble","Best Buds","Music","HUD","Spotify HUD","General"};
    private String tab="Visuals";
    private boolean customiseSpotify;
    private float scale,originX,originY,transition=1,brightness=(float)AstraConfig.menuBrightness;
    private long lastFrame=System.nanoTime();
    public ClientMenuScreen() { super(Component.literal("Astra Client")); }
    private void fit() {
        scale=Math.min(1.3f,Math.min((width-18f)/W,(height-18f)/H));
        originX=(width-W*scale)/2;originY=(height-H*scale)/2;
    }
    @Override protected void init() {
        fit();
        addRenderableWidget(new MenuButton(601,15,25,26,"X","",()->false,false,this::onClose));
        for(int i=0;i<TABS.length;i++) {
            String next=TABS[i];
            addRenderableWidget(new MenuButton(14,74+i*37,112,31,next,next.equals("Spotify HUD")?"Music":next,()->tab.equals(next),false,()->{
                if(!tab.equals(next) || customiseSpotify) {tab=next;customiseSpotify=false;transition=0;rebuildWidgets();}
            }));
        }
        switch(tab) {
            case "Visuals" -> {
                addRenderableWidget(new MenuButton(455,72,160,25,"Bubble Font","",()->AstraConfig.bubbleFont,true,()->{
                    AstraConfig.bubbleFont=!AstraConfig.bubbleFont;AstraConfig.changed();
                }));
                slider(153,129,462,()->AstraConfig.menuBrightness,v->{AstraConfig.menuBrightness=v;AstraConfig.changed();},v->"Brightness: "+Math.round(v*100)+"%");
                addRenderableWidget(new MenuSlider(153,190,462,()->(minecraft.options.fov().get()-30)/80.0,v->{minecraft.options.fov().set((int)Math.round(30+v*80));AstraConfig.nativeChanged();},v->"Field of view: "+minecraft.options.fov().get(),1.0/80));
                for(int i=0;i<Theme.values().length;i++) {
                    Theme theme=Theme.values()[i];
                    addRenderableWidget(new MenuButton(153+i*117,325,111,33,theme.label,"",()->AstraConfig.theme()==theme,true,()->AstraConfig.select(theme)));
                }
            }
            case "Settings" -> {
                toggle(153,137,462,"Smooth animations",()->AstraConfig.animations,()->{AstraConfig.animations=!AstraConfig.animations;AstraConfig.changed();});
                toggle(153,191,462,"Button sounds",()->AstraConfig.sounds,()->{AstraConfig.sounds=!AstraConfig.sounds;AstraConfig.changed();});

            }
            case "Music" -> {
                slider(153,137,462,this::music,this::setMusic,v->"Minecraft music volume: "+Math.round(music()*100)+"%");
                addRenderableWidget(new MenuButton(487,110,125,24,"Mute","",()->music()==0,true,()->{
                    if(music()>0) {AstraConfig.restoreMusic=music();AstraConfig.changed();setMusic(0);}
                    else setMusic(AstraConfig.restoreMusic>0?AstraConfig.restoreMusic:.5);
                }));
            }
            case "HUD" -> {
                toggle(153,137,462,"Show Astra watermark",()->AstraConfig.hudVisible,()->{AstraConfig.hudVisible=!AstraConfig.hudVisible;AstraConfig.changed();});
                toggle(153,191,462,"Show moon logo",()->AstraConfig.hudLogo,()->{AstraConfig.hudLogo=!AstraConfig.hudLogo;AstraConfig.changed();});
            }
            case "Spotify HUD" -> {
                if(customiseSpotify) {
                    for(int i=0;i<SpotifyHudTheme.values().length;i++) {
                        SpotifyHudTheme theme=SpotifyHudTheme.values()[i];
                        addRenderableWidget(new MenuButton(153+i*117,177,111,33,theme.label,"",()->AstraConfig.spotifyTheme()==theme,true,()->AstraConfig.selectSpotifyTheme(theme)));
                    }
                    addRenderableWidget(new MenuButton(153,226,160,27,"Back to Spotify HUD","",()->false,false,()->spotifyPage(false)));
                } else {
                    addRenderableWidget(new MenuButton(153,137,224,29,"Enable Spotify HUD","",()->AstraConfig.hudSpotify,true,this::toggleSpotifyHud));
                    addRenderableWidget(new MenuButton(389,137,226,29,"Enable Lyrics","",()->AstraConfig.lyricsEnabled,true,()->{AstraConfig.lyricsEnabled=!AstraConfig.lyricsEnabled;AstraConfig.changed();}));
                    addRenderableWidget(new MenuButton(153,174,224,29,"Desktop link","",()->AstraConfig.spotifyEnabled,true,()->{AstraConfig.spotifyEnabled=!AstraConfig.spotifyEnabled;AstraConfig.changed();SpotifyBridge.tick();}));
                    addRenderableWidget(new MenuButton(389,174,226,29,"Reconnect","",()->false,false,SpotifyBridge::reconnect)
                        .available(()->SpotifyBridge.windows() && AstraConfig.spotifyEnabled));
                    addRenderableWidget(new MenuSlider(153,211,462,()->(AstraConfig.spotifyHudScale-.5)/.5,v->{
                        AstraConfig.spotifyHudScale=Math.round((.5+v*.5)*100)/100.0;AstraConfig.changed();
                    },v->"Spotify HUD size: "+Math.round(AstraConfig.spotifyHudScale*100)+"%",.02));
                    addRenderableWidget(new MenuButton(153,321,143,28,"Previous","",()->false,false,()->SpotifyBridge.send("previous"))
                        .available(()->SpotifyBridge.state().connected() && SpotifyBridge.state().previous()));
                    addRenderableWidget(new MenuButton(307,321,153,28,"Play / pause","",()->SpotifyBridge.state().playing(),false,()->SpotifyBridge.send("toggle"))
                        .available(()->SpotifyBridge.state().connected() && SpotifyBridge.state().toggle()));
                    addRenderableWidget(new MenuButton(471,321,144,28,"Next","",()->false,false,()->SpotifyBridge.send("next"))
                        .available(()->SpotifyBridge.state().connected() && SpotifyBridge.state().next()));
                    addRenderableWidget(new MenuButton(153,357,462,26,"Customise Spotify HUD","General",()->false,false,()->spotifyPage(true)));
                }
            }
            case "General" -> addRenderableWidget(new MenuButton(153,295,220,32,"Reset Astra preferences","General",()->false,false,()->{
                AstraConfig.reset();brightness=1;transition=0;rebuildWidgets();
            }));
        }
    }
    private void spotifyPage(boolean customise) {customiseSpotify=customise;transition=0;rebuildWidgets();}
    private void slider(int x,int y,int w,DoubleSupplier read,DoubleConsumer write,Function<Double,String> format) {
        addRenderableWidget(new MenuSlider(x,y,w,read,write,format));
    }
    private void toggle(int x,int y,int w,String label,BooleanSupplier read,Runnable write) {
        addRenderableWidget(new MenuButton(x,y,w,35,label,"",read,true,write));
    }
    private void toggleSpotifyHud() {
        AstraConfig.hudSpotify=!AstraConfig.hudSpotify;
        if(AstraConfig.hudSpotify) {
            AstraConfig.spotifyEnabled=true;
            if(!SpotifyBridge.state().connected())SpotifyBridge.reconnect();
        }
        AstraConfig.changed();
    }
    private double music() { return minecraft.options.getSoundSourceOptionInstance(SoundSource.MUSIC).get(); }
    private void setMusic(double volume) {
        if(volume>0) {AstraConfig.restoreMusic=volume;AstraConfig.changed();}
        minecraft.options.getSoundSourceOptionInstance(SoundSource.MUSIC).set(Math.clamp(volume,0,1));AstraConfig.nativeChanged();
    }
    private String fitText(String value,int maxWidth) {
        if(font.width(Ui.text(value))<=maxWidth) return value;
        String trim=value;
        while(!trim.isEmpty() && font.width(Ui.text(trim+"..."))>maxWidth) trim=trim.substring(0,trim.offsetByCodePoints(trim.length(),-1));
        return trim+"...";
    }
    private void text(GuiGraphics g,String label,int x,int y,int color) {Ui.animated(g,font,label,x,y,color);}
    private void card(GuiGraphics g,int x,int y,int w,int h,String title,String icon) {
        Ui.round(g,x-2,y-2,w+4,h+4,19,0x299A55EA);
        Ui.round(g,x,y,w,h,17,0xFFE4C2FA);
        Ui.gradient(g,x+2,y+2,w-4,h-4,15,0xF13D305B,0xF01C1935);
        MenuArt.icon(g,icon,x+12,y+12,14,0xFFC5A6F4);
        Ui.animated(g,font,Ui.heading(title),x+35,y+12,0xFFF2E6FF);
    }
    @Override public void render(GuiGraphics g,int mouseX,int mouseY,float delta) {
        fit();long now=System.nanoTime();float dt=Math.min(.1f,(now-lastFrame)/1e9f);lastFrame=now;
        transition=AstraConfig.animations?Math.min(1,transition+dt*7):1;
        float target=(float)AstraConfig.menuBrightness;
        brightness=AstraConfig.animations?brightness+(target-brightness)*(1-(float)Math.exp(-dt*24)):target;
        g.pose().pushMatrix();g.pose().translate(originX,originY);g.pose().scale(scale,scale);
        Ui.round(g,-2,-2,W+4,H+4,20,0x457F55D7);
        Ui.round(g,-1,-1,W+2,H+2,19,0xFFD3A5FF);
        MenuArt.background(g,W,H);
        MenuArt.icon(g,"star",24,19,23,0xFFC6A2FF);
        Ui.centered(g,font,"Astra Client",64+(int)(font.width(Ui.heading("Astra Client"))*.85f),14,1.7f,0xFFF0E9FF);
        text(g,"Minecraft Client",64,40,0xFFA2A2C1);
        g.fill(12,61,W-12,62,0x7F766498);
        g.fill(133,71,134,H-20,0x554D4B70);
        Ui.centered(g,font,tab,X+font.width(Ui.heading(tab))*3/4,76,1.5f,0xFFF1EAFF);
        switch(tab) {
            case "Visuals" -> {
                card(g,X,105,CW,147,"Appearance","Visuals");
                text(g,"Adjusts menu brightness only; the world is unchanged.",163,177,0xFFA4A3BE);
                card(g,X,265,CW,116,"Menu Background","General");
                text(g,"Choose a background theme for the Astra menu.",156,299,0xFFB1ABC8);
            }
            case "Settings" -> {
                card(g,X,105,CW,195,"Client preferences","Settings");
                text(g,"Gentle motion, hover transitions and animated sliders.",163,177,0xFFA4A3BE);
                text(g,"Soft UI clicks. Respects Minecraft's sound volume.",163,231,0xFFA4A3BE);
                
                
                text(g,"Preferences are saved automatically.",156,271,0xFFB8A6D9);
            }
            case "Music" -> {
                card(g,X,105,CW,104,"Minecraft music","Music");
                text(g,"This volume controls Minecraft, not Spotify.",163,191,0xFFA4A3BE);
                text(g,"Spotify controls are in the Spotify HUD category.",156,238,0xFFB8A6D9);
            }
            case "HUD" -> {
                card(g,X,105,CW,195,"Astra HUD elements","HUD");
                text(g,"A compact pill with smooth entry and resizing.",163,177,0xFFA4A3BE);
                text(g,"The moon gently breathes while animations are on.",163,231,0xFFA4A3BE);
                text(g,"Spotify options are in the Spotify HUD category.",156,271,0xFFB8A6D9);
            }
            case "Spotify HUD" -> {
                if(customiseSpotify) {
                    card(g,X,105,CW,160,"Customise Spotify HUD","General");
                    text(g,"Choose a theme for your Spotify HUD.",156,148,0xFFB8A6D9);
                    text(g,"Saves automatically.",331,236,0xFFB8A6D9);
                    card(g,X,278,CW,105,"Live preview","Visuals");
                    SpotifyHud.drawPreview(g,font,X+CW/2,310);
                } else {
                    card(g,X,105,CW,282,"Playback and HUD","Music");
                    var media=SpotifyBridge.state();
                    text(g,media.connected()?media.playing()?"Connected / Playing":"Connected / Paused":fitText(media.status(),445),156,267,media.connected()?0xFFC8B0F3:0xFFA4A3BE);
                    text(g,fitText(media.connected()?media.title():"Open Spotify on Windows and play a song.",445),156,285,0xFFF0E8FF);
                    text(g,fitText(media.connected()?media.artist():"Close this menu to view the HUD. Lyrics use LRCLIB online.",445),156,303,0xFFB6B2CD);
                }
            }
            case "Jamble", "Best Buds" -> {
                card(g,X,105,CW,195,tab,tab);
                text(g,"Coming later",162,157,0xFFE7DCF9);
                text(g,tab.equals("Jamble")?"A dedicated page for future Jamble features.":"A dedicated page for future friend-related features.",162,182,0xFFA9A9C2);
                text(g,"No features have been specified for this section yet.",162,207,0xFFA9A9C2);
            }
            case "General" -> {
                card(g,X,105,CW,260,"About Astra Client","General");
                String version=FabricLoader.getInstance().getModContainer(AstraClient.MOD_ID).orElseThrow().getMetadata().getVersion().getFriendlyString();
                text(g,"Astra Client "+version,162,147,0xFFE7DCF9);
                text(g,"Minecraft Java 1.21.11 / Java 21",162,173,0xFFAEABC6);
                text(g,"Fabric Loader "+FabricLoader.getInstance().getModContainer("fabricloader").orElseThrow().getMetadata().getVersion().getFriendlyString(),162,195,0xFFAEABC6);
                text(g,"Appearance, music controls and a clean HUD.",162,225,0xFFAEABC6);
                text(g,"Reset restores Astra's theme and preferences.",162,260,0xFFAEABC6);
                text(g,"Minecraft FOV and music volume are kept.",162,339,0xFFAEABC6);
            }
        }
        super.render(g,(int)((mouseX-originX)/scale),(int)((mouseY-originY)/scale),delta);
        if(transition<1) Ui.round(g,X,70,CW,H-85,12,Ui.alpha(0xFF171B30,(1-transition)*.6f));
        Ui.round(g,0,0,W,H,18,Ui.alpha(0xFF000000,(1-brightness)*.90f));
        g.pose().popMatrix();
    }
    private MouseButtonEvent local(MouseButtonEvent e) {return new MouseButtonEvent((e.x()-originX)/scale,(e.y()-originY)/scale,e.buttonInfo());}
    @Override public boolean mouseClicked(MouseButtonEvent e,boolean twice) {return super.mouseClicked(local(e),twice);}
    @Override public boolean mouseReleased(MouseButtonEvent e) {return super.mouseReleased(local(e));}
    @Override public boolean mouseDragged(MouseButtonEvent e,double dx,double dy) {return super.mouseDragged(local(e),dx/scale,dy/scale);}
    @Override public boolean keyPressed(KeyEvent key) {
        if(key.key()==GLFW.GLFW_KEY_RIGHT_SHIFT) {onClose();return true;}
        return super.keyPressed(key);
    }
    @Override public void removed() {AstraConfig.flush();super.removed();}
    @Override public boolean isPauseScreen() {return false;}
}
