package client.astra;

import com.google.gson.*;
import java.net.*;
import java.net.http.*;
import java.nio.charset.StandardCharsets;
import java.time.Duration;
import java.util.*;
import java.util.concurrent.*;
import java.util.regex.*;

/** Optional online lyrics lookup, never on Minecraft's render or tick thread. */
public final class LyricsService {
    public record Line(double seconds,String text) {}
    public record Lyrics(String status,List<Line> lines,boolean synced) {
        public int index(double seconds) {
            if(lines.isEmpty()) return -1;
            if(!synced) return (int)(Math.max(0,seconds)/8)%lines.size();
            int low=0,high=lines.size()-1,result=-1;
            while(low<=high) {int mid=(low+high)>>>1;if(lines.get(mid).seconds()<=seconds) {result=mid;low=mid+1;} else high=mid-1;}
            return result;
        }
    }
    private record Cached(Lyrics lyrics,long expires) {}
    private static final ExecutorService WORK=Executors.newSingleThreadExecutor(r->{var t=new Thread(r,"Astra lyrics lookup");t.setDaemon(true);return t;});
    private static final HttpClient HTTP=HttpClient.newBuilder().connectTimeout(Duration.ofSeconds(5)).build();
    private static final Map<String,Cached> CACHE=new LinkedHashMap<>(32,.75f,true) {
        @Override protected boolean removeEldestEntry(Map.Entry<String,Cached> e) {return size()>32;}
    };
    private static final Pattern TIMESTAMP=Pattern.compile("\\[(\\d{1,3}):(\\d{2})(?:[.:](\\d{1,3}))?\\]");
    private static final Pattern OFFSET=Pattern.compile("\\[offset:([+-]?\\d+)\\]",Pattern.CASE_INSENSITIVE);
    private static volatile Lyrics current=empty("Waiting for Spotify");
    private static String key="";
    private static volatile long retryAt;
    private static volatile int generation;
    private static Future<?> request;
    private LyricsService() {}
    private static Lyrics empty(String message) {return new Lyrics(message,List.of(),true);}
    public static Lyrics current() {return current;}
    public static void tick(boolean inWorld) {
        var media=SpotifyBridge.state();
        if(!inWorld || !AstraConfig.lyricsEnabled || !AstraConfig.hudSpotify || !media.connected() || media.title().isBlank()) {
            if(!key.isEmpty()) {generation++;if(request!=null)request.cancel(true);key="";current=empty("Waiting for Spotify");}
            return;
        }
        String next=media.trackKey()+"|"+Math.round(media.duration());long now=System.nanoTime();
        if(next.equals(key) && now<retryAt) return;
        key=next;int token=++generation;if(request!=null)request.cancel(true);
        synchronized(CACHE) {
            Cached cached=CACHE.get(next);
            if(cached!=null && cached.expires()>now) {current=cached.lyrics();retryAt=cached.expires();return;}
        }
        current=empty("Finding lyrics...");retryAt=now+60_000_000_000L;
        request=WORK.submit(()->{
            Lyrics result;long ttl=600_000_000_000L;
            try {
                URI uri=query(media.title(),media.artist(),media.album(),media.duration());
                var response=HTTP.send(HttpRequest.newBuilder(uri).timeout(Duration.ofSeconds(8))
                    .header("User-Agent","AstraClient/1.6.0 (https://github.com/fragng/astra-client)").GET().build(),HttpResponse.BodyHandlers.ofInputStream());
                try(var body=response.body()) {
                    if(response.statusCode()==404) result=empty("Lyrics unavailable for this song");
                    else if(response.statusCode()!=200) {result=empty("Lyrics service unavailable");ttl=60_000_000_000L;}
                    else {
                        byte[] bytes=body.readNBytes(1_048_577);
                        if(bytes.length>1_048_576) throw new IllegalArgumentException("Oversized lyrics response");
                        result=parse(new String(bytes,StandardCharsets.UTF_8));
                    }
                }
            } catch(InterruptedException e) {Thread.currentThread().interrupt();return;}
            catch(Exception e) {result=empty("Lyrics unavailable — check your connection");ttl=60_000_000_000L;}
            long expires=System.nanoTime()+ttl;
            synchronized(CACHE) {CACHE.put(next,new Cached(result,expires));}
            if(token==generation) {current=result;retryAt=expires;}
        });
    }
    public static URI query(String title,String artist,String album,double duration) {
        String path="https://lrclib.net/api/get?track_name="+encode(title)+"&artist_name="+encode(artist);
        if(!album.isBlank()) path+="&album_name="+encode(album);
        if(duration>0) path+="&duration="+Math.round(duration);
        return URI.create(path);
    }
    private static String encode(String s) {return URLEncoder.encode(s,StandardCharsets.UTF_8);}
    public static Lyrics parse(String json) {
        JsonObject j=JsonParser.parseString(json).getAsJsonObject();
        if(j.has("instrumental") && j.get("instrumental").getAsBoolean()) return empty("Instrumental • no lyrics");
        String synced=value(j,"syncedLyrics");List<Line> lines=new ArrayList<>();double offset=0;
        var om=OFFSET.matcher(synced);if(om.find()) offset=Double.parseDouble(om.group(1))/1000;
        for(String raw:synced.split("\\R")) {
            var matcher=TIMESTAMP.matcher(raw);List<Double> stamps=new ArrayList<>();int end=0;
            while(matcher.find()) {
                double sec=Integer.parseInt(matcher.group(1))*60+Integer.parseInt(matcher.group(2));
                if(matcher.group(3)!=null) sec+=Double.parseDouble("0."+matcher.group(3));
                stamps.add(Math.max(0,sec-offset));end=matcher.end();
            }
            String text=clean(raw.substring(end).replaceAll("<\\d{1,3}:\\d{2}(?:[.:]\\d{1,3})?>", ""));
            for(double stamp:stamps) lines.add(new Line(stamp,text));
        }
        if(!lines.isEmpty()) {lines.sort(Comparator.comparingDouble(Line::seconds));return new Lyrics("Synced • LRCLIB",List.copyOf(lines),true);}
        for(String raw:value(j,"plainLyrics").split("\\R")) {String text=clean(raw);if(!text.isBlank())lines.add(new Line(0,text));}
        return lines.isEmpty()?empty("Lyrics unavailable for this song"):new Lyrics("Unsynced • LRCLIB",List.copyOf(lines),false);
    }
    private static String value(JsonObject j,String key) {return j.has(key)&&!j.get(key).isJsonNull()?j.get(key).getAsString():"";}
    private static String clean(String s) {s=s.replaceAll("[\\p{Cntrl}]"," ").strip();return s.length()>4096?s.substring(0,4096):s;}
    public static void stop() {generation++;if(request!=null)request.cancel(true);WORK.shutdownNow();}
}
