# Astra Client 1.6.0 validation

- Built on Java 21 for Minecraft 1.21.11 / Fabric Loader 0.19.3.
- Opened the real Minecraft client with Mod Menu and a separate development-only Spotify fixture.
- Navigated all eight sidebar categories, including the new Spotify HUD category. Checked that native Minecraft Music controls remain on Music, Astra watermark controls on HUD, and general preferences on Settings.
- Exercised the relocated Spotify HUD / lyrics switches and size slider; saved JSON values changed correctly. Enable HUD still enables Desktop link.
- Selected Galaxy, Astra, Nebula and Black. Checked saved selection and captured four distinct previews and actual in-game HUD backgrounds. The main-menu background preference stayed unchanged.
- Checked the new category and customisation page fit a 640×480 game window.
- Exercised Customise Spotify HUD → Back. Visually checked the icon-free card layout and readable new sidebar label.
- Unit tests checked smooth monotonic lyric interpolation, frame-rate independence, settling without overshoot, seek/track reset and reduced-motion behaviour.
- Captured intermediate rendered lyric transition frames and the settled next line inside Minecraft using original test lyrics.
- The production PowerShell poll/JSON/command loop passed with mocked Windows sessions for song metadata, timeline advancement beyond five seconds, pause/next/previous and shutdown. Artwork calls are removed from the production helper.

Earlier playback-recovery tests from 1.5.2 exercised the production Java bridge with real substitute child processes: startup failure, retry delay, reconnect after process exit and disabling during startup. That lifecycle logic is unchanged in this release.

The media fixture, synthetic song and test lyrics are outside the project and excluded from the mod. Live Windows Spotify playback remains unverified on this Linux host. No FPS improvement benchmark is claimed.
