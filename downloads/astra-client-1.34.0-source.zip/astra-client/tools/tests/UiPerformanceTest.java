package client.astra;

import com.mojang.blaze3d.vertex.VertexConsumer;
import net.minecraft.client.gui.navigation.ScreenRectangle;
import org.joml.Matrix3x2f;
import java.lang.reflect.Proxy;
import java.util.*;

public final class UiPerformanceTest {
    private static void check(boolean ok,String message){if(!ok)throw new AssertionError(message);}
    private static final class Capture {
        final List<float[]> points=new ArrayList<>();final List<Integer> colors=new ArrayList<>();
        final VertexConsumer consumer=(VertexConsumer)Proxy.newProxyInstance(VertexConsumer.class.getClassLoader(),new Class[]{VertexConsumer.class},(proxy,method,args)->{
            if(method.getName().equals("addVertexWith2DPose")){var pose=(org.joml.Matrix3x2fc)args[0];var p=pose.transformPosition(((Number)args[1]).floatValue(),((Number)args[2]).floatValue(),new org.joml.Vector2f());points.add(new float[]{p.x,p.y});}
            if(method.getName().equals("setColor"))colors.add((Integer)args[0]);return proxy;
        });
        int coverage(double x,double y){int alpha=0;for(int i=0;i<points.size();i+=4){var a=points.get(i);var b=points.get(i+2);if(x>=a[0]&&x<b[0]&&y>=a[1]&&y<b[1]){int next=colors.get(i)>>>24;alpha=next+alpha*(255-next)/255;}}return alpha;}
    }
    public static void main(String[] args)throws Exception{
        for(int fps:new int[]{20,60,144}){
            double value=0;for(int i=0;i<fps;i++)value=SmoothMotion.approach(value,1,1.0/fps,12,true);
            check(value==1,"All frame rates settle exactly");
        }
        check(SmoothMotion.approach(0,1,.3,12,true)>.97,"A dropped frame consumes elapsed time rather than stretching the transition");
        check(SmoothMotion.approach(.3,1,-1,12,true)==.3 && SmoothMotion.approach(0,1,0,12,false)==1,"Negative time and motion-off bounds");
        var body=Ui.text("Repeated label");check(body==Ui.text("Repeated label") && body!=Ui.heading("Repeated label"),"Read-only label/style reuse");
        for(int i=0;i<1500;i++)Ui.text("bounded "+i);
        var field=Ui.class.getDeclaredField("TEXT");field.setAccessible(true);check(((Map<?,?>)field.get(null)).size()<=512,"Dynamic lyrics/status cannot grow the label cache without limit");
        String longLabel="x".repeat(300);check(Ui.text(longLabel)!=Ui.text(longLabel),"Long external text is not retained");
        for(int radius:new int[]{0,1,4,11,17,20,80})for(int[] shape:new int[][]{{224,29},{462,94},{3,3},{180,60}}){
            var mesh=RoundedGradient.create(new Matrix3x2f().translate(10,20),0,0,shape[0],shape[1],radius,0x80774499,0x80332255,null);var capture=new Capture();mesh.buildVertices(capture.consumer);
            check(capture.points.size()==capture.colors.size() && capture.points.size()%4==0 && !capture.points.isEmpty(),"Valid packed GUI quads");
            check(mesh.bounds().left()==10 && mesh.bounds().top()==20 && mesh.bounds().width()==shape[0] && mesh.bounds().height()==shape[1],"Transformed bounds retain exact panel area");
            for(var p:capture.points)check(p[0]>=10 && p[0]<=10+shape[0] && p[1]>=20 && p[1]<=20+shape[1],"No geometry outside the rounded panel");
            check(capture.coverage(10+shape[0]*.51,20+shape[1]*.51)==128,"Translucent panel centre drawn once without overlapping alpha");
            if(mesh.radius()>4)check(capture.coverage(10.1,20.1)==0,"Rounded corner remains transparent");
        }
        var scissor=new ScreenRectangle(20,30,10,10);var clipped=RoundedGradient.create(new Matrix3x2f(),0,0,80,80,11,-1,-1,scissor);check(clipped.bounds().equals(scissor),"Clipping retained");
        System.out.println("PASS frame-rate-independent motion, dropped-frame recovery, bounded read-only text reuse and rounded gradient vertex/bounds/clipping/alpha invariants");
    }
}
