package client.astra;

/** Frame-rate-independent lyric scrolling. Seeks and replacement lyrics snap to the right line. */
public final class LyricMotion {
    private Object identity;
    private double position;
    private int target=-1;
    public double update(Object identity,int next,double seconds,boolean animated) {
        if(this.identity!=identity || target<0 || next<0 || next<target || Math.abs(next-position)>1.5 || !animated) {
            this.identity=identity;position=next;
        } else {
            position=SmoothMotion.approach(position,next,seconds,12,true);
            if(Math.abs(next-position)<.001)position=next;
        }
        target=next;
        return position;
    }
    public void reset() {identity=null;position=0;target=-1;}
}
