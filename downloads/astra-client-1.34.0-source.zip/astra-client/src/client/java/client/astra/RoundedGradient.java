package client.astra;

import com.mojang.blaze3d.pipeline.RenderPipeline;
import com.mojang.blaze3d.vertex.VertexConsumer;
import net.minecraft.client.gui.navigation.ScreenRectangle;
import net.minecraft.client.gui.render.TextureSetup;
import net.minecraft.client.gui.render.state.GuiElementRenderState;
import net.minecraft.client.renderer.RenderPipelines;
import org.joml.Matrix3x2f;

/** One GUI submission for an entire rounded gradient, retaining the existing half-pixel edges. */
public record RoundedGradient(Matrix3x2f pose,int width,int height,int radius,int top,int bottom,
        ScreenRectangle scissorArea,ScreenRectangle bounds) implements GuiElementRenderState {
    private static final float[][] EDGES=new float[41][];
    static {for(int r=0;r<EDGES.length;r++){EDGES[r]=new float[r];for(int y=0;y<r;y++)EDGES[r][y]=(float)Math.max(0,r-Math.sqrt(Math.max(0,r*r-Math.pow(r-y-.5,2))));}}
    public static RoundedGradient create(org.joml.Matrix3x2fc transform,int x,int y,int w,int h,int r,int top,int bottom,ScreenRectangle scissor){
        var pose=new Matrix3x2f(transform).translate(x,y).scale(.5f);
        var bounds=new ScreenRectangle(0,0,w*2,h*2).transformMaxBounds(pose);
        return new RoundedGradient(pose,w*2,h*2,Math.clamp(r,0,Math.min(20,Math.min(w,h)/2))*2,top,bottom,scissor,scissor==null?bounds:scissor.intersection(bounds));
    }
    @Override public RenderPipeline pipeline(){return RenderPipelines.GUI;}
    @Override public TextureSetup textureSetup(){return TextureSetup.noTexture();}
    private int color(int row){return Ui.blend(top,bottom,row/(float)Math.max(1,height-1));}
    private void rect(VertexConsumer v,int x0,int y0,int x1,int y1,int a,int b){
        if(x1<=x0||y1<=y0)return;
        v.addVertexWith2DPose(pose,x0,y0).setColor(a);v.addVertexWith2DPose(pose,x0,y1).setColor(b);
        v.addVertexWith2DPose(pose,x1,y1).setColor(b);v.addVertexWith2DPose(pose,x1,y0).setColor(a);
    }
    private void corner(VertexConsumer v,int row,int mirrored){
        float edge=EDGES[radius][row];int pad=(int)edge,c=color(mirrored),fade=Ui.alpha(c,1-(edge-pad));
        rect(v,pad+1,mirrored,radius,mirrored+1,c,c);rect(v,width-radius,mirrored,width-pad-1,mirrored+1,c,c);
        rect(v,pad,mirrored,pad+1,mirrored+1,fade,fade);rect(v,width-pad-1,mirrored,width-pad,mirrored+1,fade,fade);
    }
    @Override public void buildVertices(VertexConsumer v){
        rect(v,radius,0,width-radius,height,top,bottom);
        if(height>radius*2){int a=color(radius),b=color(height-radius);rect(v,0,radius,radius,height-radius,a,b);rect(v,width-radius,radius,width,height-radius,a,b);}
        for(int row=0;row<radius;row++){corner(v,row,row);corner(v,row,height-row-1);}
    }
}
