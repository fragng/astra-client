package client.astra;

import net.minecraft.client.gui.Font;
import net.minecraft.client.gui.GuiGraphics;
import net.minecraft.network.chat.Component;
import net.minecraft.network.chat.FontDescription;
import net.minecraft.resources.Identifier;

public final class Ui {
    public static final FontDescription FONT = new FontDescription.Resource(Identifier.fromNamespaceAndPath(AstraClient.MOD_ID, "ui"));
    public static final FontDescription HEADING = new FontDescription.Resource(Identifier.fromNamespaceAndPath(AstraClient.MOD_ID, "heading"));
    private record TextKey(String value,boolean heading){}
    private static final java.util.LinkedHashMap<TextKey,Component> TEXT=new java.util.LinkedHashMap<>(128,.75f,true);
    private static synchronized Component label(String value,boolean heading){
        if(value.length()>256)return Component.literal(value).withStyle(s->s.withFont(heading?HEADING:FONT));
        var key=new TextKey(value,heading);var cached=TEXT.get(key);if(cached!=null)return cached;
        var next=Component.literal(value).withStyle(s->s.withFont(heading?HEADING:FONT));
        if(TEXT.size()>=512)TEXT.remove(TEXT.keySet().iterator().next());TEXT.put(key,next);return next;
    }
    /** Shared labels are read-only. Minecraft refreshes their visual order when language changes. */
    public static Component heading(String value) { return label(value,true); }
    private static float opacity=1;
    public static float pushOpacity(float value) {float old=opacity;opacity*=Math.clamp(value,0,1);return old;}
    public static void restoreOpacity(float value) {opacity=value;}
    public static int tint(int color) {return alpha(color,opacity);}
    private Ui() {}

    public static Component text(String value) { return label(value,false); }

    public static int alpha(int color, float alpha) {
        return (Math.round((color >>> 24) * Math.clamp(alpha, 0f, 1f)) << 24) | (color & 0xFFFFFF);
    }

    public static int blend(int a, int b, float t) {
        int result = 0;
        for (int shift = 0; shift <= 24; shift += 8) {
            int av = (a >>> shift) & 255, bv = (b >>> shift) & 255;
            result |= Math.round(av + (bv - av) * t) << shift;
        }
        return result;
    }

    public static int inset(int row, int height, int radius) {
        double distance = radius - Math.min(row + .5, height - row - .5);
        return distance <= 0 ? 0 : Math.max(0, (int) Math.ceil(radius - Math.sqrt(radius * radius - distance * distance)));
    }

    private static final Identifier[] ROUND=new Identifier[21];
    static {for(int r=1;r<ROUND.length;r++)ROUND[r]=Identifier.fromNamespaceAndPath(AstraClient.MOD_ID,"widget/round/radius_"+r);}
    public static void round(GuiGraphics g,int x,int y,int w,int h,int radius,int color) {
        color=tint(color);
        if(w<=0 || h<=0 || (color>>>24)==0)return;
        int r=Math.clamp(radius,0,Math.min(w,h)/2);
        if(r==0) {g.fill(x,y,x+w,y+h,color);return;}
        // All client radii fit the fixed atlas. Clamp unusual external callers.
        r=Math.min(r,20);
        g.blitSprite(net.minecraft.client.renderer.RenderPipelines.GUI_TEXTURED,ROUND[r],x,y,w,h,color);
    }

    public static void gradient(GuiGraphics g, int x, int y, int w, int h, int radius, int top, int bottom) {
        if(PerformanceMode.enabled()){round(g,x,y,w,h,radius,blend(top,bottom,.5f));return;}
        top=tint(top);bottom=tint(bottom);
        if (w <= 0 || h <= 0 || ((top|bottom)>>>24)==0) return;
        g.guiRenderState.submitGuiElement(RoundedGradient.create(g.pose(),x,y,w,h,radius,top,bottom,g.scissorStack.peek()));
    }

    public static void control(GuiGraphics g, int x, int y, int w, int h, boolean highlighted, boolean disabled, float opacity) {
        int r = Math.min(10, h / 2);
        var palette=AstraConfig.colour();
        int accent = palette.accent;
        round(g,x,y+2,w,h,r,alpha(palette.background,opacity*.9f));
        round(g, x, y, w, h, r, alpha(disabled ? alpha(palette.border,.4f) : highlighted ? accent : palette.border, opacity));
        gradient(g, x + 2, y + 2, w - 4, h - 4, r - 2,
            alpha(disabled ? alpha(palette.panelTop,.8f) : highlighted ? palette.activeTop : palette.panelTop, opacity),
            alpha(disabled ? alpha(palette.panelBottom,.8f) : highlighted ? palette.activeBottom : palette.panelBottom, opacity));
    }

    public static void animated(GuiGraphics g, Font font, net.minecraft.network.chat.Component label, float x, float y, int color) {
        color=tint(ClientColour.readableText(color));
        // Stable typography: motion is reserved for brief interactions, not drifting glyphs.
        g.pose().pushMatrix();g.pose().translate(Math.round(x*2)/2f,Math.round(y*2)/2f);
        if(!PerformanceMode.enabled()){g.pose().pushMatrix();g.pose().translate(.5f,.75f);
        g.drawString(font,label,0,0,alpha(0xFF070A18,(color>>>24)/255f*.8f),false);g.pose().popMatrix();}
        g.drawString(font,label,0,0,color,false);g.pose().popMatrix();
    }
    public static void animated(GuiGraphics g, Font font, String label, float x, float y, int color) { animated(g,font,text(label),x,y,color); }

    public static void texture(net.minecraft.client.gui.GuiGraphics g,Identifier texture,int x,int y,int w,int h,
            float u0,float u1,float v0,float v1,int tw,int th) {
        if(w<=0 || h<=0)return;
        g.blit(net.minecraft.client.renderer.RenderPipelines.GUI_TEXTURED,texture,x,y,u0*tw,v0*th,w,h,
            Math.max(1,Math.round((u1-u0)*tw)),Math.max(1,Math.round((v1-v0)*th)),tw,th,tint(0xFFFFFFFF));
    }

    public static void centered(GuiGraphics g, Font font, String text, int center, int y, float scale, int color) {
        var label = heading(text);
        g.pose().pushMatrix();
        g.pose().translate(center, y);
        g.pose().scale(scale, scale);
        animated(g,font,label,-font.width(label)/2f,0,color);
        g.pose().popMatrix();
    }
}
