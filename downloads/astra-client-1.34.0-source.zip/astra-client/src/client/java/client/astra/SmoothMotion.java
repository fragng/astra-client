package client.astra;

/** Elapsed-time damping without slowing down a transition after a dropped frame. */
public final class SmoothMotion {
    private SmoothMotion(){}
    public static double approach(double current,double target,double seconds,double speed,boolean animate){
        if(!animate)return target;
        double next=current+(target-current)*(-Math.expm1(-Math.clamp(seconds,0,1)*speed));
        return Math.abs(next-target)<.0001?target:next;
    }
}
