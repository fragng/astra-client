package client.astra;

import net.minecraft.client.Minecraft;
import net.minecraft.client.gui.GuiGraphics;
import net.minecraft.client.gui.components.AbstractSliderButton;
import net.minecraft.network.chat.Component;
import java.util.function.*;

public final class MenuSlider extends AbstractSliderButton {
    private final DoubleSupplier read;
    private final DoubleConsumer write;
    private final Function<Double,String> format;
    private double shown;
    private String formatted="";
    private net.minecraft.network.chat.Component prefix,suffix;
    private final double step;
    private long last=System.nanoTime();
    public MenuSlider(int x,int y,int w,DoubleSupplier read,DoubleConsumer write,Function<Double,String> format) {
        this(x,y,w,read,write,format,.01);
    }
    public MenuSlider(int x,int y,int w,DoubleSupplier read,DoubleConsumer write,Function<Double,String> format,double step) {
        super(x,y,w,47,Component.empty(),read.getAsDouble());
        this.step=step;
        this.read=read;this.write=write;this.format=format;shown=value;updateMessage();
    }
    @Override protected void updateMessage() {
        if(format==null)return;String label=format.apply(value);if(label.equals(formatted))return;
        formatted=label;setMessage(Ui.text(label));int split=label.lastIndexOf(':');
        prefix=split<0?null:Ui.text(label.substring(0,split+1)+" ");suffix=split<0?null:Ui.heading(label.substring(split+1).trim());
    }
    @Override protected void applyValue() { if(write!=null) write.accept(Math.clamp(value,0,1));updateMessage(); }
    @Override public boolean keyPressed(net.minecraft.client.input.KeyEvent key) {
        if (isFocused()) {
            int k=key.key();
            if(k==org.lwjgl.glfw.GLFW.GLFW_KEY_LEFT || k==org.lwjgl.glfw.GLFW.GLFW_KEY_RIGHT
                    || k==org.lwjgl.glfw.GLFW.GLFW_KEY_HOME || k==org.lwjgl.glfw.GLFW.GLFW_KEY_END) {
                value=k==org.lwjgl.glfw.GLFW.GLFW_KEY_HOME?0:k==org.lwjgl.glfw.GLFW.GLFW_KEY_END?1:
                    Math.clamp(read.getAsDouble()+(k==org.lwjgl.glfw.GLFW.GLFW_KEY_LEFT?-step:step),0,1);
                applyValue();return true;
            }
        }
        return super.keyPressed(key);
    }
    @Override public void renderWidget(GuiGraphics g,int mx,int my,float delta) {
        double next=Math.clamp(read.getAsDouble(),0,1);if(Double.compare(value,next)!=0){value=next;updateMessage();}
        long now=System.nanoTime();double dt=(now-last)/1e9;last=now;
        shown=SmoothMotion.approach(shown,value,dt,22,AstraConfig.animations);
        var palette=AstraConfig.colour();
        int x=getX(),y=getY(),w=getWidth();
        Ui.round(g,x,y,w,getHeight(),8,Ui.alpha(palette.panelTop,.65f));
        var font=Minecraft.getInstance().font;
        if(prefix!=null) {
            Ui.animated(g,font,prefix,x+10,y+8,0xFFE9E4F7);
            Ui.animated(g,font,suffix,x+10+font.width(prefix),y+7,0xFFF2DFFF);
        } else Ui.animated(g,font,getMessage(),x+10,y+8,0xFFE9E4F7);
        int tx=x+4,ty=y+32,tw=w-8;
        Ui.round(g,tx-1,ty-1,tw+2,9,4,palette.background);
        Ui.round(g,tx,ty,tw,7,3,palette.border);
        Ui.round(g,tx+2,ty+2,tw-4,3,1,palette.panelBottom);
        float knobPosition=(float)(shown*tw);int knob=tx+(int)knobPosition;
        Ui.round(g,tx+1,ty+1,Math.max(2,knob-tx),5,2,palette.accent);
        if(knob>tx+4) g.fill(tx+3,ty+2,knob,ty+3,Ui.tint(palette.accent));
        g.pose().pushMatrix();g.pose().translate(knobPosition-(int)knobPosition,0);
        Ui.round(g,knob-8,ty-5,16,16,8,palette.background);
        Ui.round(g,knob-7,ty-5,14,14,7,isHoveredOrFocused()?0xFFFFFFFF:palette.accent);
        Ui.round(g,knob-5,ty-3,10,10,5,palette.activeTop);
        Ui.round(g,knob-3,ty-2,4,3,1,0xFFFFFFFF);
        g.pose().popMatrix();

    }
}
