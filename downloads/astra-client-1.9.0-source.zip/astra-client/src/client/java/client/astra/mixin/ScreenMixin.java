package client.astra.mixin;

import client.astra.*;
import net.minecraft.client.gui.GuiGraphics;
import net.minecraft.client.gui.screens.Screen;
import net.minecraft.client.gui.screens.TitleScreen;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;

@Mixin(Screen.class)
public abstract class ScreenMixin {
    @Inject(method = "renderPanorama", at = @At("HEAD"), cancellable = true)
    private void astra$background(GuiGraphics graphics, float delta, CallbackInfo ci) {
        if ((Object) this instanceof TitleScreen && AstraConfig.theme() != Theme.NORMAL) {
            Backgrounds.draw(graphics, graphics.guiWidth(), graphics.guiHeight());
            ci.cancel();
        }
    }
    @Inject(method="renderPanorama",at=@At("RETURN"))
    private void astra$normalReactive(GuiGraphics graphics,float delta,CallbackInfo ci) {
        if((Object)this instanceof TitleScreen && AstraConfig.theme()==Theme.NORMAL)ReactiveBackdrop.draw(graphics,graphics.guiWidth(),graphics.guiHeight());
    }
}
