package client.astra;

import net.minecraft.client.gui.GuiGraphics;
import net.minecraft.client.renderer.RenderPipelines;
import net.minecraft.resources.Identifier;

/** A fixed-size scene. Every object uses a cached atlas sprite. */
public final class ReactiveBackdrop {
    private static final Identifier VIOLET=id("planet_violet"),ICE=id("planet_ice"),ROCKET=id("rocket"),METEOR=id("meteor"),SHOOTING=id("shooting_star"),STAR=id("star");
    private ReactiveBackdrop() {}
    private static Identifier id(String name) {return Identifier.fromNamespaceAndPath(AstraClient.MOD_ID,"space/"+name);}
    private static float cycle(double value) {return (float)(value-Math.floor(value));}
    private static float edge(float progress) {return Math.min(1,Math.min(progress*8,(1-progress)*8));}
    private static void sprite(GuiGraphics g,Identifier id,float x,float y,int w,int h,float angle,float opacity) {
        g.pose().pushMatrix();g.pose().translate(x,y);g.pose().rotate(angle);
        g.blitSprite(RenderPipelines.GUI_TEXTURED,id,-w/2,-h/2,w,h,Ui.tint(Ui.alpha(0xFFFFFFFF,opacity)));
        g.pose().popMatrix();
    }
    public static void draw(GuiGraphics g,int w,int h) {
        if(!AstraConfig.reactiveBackground)return;
        double time=AstraConfig.animations?System.nanoTime()/1e9:0;
        float size=Math.clamp(w/640f,.6f,1.3f);
        g.enableScissor(3,3,w-3,h-3);
        for(int i=0;i<12;i++) {
            float x=18+(i*137%601)/640f*(w-36),y=16+(i*79%347)/400f*(h-32);
            float a=.16f+(float)(Math.sin(time*.32+i)*.5+.5)*.16f;
            sprite(g,STAR,x,y,5,5,0,a);
        }
        float p=cycle(time/150+.16);
        sprite(g,VIOLET,-55+p*(w+110),h*(.22f+(float)Math.sin(time*.025)*.04f),(int)(58*size),(int)(46*size),.15f,.48f*edge(p));
        p=cycle(time/205+.61);
        sprite(g,ICE,w+45-p*(w+90),h*(.76f+(float)Math.sin(time*.02)*.035f),(int)(44*size),(int)(35*size),-.15f,.40f*edge(p));
        p=cycle(time/48+.36);
        sprite(g,ROCKET,-35+p*(w+70),h*(.87f-p*.7f),(int)(17*size),(int)(27*size),.95f,.58f*edge(p));
        streak(g,METEOR,w,h,cycle(time/11+.04),.23f,true,size);
        streak(g,METEOR,w,h,cycle(time/17+.37),.14f,true,size*.7f);
        streak(g,SHOOTING,w,h,cycle(time/8+.03),.19f,false,size);
        streak(g,SHOOTING,w,h,cycle(time/13+.58),.14f,false,size*.7f);
        g.disableScissor();
    }
    private static void streak(GuiGraphics g,Identifier sprite,int w,int h,float phase,float active,boolean meteor,float size) {
        if(phase>=active)return;
        float p=phase/active,dx=meteor?-(w+80):w+80,dy=h*(meteor?.58f:.30f);
        float x=(meteor?w+40:-40)+p*dx,y=h*(meteor?.03f:.10f)+p*dy;
        float a=(float)Math.sin(p*Math.PI)*(meteor?.64f:.58f);
        sprite(g,sprite,x,y,(int)((meteor?47:82)*size),(int)((meteor?17:16)*size),(float)Math.atan2(dy,dx),a);
    }
}
