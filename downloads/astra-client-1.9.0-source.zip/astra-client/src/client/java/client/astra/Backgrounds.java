package client.astra;

import net.minecraft.client.Minecraft;
import net.minecraft.client.gui.GuiGraphics;

public final class Backgrounds {
    private Backgrounds() {}

    public static void draw(GuiGraphics g, int width, int height) {
        var texture = AstraConfig.theme().texture;
        var gpu = Minecraft.getInstance().getTextureManager().getTexture(texture).getTexture();
        float sourceAspect = gpu.getWidth(0) / (float) gpu.getHeight(0);
        float targetAspect = width / (float) height;
        float zoom=AstraConfig.reactiveBackground?.94f:1;
        float uSpan = Math.min(1f, targetAspect / sourceAspect)*zoom;
        float vSpan = Math.min(1f, sourceAspect / targetAspect)*zoom;
        double time=AstraConfig.reactiveBackground && AstraConfig.animations?System.nanoTime()/1e9:0;
        float u=(1-uSpan)*(.5f+(float)Math.sin(time*.045)*.35f),v=(1-vSpan)*(.5f+(float)Math.cos(time*.035)*.35f);
        g.blit(texture,0,0,width,height,u,u+uSpan,v,v+vSpan);
        g.nextStratum();
        ReactiveBackdrop.draw(g,width,height);
        g.nextStratum();
        g.fill(0, 0, width, height, 0x38040815);
    }
}
