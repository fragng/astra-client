package client.astra;

import com.google.gson.*;
import net.fabricmc.loader.api.FabricLoader;
import net.minecraft.client.Minecraft;
import java.nio.file.*;
import java.nio.charset.StandardCharsets;
import java.security.PublicKey;
import java.time.*;
import java.time.format.DateTimeFormatter;

/** Offline account-bound grants. No local first-launch activation or shared service. */
public final class PremiumEdition {
    private static final Path CLOCK=FabricLoader.getInstance().getConfigDir().resolve("astra-premium-clock.json");
    private static boolean edition;
    private static PremiumLicense.Grant grant;
    private static PremiumLicense.Status failure=PremiumLicense.Status.UNLICENSED;
    private static PublicKey trusted;
    private static java.util.UUID cachedAccount;
    private static String cachedFingerprint="";
    private static long baseTime,baseNanos,nextSave;
    private PremiumEdition(){}
    public static PublicKey trustedKey()throws java.security.GeneralSecurityException,java.io.IOException{
        if(trusted==null)try(var in=PremiumEdition.class.getResourceAsStream("/astra-premium-public.der")){
            if(in==null)throw new java.io.IOException("Missing Premium verification key.");trusted=PremiumLicense.publicKey(in.readNBytes(4096));
        }return trusted;
    }
    public static void initialize(){
        baseTime=System.currentTimeMillis();baseNanos=System.nanoTime();grant=null;edition=false;failure=PremiumLicense.Status.UNLICENSED;
        try(var in=PremiumEdition.class.getResourceAsStream("/astra-edition.json")){
            edition=in!=null && JsonParser.parseReader(new java.io.InputStreamReader(in,StandardCharsets.UTF_8)).getAsJsonObject().get("premium").getAsBoolean();
        }catch(Exception ignored){}
        if(!edition)return;
        try(var in=PremiumEdition.class.getResourceAsStream("/"+PremiumJar.LICENSE)){
            if(in==null)return;var data=in.readNBytes(16385);if(data.length>16384)throw new IllegalArgumentException("Oversized grant");
            var result=PremiumLicense.verify(new String(data,StandardCharsets.UTF_8),trustedKey(),account(),baseTime);grant=result.grant();failure=result.status();
            if(grant!=null && Files.isRegularFile(CLOCK))try{
                var j=JsonParser.parseString(Files.readString(CLOCK)).getAsJsonObject();
                if(grant.serial().toString().equals(j.get("license").getAsString()))baseTime=Math.max(baseTime,j.get("lastSeenAt").getAsLong());
            }catch(Exception ignored){}
        }catch(Exception e){failure=PremiumLicense.Status.INVALID;grant=null;}
        flush();
    }
    private static java.util.UUID account(){var mc=Minecraft.getInstance();return mc==null || mc.getUser()==null?null:mc.getUser().getProfileId();}
    private static String accountFingerprint(){
        var id=account();if(!java.util.Objects.equals(id,cachedAccount)){cachedAccount=id;cachedFingerprint=PremiumLicense.fingerprint(id);}return cachedFingerprint;
    }
    private static long now(){return Math.max(System.currentTimeMillis(),baseTime+Math.max(0,(System.nanoTime()-baseNanos)/1_000_000));}
    public static boolean edition(){return edition;}
    public static PremiumLicense.Status status(){
        if(!edition || grant==null)return failure;
        if(!grant.accountHash().equals(accountFingerprint()))return PremiumLicense.Status.WRONG_ACCOUNT;
        long n=now();return n<grant.issuedAt()-300_000?PremiumLicense.Status.NOT_YET_VALID:n<grant.expiresAt()?PremiumLicense.Status.ACTIVE:PremiumLicense.Status.EXPIRED;
    }
    public static boolean premium(){return status()==PremiumLicense.Status.ACTIVE;}
    public static long remaining(){return premium()?Math.max(0,(grant.expiresAt()-now())/1000):0;}
    public static String timeLeft(){long n=remaining();return n/86400+"d "+n/3600%24+"h "+n/60%60+"m "+n%60+"s";}
    public static String expiry(){return grant==null?"Not active":Instant.ofEpochMilli(grant.expiresAt()).atZone(ZoneId.systemDefault()).format(DateTimeFormatter.ofPattern("dd MMM yyyy HH:mm z"));}
    public static String description(){return switch(status()){
        case ACTIVE->"Premium / licensed to "+grant.name()+".";
        case WRONG_ACCOUNT->"This Premium file belongs to another Minecraft account.";
        case EXPIRED->"This account's 30-day Premium file has expired.";
        case INVALID->"Invalid Premium license. Member mode is active.";
        case NOT_YET_VALID->"Check your system date. Premium is not active yet.";
        default->edition?"An owner-issued Premium file is required.":"Astra Client / Member edition";
    };}
    public static void tick(){if(grant!=null && grant.accountHash().equals(accountFingerprint()) && System.nanoTime()>nextSave)flush();}
    public static void flush(){
        if(grant==null || !grant.accountHash().equals(accountFingerprint()))return;
        try{
            var j=new JsonObject();j.addProperty("license",grant.serial().toString());j.addProperty("lastSeenAt",now());Files.createDirectories(CLOCK.getParent());
            var temp=CLOCK.resolveSibling("astra-premium-clock.json.tmp");Files.writeString(temp,new Gson().toJson(j));
            try{Files.move(temp,CLOCK,StandardCopyOption.REPLACE_EXISTING,StandardCopyOption.ATOMIC_MOVE);}catch(AtomicMoveNotSupportedException e){Files.move(temp,CLOCK,StandardCopyOption.REPLACE_EXISTING);}
        }catch(Exception e){org.slf4j.LoggerFactory.getLogger("Astra Client").warn("Could not save Premium clock checkpoint.");}
        nextSave=System.nanoTime()+60_000_000_000L;
    }
}
