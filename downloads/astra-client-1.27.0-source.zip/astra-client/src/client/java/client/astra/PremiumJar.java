package client.astra;

import com.google.gson.*;
import java.io.*;
import java.nio.charset.StandardCharsets;
import java.nio.file.*;
import java.util.jar.*;

/** Copies the installed mod with a signed public grant, never with its issuing key. */
public final class PremiumJar {
    public static final String LICENSE="astra-premium-license.json";
    private PremiumJar(){}
    public static void write(Path installed,Path output,String grant)throws IOException{
        if(!Files.isRegularFile(installed))throw new IOException("Install the release JAR before issuing Premium files.");
        Files.createDirectories(output.toAbsolutePath().getParent());
        Path temp=Files.createTempFile(output.toAbsolutePath().getParent(),".astra-premium-",".tmp");
        try(var source=new JarFile(installed.toFile());var target=new JarOutputStream(Files.newOutputStream(temp))){
            var metadata=source.getJarEntry("fabric.mod.json");if(metadata==null)throw new IOException("Not an Astra release JAR.");
            JsonObject mod;
            try(var in=source.getInputStream(metadata)){mod=JsonParser.parseReader(new InputStreamReader(in,StandardCharsets.UTF_8)).getAsJsonObject();}
            if(!mod.get("id").getAsString().equals("astra-client"))throw new IOException("Not an Astra release JAR.");
            String version=mod.get("version").getAsString();if(!version.endsWith("-premium"))mod.addProperty("version",version+"-premium");
            var entries=source.entries();
            while(entries.hasMoreElements()){
                var entry=entries.nextElement();String name=entry.getName(),upper=name.toUpperCase(java.util.Locale.ROOT);
                if(name.equals(LICENSE)||name.equals("astra-edition.json")||name.equals("fabric.mod.json")||upper.equals("META-INF/INDEX.LIST")||upper.matches("META-INF/[^/]+\\.(SF|RSA|DSA|EC)"))continue;
                target.putNextEntry(new JarEntry(name));if(!entry.isDirectory())try(var in=source.getInputStream(entry)){in.transferTo(target);}target.closeEntry();
            }
            put(target,"fabric.mod.json",new GsonBuilder().setPrettyPrinting().create().toJson(mod));
            put(target,"astra-edition.json","{\"premium\":true,\"days\":30,\"accountBound\":true}");put(target,LICENSE,grant);
        }catch(Exception e){Files.deleteIfExists(temp);if(e instanceof IOException io)throw io;throw new IOException("Could not create Premium file.",e);}
        try{Files.move(temp,output);}finally{Files.deleteIfExists(temp);}
    }
    private static void put(JarOutputStream target,String name,String text)throws IOException{target.putNextEntry(new JarEntry(name));target.write(text.getBytes(StandardCharsets.UTF_8));target.closeEntry();}
}
