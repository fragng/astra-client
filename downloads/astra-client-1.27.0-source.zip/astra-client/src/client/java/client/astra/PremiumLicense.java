package client.astra;

import com.google.gson.*;
import java.nio.charset.StandardCharsets;
import java.security.*;
import java.security.spec.*;
import java.time.Duration;
import java.util.*;

/** Signed grants bind an issued file to one launcher account, with a fixed expiry. */
public final class PremiumLicense {
    public static final long PERIOD=Duration.ofDays(30).toMillis();
    public static final UUID OWNER=UUID.fromString("675e4188-9b81-4829-ae87-cc1c114392d1");
    public record Grant(UUID account,String name,UUID serial,long issuedAt,long expiresAt) {}
    public enum Status {ACTIVE,UNLICENSED,WRONG_ACCOUNT,EXPIRED,NOT_YET_VALID,INVALID}
    public record Result(Status status,Grant grant) {}
    private PremiumLicense(){}
    public static boolean owner(UUID account){return OWNER.equals(account);}
    public static boolean username(String value){return value!=null && value.matches("[A-Za-z0-9_]{3,16}");}
    public static PublicKey publicKey(byte[] der)throws GeneralSecurityException{return KeyFactory.getInstance("Ed25519").generatePublic(new X509EncodedKeySpec(der));}
    public static PrivateKey privateKey(byte[] der)throws GeneralSecurityException{return KeyFactory.getInstance("Ed25519").generatePrivate(new PKCS8EncodedKeySpec(der));}
    private static byte[] canonical(Grant g){
        if(g.account()==null || g.serial()==null || !username(g.name()) || g.issuedAt()<=0 || g.issuedAt()>Long.MAX_VALUE-PERIOD || g.expiresAt()!=g.issuedAt()+PERIOD)throw new IllegalArgumentException("Invalid grant");
        return ("astra-premium-v1\n"+g.account()+"\n"+g.name()+"\n"+g.serial()+"\n"+g.issuedAt()+"\n"+g.expiresAt()+"\n").getBytes(StandardCharsets.UTF_8);
    }
    public static String issue(Grant g,PrivateKey key)throws GeneralSecurityException{
        var signer=Signature.getInstance("Ed25519");signer.initSign(key);signer.update(canonical(g));
        var j=new JsonObject();j.addProperty("schema",1);j.addProperty("account",g.account().toString());j.addProperty("name",g.name());j.addProperty("serial",g.serial().toString());j.addProperty("issuedAt",g.issuedAt());j.addProperty("expiresAt",g.expiresAt());j.addProperty("signature",Base64.getEncoder().encodeToString(signer.sign()));return new Gson().toJson(j);
    }
    public static Result verify(String text,PublicKey trusted,UUID account,long now){
        if(text==null)return new Result(Status.UNLICENSED,null);
        try{
            if(text.length()>16384 || trusted==null)throw new IllegalArgumentException("License size/key");
            var j=JsonParser.parseString(text).getAsJsonObject();if(j.get("schema").getAsInt()!=1)throw new IllegalArgumentException("License schema");
            var g=new Grant(UUID.fromString(j.get("account").getAsString()),j.get("name").getAsString(),UUID.fromString(j.get("serial").getAsString()),j.get("issuedAt").getAsLong(),j.get("expiresAt").getAsLong());
            var verifier=Signature.getInstance("Ed25519");verifier.initVerify(trusted);verifier.update(canonical(g));
            if(!verifier.verify(Base64.getDecoder().decode(j.get("signature").getAsString())))return new Result(Status.INVALID,null);
            if(!g.account().equals(account))return new Result(Status.WRONG_ACCOUNT,g);
            if(now<g.issuedAt()-300_000)return new Result(Status.NOT_YET_VALID,g);
            return new Result(now<g.expiresAt()?Status.ACTIVE:Status.EXPIRED,g);
        }catch(Exception e){return new Result(Status.INVALID,null);}
    }
}
