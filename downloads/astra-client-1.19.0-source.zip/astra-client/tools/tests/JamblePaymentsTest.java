package client.astra;

import java.util.UUID;

/** Behaviour contracts for currency, FIFO payouts and responsive non-overlap. */
public final class JamblePaymentsTest {
    private static void check(boolean value,String label){if(!value)throw new AssertionError(label);}
    private static void amount(String value,long cents){check(JambleMoney.parse(value)==cents,value);}
    private static void invalid(String value){try{JambleMoney.parse(value);throw new AssertionError("Accepted "+value);}catch(IllegalArgumentException expected){}}
    public static void main(String[] args){
        amount("1K",100_000);amount("2.5m",250_000_000L);amount("1B",100_000_000_000L);amount("$1,234.56",123456);amount("0.00001K",1);amount("12.34567M",1_234_567_000L);amount("0",0);
        for(String s:new String[]{"-1K","NaN","Infinity","1e9","1KK","1.2.3M","1,00","0.001","100000000000000000000B","1K extra","1\nK","","1_000"})invalid(s);
        check(JambleMoney.parse(JambleMoney.editable(JambleMoney.MAX_CENTS))==JambleMoney.MAX_CENTS,"large exact editable round trip");
        check(JambleMoney.exact(123456).equals("$1,234.56"),"exact display");check(JambleMoney.compact(250000000).equals("2.5M"),"compact display");
        var paid=JambleMoney.notice("JackJ25 paid you $2.5M.");check(paid!=null && paid.username().equals("JackJ25") && paid.cents()==250000000,"server notice");
        check(JambleMoney.notice("§aJackJ25 §fpaid you §a1K")!=null,"legacy formatting");
        for(String s:new String[]{"<Fake> JackJ25 paid you 1M","Fake: JackJ25 paid you 1M","You paid JackJ25 1M","JackJ25 paid you -1K","JackJ25 paid you 0","JackJ25 paid you 1e9","JackJ25 paid you 1M then 2M","JackJ25\npaid you 1M"})check(JambleMoney.notice(s)==null,"reject "+s);
        check(JambleMoney.donutHost("DonutSMP.net") && JambleMoney.donutHost("play.donutsmp.net."),"Donut host");
        for(String s:new String[]{"donutsmp.net.evil.com","evildonutsmp.net","127.0.0.1","example.com","donutsmp.net:25565"})check(!JambleMoney.donutHost(s),"reject host "+s);
        var ledger=new JamblePaymentLedger();long min=100000,max=100000000000L;
        check(ledger.receive(new JambleMoney.Payment("Below",min-1),min,max)==null,"minimum");check(ledger.receive(new JambleMoney.Payment("Above",max+1),min,max)==null,"maximum");
        var first=ledger.receive(new JambleMoney.Payment("First",min),min,max);var second=ledger.receive(new JambleMoney.Payment("Second",max),min,max);
        check(ledger.confirm(first.id())==null,"no win before roll");check(ledger.resolve(1,JambleRules.Side.HOST)==first,"FIFO host");check(ledger.confirm(first.id())==null,"no payout for host winner");
        check(ledger.resolve(1,JambleRules.Side.VIEWER)==null,"no duplicate round");check(ledger.resolve(2,JambleRules.Side.VIEWER)==second,"FIFO viewer");
        var payout=ledger.confirm(second.id());check(payout!=null && payout.username().equals("Second") && payout.cents()==max*2,"exact 2x");
        check(ledger.confirm(second.id())==null && ledger.confirm(UUID.randomUUID())==null,"duplicate/stale clicks");
        var repeat1=ledger.receive(new JambleMoney.Payment("Repeat",min),min,max);var repeat2=ledger.receive(new JambleMoney.Payment("Repeat",min),min,max);
        check(!repeat1.id().equals(repeat2.id()),"identical legitimate payments stay distinct");ledger.resolve(3,JambleRules.Side.VIEWER);ledger.resolve(4,JambleRules.Side.VIEWER);
        check(ledger.confirm(repeat2.id())!=null && ledger.confirm(repeat1.id())!=null,"multiple unconfirmed winners independent");
        ledger.clear();check(ledger.payout()==null && ledger.pending()==0 && ledger.confirm(second.id())==null,"session clear");
        for(int i=0;i<JamblePaymentLedger.MAX_ENTRIES;i++)check(ledger.receive(new JambleMoney.Payment("Queue",min),min,max)!=null,"queue insert");
        check(ledger.receive(new JambleMoney.Payment("Overflow",min),min,max)==null,"bounded pending queue");ledger.resolve(1,JambleRules.Side.HOST);check(ledger.receive(new JambleMoney.Payment("Next",min),min,max)!=null,"resolved entry evicted first");
        ledger.clear();var largest=ledger.receive(new JambleMoney.Payment("Largest",JambleMoney.MAX_CENTS),0,JambleMoney.MAX_CENTS);ledger.resolve(1,JambleRules.Side.VIEWER);check(ledger.confirm(largest.id()).cents()==JambleMoney.MAX_CENTS*2,"no overflow");
        int count=0;
        for(int w:new int[]{320,360,426,480,640,854,960,1280,1920})for(int h:new int[]{240,270,300,360,480,540,720,1080})for(boolean music:new boolean[]{false,true})for(boolean lyrics:new boolean[]{false,true})for(double scale:new double[]{.5,.7,1}){
            var b=JambleLayout.compute(w,h,true,music,lyrics,scale);
            check(b.cardX()>=12 && b.cardX()+b.cardWidth()<=w-12,"compact card bounds");
            if(music)check(b.cardY()>=12+Math.ceil((lyrics?130:70)*b.musicScale())+5,"card below lyrics");
            check(b.cardY()+b.cardHeight()+7<=b.toastY(),"card/result never blocked by payout toast");
            check(b.toastY()+b.toastHeight()<=h-50,"toast above native HUD");
            var idle=JambleLayout.compute(w,h,false,music,lyrics,scale);
            check(Math.abs(idle.musicScale()-Math.min((float)scale,(w-16f)/320))<.00001,"no music scaling while idle");count++;
        }
        System.out.println("PASS exact K/M/B cents, notice/origin parsing, bounds, FIFO host/viewer association, 2x and duplicate/overflow/session handling; "+count+" responsive layouts");
    }
}
