package client.astra;

import net.minecraft.client.gui.GuiGraphics;
import net.minecraft.client.gui.screens.Screen;
import net.minecraft.client.input.KeyEvent;
import net.minecraft.client.input.MouseButtonEvent;
import net.minecraft.network.chat.Component;
import java.util.*;

/** Small, cursor-enabled native screen: stable payment identity and real confirm buttons. */
public final class JambleReviewScreen extends Screen {
    private static final int W=330,H=180;
    private UUID selected;
    private final Screen back;
    private List<JamblePaymentLedger.Entry> records=List.of();
    private long seen,last=System.nanoTime();
    private boolean recordedHere;
    private String amountLine="",statusLine="",counter="";
    private float scale,ox,oy,opening;
    public JambleReviewScreen(UUID id,Screen back){super(Component.literal("Jamble payment"));selected=id;this.back=back;}
    private void fit(){scale=Math.min(1,Math.min((width-24f)/W,(height-24f)/H));ox=(width-W*scale)/2;oy=(height-H*scale)/2+(1-opening)*4;}
    private JamblePaymentLedger.Entry selected(){return selected==null?null:JamblePayments.ledger().get(selected);}
    @Override protected void init(){
        fit();seen=JamblePayments.revision();records=JamblePayments.ledger().entries();
        if(selected==null){var first=JamblePayments.ledger().current();selected=first!=null?first.id():records.isEmpty()?null:records.getLast().id();}
        addRenderableWidget(new MenuButton(W-37,10,25,24,"X","",()->false,false,this::onClose));
        var entry=selected();if(entry==null)return;
        String label=switch(entry.status()){case WAITING->"Await roll";case VIEWER_WIN->"Mark won";case HOST_WIN->"Host won";case CONFIRMED->"Recorded";};
        addRenderableWidget(new MenuButton(W-108,46,88,26,label,"",()->entry.status()==JamblePaymentLedger.Status.CONFIRMED,false,()->{
            if(JamblePayments.confirm(entry.id().toString())!=null){recordedHere=true;rebuildWidgets();}
        }).available(()->entry.status()==JamblePaymentLedger.Status.VIEWER_WIN));
        int index=records.indexOf(entry);
        amountLine="Paid "+JambleMoney.exact(entry.cents())+" / 2x "+JambleMoney.exact(entry.payout());
        statusLine=switch(entry.status()){
            case WAITING->"Waiting for the next Host / Viewer roll.";
            case VIEWER_WIN->"Viewer won. Click Mark won to record the 2x payout.";
            case HOST_WIN->"Host won this round. No viewer payout.";
            case CONFIRMED->"Payout recorded. Pay through the server's normal controls.";
        };
        counter=(index+1)+" / "+records.size();
        addRenderableWidget(new MenuButton(20,144,76,24,"Previous","",()->false,false,()->select(-1)).available(()->index>0));
        addRenderableWidget(new MenuButton(W-96,144,76,24,"Next","",()->false,false,()->select(1)).available(()->index>=0 && index+1<records.size()));
    }
    private void select(int direction){int i=records.indexOf(selected());if(i>=0 && i+direction>=0 && i+direction<records.size()){selected=records.get(i+direction).id();rebuildWidgets();}}
    @Override public void tick(){if(!JamblePayments.enabled()){onClose();return;}if(seen!=JamblePayments.revision())rebuildWidgets();}
    private void text(GuiGraphics g,String value,int x,int y,int room,float preferred,int color){
        var label=Ui.text(value);float s=Math.min(preferred,room/(float)Math.max(1,font.width(label)));
        g.pose().pushMatrix();g.pose().translate(x,y);g.pose().scale(s,s);Ui.animated(g,font,label,0,0,color);g.pose().popMatrix();
    }
    @Override public void render(GuiGraphics g,int mx,int my,float delta){
        long now=System.nanoTime();float dt=Math.min(.1f,(now-last)/1e9f);last=now;opening=AstraConfig.animations?opening+(1-opening)*(1-(float)Math.exp(-dt*22)):1;fit();
        g.pose().pushMatrix();g.pose().translate(ox,oy);g.pose().scale(scale,scale);float opacity=Ui.pushOpacity(opening);
        Ui.round(g,-1,-1,W+2,H+2,14,0xBB89729F);Ui.round(g,0,0,W,H,13,0xFA171A27);
        text(g,"Jamble payment",20,17,250,1.1f,0xFFEAE0F5);
        var entry=selected();
        if(entry==null)text(g,"This payment is no longer available.",20,74,W-40,.9f,0xFFAFA6BD);
        else{
            text(g,entry.username(),20,51,W-140,1.1f,0xFFF1EAF8);
            text(g,amountLine,20,81,W-40,.78f,0xFFC1B4D0);
            var roll=JamblePayments.roll(entry.id());
            if(roll!=null)text(g,"Host "+roll.host().label()+"   /   Viewer "+roll.viewer().label(),20,102,W-40,.82f,0xFFCABCDD);
            text(g,statusLine,20,123,W-40,.69f,entry.status()==JamblePaymentLedger.Status.VIEWER_WIN?0xFF99D9D8:0xFFADA3B9);
            text(g,counter,W/2-font.width(Ui.text(counter))/2,151,100,.8f,0xFFB8AAC8);
        }
        super.render(g,(int)((mx-ox)/scale),(int)((my-oy)/scale),delta);Ui.restoreOpacity(opacity);g.pose().popMatrix();
    }
    @Override public void renderBackground(GuiGraphics g,int mx,int my,float delta){}
    private MouseButtonEvent local(MouseButtonEvent e){return new MouseButtonEvent((e.x()-ox)/scale,(e.y()-oy)/scale,e.buttonInfo());}
    @Override public boolean mouseClicked(MouseButtonEvent e,boolean twice){return super.mouseClicked(local(e),twice);}
    @Override public boolean mouseReleased(MouseButtonEvent e){return super.mouseReleased(local(e));}
    @Override public boolean mouseDragged(MouseButtonEvent e,double dx,double dy){return super.mouseDragged(local(e),dx/scale,dy/scale);}
    @Override public boolean keyPressed(KeyEvent e){if(JamblePayments.reviewKey(e)){onClose();return true;}return super.keyPressed(e);}
    @Override public void onClose(){JamblePayments.closedReview(recordedHere);minecraft.setScreen(back);}
    @Override public boolean isPauseScreen(){return false;}
}
