package client.astra;

import net.minecraft.client.Minecraft;
import net.minecraft.client.gui.screens.inventory.AnvilScreen;
import net.minecraft.core.component.DataComponents;
import net.minecraft.world.item.Item;
import net.minecraft.world.item.ItemStack;
import java.util.*;

/** Read-only hotbar acquisition tracker. It never moves or changes inventory items. */
public final class JambleHud {
    private static final long PAIR_TIME=2_000_000_000L,DISPLAY_TIME=8_000_000_000L;
    private record Key(Item item,JambleRules.Number number){}
    private record Entry(long count,ItemStack icon){}
    private record Snapshot(Map<Item,Long> physical,Map<Key,Long> named,Map<Key,Entry> hotbar){}
    private record Pending(Key key,ItemStack icon,long time){}
    public record Round(JambleRules.Number host,JambleRules.Number viewer,ItemStack hostIcon,ItemStack viewerIcon,JambleRules.Side winner,long started,long sequence){}
    private static Object player,level;
    private static Snapshot previous;
    private static Pending host,viewer;
    private static Round round;
    private static long readyAt,sequence;
    private static String status="Off";
    private JambleHud(){}
    public static Round round(){return round;}
    public static String status(){return status;}
    public static void reset(){player=null;level=null;previous=null;host=null;viewer=null;round=null;readyAt=0;status=AstraConfig.jambleEnabled?"Waiting for the hotbar to synchronise...":"Off";}
    private static void add(Snapshot s,ItemStack stack,boolean hotbar){
        if(stack.isEmpty())return;
        s.physical.merge(stack.getItem(),(long)stack.getCount(),Long::sum);
        var name=stack.get(DataComponents.CUSTOM_NAME);if(name==null)return;
        var number=JambleRules.parse(name.getString());if(number==null)return;
        var key=new Key(stack.getItem(),number);s.named.merge(key,(long)stack.getCount(),Long::sum);
        if(hotbar){var old=s.hotbar.get(key);s.hotbar.put(key,new Entry((old==null?0:old.count)+stack.getCount(),stack));}
    }
    private static Snapshot snapshot(Minecraft mc){
        var s=new Snapshot(new HashMap<>(),new HashMap<>(),new LinkedHashMap<>());
        var inventory=mc.player.getInventory();for(int i=0;i<inventory.getContainerSize();i++)add(s,inventory.getItem(i),i<9);
        // Cursor-held items are still owned; moving them back into the hotbar is not a pickup.
        add(s,mc.player.containerMenu.getCarried(),false);return s;
    }
    public static void tick(Minecraft mc){
        if(!PremiumEdition.premium()||!AstraConfig.jambleEnabled||mc.player==null||mc.level==null){if(previous!=null||round!=null||player!=null)reset();return;}
        long now=System.nanoTime();Snapshot current=snapshot(mc);
        if(player!=mc.player||level!=mc.level||previous==null){player=mc.player;level=mc.level;previous=current;host=null;viewer=null;round=null;readyAt=now+1_000_000_000L;status="Waiting for the hotbar to synchronise...";return;}
        if(now<readyAt || mc.screen instanceof AnvilScreen){previous=current;host=null;viewer=null;return;}
        if(host!=null&&(now-host.time>PAIR_TIME||!current.hotbar.containsKey(host.key)))host=null;
        if(viewer!=null&&(now-viewer.time>PAIR_TIME||!current.hotbar.containsKey(viewer.key)))viewer=null;
        Pending newHost=null,newViewer=null;boolean ambiguous=false;
        var gains=new HashMap<Item,Long>();current.physical.forEach((item,count)->gains.put(item,count-previous.physical.getOrDefault(item,0L)));
        for(var pair:current.hotbar.entrySet()) {
            Key key=pair.getKey();Entry entry=pair.getValue();Entry old=previous.hotbar.get(key);
            long hotGain=entry.count-(old==null?0:old.count),namedGain=current.named.getOrDefault(key,0L)-previous.named.getOrDefault(key,0L);
            long added=Math.min(Math.min(hotGain,namedGain),gains.getOrDefault(key.item,0L));
            if(added<=0)continue;
            gains.merge(key.item,-added,Long::sum);
            if(added!=1){ambiguous=true;continue;}
            var next=new Pending(key,entry.icon.copyWithCount(1),now);
            if(key.number.side()==JambleRules.Side.HOST){if(newHost!=null||host!=null)ambiguous=true;newHost=next;}
            else {if(newViewer!=null||viewer!=null)ambiguous=true;newViewer=next;}
        }
        previous=current;
        if(ambiguous){host=null;viewer=null;round=null;status="Receive exactly one Host and one Viewer item together.";return;}
        if(newHost!=null)host=newHost;if(newViewer!=null)viewer=newViewer;
        if(host!=null&&viewer!=null){
            var h=host;var v=viewer;host=null;viewer=null;
            round=new Round(h.key.number,v.key.number,h.icon,v.icon,JambleRules.winner(h.key.number,v.key.number),now,++sequence);
            JamblePayments.onRound(round);
            status=round.winner==JambleRules.Side.HOST?"Host Wins!":"Viewer Wins!";
        }else status=host!=null?"Host received. Waiting for Viewer...":viewer!=null?"Viewer received. Waiting for Host...":"Watching hotbar for a new pair.";
    }
    public static boolean visible(){return JamblePayments.hasCard();}
    public static int spotifyTop(int width){return 12;}
}
