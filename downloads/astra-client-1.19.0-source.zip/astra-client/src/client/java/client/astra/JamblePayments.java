package client.astra;

import com.mojang.brigadier.arguments.StringArgumentType;
import net.fabricmc.fabric.api.client.command.v2.ClientCommandManager;
import net.fabricmc.fabric.api.client.command.v2.ClientCommandRegistrationCallback;
import net.fabricmc.fabric.api.client.message.v1.ClientReceiveMessageEvents;
import net.minecraft.client.Minecraft;
import net.minecraft.client.KeyMapping;
import net.minecraft.client.gui.Font;
import net.minecraft.client.gui.GuiGraphics;
import net.minecraft.client.gui.screens.Screen;
import net.minecraft.client.gui.screens.ChatScreen;
import net.minecraft.client.multiplayer.resolver.ServerAddress;
import net.minecraft.network.chat.*;
import java.util.*;

/** Receipt-driven UI. Confirmation uses native screen buttons, never a locked game cursor. */
public final class JamblePayments {
    private static final JamblePaymentLedger LEDGER=new JamblePaymentLedger();
    private static final Map<UUID,JambleHud.Round> ROLLS=new HashMap<>();
    private static Object connection;
    private static KeyMapping reviewKey;
    private static long revision,outcomeUntil,toastUntil,lastFrame,reviewBlockedUntil;
    private static JamblePaymentLedger.Entry outcome,lastCard;
    private static float cardAlpha,toastAlpha;
    private JamblePayments(){}
    private static boolean authorized(){return PremiumEdition.premium() && AstraConfig.jambleEnabled;}
    public static boolean enabled(){var mc=Minecraft.getInstance();return authorized() && mc.player!=null && mc.level!=null;}
    public static void initialize(){
        reviewKey=net.fabricmc.fabric.api.client.keybinding.v1.KeyBindingHelper.registerKeyBinding(new KeyMapping("Review Jamble payments",org.lwjgl.glfw.GLFW.GLFW_KEY_J,KeyMapping.Category.MISC));
        ClientReceiveMessageEvents.MODIFY_GAME.register((message,overlay)->{
            if(overlay || !authorized())return message;
            var server=Minecraft.getInstance().getCurrentServer();
            return receive(message,server==null?"":ServerAddress.parseString(server.ip).getHost());
        });
        ClientCommandRegistrationCallback.EVENT.register((dispatcher,access)->{
            for(String action:new String[]{"review","win"})dispatcher.register(ClientCommandManager.literal("astrajamble").then(ClientCommandManager.literal(action)
                .then(ClientCommandManager.argument("payment",StringArgumentType.word()).executes(context->{
                    try{
                        UUID id=UUID.fromString(StringArgumentType.getString(context,"payment"));
                        if(sync() && LEDGER.get(id)!=null){openReview(id,null);return 1;}
                    }catch(IllegalArgumentException ignored){}
                    context.getSource().sendFeedback(Component.literal("That Jamble payment is no longer in this session."));return 0;
                }))));
        });
    }
    public static String reviewKeyName(){return reviewKey==null?"J":reviewKey.getTranslatedKeyMessage().getString();}
    public static boolean reviewKey(net.minecraft.client.input.KeyEvent event){return reviewKey!=null && reviewKey.matches(event);}
    public static void openReview(UUID id,Screen back){
        if(sync() && LEDGER.size()>0)Minecraft.getInstance().setScreen(new JambleReviewScreen(id,back));
    }
    private static boolean sync(){
        var next=Minecraft.getInstance().getConnection();
        if(!authorized() || next==null){if(connection!=null || LEDGER.size()>0)clear();return false;}
        if(connection!=next){clear();connection=next;}return true;
    }
    public static void tick(Minecraft client){
        sync();if(reviewKey!=null)while(reviewKey.consumeClick())if(client.screen==null && enabled() && LEDGER.size()>0 && System.nanoTime()>reviewBlockedUntil)openReview(null,null);
    }
    public static void clear(){
        connection=null;LEDGER.clear();ROLLS.clear();outcome=null;lastCard=null;outcomeUntil=0;toastUntil=0;cardAlpha=0;toastAlpha=0;revision++;
    }
    public static Component receive(Component message,String host){
        if(!sync() || !JambleMoney.donutHost(host))return message;
        var paid=JambleMoney.notice(message.getString());if(paid==null)return message;
        var entry=LEDGER.receive(paid,AstraConfig.jambleMinPay,AstraConfig.jambleMaxPay);
        if(entry==null){
            if(paid.cents()>=AstraConfig.jambleMinPay && paid.cents()<=AstraConfig.jambleMaxPay)return message.copy().append(Component.literal(" [Jamble queue full]"));
            return message;
        }
        ROLLS.keySet().removeIf(id->LEDGER.get(id)==null);revision++;
        return message.copy().append(Component.literal(" ")).append(reviewButton(entry));
    }
    private static Component reviewButton(JamblePaymentLedger.Entry entry){
        return Component.literal("[Review]").withStyle(style->style.withColor(0xBCA2F5).withUnderlined(true)
            .withClickEvent(new ClickEvent.RunCommand("/astrajamble review "+entry.id()))
            .withHoverEvent(new HoverEvent.ShowText(Component.literal("Open "+entry.username()+"'s payment. You can also press "+reviewKeyName()+". Viewer payout: "+JambleMoney.exact(entry.payout())+". Local record only."))));
    }
    public static void onRound(JambleHud.Round round){
        if(!sync())return;var entry=LEDGER.resolve(round.sequence(),round.winner());
        if(entry==null)return;
        ROLLS.put(entry.id(),round);outcome=entry;outcomeUntil=System.nanoTime()+3_500_000_000L;revision++;
    }
    public static JamblePaymentLedger.Payout confirm(String value){
        if(!sync())return null;
        try{
            var result=LEDGER.confirm(UUID.fromString(value));
            if(result!=null){toastUntil=System.nanoTime()+4_000_000_000L;revision++;}return result;
        }catch(IllegalArgumentException e){return null;}
    }
    public static void closedReview(boolean recorded){reviewBlockedUntil=System.nanoTime()+250_000_000L;if(recorded)remindPayout();}
    public static void remindPayout(){if(LEDGER.payout()!=null)toastUntil=System.nanoTime()+4_000_000_000L;}
    public static JamblePaymentLedger ledger(){return LEDGER;}
    public static long revision(){return revision;}
    public static JambleHud.Round roll(UUID id){return ROLLS.get(id);}
    private static JamblePaymentLedger.Entry card(){
        if(!enabled())return null;
        if(outcome!=null && outcome.status()!=JamblePaymentLedger.Status.CONFIRMED && System.nanoTime()<outcomeUntil)return outcome;
        return LEDGER.current();
    }
    public static boolean hasCard(){return enabled() && (card()!=null || lastCard!=null && cardAlpha>.01f);}
    public static boolean hasToast(){return enabled() && LEDGER.payout()!=null && System.nanoTime()<toastUntil;}
    public static JambleLayout layout(int width,int height){return JambleLayout.compute(width,height,hasCard(),AstraConfig.hudSpotify,AstraConfig.lyricsEnabled,AstraConfig.spotifyHudScale);}
    public static JambleLayout layout(int width){return layout(width,Minecraft.getInstance().getWindow().getGuiScaledHeight());}
    private static void text(GuiGraphics g,Font font,String value,int x,int y,int room,float maxScale,int color){
        var label=Ui.text(value);float scale=Math.min(maxScale,room/(float)Math.max(1,font.width(label)));
        g.pose().pushMatrix();g.pose().translate(x,y);g.pose().scale(scale,scale);Ui.animated(g,font,label,0,0,color);g.pose().popMatrix();
    }
    private static void item(GuiGraphics g,net.minecraft.world.item.ItemStack stack,int x,int y){
        g.pose().pushMatrix();g.pose().translate(x,y);g.pose().scale(.625f,.625f);g.renderFakeItem(stack,0,0);g.pose().popMatrix();
    }
    public static void draw(GuiGraphics g,Font font){
        var mc=Minecraft.getInstance();
        if(!enabled() || mc.options.hideGui || mc.getDebugOverlay().showDebugScreen() || mc.screen!=null && !(mc.screen instanceof ChatScreen)){lastFrame=0;return;}
        long now=System.nanoTime();float dt=lastFrame==0?.016f:Math.min(.1f,(now-lastFrame)/1e9f);lastFrame=now;
        var current=card();if(current!=null)lastCard=current;
        float ease=AstraConfig.animations?1-(float)Math.exp(-dt*18):1;
        cardAlpha+=( (current!=null?1:0)-cardAlpha)*ease;toastAlpha+=((hasToast()?1:0)-toastAlpha)*ease;
        var box=layout(g.guiWidth(),g.guiHeight());
        if(lastCard!=null && cardAlpha>.01f){
            float old=Ui.pushOpacity(cardAlpha);int x=box.cardX(),y=box.cardY()-Math.round((1-cardAlpha)*3),w=box.cardWidth();
            Ui.round(g,x,y,w,box.cardHeight(),9,0xA17A668F);Ui.round(g,x+1,y+1,w-2,box.cardHeight()-2,8,0xF0171925);
            text(g,font,lastCard.username()+"  "+lastCard.amount(),x+9,y+5,w-18,.85f,0xFFF1E9FC);
            var roll=ROLLS.get(lastCard.id());
            if(roll!=null){
                item(g,roll.hostIcon(),x+9,y+17);text(g,font,"H "+roll.host().label(),x+22,y+19,37,.65f,0xFFCDBBDE);
                item(g,roll.viewerIcon(),x+62,y+17);text(g,font,"V "+roll.viewer().label(),x+75,y+19,30,.65f,0xFFCDBBDE);
                text(g,font,roll.winner()==JambleRules.Side.VIEWER?"Viewer Wins!":"Host Wins!",x+116,y+19,w-124,.72f,roll.winner()==JambleRules.Side.VIEWER?0xFF94D9EB:0xFFE7C785);
            }else text(g,font,"Waiting for the roll",x+9,y+18,w-18,.72f,0xFFA8A1B7);
            text(g,font,reviewKeyName()+": review payments"+(LEDGER.pending()>1?"  +"+(LEDGER.pending()-1):""),x+9,y+32,w-18,.6f,0xFF9992AA);
            Ui.restoreOpacity(old);
        }
        if(LEDGER.payout()!=null && toastAlpha>.01f){
            float old=Ui.pushOpacity(toastAlpha);int x=box.toastX(),y=box.toastY(),w=box.toastWidth();
            Ui.round(g,x,y,w,box.toastHeight(),8,0xED1B2026);text(g,font,LEDGER.payout().label(),x+10,y+7,w-20,.8f,0xFFE3D3A7);Ui.restoreOpacity(old);
        }
    }
}
