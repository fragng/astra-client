$ErrorActionPreference = 'Stop'
[Console]::OutputEncoding = New-Object System.Text.UTF8Encoding($false)
Add-Type -AssemblyName System.Runtime.WindowsRuntime
Add-Type -TypeDefinition @'
using System;
using System.Threading.Tasks;
public static class AstraInput {
    public static Task<string> Next() { return Task.Factory.StartNew(() => Console.ReadLine(), System.Threading.CancellationToken.None, TaskCreationOptions.LongRunning, TaskScheduler.Default); }
}
'@
$managerType = [Windows.Media.Control.GlobalSystemMediaTransportControlsSessionManager, Windows.Media.Control, ContentType=WindowsRuntime]
$mediaType = [Windows.Media.Control.GlobalSystemMediaTransportControlsSessionMediaProperties, Windows.Media.Control, ContentType=WindowsRuntime]
$asTask = [System.WindowsRuntimeSystemExtensions].GetMethods() | Where-Object { $_.Name -eq 'AsTask' -and $_.IsGenericMethod -and $_.GetParameters().Count -eq 1 -and $_.GetParameters()[0].ParameterType.Name -eq 'IAsyncOperation`1' } | Select-Object -First 1
function Await($operation, [Type]$resultType) {
    $task = $asTask.MakeGenericMethod($resultType).Invoke($null, @($operation))
    if (-not $task.Wait(2500)) { throw 'Desktop media request timed out.' }
    return $task.Result
}
function Emit($data) { [Console]::WriteLine(($data | ConvertTo-Json -Compress -Depth 4)); [Console]::Out.Flush() }
# Artwork and timeline are local Windows media metadata; no Spotify API login.
$streamType = [Windows.Storage.Streams.IRandomAccessStreamWithContentType, Windows.Storage.Streams, ContentType=WindowsRuntime]
$readerType = [Windows.Storage.Streams.DataReader, Windows.Storage.Streams, ContentType=WindowsRuntime]
function Artwork($thumbnail) {
    if ($null -eq $thumbnail) { return '' }
    $stream = $null; $reader = $null
    try {
        $stream = Await ($thumbnail.OpenReadAsync()) $streamType
        if ($stream.Size -le 0 -or $stream.Size -gt 524288) { return '' }
        $reader = [Windows.Storage.Streams.DataReader]::new($stream)
        $count = Await ($reader.LoadAsync([uint32]$stream.Size)) ([uint32])
        $bytes = New-Object byte[] $count
        $reader.ReadBytes($bytes)
        return [Convert]::ToBase64String($bytes)
    } catch { return '' }
    finally {
        if ($null -ne $reader) { try { $reader.Dispose() } catch { } }
        if ($null -ne $stream) { try { $stream.Dispose() } catch { } }
    }
}
$coverKey = ''; $cover = ''; $coverPoll = 0
$manager = Await ($managerType::RequestAsync()) $managerType
$inputTask = [AstraInput]::Next()
while ($true) {
    try {
        $session = $manager.GetSessions() | Where-Object { $_.SourceAppUserModelId -match '(?i)spotify' } | Select-Object -First 1
        if ($inputTask.IsCompleted) {
            $command = $inputTask.Result
            if ($null -eq $command -or $command -eq 'quit') { break }
            $inputTask = [AstraInput]::Next()
            if ($session) {
                $accepted = $true
                switch ($command) {
                    'toggle' { $accepted = Await ($session.TryTogglePlayPauseAsync()) ([bool]) }
                    'next' { $accepted = Await ($session.TrySkipNextAsync()) ([bool]) }
                    'previous' { $accepted = Await ($session.TrySkipPreviousAsync()) ([bool]) }
                }
                if (-not $accepted) { Emit @{ connected=$false; status='Spotify did not accept the playback command. Try again.' }; Start-Sleep -Milliseconds 300; continue }
            }
        }
        if (-not $session) {
            Emit @{ connected=$false; status='Open the Spotify desktop app and play a song.' }
        } else {
            $media = Await ($session.TryGetMediaPropertiesAsync()) $mediaType
            $info = $session.GetPlaybackInfo()
            $key = ([string]$media.Title) + '|' + ([string]$media.Artist) + '|' + ([string]$media.AlbumTitle)
            if ($key -ne $coverKey) { $coverKey = $key; $cover = ''; $coverPoll = 0 }
            if (-not $cover -and ($coverPoll % 10 -eq 0)) {
                try { $cover = Artwork $media.Thumbnail } catch { $cover = '' }
            }
            $coverPoll++
            $position = 0.0; $duration = 0.0
            try {
                $timeline = $session.GetTimelineProperties()
                $position = [Math]::Max(0, ($timeline.Position - $timeline.StartTime).TotalSeconds)
                $duration = [Math]::Max(0, ($timeline.EndTime - $timeline.StartTime).TotalSeconds)
                if ($duration -le 0) { $duration = [Math]::Max(0, ($timeline.MaxSeekTime - $timeline.StartTime).TotalSeconds) }
                if ($info.PlaybackStatus.ToString() -eq 'Playing') {
                    $advance = ([DateTimeOffset]::UtcNow - $timeline.LastUpdatedTime).TotalSeconds
                    # Windows may only update this timestamp on play/pause or seek.
                    # Capping the advance at five seconds freezes the progress and lyrics.
                    if ($advance -ge 0 -and $advance -le 604800) { $position += $advance }
                }
                if ($duration -gt 0) { $position = [Math]::Min($position, $duration) }
            } catch { } # Missing timeline never hides otherwise valid song metadata.
            Emit @{ connected=$true; title=[string]$media.Title; artist=[string]$media.Artist; album=[string]$media.AlbumTitle; artwork=$cover; position=$position; duration=$duration; playing=($info.PlaybackStatus.ToString() -eq 'Playing'); toggle=[bool]$info.Controls.IsPlayPauseToggleEnabled; next=[bool]$info.Controls.IsNextEnabled; previous=[bool]$info.Controls.IsPreviousEnabled; status=$info.PlaybackStatus.ToString() }
        }
    } catch {
        Emit @{ connected=$false; status='Windows media session is not ready. Retrying automatically.' }
    }
    Start-Sleep -Milliseconds 1000
}
