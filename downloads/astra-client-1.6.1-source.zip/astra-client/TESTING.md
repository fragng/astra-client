# Astra Client 1.6.1 validation

- Built with Java 21 for Minecraft 1.21.11 / Fabric Loader 0.19.3.
- Removed the standalone Music category, its music-volume and mute controls, and the unused restoreMusic preference. Native Minecraft sound settings are untouched.
- Opened the real Minecraft client with a separate development-only chest fixture containing 54 named items and multiline lore (90 rendered slots including player inventory).
- Measured the same chest before/after the rendering change, hovering one item and sweeping across all 54 items. The test fixture counted GuiRenderState.submitGuiElement submissions per frame; these are GUI elements, not GPU draw calls or a universal FPS measurement.

| Scenario | Before elements/frame | After elements/frame |
| --- | ---: | ---: |
| Pointer outside slots | 8651 | 868 |
| Hover one item | 8810 | 881 |
| Sweep across items | 8810 | 881 |

The hover scenario submitted 90% fewer GUI elements. This is a diagnostic measurement from a software-rendered Linux development environment, not a hardware FPS guarantee. Item/tooltip content, styles and rounded corners were visually compared.

- Checked cached sprites after F3+T resource reload. No missing sprites or metadata errors appeared, and the tooltip remained opaque over items.
- Navigated all seven remaining categories, including Spotify HUD and General. Verified the existing Spotify HUD theme preference remains saved.
- The atlas sprites use fixed/stretch and stretched-nine-slice scaling; stretch_inner is explicitly enabled to avoid tiling the small panel centre into many quads.
- The optional Python/Pillow asset generator is included; Pillow is not a Minecraft runtime dependency.

The chest fixture and performance instrumentation are outside the project and excluded from the jar/source archive. Spotify playback and lyric handling are unchanged; live Windows Spotify remains unverified from this Linux host.
