package client.astra;

import net.minecraft.client.gui.Font;
import net.minecraft.client.gui.GuiGraphics;
import net.minecraft.client.renderer.RenderPipelines;
import net.minecraft.resources.Identifier;

public final class AstraBranding {
    private static final Identifier LOGO=Identifier.fromNamespaceAndPath(AstraClient.MOD_ID,"textures/logo.png");
    private static long last;
    private static float visibility,width=110,height=23;
    private AstraBranding() {}
    public static void drawTitle(GuiGraphics g,Font font,int screenWidth,float alpha) {AstraMenu.drawHeading(g,screenWidth,g.guiHeight(),alpha);}
    public static void drawHud(GuiGraphics g,Font font,int x,int y) {
        long now=System.nanoTime();float dt=Math.min(.1f,(now-last)/1e9f);
        if(now-last>600_000_000L) visibility=0;last=now;
        float target=AstraConfig.hudVisible?1:0;
        visibility=AstraConfig.animations?visibility+(target-visibility)*(1-(float)Math.exp(-dt*12)):target;
        if(visibility<.01f) return;
        int nameX=AstraConfig.hudLogo?27:9;
        float desiredWidth=font.width(Ui.heading(AstraClient.NAME))+nameX+10;
        float desiredHeight=23;
        float speed=AstraConfig.animations?1-(float)Math.exp(-dt*12):1;
        width+=(desiredWidth-width)*speed;height+=(desiredHeight-height)*speed;
        double time=AstraConfig.animations && !PerformanceMode.enabled()?now/1e9:0;
        float floatY=0;
        g.pose().pushMatrix();g.pose().translate(x-(1-visibility)*12,y+floatY);
        int w=Math.round(width),h=Math.round(height);
        Ui.round(g,-2,-2,w+4,h+4,13,Ui.alpha(0xFF9B7CE8,visibility*(.07f+(float)(Math.sin(time*1.1)+1)*.015f)));
        Ui.round(g,0,0,w,h,11,Ui.alpha(0xFFA484C6,visibility*.6f));
        Ui.gradient(g,1,1,w-2,h-2,10,Ui.alpha(0xEE3B2E51,visibility),Ui.alpha(0xEE18172D,visibility));
        if(AstraConfig.hudLogo) {
            float pulse=AstraConfig.animations && !PerformanceMode.enabled()?1+(float)Math.sin(time*1.1)*.035f:1;
            g.pose().pushMatrix();g.pose().translate(13,11.5f);g.pose().scale(pulse,pulse);
            g.blit(RenderPipelines.GUI_TEXTURED,LOGO,-8,-8,0f,0f,16,16,1254,1254,1254,1254,Ui.alpha(0xFFFFFFFF,visibility));g.pose().popMatrix();
        }
        Ui.animated(g,font,Ui.heading(AstraClient.NAME),nameX,6,Ui.alpha(0xFFF0E6FF,visibility));
        g.pose().popMatrix();
    }
}
