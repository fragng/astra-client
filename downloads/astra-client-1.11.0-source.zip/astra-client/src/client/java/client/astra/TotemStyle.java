package client.astra;

import net.minecraft.resources.Identifier;
import net.minecraft.world.item.ItemStack;
import net.minecraft.world.item.Items;

public enum TotemStyle {
    NONE("Minecraft", "none"),
    DRDONUT("Drdonut", "drdonut"),
    JETTISM("Jettism", "jettism"),
    FAREX("Farex", "farex"),
    HOOZAR0("Hoozar0", "hoozar0"),
    JACK("Jack", "jack");
    public static final TotemStyle[] PACK={DRDONUT,JETTISM,FAREX,HOOZAR0,JACK};
    public final String creator,id;
    public final Identifier model,texture;
    TotemStyle(String creator,String id){
        this.creator=creator;this.id=id;
        model=Identifier.fromNamespaceAndPath(AstraClient.MOD_ID,"totem/"+id);
        texture=Identifier.fromNamespaceAndPath(AstraClient.MOD_ID,"textures/item/totem/"+id+".png");
    }
    public String label(){return creator+"'s Totem";}
    /** Render-only model choice; never alters the original stack or its components. */
    public static Identifier resolve(Identifier original,ItemStack stack){
        TotemStyle style=AstraConfig.totemStyle();
        return style!=NONE && stack.is(Items.TOTEM_OF_UNDYING)?style.model:original;
    }
    public void preview(net.minecraft.client.gui.GuiGraphics g,int x,int y,int size){
        if(this==NONE)MenuArt.icon(g,"Customize Totem",x,y,size,0xFFFFFFFF);
        else Ui.texture(g,texture,x,y,size,size,0,1,0,1,64,64);
    }
}
