package client.astra;
public final class CharacterAnimationTest {
    private static void check(boolean ok,String message){if(!ok)throw new AssertionError(message);}
    public static void main(String[] args){
        check(CharacterAnimation.blink(1)==0,"eyes rest open");check(CharacterAnimation.blink(.1)>.999,"eyelids close");check(CharacterAnimation.blink(4.8)>.999,"periodic blink");
        float value=0;for(int i=0;i<60;i++)value=CharacterAnimation.approach(value,1,.05f);check(value>.99 && value<=1,"exertion rises smoothly");float high=value;for(int i=0;i<60;i++)value=CharacterAnimation.approach(value,0,.05f);check(value>0 && value<high*.5,"sweat fades gradually");
        float[] sample={0,1,0,.5f};check(CharacterAnimation.envelope(sample,-1)==0,"before speech");check(Math.abs(CharacterAnimation.envelope(sample,.02)-.5)<.00001,"interpolated mouth");check(CharacterAnimation.envelope(sample,.04)==1,"peak follows audio");check(CharacterAnimation.envelope(sample,1)==0,"mouth closes after clip");check(CharacterAnimation.envelope(new float[0],1)==0,"missing envelope safe");
        for(int i=0;i<10000;i++){float b=CharacterAnimation.blink(i/100f);check(b>=0&&b<=1,"bounded blink");}
        System.out.println("PASS eyelid timing, bounded sweat rise/fade and audio-envelope mouth interpolation");
    }
}
