package client.astra;

/** Temporal and responsive-layout contracts, independent of a running Minecraft window. */
public final class SceneTransitionTest {
    private static void require(boolean value,String message){if(!value)throw new AssertionError(message);}
    private static void close(double a,double b,String message){require(Math.abs(a-b)<1e-8,message+": "+a+" vs "+b);}
    private static int integer(String method,int h)throws Exception{var m=AstraMenu.class.getDeclaredMethod(method,int.class);m.setAccessible(true);return (int)m.invoke(null,h);}
    public static void main(String[] args)throws Exception{
        int pairs=0;
        for(int a=0;a<6;a++)for(int b=0;b<6;b++)for(int fps:new int[]{20,60,144}){
            var s=new SceneTransition(6);s.frame(a,0,true);close(s.weight(a),1,"initial settled");s.frame(b,0,true);
            double oldOffset=s.offset(a);
            for(int frame=1;frame<=Math.ceil(SceneTransition.DURATION*fps);frame++){
                s.frame(b,frame/(double)fps,true);double sum=0;
                for(int i=0;i<6;i++){require(s.weight(i)>=0 && s.weight(i)<=1,"valid weight");sum+=s.weight(i);}
                close(sum,1,"full coverage");
                if(a!=b){require(s.offset(a)<=oldOffset+1e-9,"outgoing travels left");oldOffset=s.offset(a);}
            }
            s.frame(b,SceneTransition.DURATION+.1,true);close(s.weight(b),1,"duration endpoint");close(s.offset(b),0,"destination settled");require(!s.moving(),"transition completes");pairs++;
        }
        var s=new SceneTransition(6);s.frame(0,0,true);s.frame(1,0,true);s.frame(1,.52,true);
        double previousEnergy=s.energy();double[] weights=new double[6],offsets=new double[6];for(int i=0;i<6;i++){weights[i]=s.weight(i);offsets[i]=s.offset(i);}
        s.frame(5,.52,true);close(s.energy(),previousEnergy,"retarget preserves zoom energy");
        for(int i=0;i<6;i++)if(weights[i]>1e-9){close(s.weight(i),weights[i],"retarget preserves color");close(s.offset(i),offsets[i],"retarget preserves pose");}
        for(int n=1;n<=10000;n++){s.frame(n%6,.52+n*.003,true);double sum=0;for(int i=0;i<6;i++){require(Double.isFinite(s.weight(i)) && Double.isFinite(s.offset(i)) && s.weight(i)>=0,"rapid retarget valid");sum+=s.weight(i);}close(sum,1,"rapid retarget coverage");}
        s.frame(4,40,false);close(s.weight(4),1,"reduced motion immediate");require(!s.moving(),"reduced motion settled");
        for(float span:new float[]{.01f,.2f,.66f,.82f})for(double offset:new double[]{-10,-.24,0,.24,10})for(double drift:new double[]{-1,0,1}){float uv=ThemeMotion.origin(span,offset,drift);require(uv>=0 && uv+span<=1,"UV coverage without edge clamp");}
        require(SceneTransition.TRAVEL>=.2 && SceneTransition.DURATION>=1.5,"visible relaxed travel");
        var zoom=new SceneTransition(6);zoom.frame(0,0,true);zoom.frame(1,0,true);zoom.frame(1,SceneTransition.DURATION/2,true);close(zoom.energy(),1,"midpoint zoom energy");require(ThemeMotion.crop(zoom.energy())<ThemeMotion.crop(0),"camera moves into scene");
        int layouts=0;
        for(int w:new int[]{320,360,426,480,640,960,1280,1920})for(int h:new int[]{180,200,220,240,270,290,360,480,720,1080}){
            int top=integer("panelTop",h),height=integer("panelHeight",h),header=integer("headerHeight",h),row=integer("rowHeight",h),gap=integer("rowGap",h),reactive=integer("reactiveY",h),rh=integer("reactiveHeight",h);
            require(top>=4 && top+height<=h-4,"panel inside viewport "+w+"x"+h);
            require(AstraMenu.panelX(w)>=4 && AstraMenu.panelX(w)+AstraMenu.panelWidth(w)<=w-4,"right margin");
            require(top+header+5*(row+gap)+row<reactive && reactive+rh<=top+height-4,"six rows and reactive fit");layouts++;
        }
        System.out.println("PASS "+pairs+" frame-rate/theme-pair endpoints, normalized blends, continuous rapid retargeting (10000), leftward motion, reduced motion and "+layouts+" six-choice responsive layouts");
    }
}
