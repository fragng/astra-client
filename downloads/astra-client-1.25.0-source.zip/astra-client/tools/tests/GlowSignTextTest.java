package client.astra;
import net.minecraft.network.chat.*;
import net.minecraft.resources.Identifier;
import net.minecraft.world.item.DyeColor;
import net.minecraft.world.level.block.entity.SignText;
import java.util.Optional;
public final class GlowSignTextTest {
    private static void check(boolean ok,String why){if(!ok)throw new AssertionError(why);}
    public static void main(String[] args){
        var original=new SignText();check(GlowSignText.forRender(original)==original,"plain signs untouched");
        var custom=new FontDescription.Resource(Identifier.withDefaultNamespace("alt"));
        var styled=Component.literal("Glow Ω你好").withStyle(s->s.withBold(true).withItalic(true).withColor(0x37D6A1).withClickEvent(new ClickEvent.RunCommand("/example"))).append(Component.literal(" server-font").withStyle(s->s.withFont(custom)));
        var glow=original.setMessage(0,styled,Component.literal("Filtered")).setColor(DyeColor.BLACK).setHasGlowingText(true);var fixed=GlowSignText.forRender(glow);
        check(fixed!=glow && fixed.hasGlowingText() && fixed.getColor()==DyeColor.BLACK,"preserve glow and dye");check(fixed.getMessage(0,false).getString().equals(styled.getString()),"unicode/text preserved");check(fixed.getMessage(0,true).getString().equals("Filtered"),"filtered text preserved");
        final int[] spans={0};fixed.getMessage(0,false).visit((style,text)->{if(text.startsWith("Glow")){check(style.getFont().equals(GlowSignText.FONT),"stable native font alias");check(style.isBold() && style.isItalic() && style.getColor().getValue()==0x37D6A1 && style.getClickEvent()!=null,"all style metadata preserved");}if(text.contains("server-font"))check(style.getFont().equals(custom),"server custom font respected");spans[0]++;return Optional.<Object>empty();},Style.EMPTY);
        check(spans[0]>=2,"styled spans retained");check(glow.getMessage(0,false).getStyle().getFont().equals(FontDescription.DEFAULT),"world sign not mutated");check(GlowSignText.forRender(glow)==fixed,"cached render copy");check(GlowSignText.forRender(glow.setMessage(1,Component.literal("changed")))!=fixed,"updated sign invalidates naturally");
        System.out.println("PASS glow-sign native font, filtered/Unicode text, dye/bold/italic/click styles, custom fonts, cache identity and unchanged world text");
    }
}
