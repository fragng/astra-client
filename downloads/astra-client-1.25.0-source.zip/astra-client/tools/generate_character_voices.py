"""Author original neural speech clips; development-only Piper/FFmpeg, never runtime.
Usage: python generate_character_voices.py /path/to/en_GB-vctk-medium.onnx
Model/dataset provenance and CC BY attribution: CHARACTER_VOICES.md.
"""
from pathlib import Path
import json,sys,wave,subprocess,tempfile,hashlib,array,math
from character_dialogue import LINES
EVENTS={
'join':('A fresh adventure. Let us make it a good one.','Back in the world. Ready when you are.'),
'totem':('That was close. A second chance!','Still here! That little totem saved the day.'),
'rain':('Here comes the rain. Rather refreshing.','Looks like we are getting a little shower.'),
'clear':('The rain has stopped. What a lovely view.','Clear skies again. Much better.'),
' thunder':('That thunder sounds serious. Find some shelter.','A proper storm is rolling in.'),
'dawn':('Good morning. A whole new day ahead.','The sun is coming up. Beautiful.'),
'dusk':('The sun is setting. Time to be a little careful.','Night is on its way. Keep a torch handy.'),
'hurt':('Ouch! Let us be a little more careful.','That hurt. Take a breath.'),
'low_health':('Easy now. You need to heal.','Health is low. Find somewhere safe.'),
'recovered':('Feeling better. That is more like it.','All patched up. Good to go.'),
'death':('Well, that did not go to plan.','A rough ending. We can try again.'),
'respawn':('A fresh start. Let us take it steady.','Back on our feet. Another chance.'),
'dimension':('A different world. Take a moment to look around.','New surroundings. This should be interesting.'),
'diamond':('Diamonds! Now that is a lovely discovery.','Something sparkling. Excellent find.'),
'mining':('A little hard work goes a long way.','Another block down. Nice and steady.'),
'eating':('A little snack. Just what we needed.','That should keep us going.'),
'fishing':('Line is out. Let us see what bites.','A quiet moment by the water. Lovely.'),
'swimming':('Into the water. Mind your breath.','A little swim. Very refreshing.'),
'fire':('Getting a bit too hot. Find some water.','We are on fire! Time to cool down.'),
'flying':('What a view from up here.','Up in the air. Nice and smooth.'),
'sleep':('Time for a little rest. Good night.','A comfortable bed. See you in the morning.'),
'level_up':('Another level. Nicely done.','A little more experience. Good progress.'),
'advancement':('A new milestone. You earned that.','Now that is something to be proud of.'),
'victory':('Nicely handled. Take a moment to recover.','That is settled. Well done.'),
'fall':('Quite a landing. Watch your step.','That was a long way down. Take it easy.'),
'crafting':('Something useful, made by hand.','A little crafting. That will come in handy.'),
'chest':('Let us see what is tucked away in here.','A little organising. Always worth doing.')}
EVENTS={k.strip():v for k,v in EVENTS.items()}
# Separate licensed dataset speakers; these do not impersonate actors or DrDonutt.
STYLES={'spongebob':('p226',.91),'drdonutt':('p227',1.0),'patrick':('p232',1.10),'squidward':('p243',1.04),'mr_krabs':('p251',.98),'sandy':('p225',.95)}
EXTRAS={
'spongebob':{'rain':('A sponge does enjoy a little water.','A rainy day. Good thing I am absorbent.'),'totem':('That was a close squeeze, even for a sponge!','A second chance! Still full of spirit.'),'mining':('One little block at a time. We have got this.','Sponge power and a little patience. There we go.')},
'patrick':{'mining':('I like this rock. Oh, there it goes.','Was that the right rock? Looks good to me.'),'fishing':('We could wait here all day. I would not mind.','A very relaxing bit of doing nothing.')},
'squidward':{'rain':('Rain. How delightfully predictable.','A rainy afternoon. I suppose it could be worse.'),'mining':('Another block. Truly thrilling work.','Very industrious. Do take your time.')},
'mr_krabs':{'diamond':('Now that is a valuable little find!','Something shiny. Keep that somewhere safe.'),'chest':('A little treasure tucked away, perhaps.','Let us keep our valuables in order.')},
'sandy':{'dimension':('A new environment. Plenty to investigate.','Interesting conditions. Let us explore carefully.'),'crafting':('A little ingenuity goes a long way.','A useful invention. Nicely put together.')},
'drdonutt':{'totem':('Close call. Reset and stay focused.','Good save. Take a second to heal.'),'victory':('Clean finish. Stay sharp.','Nicely played. Keep your head in the game.')}}

def main():
 from piper import PiperVoice,SynthesisConfig
 root=Path(__file__).resolve().parents[1]/'src/main/resources/assets/astra-client'
 model=Path(sys.argv[1]);voice=PiperVoice.load(model);voice.session.disable_fallback()
 us_model=model.with_name('ljspeech.onnx');us_voice=PiperVoice.load(us_model)
 profiles={'spongebob':(1.27,'equalizer=f=1700:t=q:w=1.1:g=3,equalizer=f=180:t=q:w=1:g=-3'),'patrick':(.77,'equalizer=f=160:t=q:w=1:g=2,lowpass=f=7000'),'squidward':(.94,'equalizer=f=1150:t=q:w=1.3:g=5,equalizer=f=250:t=q:w=1:g=-3'),'mr_krabs':(.84,'equalizer=f=190:t=q:w=1:g=3,aexciter=amount=1.2:blend=.12'),'sandy':(1.08,'equalizer=f=2700:t=q:w=1:g=2'),'drdonutt':(1.0,'anull')}
 speakers=json.loads(Path(str(model)+'.json').read_text())['speaker_id_map']
 sounds=json.loads((root/'sounds.json').read_text());lang_path=root/'lang/en_us.json';lang=json.loads(lang_path.read_text()) if lang_path.exists() else {};manifest={}
 with tempfile.TemporaryDirectory() as temp:
  wav=Path(temp)/'line.wav'
  for style,(speaker,speed) in STYLES.items():
   entries={};folder=root/'sounds/characters'/style;folder.mkdir(parents=True,exist_ok=True)
   for number,(event,default) in enumerate(EVENTS.items()):
    clips=[]
    for i,text in enumerate(tuple(LINES[style][number].split('|'))+EXTRAS.get(style,{}).get(event,default)):
     ident=f'character.{style}.{event}.{i}';dest=folder/f'{event}_{i}.ogg'
     with wave.open(str(wav),'wb') as audio:(us_voice if style=='sandy' else voice).synthesize_wav(text,audio,SynthesisConfig(speaker_id=None if style=='sandy' else speakers[speaker],length_scale=speed,noise_scale=.333,noise_w_scale=.5))
     pitch,eq=profiles[style]
     filtering=f'rubberband=pitch={pitch}:formant=shifted:transients=smooth,{eq},loudnorm=I=-19:TP=-2:LRA=7,afade=t=in:d=0.025'
     subprocess.run(['ffmpeg','-nostdin','-loglevel','error','-y','-i',str(wav),'-af',filtering,'-ac','1','-ar','22050','-c:a','libvorbis','-q:a','3',str(dest)],check=True)
     duration=float(subprocess.check_output(['ffprobe','-v','error','-show_entries','format=duration','-of','csv=p=0',str(dest)]))
     pcm=array.array('h',subprocess.check_output(['ffmpeg','-nostdin','-loglevel','error','-i',str(dest),'-f','s16le','-ac','1','-ar','8000','-']))
     rms=[math.sqrt(sum(v*v for v in pcm[a:a+320])/max(1,len(pcm[a:a+320]))) for a in range(0,len(pcm),320)]
     peak=max(rms,default=1) or 1
     mouth=[round(min(1,v/peak),3) for v in rms]
     clips.append({'sound':ident,'text':text,'seconds':round(duration,3),'mouth':mouth})
     sounds[ident]={'subtitle':'subtitles.astra-client.'+ident,'sounds':[{'name':f'astra-client:characters/{style}/{event}_{i}','stream':True}]}
     lang['subtitles.astra-client.'+ident]=style.replace('_',' ').title()+': '+text
    entries[event]=clips
   manifest[style]=entries;print('Authored',style,len(entries)*4,'clips',flush=True)
 (root/'sounds.json').write_text(json.dumps(sounds,indent=2)+'\n');lang_path.parent.mkdir(parents=True,exist_ok=True);lang_path.write_text(json.dumps(lang,indent=2)+'\n')
 (root/'voices/manifest.json').write_text(json.dumps({'source':'Piper en_GB-vctk-medium / VCTK 0.92, CC BY 4.0; see CHARACTER_VOICES.md','model_sha256':hashlib.sha256(model.read_bytes()).hexdigest(),'us_model_sha256':hashlib.sha256(us_model.read_bytes()).hexdigest(),'profiles':profiles,'characters':manifest},indent=2)+'\n')
if __name__=='__main__':main()
