package client.astra;

/** Aspect-independent camera travel without clamped/stalled texture edges. */
public final class ThemeMotion {
    private ThemeMotion(){}
    public static float crop(double energy){return .82f-.16f*(float)Math.clamp(energy,0,1);}
    public static float origin(float span,double offset,double drift){
        double margin=(1-span)*.5;
        return (float)(margin-Math.tanh(offset/SceneTransition.TRAVEL)*margin*.88+Math.clamp(drift,-1,1)*margin*.06);
    }
}
