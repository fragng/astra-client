package client.astra.mixin;
import client.astra.GlowSignText;
import net.minecraft.client.renderer.blockentity.AbstractSignRenderer;
import net.minecraft.client.renderer.blockentity.state.SignRenderState;
import net.minecraft.client.renderer.feature.ModelFeatureRenderer;
import net.minecraft.world.level.block.entity.SignBlockEntity;
import net.minecraft.world.phys.Vec3;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.*;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;
@Mixin(AbstractSignRenderer.class)
public abstract class GlowSignMixin {
    @Inject(method="extractRenderState(Lnet/minecraft/world/level/block/entity/SignBlockEntity;Lnet/minecraft/client/renderer/blockentity/state/SignRenderState;FLnet/minecraft/world/phys/Vec3;Lnet/minecraft/client/renderer/feature/ModelFeatureRenderer$CrumblingOverlay;)V",at=@At("RETURN"))
    private void astra$glowFont(SignBlockEntity entity,SignRenderState state,float delta,Vec3 camera,ModelFeatureRenderer.CrumblingOverlay overlay,CallbackInfo ci){
        state.frontText=GlowSignText.forRender(state.frontText);state.backText=GlowSignText.forRender(state.backText);
    }
}
