package client.astra;

import com.google.gson.*;
import net.minecraft.client.Minecraft;
import net.minecraft.client.resources.sounds.*;
import net.minecraft.client.gui.screens.inventory.*;
import net.minecraft.sounds.SoundSource;
import net.minecraft.resources.Identifier;
import net.minecraft.util.RandomSource;
import net.minecraft.world.entity.LivingEntity;
import net.minecraft.world.level.Level;
import net.minecraft.world.level.block.Blocks;
import net.minecraft.world.level.block.state.BlockState;
import java.io.*;
import java.nio.charset.StandardCharsets;
import java.util.*;

/** Tick/event-driven local speech. No HTTP, speech engine, inventory scanning or per-frame work. */
public final class CharacterVoices {
    private record Clip(Identifier sound,String text,double seconds,float[] mouth){}
    private static final EnumMap<CharacterStyle,EnumMap<VoiceEvent,List<Clip>>> CLIPS=new EnumMap<>(CharacterStyle.class);
    private static final VoiceGate GATE=new VoiceGate();
    private static final int[][] CHOICE=new int[CharacterStyle.values().length][VoiceEvent.values().length];
    private static boolean loaded,primed,dead,rain,thunder,night,water,fire,flying,sleeping,fishing,needsHealing;
    private static int level,hurt;
    private static float health;
    private static double fall;
    private static Object world,player,screen;
    private static CharacterStyle style=CharacterStyle.NONE;
    private static VoiceEvent pending,lastEvent;
    private static SoundInstance current;
    private static LivingEntity target;
    private static long targetUntil;
    private static String lastLine="";
    private static Clip spoken;private static long started,pausedAt,pausedTotal;
    private CharacterVoices(){}
    private static void load(){
        if(loaded)return;loaded=true;
        try(var stream=CharacterVoices.class.getResourceAsStream("/assets/astra-client/voices/manifest.json")){
            if(stream==null)throw new FileNotFoundException("Character voice manifest");
            var data=JsonParser.parseReader(new InputStreamReader(stream,StandardCharsets.UTF_8)).getAsJsonObject().getAsJsonObject("characters");
            for(var s:CharacterStyle.CHOICES){var map=new EnumMap<VoiceEvent,List<Clip>>(VoiceEvent.class);var actor=data.getAsJsonObject(s.id);
                for(var event:VoiceEvent.values()){List<Clip> clips=new ArrayList<>();for(var value:actor.getAsJsonArray(event.id())){var j=value.getAsJsonObject();clips.add(new Clip(Identifier.fromNamespaceAndPath(AstraClient.MOD_ID,j.get("sound").getAsString()),j.get("text").getAsString(),j.get("seconds").getAsDouble(),mouthSamples(j)));}map.put(event,List.copyOf(clips));}CLIPS.put(s,map);
            }
        }catch(Exception e){CLIPS.clear();org.slf4j.LoggerFactory.getLogger("Astra Voices").warn("Character speech unavailable; leaving vanilla audio unchanged.",e);}
    }
    private static float[] mouthSamples(JsonObject j){if(!j.has("mouth"))return new float[0];var a=j.getAsJsonArray("mouth");float[] result=new float[a.size()];for(int i=0;i<result.length;i++)result[i]=Math.clamp(a.get(i).getAsFloat(),0,1);return result;}
    public static float mouth(){if(spoken==null)return 0;long now=pausedAt==0?System.nanoTime():pausedAt;return CharacterAnimation.envelope(spoken.mouth,(now-started-pausedTotal)/1e9);}
    public static boolean active(){return AstraConfig.characterVoices && AstraConfig.characterStyle()!=CharacterStyle.NONE && AstraConfig.characterVoiceVolume>0;}
    public static void stop(){if(current!=null)Minecraft.getInstance().getSoundManager().stop(current);current=null;pending=null;lastLine="";spoken=null;started=pausedAt=pausedTotal=0;GATE.clear();}
    public static void request(VoiceEvent event){
        var mc=Minecraft.getInstance();
        if(!active() || mc.player==null || mc.level==null || !event.enabled(AstraConfig.characterVoiceGroups))return;
        if(mc.screen!=null && event!=VoiceEvent.CHEST && event!=VoiceEvent.CRAFTING && event.priority<90)return;
        if(pending==null || event.priority>pending.priority)pending=event;
    }
    public static void broken(BlockState block){request(block.is(Blocks.DIAMOND_ORE)||block.is(Blocks.DEEPSLATE_DIAMOND_ORE)?VoiceEvent.DIAMOND:VoiceEvent.MINING);}
    public static void attacked(LivingEntity entity){target=entity;targetUntil=System.nanoTime()+10_000_000_000L;}
    public static void selected(){stop();style=AstraConfig.characterStyle();primed=false;var mc=Minecraft.getInstance();if(active() && mc.player!=null && mc.level!=null)play(VoiceEvent.JOIN,true);}
    public static void preview(){if(active())play(VoiceEvent.JOIN,true);}
    public static String status(){return AstraConfig.characterStyle()==CharacterStyle.NONE?"Select a character to hear its voice.":!AstraConfig.characterVoices?"Enable voice lines to hear reactions.":lastLine.isEmpty()?"Ready / original licensed synthetic voice.":lastLine;}
    private static void play(VoiceEvent event,boolean preview){
        load();var actor=CLIPS.get(AstraConfig.characterStyle());if(actor==null)return;var choices=actor.get(event);if(choices==null||choices.isEmpty())return;
        int s=AstraConfig.characterStyle().ordinal(),e=event.ordinal(),index=CHOICE[s][e]%choices.size();var clip=choices.get(index);
        if(preview)GATE.clear();
        if(!GATE.accept(event,System.nanoTime(),clip.seconds,AstraConfig.characterVoiceCadence))return;
        if(current!=null)Minecraft.getInstance().getSoundManager().stop(current);
        current=new SimpleSoundInstance(clip.sound,SoundSource.VOICE,(float)AstraConfig.characterVoiceVolume,1,RandomSource.create(),false,0,SoundInstance.Attenuation.NONE,0,0,0,true);
        Minecraft.getInstance().getSoundManager().play(current);spoken=clip;started=System.nanoTime();pausedAt=pausedTotal=0;CHOICE[s][e]++;lastLine=clip.text;lastEvent=event;
    }
    public static void tick(Minecraft mc){
        if(spoken!=null){long now=System.nanoTime();if(mc.isPaused()){if(pausedAt==0)pausedAt=now;}else if(pausedAt!=0){pausedTotal+=now-pausedAt;pausedAt=0;}}

        if(mc.player==null || mc.level==null){stop();primed=false;world=player=screen=null;target=null;style=CharacterStyle.NONE;return;}
        if(!active()){if(current!=null||pending!=null)stop();primed=false;target=null;return;}
        var p=mc.player;var l=mc.level;
        if(style!=AstraConfig.characterStyle()){stop();primed=false;style=AstraConfig.characterStyle();}
        boolean changedWorld=world!=l,respawn=player!=p && dead;
        if(changedWorld)target=null;
        boolean nowRain=l.dimension()==Level.OVERWORLD && l.isRaining(),nowThunder=nowRain && l.isThundering();
        boolean nowNight=Math.floorMod(l.getDayTime(),24000)>=13000;
        boolean nowDead=!p.isAlive(),nowWater=p.isInWater(),nowFire=p.isOnFire(),nowFlying=p.isFallFlying(),nowSleep=p.isSleeping(),nowFishing=p.fishing!=null;
        if(!primed || changedWorld || player!=p){
            request(respawn?VoiceEvent.RESPAWN:primed&&changedWorld?VoiceEvent.DIMENSION:VoiceEvent.JOIN);primed=true;needsHealing=p.getHealth()<=6;
        }else{
            if(nowRain&&!rain)request(VoiceEvent.RAIN);if(!nowRain&&rain)request(VoiceEvent.CLEAR);if(nowThunder&&!thunder)request(VoiceEvent.THUNDER);
            if(l.dimension()==Level.OVERWORLD && night!=nowNight)request(nowNight?VoiceEvent.DUSK:VoiceEvent.DAWN);
            if(!dead&&nowDead)request(VoiceEvent.DEATH);
            if(!nowDead){
                if(p.getHealth()<health || p.hurtTime>hurt)request(p.onGround()&&fall>4?VoiceEvent.FALL:VoiceEvent.HURT);
                if(p.getHealth()<=6 && health>6){needsHealing=true;request(VoiceEvent.LOW_HEALTH);}
                if(needsHealing && p.getHealth()>=p.getMaxHealth()*.75){needsHealing=false;request(VoiceEvent.RECOVERED);}
                if(nowWater&&!water)request(VoiceEvent.SWIMMING);if(nowFire&&!fire)request(VoiceEvent.FIRE);
                if(nowFlying&&!flying)request(VoiceEvent.FLYING);if(nowSleep&&!sleeping)request(VoiceEvent.SLEEP);if(nowFishing&&!fishing)request(VoiceEvent.FISHING);
                if(p.experienceLevel>level)request(VoiceEvent.LEVEL_UP);
            }
        }
        if(mc.screen!=screen && (mc.screen instanceof ContainerScreen || mc.screen instanceof ShulkerBoxScreen || mc.screen instanceof HopperScreen || mc.screen instanceof DispenserScreen))request(VoiceEvent.CHEST);
        if(target!=null){if(target.isDeadOrDying()){request(VoiceEvent.VICTORY);target=null;}else if(target.isRemoved()||System.nanoTime()>targetUntil)target=null;}
        world=l;player=p;screen=mc.screen;dead=nowDead;rain=nowRain;thunder=nowThunder;night=nowNight;water=nowWater;fire=nowFire;flying=nowFlying;sleeping=nowSleep;fishing=nowFishing;health=p.getHealth();hurt=p.hurtTime;fall=p.fallDistance;level=p.experienceLevel;
        if(pending!=null){var event=pending;pending=null;play(event,false);}
    }
}
