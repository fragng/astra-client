package client.astra;

import net.minecraft.network.chat.*;
import net.minecraft.resources.Identifier;
import net.minecraft.world.level.block.entity.SignText;
import java.util.*;
import net.fabricmc.fabric.api.resource.*;
import net.minecraft.server.packs.PackType;
import net.minecraft.server.packs.resources.ResourceManager;

/** Render-only font alias keeps glow glyphs, wrapping, centering and outlines consistent. */
public final class GlowSignText {
    public static final FontDescription FONT=new FontDescription.Resource(Identifier.fromNamespaceAndPath(AstraClient.MOD_ID,"sign-vanilla"));
    private static final Map<SignText,SignText> CACHE=new WeakHashMap<>();
    private GlowSignText(){}
    public static void initialize(){ResourceManagerHelper.get(PackType.CLIENT_RESOURCES).registerReloadListener(new SimpleSynchronousResourceReloadListener(){
        public Identifier getFabricId(){return Identifier.fromNamespaceAndPath(AstraClient.MOD_ID,"glow_sign_font");}
        public void onResourceManagerReload(ResourceManager resources){CACHE.clear();}
    });}
    private static Component copy(Component original){
        var result=Component.empty();
        original.visit((style,text)->{
            var font=style.getFont();
            if(font.equals(FontDescription.DEFAULT)||font.equals(Ui.FONT)||font.equals(Ui.HEADING)||font.equals(new FontDescription.Resource(Identifier.fromNamespaceAndPath(AstraClient.MOD_ID,"default-bubble"))))style=style.withFont(FONT);
            result.append(Component.literal(text).setStyle(style));return Optional.<Object>empty();
        },Style.EMPTY);
        return result;
    }
    public static SignText forRender(SignText original){
        if(!original.hasGlowingText())return original;
        return CACHE.computeIfAbsent(original,key->{
            Component[] normal=new Component[4],filtered=new Component[4];
            for(int i=0;i<4;i++){normal[i]=copy(key.getMessage(i,false));filtered[i]=copy(key.getMessage(i,true));}
            return new SignText(normal,filtered,key.getColor(),key.hasGlowingText());
        });
    }
}
