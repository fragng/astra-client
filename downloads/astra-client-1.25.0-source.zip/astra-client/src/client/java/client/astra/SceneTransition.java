package client.astra;

/** Fixed-size blend state: wall-clock easing, continuous retargets, no frame allocations. */
public final class SceneTransition {
    public static final double DURATION=1.65,TRAVEL=.24;
    private final double[] weights,offsets,startWeights,startOffsets;
    private int target=-1;
    private double started,energy,startEnergy;
    public SceneTransition(int count){if(count<1)throw new IllegalArgumentException("count");weights=new double[count];offsets=new double[count];startWeights=new double[count];startOffsets=new double[count];}
    public void frame(int next,double now,boolean animated){
        if(next<0 || next>=weights.length || !Double.isFinite(now))throw new IllegalArgumentException("frame");
        if(target<0 || !animated){settle(next);started=now;return;}
        evaluate(now);
        if(next==target)return;
        System.arraycopy(weights,0,startWeights,0,weights.length);
        System.arraycopy(offsets,0,startOffsets,0,offsets.length);
        startEnergy=energy;target=next;started=now;
        // An unseen destination starts on the right. Existing visible layers keep their pose.
        if(startWeights[next]<1e-12)startOffsets[next]=TRAVEL;
        evaluate(now);
    }
    private void settle(int next){
        java.util.Arrays.fill(weights,0);java.util.Arrays.fill(offsets,0);weights[next]=1;target=next;energy=startEnergy=0;
        System.arraycopy(weights,0,startWeights,0,weights.length);System.arraycopy(offsets,0,startOffsets,0,offsets.length);
    }
    private void evaluate(double now){
        double t=Math.clamp((now-started)/DURATION,0,1),e=t*t*t*(t*(t*6-15)+10);
        energy=startEnergy*(1-e)+(1-startEnergy)*4*e*(1-e);
        for(int i=0;i<weights.length;i++){
            weights[i]=startWeights[i]*(1-e)+(i==target?e:0);
            offsets[i]=i==target?startOffsets[i]*(1-e):startOffsets[i]-TRAVEL*e;
        }
    }
    public double energy(){return energy;}
    public double weight(int index){return weights[index];}
    public double offset(int index){return offsets[index];}
    public int target(){return target;}
    public boolean moving(){return target>=0 && weights[target]<1-1e-9;}
}
