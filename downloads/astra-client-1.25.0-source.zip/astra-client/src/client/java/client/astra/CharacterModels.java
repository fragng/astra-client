package client.astra;

import com.google.gson.*;
import net.minecraft.client.model.player.PlayerModel;
import net.minecraft.client.model.geom.*;
import net.minecraft.client.renderer.entity.state.AvatarRenderState;
import java.io.*;
import java.nio.charset.StandardCharsets;
import java.util.*;

/** Cached curved geometry; independent native world/preview poses and articulated details. */
public final class CharacterModels {
    private static final EnumMap<CharacterStyle,PlayerModel> CACHE=new EnumMap<>(CharacterStyle.class),PREVIEWS=new EnumMap<>(CharacterStyle.class);
    private static final EnumMap<CharacterStyle,Map<String,List<ModelPart.Cube>>> GEOMETRY=new EnumMap<>(CharacterStyle.class);
    private static JsonObject definitions;
    private CharacterModels(){}
    public static PlayerModel preview(CharacterStyle style){var model=(CharacterPlayerModel)PREVIEWS.computeIfAbsent(style,CharacterModels::bake);model.preparePreview();return model;}
    public static PlayerModel model(CharacterStyle style){if(style==CharacterStyle.NONE)throw new IllegalArgumentException("Native player has no replacement");return CACHE.computeIfAbsent(style,CharacterModels::bake);}
    private static ModelPart.Cube cube(JsonObject box){
        var from=box.getAsJsonArray("from");var size=box.getAsJsonArray("size");
        var shape=CharacterMesh.build(from.get(0).getAsFloat(),from.get(1).getAsFloat(),from.get(2).getAsFloat(),size.get(0).getAsFloat(),size.get(1).getAsFloat(),size.get(2).getAsFloat(),box.has("power")?box.get("power").getAsDouble():.35,box.has("taper")?box.get("taper").getAsDouble():0,box.has("ring")&&box.get("ring").getAsBoolean(),box.has("band")?box.get("band").getAsDouble():.28,box.has("detail")?box.get("detail").getAsInt():0);
        List<CharacterSurface.Pore> pores=new ArrayList<>();
        if(box.has("pores"))for(var value:box.getAsJsonArray("pores")){var p=value.getAsJsonArray();pores.add(new CharacterSurface.Pore(p.get(0).getAsFloat(),p.get(1).getAsFloat(),p.get(2).getAsFloat(),p.get(3).getAsFloat()));}
        return new CurvedCharacterCube(CharacterSurface.recess(shape,pores),box.get("color").getAsInt(),box.has("material")?box.get("material").getAsString():"",pores);
    }
    private record Detail(ModelPart part,String effect,float baseY,int index,float[] path){}
    private static PlayerModel bake(CharacterStyle style){
        if(definitions==null){try(var stream=CharacterModels.class.getResourceAsStream("/assets/astra-client/characters/models.json")){
            if(stream==null)throw new FileNotFoundException("Character geometry");definitions=JsonParser.parseReader(new InputStreamReader(stream,StandardCharsets.UTF_8)).getAsJsonObject().getAsJsonObject("models");
        }catch(IOException e){throw new IllegalStateException("Could not load character geometry",e);}}
        var parts=definitions.getAsJsonObject(style.id).getAsJsonObject("parts");var head=parts.getAsJsonObject("head");
        var geometry=GEOMETRY.computeIfAbsent(style,key->{Map<String,List<ModelPart.Cube>> result=new LinkedHashMap<>();
            for(var entry:parts.entrySet()){List<ModelPart.Cube> cubes=new ArrayList<>();for(var value:entry.getValue().getAsJsonObject().getAsJsonArray("boxes"))cubes.add(cube(value.getAsJsonObject()));result.put(entry.getKey(),List.copyOf(cubes));}
            if(head.has("details"))for(var value:head.getAsJsonArray("details")){var d=value.getAsJsonObject();String name=d.get("name").getAsString();result.put("detail_"+name,List.of(cube(d)));
                if(d.get("effect").getAsString().equals("sweat")){
                    var size=d.getAsJsonArray("size");var glint=CharacterMesh.build(0,0,0,size.get(0).getAsFloat()*.3f,size.get(1).getAsFloat()*.25f,.055f,1,0,false,.2);
                    result.put("glint_"+name,List.of(new CurvedCharacterCube(glint,d.get("glintColor").getAsInt(),"",List.of())));
                }
            }return result;
        });
        Map<String,ModelPart> children=new LinkedHashMap<>();List<Detail> details=new ArrayList<>();
        for(var entry:parts.entrySet()){
            String overlay=switch(entry.getKey()){case "head"->"hat";case "body"->"jacket";case "right_arm"->"right_sleeve";case "left_arm"->"left_sleeve";case "right_leg"->"right_pants";default->"left_pants";};
            Map<String,ModelPart> sub=new LinkedHashMap<>();sub.put(overlay,new ModelPart(List.of(),Map.of()));
            if(entry.getKey().equals("head") && head.has("details"))for(var value:head.getAsJsonArray("details")){
                var d=value.getAsJsonObject();String name=d.get("name").getAsString(),effect=d.get("effect").getAsString();Map<String,ModelPart> extra=new LinkedHashMap<>();
                if(effect.equals("sweat")){var glint=new ModelPart(geometry.get("glint_"+name),Map.of());var pos=PartPose.offset(.06f,.12f,-.035f);glint.setInitialPose(pos);glint.loadPose(pos);extra.put("highlight",glint);}
                var detail=new ModelPart(geometry.get("detail_"+name),extra);var xyz=d.getAsJsonArray("position");var pose=PartPose.offset(xyz.get(0).getAsFloat(),xyz.get(1).getAsFloat(),xyz.get(2).getAsFloat());detail.setInitialPose(pose);detail.loadPose(pose);detail.visible=false;sub.put(name,detail);float[] path=new float[d.has("surfacePath")?d.getAsJsonArray("surfacePath").size():0];for(int i=0;i<path.length;i++)path[i]=d.getAsJsonArray("surfacePath").get(i).getAsFloat();details.add(new Detail(detail,effect,pose.y(),details.size(),path));
            }
            var part=new ModelPart(geometry.get(entry.getKey()),sub);var p=entry.getValue().getAsJsonObject().getAsJsonArray("pivot");var pose=PartPose.offset(p.get(0).getAsFloat(),p.get(1).getAsFloat(),p.get(2).getAsFloat());part.setInitialPose(pose);part.loadPose(pose);children.put(entry.getKey(),part);
        }
        return new CharacterPlayerModel(new ModelPart(List.of(),children),style,details);
    }
    private static final class CharacterPlayerModel extends PlayerModel {
        private final float armRadius;private final CharacterStyle style;private final List<Detail> details;private final List<ModelPart> all;
        CharacterPlayerModel(ModelPart root,CharacterStyle style,List<Detail> details){super(root,false);armRadius=Math.abs(rightArm.getInitialPose().x());this.style=style;this.details=List.copyOf(details);all=List.copyOf(root.getAllParts());}
        void preparePreview(){for(var part:all)part.resetPose();applyDetails((float)((System.nanoTime()%600_000_000_000L)/1e9));}
        @Override public void setupAnim(AvatarRenderState state){super.setupAnim(state);if(state.attackTime>0 && armRadius!=5){rightArm.x*=armRadius/5;leftArm.x*=armRadius/5;}applyDetails(state.ageInTicks/20f);}
        private void applyDetails(float seconds){
            boolean enabled=AstraConfig.characterDetails,animate=enabled&&AstraConfig.animations&&!PerformanceMode.enabled();
            float blink=animate?CharacterAnimation.blink(seconds+style.ordinal()*.61):0;
            float sweat=enabled?CharacterEffects.sweat():0,mouth=animate&&style==AstraConfig.characterStyle()?CharacterVoices.mouth():0;
            if(animate){float breath=(float)Math.sin(seconds*2.2+style.ordinal())*.008f;body.yScale=1+breath;head.y+=breath*3;}
            for(var d:details){var p=d.part;
                switch(d.effect){
                    case "lid"->{p.visible=blink>.04f;p.yScale=Math.max(.001f,blink);}
                    case "mouth"->{p.visible=mouth>.025f;p.yScale=.05f+mouth*.8f;p.xScale=1+mouth*.04f;}
                    case "sweat"->{float phase=animate?(float)((seconds*.37+d.index*.237)%1):.45f;p.visible=sweat>.1f && phase>.04f && phase<.96f;p.y=d.baseY+phase*.9f;if(d.path.length>0)p.z=CharacterAnimation.path(d.path,phase);float size=sweat*(.5f+.5f*(float)Math.sin(phase*Math.PI));p.xScale=p.yScale=p.zScale=size;}
                }
            }
        }
    }
}
