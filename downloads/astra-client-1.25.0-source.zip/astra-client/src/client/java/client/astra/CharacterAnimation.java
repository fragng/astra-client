package client.astra;

/** Bounded cosmetic motion; no random particles, world mutations or per-frame mesh builds. */
public final class CharacterAnimation {
    private CharacterAnimation(){}
    public static float blink(double seconds){double t=seconds%4.7;if(t<0)t+=4.7;return t<.2?(float)Math.sin(t/.2*Math.PI):0;}
    public static float approach(float value,float target,float seconds){return value+(target-value)*(1-(float)Math.exp(-Math.max(0,seconds)*(target>value?1.7:.24)));}
    public static float path(float[] samples,float phase){if(samples.length==0)return 0;float p=Math.clamp(phase,0,1)*(samples.length-1);int a=(int)p,b=Math.min(a+1,samples.length-1);return samples[a]+(samples[b]-samples[a])*(p-a);}
    public static float envelope(float[] samples,double seconds){
        if(samples.length==0 || seconds<0 || seconds>=samples.length*.04)return 0;
        double pos=seconds/.04;int a=(int)pos,b=Math.min(a+1,samples.length-1);
        return (float)Math.clamp(samples[a]+(samples[b]-samples[a])*(pos-a),0,1);
    }
}
