package client.astra;

import com.mojang.blaze3d.platform.InputConstants;
import net.minecraft.client.Minecraft;
import net.minecraft.client.KeyMapping;
import net.minecraft.client.CameraType;
import net.ninjadev.freelook.fabric.init.ModKeybinds;

/** Integrates the bundled, unmodified FreeLook mod's real native key mapping. */
public final class FreelookBridge {
    private static CameraType previousView;
    private static boolean holding;
    private FreelookBridge() {}
    public static void initialize() {
        if(AstraConfig.freelookKey==null) {
            AstraConfig.freelookKey=ModKeybinds.keyFreeLook.saveString();AstraConfig.changed();
        }
        if(AstraConfig.freelookKey.equals("key.keyboard.escape")) {
            AstraConfig.freelookKey=InputConstants.UNKNOWN.getName();AstraConfig.changed();AstraConfig.nativeChanged();
        }
        try {ModKeybinds.keyFreeLook.setKey(InputConstants.getKey(AstraConfig.freelookKey));}
        catch(Exception e) {AstraConfig.freelookKey="key.keyboard.left.alt";ModKeybinds.keyFreeLook.setKey(InputConstants.getKey(AstraConfig.freelookKey));AstraConfig.changed();}
        // The Astra entry uses hold-to-look. The upstream secondary toggle is unused.
        ModKeybinds.keyToggleMode.setKey(InputConstants.UNKNOWN);
        KeyMapping.resetMapping();
    }
    public static boolean allowed() {
        var mc=Minecraft.getInstance();
        return AstraConfig.freelookEnabled && mc.player!=null && mc.screen==null && mc.isWindowActive()
            && !mc.options.getCameraType().isFirstPerson() && !mc.options.getCameraType().isMirrored();
    }
    public static void tick() {
        String key=ModKeybinds.keyFreeLook.saveString();
        if(key.equals("key.keyboard.escape")) {bind(InputConstants.UNKNOWN);return;}
        if(!key.equals(AstraConfig.freelookKey)) {AstraConfig.freelookKey=key;AstraConfig.changed();}
        updatePerspective();
    }
    /** A held bind works from the usual first-person view too. */
    public static void updatePerspective() {
        var mc=Minecraft.getInstance();
        boolean down=AstraConfig.freelookEnabled && mc.player!=null && mc.screen==null && mc.isWindowActive()
            && !ModKeybinds.keyFreeLook.isUnbound() && ModKeybinds.keyFreeLook.isDown();
        if(!down) {
            if(holding && previousView!=null && mc.options.getCameraType()==CameraType.THIRD_PERSON_BACK)
                mc.options.setCameraType(previousView);
            holding=false;previousView=null;return;
        }
        if(!holding) {
            previousView=mc.options.getCameraType();holding=true;
            mc.options.setCameraType(CameraType.THIRD_PERSON_BACK);
        }
    }
    public static String conflict() {
        var key=ModKeybinds.keyFreeLook;
        if(key.isUnbound())return "";
        for(var other:Minecraft.getInstance().options.keyMappings) {
            if(other!=key && !other.isUnbound() && key.same(other))return net.minecraft.network.chat.Component.translatable(other.getName()).getString();
        }
        return "";
    }
    public static String keyName() {return ModKeybinds.keyFreeLook.isUnbound()?"Not bound":ModKeybinds.keyFreeLook.getTranslatedKeyMessage().getString();}
    public static void bind(InputConstants.Key key) {
        if(key.equals(InputConstants.getKey("key.keyboard.escape")))key=InputConstants.UNKNOWN;
        ModKeybinds.keyFreeLook.setDown(false);ModKeybinds.keyFreeLook.setKey(key);
        KeyMapping.resetMapping();AstraConfig.freelookKey=key.getName();AstraConfig.changed();AstraConfig.nativeChanged();
    }
}
