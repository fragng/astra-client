package client.astra;

import java.util.*;

public final class CaseGameTest {
    private static void check(boolean ok,String message){if(!ok)throw new AssertionError(message);}
    public static void main(String[] args){
        var counts=new EnumMap<CaseReward,Integer>(CaseReward.class);for(int i=0;i<CaseReward.TICKETS;i++)counts.merge(CaseReward.pick(i),1,Integer::sum);
        for(var reward:CaseReward.values())check(counts.get(reward)==reward.weight,"exact mutually exclusive reward weight "+reward);
        check(counts.get(CaseReward.WINGS)*500==CaseReward.TICKETS,"unchanged wings distribution");check(counts.get(CaseReward.CROWN)*250==CaseReward.TICKETS,"unchanged crown distribution");check(counts.get(CaseReward.SKIN_TOTEM)*2000==CaseReward.TICKETS,"unchanged skin distribution");check(counts.get(CaseReward.INFINITE_CASES)*70000==CaseReward.TICKETS,"exact Infinite Cases distribution");
        check(counts.get(CaseReward.DISCORD_RANK)*400==CaseReward.TICKETS,"rank distribution");check(counts.get(CaseReward.MONTH_PREMIUM)*1200==CaseReward.TICKETS,"month distribution");check(counts.get(CaseReward.LIFETIME_PREMIUM)*3000==CaseReward.TICKETS,"lifetime distribution");
        long now=1_800_000_000_000L;String account="a".repeat(64);var member=new CaseLedger(account);
        for(int i=0;i<100;i++)check(member.open(false,now+i,59999,i,UUID.randomUUID())!=null,"member allowance");
        check(member.open(false,now+1000,0,0,UUID.randomUUID())==null,"exhaustion cannot award or spend");check(member.total==100&&member.spent==100&&member.claims.isEmpty(),"no phantom rewards");
        var restored=CaseLedger.decode(member.encode(),account);check(restored.remaining(false,now+1000)==0,"restart retains quota");check(restored.remaining(false,now-86400000)==0,"rollback does not replenish");
        check(restored.remaining(true,now+1000)==100,"premium upgrade adds extra allowance without resetting usage");
        for(int i=0;i<100;i++)check(restored.open(true,now+1000+i,59999,0,UUID.randomUUID())!=null,"premium allowance");
        check(restored.remaining(true,now+2000)==0&&restored.remaining(false,now+2000)==0,"tier expiry does not restore cases");
        check(restored.remaining(true,now+CaseLedger.WINDOW-1)==0,"window not early");check(restored.remaining(true,now+CaseLedger.WINDOW)==200,"exact refill boundary");
        check(restored.remaining(true,now+CaseLedger.WINDOW*10)==200,"offline refill never stacks above cap");
        int crownTicket=CaseReward.DISCORD_RANK.weight+CaseReward.MONTH_PREMIUM.weight+CaseReward.LIFETIME_PREMIUM.weight;
        var cosmetics=new CaseLedger(account);var a=cosmetics.open(false,now,crownTicket,0,UUID.randomUUID());var b=cosmetics.open(false,now+1,crownTicket,1,UUID.randomUUID());check(a.reward()==CaseReward.CROWN&&!a.duplicate()&&b.duplicate(),"cosmetic ownership and duplicate retained without reroll");check(cosmetics.owned.contains(CaseReward.CROWN)&&!cosmetics.crown,"unlock is separate from equipment");
        var claim=cosmetics.open(false,now+2,0,0,UUID.randomUUID());check(claim.reward()==CaseReward.DISCORD_RANK&&cosmetics.claims.size()==1,"major win has retained claim ID");check(CaseLedger.decode(cosmetics.encode(),account).claims.getFirst().id().equals(claim.id()),"claim survives restart");
        cosmetics.seenWin=claim.id();check(CaseLedger.decode(cosmetics.encode(),account).seenWin.equals(claim.id()),"win acknowledgement survives restart");
        var committed=cosmetics.copy();committed.open(false,now+3,0,0,UUID.randomUUID());check(cosmetics.total+1==committed.total,"transaction copy leaves original unchanged until persistence commits");
        try{CaseLedger.decode(cosmetics.encode(),"b".repeat(64));throw new AssertionError("cross-account ledger accepted");}catch(IllegalArgumentException expected){}
        int infiniteTicket=0;for(var reward:CaseReward.values()){if(reward==CaseReward.INFINITE_CASES)break;infiniteTicket+=reward.weight;}
        var infinite=new CaseLedger(account);for(int i=0;i<99;i++)infinite.open(false,now+i,CaseReward.TICKETS-1,0,UUID.randomUUID());
        var jackpot=infinite.open(false,now+100,infiniteTicket,0,UUID.randomUUID());check(jackpot.reward()==CaseReward.INFINITE_CASES&&infinite.unlimited(),"final ordinary case can permanently unlock unlimited opens");
        check(infinite.remaining(false,now+101)==Integer.MAX_VALUE,"immediate unlimited Member allowance");long spent=infinite.spent;
        for(int i=0;i<1000;i++)check(infinite.open(false,now+102+i,CaseReward.TICKETS-1,0,UUID.randomUUID())!=null,"opens beyond former quota");
        check(infinite.spent==spent&&infinite.total==1100,"unlimited opens keep bounded spent and count lifetime draws");
        var savedInfinite=CaseLedger.decode(infinite.encode(),account);check(savedInfinite.unlimited()&&savedInfinite.remaining(false,now-1)==Integer.MAX_VALUE,"unlimited unlock survives restart/clock rollback");
        check(savedInfinite.open(false,now+2000,infiniteTicket,0,UUID.randomUUID()).duplicate(),"repeat Infinite Cases does not create a fresh reward");
        check(savedInfinite.remaining(false,now+CaseLedger.WINDOW*2)==Integer.MAX_VALUE,"unlimited survives ordinary refill boundaries and Premium expiry");
        var legacy=new CaseLedger(account);legacy.owned.add(CaseReward.WINGS);legacy.wings=true;var migrated=CaseLedger.decode(legacy.encode(),account);check(migrated.wings&&!migrated.unlimited(),"existing equipped wings migrate without gaining or losing rewards");
        for(int line=0;line<CaseReward.MISS_LINES.length;line++)check(!CaseReward.MISS_LINES[line].isBlank(),"six failure captions");check(CaseReward.MISS_LINES.length==6,"caption count");
        System.out.println("PASS exact reward distribution, member/premium caps, upgrade/expiry, restart/rollback, 12-hour boundary, nonstacking refills, duplicates, manual claim IDs and independent draw transactions");
    }
}
