package client.astra;

public final class WordleRevealTest {
    private static void check(boolean b,String message){if(!b)throw new AssertionError(message);}
    public static void main(String[] args){
        long start=1_000_000_000L;var reveal=new WordleReveal();check(!reveal.moving(start,true),"Existing saved rows start settled");reveal.start(2,start);
        for(int fps:new int[]{20,60,144})for(int i=0;i<fps*2;i++){
            long now=start+(long)(i*1e9/fps);double seconds=(now-start)/1e9;
            for(int col=0;col<5;col++){float scale=reveal.scale(2,col,now,true);check(scale>=.04f&&scale<=1,"Bounded tile flip");check(reveal.colourVisible(2,col,now,true)==(seconds>=col*WordleReveal.STAGGER+WordleReveal.FLIP/2),"Staggered feedback midpoint");check(reveal.colourVisible(1,col,now,true),"Earlier rows unchanged");}
            check(reveal.visibleRows(3,now,true)==(seconds<WordleReveal.DURATION?2:3),"Keyboard feedback waits for row");
        }
        check(!reveal.moving(start,false)&&reveal.colourVisible(2,4,start,false)&&reveal.scale(2,4,start,false)==1,"Reduced motion reveals immediately");
        reveal.reset();check(!reveal.moving(start,true),"New word reset");
        String[] argsOut=BrowserOptions.secure(new String[]{"--disable-web-security","--enable-widevine-cdm","--autoplay-policy=no-user-gesture-required","--safe-option"});
        check(java.util.Arrays.asList(argsOut).contains("--safe-option")&&!java.util.Arrays.asList(argsOut).contains("--disable-web-security"),"Browser web security remains enabled");
        for(String url:new String[]{"https://krillion.io/","https://www.krillion.io/play","https://play.krillion.io/"})check(BrowserOptions.gameUrl(url),"Genuine game origins");
        for(String url:new String[]{"http://krillion.io/","https://krillion.io.evil.example/","file:///tmp/test","javascript:alert(1)","not a URL"})check(!BrowserOptions.gameUrl(url),"Other navigation is not a trusted game origin");
        System.out.println("PASS staggered Wordle tile/keyboard reveals at20/60/144fps, bounds, reduced motion and reset; secure browser arguments and exact HTTPS game-origin routing");
    }
}
