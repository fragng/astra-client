package client.astra;

import java.nio.ByteBuffer;
import java.util.concurrent.atomic.AtomicReference;
import org.lwjgl.glfw.GLFW;

public final class BrowserBridgeTest {
    private static void check(boolean b,String message){if(!b)throw new AssertionError(message);}
    public static void main(String[] args)throws Exception{
        var sourceComponent=new java.awt.Component(){};
        for(boolean pressed:new boolean[]{true,false})for(int key:new int[]{GLFW.GLFW_KEY_ENTER,GLFW.GLFW_KEY_BACKSPACE,GLFW.GLFW_KEY_DELETE,GLFW.GLFW_KEY_A}){
            var event=BrowserInput.event(sourceComponent,pressed,key,0x153,GLFW.GLFW_MOD_CONTROL,false);
            check(event.getClass().getDeclaredField("scancode").getLong(event)==0x153,"JCEF runtime-class lookup retains Windows scan code without opening JDK modules");
            check(event.isControlDown()&&event.getID()==(pressed?java.awt.event.KeyEvent.KEY_PRESSED:java.awt.event.KeyEvent.KEY_RELEASED),"Native press/release and modifier state preserved");
        }
        check(BrowserInput.event(sourceComponent,true,GLFW.GLFW_KEY_HOME,0,0,true).getKeyChar()==0xFF50,"Linux Home uses its native X keysym rather than a printable number");
        check(BrowserInput.controlCharacter(GLFW.GLFW_KEY_ENTER)==13 && BrowserInput.controlCharacter(GLFW.GLFW_KEY_KP_ENTER)==13,"Both Enter keys deliver carriage return");
        check(BrowserInput.controlCharacter(GLFW.GLFW_KEY_BACKSPACE)==8 && BrowserInput.controlCharacter(GLFW.GLFW_KEY_DELETE)==127,"Editing characters");
        check(BrowserInput.controlCharacter(GLFW.GLFW_KEY_TAB)==9 && BrowserInput.controlCharacter(GLFW.GLFW_KEY_A)==-1,"Tab without duplicate ordinary text");
        for(int[] size:new int[][]{{3840,2160,1},{1920,1080,2},{7680,1440,1},{640,480,1},{320,240,4}}){
            var v=BrowserViewport.fit(size[0],size[1],size[2]);check(v.width()>0 && v.width()<=1280 && v.height()>0 && v.height()<=800,"Bounded Chromium resolution");
            check(v.x(size[0],size[0])==v.width() && v.y(size[1],size[1])==v.height(),"Scaled pointer reaches bottom/right");
            check(Math.abs(v.width()/(double)v.height()-size[0]/(double)size[1])<.02,"Aspect ratio preserved");
        }
        var frames=new BrowserFrames();var source=ByteBuffer.allocate(16);
        for(int i=0;i<10_000;i++){source.putInt(0,i);frames.publish(source,2,2);}
        var latest=frames.take();check(latest.pixels().getInt(0)==9999 && frames.allocations()==1 && frames.consumed()==1,"A render stall keeps one newest frame, not ten thousand queued uploads");
        for(int i=0;i<1000;i++){source.putInt(0,i);frames.publish(source,2,2);check(frames.take().pixels().getInt(0)==i,"Reuse preserves current paint");}
        check(frames.allocations()==2,"Two reusable buffers in steady state");
        check(source.position()==0 && source.limit()==16 && frames.take()==null,"Source untouched; unchanged textures need no upload");
        frames.publish(source,9999,9999);frames.publish(ByteBuffer.allocate(1),2,2);check(frames.take()==null,"Malformed/oversized paints rejected");
        var failure=new AtomicReference<Throwable>();var concurrent=new BrowserFrames();
        var producer=new Thread(()->{try{var b=ByteBuffer.allocate(16);for(int i=0;i<20_000;i++){for(int n=0;n<4;n++)b.putInt(n*4,i);concurrent.publish(b,2,2);}}catch(Throwable e){failure.set(e);}});
        producer.start();while(producer.isAlive()){var f=concurrent.take();if(f!=null){int value=f.pixels().getInt(0);for(int i=1;i<4;i++)check(f.pixels().getInt(i*4)==value,"CEF paint cannot mutate the uploading buffer");}}
        producer.join();check(failure.get()==null && concurrent.allocations()<=2,"Concurrent paints bounded");
        concurrent.close();concurrent.publish(source,2,2);check(concurrent.take()==null,"Late paints ignored after close");frames.close();
        System.out.println("PASS browser editing control characters, 4K/ultrawide pointer mapping and pixel bounds; latest-frame coalescing, two staging allocations, concurrent ownership and safe late close");
    }
}
