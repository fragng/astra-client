package client.astra;

public final class CharacterReleaseTest {
    private static void check(boolean ok,String reason){if(!ok)throw new AssertionError(reason);}
    public static void main(String[] args){
        long start=CharacterRelease.START,end=CharacterRelease.READY;
        check(CharacterRelease.progress(start-1)==0 && CharacterRelease.progress(start)==0,"progress starts at zero");
        check(Math.abs(CharacterRelease.progress(start+(end-start)/2)-.5)<.00001,"calendar midpoint is half filled");
        check(CharacterRelease.progress(end)==1 && CharacterRelease.progress(end+86400000)==1,"progress capped after release");
        check(!CharacterRelease.available(end-1) && CharacterRelease.available(end),"unlock precisely 15 December midnight London/GMT");
        for(var style:CharacterStyle.values()){check(CharacterRelease.effective(style,end-1)==CharacterStyle.NONE,"saved characters suppressed before release");check(CharacterRelease.effective(style,end)==style,"saved selections restored when ready");}
        double previous=0;for(int i=0;i<=10000;i++){double value=CharacterRelease.progress(start+(end-start)*i/10000);check(value>=previous && value>=0 && value<=1,"bounded monotonic progress");previous=value;}
        System.out.println("PASS release date, before/after boundaries, zero/half/full calendar progress, 10001 monotonic samples and all saved-character gates");
    }
}
