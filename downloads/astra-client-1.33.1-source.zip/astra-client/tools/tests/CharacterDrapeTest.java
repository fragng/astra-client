package client.astra;
public final class CharacterDrapeTest {
 private static void check(boolean ok,String message){if(!ok)throw new AssertionError(message);}
 public static void main(String[] args){
  var source=CharacterMesh.build(-2,-1,-.1f,4,2,.2f,.8,0,false,.1);
  var flat=CharacterSurface.drape(source,-2,-1,4,2,new float[][]{{1,1},{1,1}});
  var slope=CharacterSurface.drape(source,-2,-1,4,2,new float[][]{{0,2},{0,2}});
  var a=source.vertices();var b=flat.vertices();var c=slope.vertices();
  for(int i=0;i<a.length;i+=6){
   check(a[i]==b[i] && a[i+1]==b[i+1],"no face stretch");check(Math.abs(b[i+2]-a[i+2]-1)<.00001,"closed patch translated exactly");
   check(Math.abs(c[i+2]-a[i+2]-(a[i]+2)*.5)<.00001,"skin slope follows surface");
   double n=c[i+3]*c[i+3]+c[i+4]*c[i+4]+c[i+5]*c[i+5];check(Math.abs(n-1)<.00001,"smooth unit normals after bend");
   double nx=a[i+3]-.5*a[i+5],ny=a[i+4],nz=a[i+5],length=Math.sqrt(nx*nx+ny*ny+nz*nz);
   check(Math.abs(c[i+3]-nx/length)<.00001 && Math.abs(c[i+4]-ny/length)<.00001 && Math.abs(c[i+5]-nz/length)<.00001,"normals follow inverse-transpose surface slope");
   check(c[i+2]>=slope.minZ() && c[i+2]<=slope.maxZ(),"draped geometry bounds include vertices");
  }
  check(source.vertices()!=slope.vertices(),"shared source mesh unchanged");
  System.out.println("PASS facial patch contact, unchanged X/Y, transformed unit normals, correct bounds and immutable source geometry");
 }
}
