package client.astra;
import java.util.*;
public final class CaseMeshTest {
 private static void check(boolean ok,String reason){if(!ok)throw new AssertionError(reason);}
 public static void main(String[] args){
  var meshes=List.of(CaseMesh.ring(6,-9,.2),CaseMesh.tube(CaseMesh.p(0,0,0),CaseMesh.p(1,3,.2),CaseMesh.p(4,4,.8),CaseMesh.p(5,6,1),.3,.07,false,0),CaseMesh.tube(CaseMesh.p(0,0,0),CaseMesh.p(2,1,.2),CaseMesh.p(6,-2,.3),CaseMesh.p(7,-3,0),.18,.02,true,.7));
  for(var mesh:meshes){var v=mesh.vertices();check(v.length>100&&v.length%24==0,"complete quad mesh");check(mesh.maxZ()>mesh.minZ()&&mesh.maxY()>mesh.minY(),"solid curved volume");for(int i=0;i<v.length;i+=6){for(int k=0;k<6;k++)check(Float.isFinite(v[i+k]),"finite geometry");double length=v[i+3]*v[i+3]+v[i+4]*v[i+4]+v[i+5]*v[i+5];check(Math.abs(length-1)<.0001,"unit shading normals");check(v[i]>=mesh.minX()&&v[i]<=mesh.maxX()&&v[i+1]>=mesh.minY()&&v[i+1]<=mesh.maxY()&&v[i+2]>=mesh.minZ()&&v[i+2]<=mesh.maxZ(),"bounds contain geometry");}}
  var crown=CaseCosmeticMeshes.crown();var wings=CaseCosmeticMeshes.wings();check(crown.hasChild("gold")&&crown.hasChild("gems")&&crown.hasChild("glints"),"gold filigree/cyan gem groups");check(wings.hasChild("left")&&wings.hasChild("right")&&wings.getChild("left").hasChild("cream"),"independent feather/material groups");
  double previous=WingMotion.sample(0,78,true).fold();double low=1,high=0;
  for(int i=1;i<=100000;i++){double ticks=i*.02;var motion=WingMotion.sample(ticks,78,true);check(motion.fold()>=.19&&motion.fold()<.65,"wings always fold behind the body");check(Math.abs(motion.fold()-previous)<.003,"continuous motion across burst and cycle boundaries");low=Math.min(low,motion.fold());high=Math.max(high,motion.fold());previous=motion.fold();}
  check(high-low>.25,"occasional visible flap bursts");check(!WingMotion.sample(95,78,true).equals(WingMotion.sample(95,79,true)),"player-specific irregular timing");check(WingMotion.sample(0,78,false).equals(WingMotion.sample(1000,79,false)),"animation/performance preference freezes a safe resting pose");
  System.out.println("PASS closed curved ring/tubes/feathers, finite unit normals, actual gold/gem and feather model groups and bounded geometry");
 }
}
