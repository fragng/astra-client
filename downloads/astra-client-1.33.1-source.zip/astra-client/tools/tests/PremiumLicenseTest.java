package client.astra;

import com.google.gson.*;
import java.security.*;
import java.util.*;

public final class PremiumLicenseTest {
    private static void check(boolean ok,String reason){if(!ok)throw new AssertionError(reason);}
    public static void main(String[] args)throws Exception{
        var keys=KeyPairGenerator.getInstance("Ed25519").generateKeyPair();var other=KeyPairGenerator.getInstance("Ed25519").generateKeyPair();
        long issued=1_795_400_000_000L;UUID account=UUID.randomUUID(),stranger=UUID.randomUUID();
        var grant=new PremiumLicense.Grant(PremiumLicense.fingerprint(account),"ExamplePlayer",UUID.randomUUID(),issued,issued+PremiumLicense.PERIOD);
        String text=PremiumLicense.issue(grant,keys.getPrivate());
        check(PremiumLicense.verify(text,keys.getPublic(),account,issued).status()==PremiumLicense.Status.ACTIVE,"assigned account activates");
        check(PremiumLicense.verify(text,keys.getPublic(),stranger,issued).status()==PremiumLicense.Status.WRONG_ACCOUNT,"copy on another account rejected");
        check(PremiumLicense.verify(text,other.getPublic(),account,issued).status()==PremiumLicense.Status.INVALID,"untrusted issuer rejected");
        check(PremiumLicense.verify(PremiumLicense.issue(grant,other.getPrivate()),keys.getPublic(),account,issued).status()==PremiumLicense.Status.INVALID,"foreign private key rejected");
        check(PremiumLicense.verify(text,keys.getPublic(),account,grant.expiresAt()-1).status()==PremiumLicense.Status.ACTIVE,"last licensed millisecond");
        check(PremiumLicense.verify(text,keys.getPublic(),account,grant.expiresAt()).status()==PremiumLicense.Status.EXPIRED,"fixed expiry boundary");
        check(PremiumLicense.verify(text,keys.getPublic(),account,issued-300_001).status()==PremiumLicense.Status.NOT_YET_VALID,"future grant rejected");
        check(PremiumLicense.verify(null,keys.getPublic(),account,issued).status()==PremiumLicense.Status.UNLICENSED,"edition flag alone never activates");
        for(String field:new String[]{"name","accountHash","serial","issuedAt","expiresAt","schema","signature"}){
            var j=JsonParser.parseString(text).getAsJsonObject();
            switch(field){case "name"->j.addProperty(field,"OtherName");case "accountHash"->j.addProperty(field,PremiumLicense.fingerprint(UUID.randomUUID()));case "serial"->j.addProperty(field,UUID.randomUUID().toString());case "issuedAt","expiresAt"->j.addProperty(field,j.get(field).getAsLong()+86400000);case "schema"->j.addProperty(field,3);default->j.addProperty(field,"invalid");}
            check(PremiumLicense.verify(j.toString(),keys.getPublic(),account,issued).status()==PremiumLicense.Status.INVALID,"tampered "+field+" rejected");
        }
        for(String malformed:new String[]{"", "[]", "{}", "not json", "x".repeat(16385)})check(PremiumLicense.verify(malformed,keys.getPublic(),account,issued).status()==PremiumLicense.Status.INVALID,"malformed grant fails closed");
        var next=new PremiumLicense.Grant(PremiumLicense.fingerprint(account),"RenamedPlayer",UUID.randomUUID(),issued+86400000,issued+86400000+PremiumLicense.PERIOD);
        check(!next.serial().equals(grant.serial()) && next.expiresAt()>grant.expiresAt(),"fresh file gets fresh fixed period");
        check(PremiumLicense.verify(PremiumLicense.issue(next,keys.getPrivate()),keys.getPublic(),account,next.issuedAt()).status()==PremiumLicense.Status.ACTIVE,"UUID keeps working with renamed account");
        check(PremiumLicense.verify(text,keys.getPublic(),account,grant.expiresAt()).status()==PremiumLicense.Status.EXPIRED,"new issuance does not alter old expiry");
        check(!PremiumLicense.owner(stranger) && !PremiumLicense.owner(null),"owner UUID boundary");
        for(String invalid:new String[]{"../ExamplePlayer","Jack J25","ab","a".repeat(17),"Jack;test"})check(!PremiumLicense.username(invalid),"username/filename validation");
        var profile=PremiumIssuer.parseProfile("{\"id\":\"12345678123442349234123456781234\",\"name\":\"ExamplePlayer\"}","exampleplayer");check(profile.id().equals(UUID.fromString("12345678-1234-4234-9234-123456781234")),"official canonical UUID parsed");
        try{PremiumIssuer.parseProfile("{\"id\":\"12345678123442349234123456781234\",\"name\":\"OtherName\"}","ExamplePlayer");throw new AssertionError("wrong lookup name accepted");}catch(IllegalArgumentException expected){}
        var lifetime=new PremiumLicense.Grant(PremiumLicense.fingerprint(account),"ExamplePlayer",UUID.randomUUID(),issued,Long.MAX_VALUE);
        check(PremiumLicense.verify(PremiumLicense.issue(lifetime,keys.getPrivate()),keys.getPublic(),account,issued+100L*365*86400000).status()==PremiumLicense.Status.ACTIVE,"signed lifetime grant remains active");
        var forgedLifetime=JsonParser.parseString(text).getAsJsonObject();forgedLifetime.addProperty("expiresAt",Long.MAX_VALUE);check(PremiumLicense.verify(forgedLifetime.toString(),keys.getPublic(),account,issued).status()==PremiumLicense.Status.INVALID,"editing a monthly grant cannot make it lifetime");
        check(Arrays.equals(PremiumLicense.publicKey(keys.getPublic().getEncoded()).getEncoded(),keys.getPublic().getEncoded()),"public DER roundtrip");
        check(Arrays.equals(PremiumLicense.privateKey(keys.getPrivate().getEncoded()).getEncoded(),keys.getPrivate().getEncoded()),"private DER roundtrip");
        System.out.println("PASS signed account/issuer binding, every tampered field, malformed input, expiry/future boundaries, renewal and name changes, owner/username guards and official profile parsing");
    }
}
