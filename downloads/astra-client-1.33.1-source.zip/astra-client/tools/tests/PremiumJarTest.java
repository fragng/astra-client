package client.astra;

import java.nio.file.*;
import java.nio.charset.StandardCharsets;
import java.security.*;
import java.util.*;
import java.util.jar.*;

public final class PremiumJarTest {
    private static void check(boolean ok,String reason){if(!ok)throw new AssertionError(reason);}
    private static void put(JarOutputStream out,String name,String text)throws Exception{out.putNextEntry(new JarEntry(name));out.write(text.getBytes(StandardCharsets.UTF_8));out.closeEntry();}
    public static void main(String[] args)throws Exception{
        Path folder=Files.createTempDirectory("astra-license-test-");
        try{
            Path base=folder.resolve("base.jar"),output=folder.resolve("issued.jar");
            try(var out=new JarOutputStream(Files.newOutputStream(base))){put(out,"fabric.mod.json","{\"id\":\"astra-client\",\"version\":\"1.27.0\"}");put(out,"astra-edition.json","{\"premium\":false}");put(out,PremiumJar.LICENSE,"old grant");put(out,"assets/example.bin","unchanged asset");put(out,"META-INF/OLD.SF","stale jar signature");put(out,"META-INF/jars/freelook.jar","unchanged dependency");}
            byte[] original=Files.readAllBytes(base);var key=KeyPairGenerator.getInstance("Ed25519").generateKeyPair();long now=System.currentTimeMillis();UUID user=UUID.randomUUID();String license=PremiumLicense.issue(new PremiumLicense.Grant(PremiumLicense.fingerprint(user),"ExamplePlayer",UUID.randomUUID(),now,now+PremiumLicense.PERIOD),key.getPrivate());
            PremiumJar.write(base,output,license);
            try(var jar=new JarFile(output.toFile())){
                check(Arrays.equals(jar.getInputStream(jar.getEntry("assets/example.bin")).readAllBytes(),"unchanged asset".getBytes(StandardCharsets.UTF_8)),"assets copied intact");
                check(jar.getEntry("META-INF/OLD.SF")==null,"stale signature not copied");check(jar.getEntry("META-INF/jars/freelook.jar")!=null,"dependency retained");
                String saved=new String(jar.getInputStream(jar.getEntry(PremiumJar.LICENSE)).readAllBytes(),StandardCharsets.UTF_8);check(saved.equals(license),"fresh grant embedded exactly");check(PremiumLicense.verify(saved,key.getPublic(),user,now).status()==PremiumLicense.Status.ACTIVE,"produced file activates for recipient");check(PremiumLicense.verify(saved,key.getPublic(),UUID.randomUUID(),now).status()==PremiumLicense.Status.WRONG_ACCOUNT,"produced file rejects sharing to another account");
                var meta=new String(jar.getInputStream(jar.getEntry("fabric.mod.json")).readAllBytes(),StandardCharsets.UTF_8);check(meta.contains("1.27.0-premium"),"edition version updated");check(jar.stream().noneMatch(e->e.getName().contains("issuer.pk8")),"private key never included");
            }
            check(Arrays.equals(original,Files.readAllBytes(base)),"installed jar unchanged");byte[] issued=Files.readAllBytes(output);
            try{PremiumJar.write(base,output,license);throw new AssertionError("existing export overwritten");}catch(FileAlreadyExistsException expected){}check(Arrays.equals(issued,Files.readAllBytes(output)),"previous export preserved");
            try{PremiumJar.write(folder,folder.resolve("bad.jar"),license);throw new AssertionError("dev directory accepted");}catch(java.io.IOException expected){}
            try(var files=Files.list(folder)){check(files.noneMatch(p->p.getFileName().toString().endsWith(".tmp")),"temporary exports cleaned");}
            System.out.println("PASS actual grant JAR creation, private-key exclusion, recipient binding, unchanged assets/dependency/base, stale signature removal, no overwrite and failure cleanup");
        }finally{try(var paths=Files.walk(folder)){for(Path p:paths.sorted(Comparator.reverseOrder()).toList())Files.deleteIfExists(p);}}
    }
}
