package client.astra;

import java.util.*;

public final class CaseSpinTest {
    private static void check(boolean ok,String message){if(!ok)throw new AssertionError(message);}
    public static void main(String[] args){
        long start=1_000_000_000_000L;
        for(var reward:CaseReward.values())for(int i=0;i<100;i++){
            var draw=new CaseLedger.Draw(new UUID(17L*i+reward.ordinal(),91L*i),reward,1_800_000_000_000L,0,false);var spin=new CaseSpin(draw,start);double before=spin.position(start,true);
            check(new HashSet<>(spin.cards).size()>=6,"varied reward previews independent of outcome weights");
            check(spin.landing()==CaseSpin.LAND && spin.cards.get(spin.landing())==reward,"visual outcome equals committed reward");
            check(spin.cardAt(start,true)!=spin.landing(),"opening starts away from the committed landing");
            check(spin.position(start+400_000_000L,true)>before,"reel visibly scrolls before landing");
            for(int frame=0;frame<=240;frame++){long now=start+(long)(CaseSpin.SECONDS*1e9*frame/240);double p=spin.position(now,true);check(p>=before&&p<CaseSpin.SIZE,"bounded smooth forward reel");before=p;}
            check(!spin.finished(start+(long)(CaseSpin.SECONDS*1e9)-1)&&spin.finished(start+(long)(CaseSpin.SECONDS*1e9)),"frame-independent completion");
            check(spin.cardAt(start+(long)(CaseSpin.ROLL_SECONDS*1e9),true)==spin.landing()&&!spin.finished(start+(long)(CaseSpin.ROLL_SECONDS*1e9)),"prize visible under centre marker before reveal");
            check(spin.position(start,false)==spin.position(start+(long)(CaseSpin.SECONDS*1e9),false),"reduced motion stays still");
            var restored=CaseSpin.restore(draw,start+(long)(CaseSpin.SECONDS*1e9),draw.at()+5000);check(restored.finished(start+(long)(CaseSpin.SECONDS*1e9)) && restored.cards.equals(spin.cards),"saved result restores the identical winning reel");
            check((int)Math.floor(spin.position(start+(long)(CaseSpin.SECONDS*1e9),true)+.5)==spin.landing(),"red line lands inside the prize card");
        }
        check(CaseSpin.AUTO_SECONDS==CaseSpin.SECONDS*10,"auto start-to-start cadence");
        check(CaseSpin.SECONDS==4.5 && CaseSpin.ROLL_SECONDS<CaseSpin.SECONDS,"longer opening with a readable settled landing");
        System.out.println("PASS 800 committed outcomes and 192800 reel frames: accurate centre landing, stable cadence, monotonic easing, exact completion and reduced motion");
    }
}
