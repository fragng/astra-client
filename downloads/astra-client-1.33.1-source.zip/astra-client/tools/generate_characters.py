"""Author original rounded character surfaces, swatch atlas and sidebar icon.
All geometry is authored here; no photograph, skin or downloaded model is bundled.
Run with Python 3 (stdlib only).
"""
from pathlib import Path
import json,struct,zlib
ROOT=Path(__file__).resolve().parents[1]/'src/main/resources/assets/astra-client'
COLORS={'yellow':'F5D53C','sponge_shadow':'C5A226','white':'FFF8E9','black':'171A20','blue':'53A9ED','pink':'ED97AD','brown':'8B542E','red':'D43732','dark_red':'9B2928','cream':'F5D5A2','green':'A5D55C','purple':'A168BB','aqua':'87B7A7','aqua_dark':'568C83','eye_red':'9D4A37','shirt_brown':'A97C42','krab_red':'D74C46','light_blue':'A0CFE6','pants_blue':'647DAE','belt':'513E36','gold':'F5CE59','sandy_brown':'A87546','sandy_light':'C99C65','suit':'E7E6DF','suit_shadow':'A5ADB5','glass':'B9E5EC24','glass_edge':'9AC5D6','flower':'ED80C2','skin':'D9B7A2','skin_shadow':'B58F7B','hair':'4D372A','hair_light':'6D5140','denim':'344C6A','shoe':'34363E','sole':'DBDED9','mouth':'813B32','sock_blue':'72A8CA','headset':'272932','headset_trim':'4C5362','sweat':'9CDDF4C9','inner_mouth':'49232C','seam':'D1CAC1','hoodie':'15191E','hoodie_light':'242A30','hoodie_shadow':'0B1015','hoodie_stitch':'343C43','eye_brown':'654B38','aqua_crease':'79A99B'}
names=list(COLORS);palette=[COLORS[n] for n in names];assert len(palette)<=64
models={}
PIVOTS={'head':[0,0,0],'body':[0,0,0],'right_arm':[-5,2,0],'left_arm':[5,2,0],'right_leg':[-1.9,12,0],'left_leg':[1.9,12,0]}
def actor(name,spread=5,head_y=0):
 parts={n:{'pivot':list(p),'boxes':[]} for n,p in PIVOTS.items()};parts['head']['pivot'][1]=head_y;parts['right_arm']['pivot'][0]=-spread;parts['left_arm']['pivot'][0]=spread
 models[name]={'parts':parts};return parts
def box(parts,bone,x,y,z,w,h,d,color,power=.35,taper=0,ring=False,band=.28):
 assert min(w,h,d)>0
 parts[bone]['boxes'].append({'from':[x,y,z],'size':[w,h,d],'color':names.index(color),'power':power,**({'taper':taper} if taper else {}),**({'ring':True,'band':band} if ring else {})})
def global_head(p,x,y,z,w,h,d,c,power=.8,taper=0,ring=False,band=.28):box(p,'head',x,y-p['head']['pivot'][1],z,w,h,d,c,power,taper,ring,band)
def detail(p,name,x,y,z,w,h,d,color,effect):
 p['head'].setdefault('details',[]).append({'name':name,'position':[x,y-p['head']['pivot'][1],z],'from':[0,0,0],'size':[w,h,d],'color':names.index(color),'power':1,'taper':.55 if effect=='sweat' else 0,'effect':effect,'glintColor':names.index('white')})
def eye(p,x,y,z,w=3,h=3,iris='black'):
 global_head(p,x,y,z,w,h,.75,'white',1);global_head(p,x+w*.35,y+h*.25,z-.22,w*.34,h*.55,.4,iris,1);global_head(p,x+w*.42,y+h*.3,z-.3,w*.12,h*.16,.14,'white',1)
 detail(p,'lid_'+str(len(p['head'].get('details',[]))),x,y,z-.7,w,h,.18,'skin','lid')
def limb_pair(p,bone,y,h,w,d,c):
 for side in ['right','left']:box(p,side+'_'+bone,-w/2,y,-d/2,w,h,d,c,.85)
# SpongeBob: projecting eyes/nose/teeth, porous square sponge, shirt/shorts and shoes.
p=actor('spongebob',8,5);global_head(p,-7,-7,-3,14,12,6,'yellow',.19)
sponge=p['head']['boxes'][0];sponge.update(detail=48,material='sponge',pores=[[x,y-5,r,d] for x,y,r,d in [(-5.8,-5.3,.62,.28),(5.5,-5.1,.7,.3),(-5.5,.4,.55,.26),(5.4,2.8,.7,.32),(-3.9,3.2,.55,.25),(3.3,3.7,.46,.22),(-5.8,-2.3,.35,.17),(5.8,-1.5,.38,.17)]])
for x in [-6.5,5.2]:
 for y in [-5,0]:global_head(p,x,y,2.8,1.2,1.5,.35,'sponge_shadow')
for x in [-4.7,.7]:
 detail(p,'lid_'+str(x),x,-5,-4.8,4,4.7,.18,'yellow','lid')
 global_head(p,x,-5,-3.5,4,4.7,1.25,'white',1);global_head(p,x+.9,-4,-4.1,2.2,2.5,.85,'blue',1);global_head(p,x+1.5,-3.7,-4.5,1,1.7,.6,'black',1);global_head(p,x+1.55,-3.7,-4.57,.3,.4,.15,'white',1)
 for dx in [.4,1.8,3.2]:global_head(p,x+dx,-6,-3.4,.45,1.3,.45,'black')
for x in [-5.1,3.5]:global_head(p,x,-.3,-3.42,1.6,1,.45,'cream',1)
global_head(p,-.85,-2.4,-5,1.7,3,2.2,'yellow',1);global_head(p,-3,1,-3.3,6,1.6,.4,'mouth')
for x in [-1.9,.2]:global_head(p,x,1.2,-3.8,1.7,1.9,.82,'white')
box(p,'body',-7,4.3,-3,14,3,6,'white');box(p,'body',-7,6.7,-3,14,5.6,6,'brown');box(p,'body',-.65,5.4,-3.4,1.3,3.4,.45,'red')
for x in [-5,-1.5,2]:box(p,'body',x,8,-3.2,2.5,.5,.3,'black')
limb_pair(p,'arm',0,9,1.6,1.6,'yellow')
for side in ['right','left']:
 a=side+'_arm';box(p,a,-1.7,8,-1.3,3.4,2.3,2.6,'yellow',.8)
 for x in [-1.8,-.5,.8]:box(p,a,x,9.5,-1,1,2.3,1.2,'yellow',.85)
 l=side+'_leg';box(p,l,-.9,0,-.9,1.8,7,1.8,'yellow',.9);box(p,l,-1.1,6,-1.1,2.2,4.5,2.2,'white');box(p,l,-1.15,7,-1.15,2.3,.45,2.3,'red');box(p,l,-1.15,8,-1.15,2.3,.45,2.3,'sock_blue');box(p,l,-1.9,10,-3.1,3.8,2,5,'black',.75)
# DrDonutt: supplied photo reference, black pullover hoodie, short brown fringe, natural face.
p=actor('drdonutt',5)
global_head(p,-2.85,-6.7,-2.8,5.7,6.7,5.5,'skin',.68,-.12)
# Neck and small ears are part of the head, so turning never pulls them away.
global_head(p,-1.15,-.9,-1,2.3,2.3,2.2,'skin',.75)
for x in [-3.12,2.6]:
 global_head(p,x,-4.1,-.7,.55,1.25,.9,'skin',.85)
 global_head(p,x+.12,-3.85,-.77,.3,.7,.16,'skin_shadow',1)
# One fitted scalp with overlapping, smaller swept fringe locks; no headphones.
global_head(p,-2.98,-7.25,-2.6,5.96,2.65,5.45,'hair',.64)
for x,y,z,w,h,d in [(-2.9,-6.7,-2.9,1.2,1.8,1.3),(-1.95,-7.05,-3,1.35,1.65,1.4),(-.85,-7.2,-2.98,1.4,1.7,1.4),(.3,-7.02,-2.9,1.35,1.75,1.3),(1.45,-6.75,-2.7,1.3,1.7,1.15)]:
 global_head(p,x,y,z,w,h,d,'hair_light' if x in [-1.95,.3] else 'hair',.8,.15)
for x in [-2.9,2.45]:global_head(p,x,-5.9,-.6,.5,2.4,2.8,'hair',.75)
# Smaller, inset human eyes, warm eyebrows, nose bridge and a restrained smile.
for x in [-1.95,.65]:
 global_head(p,x,-4.4,-2.92,1.3,.65,.24,'white',1)
 global_head(p,x+.42,-4.37,-3.08,.46,.57,.18,'eye_brown',1)
 global_head(p,x+.54,-4.3,-3.16,.22,.39,.12,'black',1)
 global_head(p,x+.55,-4.33,-3.22,.095,.13,.06,'white',1)
 detail(p,'lid_'+str(x),x,-4.4,-3.27,1.3,.65,.12,'skin','lid')
 global_head(p,x-.05,-4.98,-2.95,1.38,.19,.16,'hair',.8)
global_head(p,-.28,-4.15,-3.12,.56,1.5,.64,'skin',.8)
global_head(p,-.42,-2.85,-3.35,.84,.48,.45,'skin',1)
for x in [-.48,.22]:global_head(p,x,-2.57,-3.37,.25,.1,.08,'skin_shadow',1)
for x,y,w in [(-.96,-1.83,.65),(-.35,-1.68,.7),(.3,-1.83,.65)]:global_head(p,x,y,-2.96,w,.13,.1,'mouth',.8)
global_head(p,-.55,-1.76,-3.02,1.1,.16,.07,'white',.7)
# Solid pullover with a hood folded behind the neck, soft cuffs, pocket and drawstrings.
box(p,'body',-4.5,0,-2.25,9,12.1,4.8,'hoodie',.32,-.04)
box(p,'body',-3.6,-.4,.3,7.2,4.5,3.1,'hoodie_light',.62)
box(p,'body',-2.1,-.25,-2.4,4.2,1.15,3.8,'hoodie_shadow',.75)
box(p,'body',-2.75,6.5,-2.42,5.5,3.1,.27,'hoodie_light',.5)
for x in [-2.7,2.57]:box(p,'body',x,6.9,-2.46,.13,2.25,.11,'hoodie_stitch',.7)
box(p,'body',-4.35,10.85,-2.3,8.7,1.35,4.8,'hoodie_shadow',.4)
for x in [-1.05,.92]:
 box(p,'body',x,.35,-2.4,.12,3.7,.22,'hoodie_stitch',.9)
 box(p,'body',x-.025,3.75,-2.49,.17,.35,.19,'seam',.7)
# Subtle left-chest stitching; no invented copy of the photograph's unreadable brand.
for i in range(3):box(p,'body',2.2+i*.24,3.5,-2.4,.15,.27,.08,'hoodie_stitch',.8)
for side in ['right','left']:
 a=side+'_arm';box(p,a,-1.7,-1.65,-1.9,3.4,6.5,3.8,'hoodie',.48)
 box(p,a,-1.48,3.35,-1.67,2.96,5.3,3.35,'hoodie',.5)
 box(p,a,-1.5,7.55,-1.72,3,1.15,3.45,'hoodie_shadow',.4)
 box(p,a,-1.35,8.25,-1.6,2.7,1.8,3.1,'skin',.65)
 # A small thumb joins the palm rather than detached finger cubes.
 box(p,a,.9 if side=='right' else -1.58,8.45,-1.25,.65,1.05,1.6,'skin',.85)
 l=side+'_leg';box(p,l,-1.96,-.65,-1.95,3.92,10.8,3.9,'denim',.34)
 box(p,l,-2,9.35,-2.85,4,2.45,5.2,'shoe',.5)
 box(p,l,-2,11.15,-2.88,4,.64,5.25,'sole',.45)
# Patrick: tapered star head, rounded belly, lime shorts and purple flower patches.
p=actor('patrick',7)
global_head(p,-2.7,-8.5,-2.6,5.4,10,5.2,'pink',1,.62)
eye(p,-2.4,-3,-3.4,2,2.7);eye(p,.4,-3,-3.4,2,2.7);global_head(p,-1.5,.2,-3.2,3,.45,.4,'mouth')
box(p,'body',-6.9,-1.3,-4,13.8,13.3,8,'pink',1,.18)
box(p,'body',-6.9,7.6,-4.15,13.8,6.2,8.3,'green',.38,-.16)
for x,y in [(-5,9),(-1,8.8),(3.3,9.6)]:
 box(p,'body',x,y,-4.25,2,1.3,.25,'purple',.8);box(p,'body',x+.6,y-.5,-4.3,.7,2.3,.3,'purple',.8)
for side in ['right','left']:
 a=side+'_arm';box(p,a,-2,-.4,-2,4,11.4,4,'pink',1,-.5)
 l=side+'_leg';box(p,l,-2.2,1.2,-2.1,4.4,8.8,4.2,'pink',1,-.18);box(p,l,-2.5,9,-3.2,5,3,5.3,'pink',1)
# Squidward: smooth bulbous head, drooping dimensional nose, brown polo and tentacles.
p=actor('squidward',5)
global_head(p,-5.5,-8.5,-4,11,7,8,'aqua',1);global_head(p,-4.5,-3.5,-3.4,8.5,4.5,6.8,'aqua',.85)
for x in [-4,-.1]:
 eye(p,x,-3.6,-3.85,3.6,2.8,'eye_red');global_head(p,x,-4,-4.1,3.6,1.4,.45,'aqua_dark')
global_head(p,-1.4,-2.2,-6.8,2.8,6,3.7,'aqua',1)
global_head(p,-3.5,-1.5,-2.8,7,3.3,5.6,'aqua',.8)
global_head(p,-2,.3,-2.9,4,.15,.15,'aqua_crease',.9)
box(p,'body',-1.6,-.65,-1.6,3.2,4.4,3.2,'aqua',.6);box(p,'body',-4,2.6,-2.6,8,10,5.2,'shirt_brown',.45)
box(p,'body',-2.9,10.6,-2,5.8,2.8,4,'aqua',.65)
for side in ['right','left']:
 a=side+'_arm';box(p,a,-1.7,-.5,-1.8,3.4,3.5,3.6,'shirt_brown');box(p,a,-1,2,-1,2,8,2,'aqua',1);box(p,a,-1.7,9,-1.3,3.4,2.5,2.6,'aqua')
 l=side+'_leg';box(p,l,-1.1,-1,-1.1,2.2,11,2.2,'aqua',.9);box(p,l,-1.8,9,-4,3.6,3,5.5,'aqua',1)
# Mr. Krabs: eye stalks, round crab body, belt/trousers and separated solid pincers.
p=actor('mr_krabs',7.4)
global_head(p,-5,-1,-3.5,10,4,7,'krab_red',.85)
for x in [-3.3,1.8]:global_head(p,x,-7.5,-1.2,1.5,7,1.5,'krab_red',1);eye(p,x-.35,-8.5,-1.7,2.2,3.2)
global_head(p,-1.5,0,-4.2,3,1.5,1.4,'krab_red');global_head(p,-3.4,1.5,-3.8,6.8,.6,.45,'mouth')
box(p,'body',-7,2,-4.2,14,8.5,8.4,'light_blue',.8);box(p,'body',-6.6,10,-4,13.2,2.3,8,'pants_blue');box(p,'body',-7,9.4,-4.3,14,1.2,8.6,'belt');box(p,'body',-1.1,9.2,-4.6,2.2,1.6,.45,'gold')
for side in ['right','left']:
 a=side+'_arm';box(p,a,-1.8,-.5,-1.8,3.6,3.5,3.6,'light_blue');box(p,a,-1.4,2,-1.4,2.8,5.5,2.8,'krab_red');box(p,a,-3.1,7,-2.1,6.2,4,4.2,'krab_red',1);box(p,a,-3.1,9,-2.1,2.3,3.2,4.2,'krab_red',.85);box(p,a,.8,9,-2.1,2.3,3.2,4.2,'krab_red',.85)
 l=side+'_leg';box(p,l,-1,0,-1,2,9.5,2,'krab_red',.85);box(p,l,-1.9,9,-3.4,3.8,3,5.4,'krab_red',1)
# Sandy: rounded squirrel, translucent bubble helmet, flower and fluffy tail.
p=actor('sandy',5.4)
global_head(p,-3.8,-6.6,-3.4,7.6,6.9,6.8,'sandy_brown',1)
for x in [-3.7,1.5]:global_head(p,x,-8.1,-1.3,2.2,2.4,1.9,'sandy_brown',1)
eye(p,-2.9,-4.9,-3.9,2.4,2.8);eye(p,.5,-4.9,-3.9,2.4,2.8)
global_head(p,-3.2,-3.1,-3.2,6.4,3.7,5.8,'sandy_brown',.8)
global_head(p,-2,-1.8,-4.5,4,2.1,2,'cream');global_head(p,-.7,-2.2,-5,1.4,1,.7,'black')
# A thin curved rim and transparent dome keep her face visible from every angle.
global_head(p,-5.7,-9,-.1,11.4,11.4,.5,'glass_edge',1,ring=True,band=.2)
for x,y in [(2.7,-7.2),(3.4,-7.5),(4,-6.9),(3.8,-6.2),(3,-6.2)]:global_head(p,x,y,-2.8,.9,.9,.55,'flower',1)
global_head(p,3.25,-6.9,-3.05,.65,.65,.8,'gold',1);box(p,'body',-4.4,0,-2.7,8.8,12,5.4,'suit',.65);box(p,'body',-4.9,0,-3.1,9.8,1.5,6.2,'suit_shadow');box(p,'body',-2,3,-3.2,4,4,.6,'gold');box(p,'body',-.7,3.7,-3.6,1.4,2.5,.6,'sandy_brown');box(p,'body',-4.5,10,-2.8,9,1,5.6,'red')
for x,y,z,w,h,d in [(-2.9,5,2.4,5.8,8,5.5),(-3.3,-1,5.2,6.6,10,5),(-2.4,-3,6.2,4.8,5,3.8)]:box(p,'body',x,y,z,w,h,d,'sandy_brown',1)
for side in ['right','left']:
 a=side+'_arm';box(p,a,-1.8,-2,-1.8,3.6,10.3,3.6,'suit',.8);box(p,a,-2,7,-2,4,1.7,4,'red');box(p,a,-2,7.9,-2,4,2.7,4,'suit_shadow')
 l=side+'_leg';box(p,l,-1.8,0,-1.8,3.6,9,3.6,'suit',.7);box(p,l,-2.1,8,-3,4.2,3.7,5.3,'suit',.8);box(p,l,-2.15,10.8,-3.05,4.3,1.2,5.4,'red')
global_head(p,-5.6,-9,-5.1,11.2,11.3,10.5,'glass',1)
# Lifelike facial details and cached, articulated expression parts.
FACE={
 'spongebob':('yellow',6,-5,-3.2,(-2.5,2.4,-3.48,5,1.9)),
 'drdonutt':('skin',2.05,-3.5,-2.9,(-.85,-1.7,-2.9,1.7,.75)),
 'patrick':('pink',2.25,-2.1,-3.25,(-1.3,.3,-3.45,2.6,1.1)),
 'squidward':('aqua',3.35,-3.1,-3.65,(-1.65,.45,-3.2,3.3,.85)),
 'mr_krabs':('krab_red',3.8,.2,-3.2,(-2.8,1.65,-3.95,5.6,1)),
 'sandy':('sandy_brown',3,-3,-3.5,(-1,-.7,-4.7,2,.6))}
for name,spec in models.items():
 p=spec['parts'];skin,temple,y,z,mouth=FACE[name]
 for d in p['head'].get('details',[]):
  if d['effect']=='lid':d['color']=names.index(skin)
 for i,x in enumerate([-temple,temple-.25,-temple+.6,temple-.8]):detail(p,'sweat_'+str(i),x,y+(i//2)*1.1,z,.34,.82,.22,'sweat','sweat')
 x,y,z,w,h=mouth;detail(p,'talk',x,y,z,w,h,.18,'inner_mouth','mouth')
 # Fine seams add a little structure to clothing without changing silhouettes.
 if name in ['spongebob','squidward','sandy','mr_krabs']:
  for side in ['right','left']:
   if name=='spongebob':
    box(p,side+'_arm',-1.15,-.5,-1.15,2.3,1.8,2.3,'white',.6)
    box(p,side+'_arm',-1,.9,-1.18,2,.11,.1,'seam',.8)
   # Rounded cuff edges supply the seam without detached decorative strips.
 if name=='patrick':
  belly=p['body']['boxes'][0];belly.update(detail=26,pores=[[0,5,.48,.22]])
  for x in [-3.3,2.7]:global_head(p,x,-.9,-3,.5,.25,.16,'mouth',1)
 if name=='squidward':
  pass # Curved, surface-fitted brow creases are authored below.
 if name=='mr_krabs':
  for side in ['right','left']:
   for yy in [4,5.2,6.4]:box(p,side+'_arm',-1.43,yy,-1.43,2.86,.2,2.86,'dark_red',.65)
# Overlapping root cuffs and shoulder volumes stay connected during native limb poses.
for name,spec in models.items():
 p=spec['parts']
 for side in ['right','left']:
  a=side+'_arm';l=side+'_leg'
  if name=='spongebob':box(p,l,-1.45,-.8,-1.35,2.9,2.2,2.7,'brown',.35)
  if name=='patrick':
   box(p,a,-2.5,-.6,-2.0,5,4.0,4,'pink',.8)
   box(p,l,-2.45,-.6,-2.5,4.9,2.65,5,'green',.65)
  if name=='squidward':box(p,a,-1.8,-.4,-1.85,3.6,3.8,3.7,'shirt_brown',.55)
  if name=='mr_krabs':
   box(p,a,-1.9,-.45,-1.85,3.8,3.65,3.7,'light_blue',.5)
   box(p,l,-1.65,-.85,-1.55,3.3,2.5,3.1,'pants_blue',.35)
  if name=='sandy':
   box(p,a,-1.95,-1.6,-1.95,3.9,3.8,3.9,'suit',.65)
   box(p,l,-1.95,-.75,-1.95,3.9,2.4,3.9,'suit',.4)
# Project small face markings onto the curved skin instead of leaving floating strips.
def surface(head,color,xx,yy,rear=False):
 hits=[]
 for b in head['boxes']:
  if b['color']!=names.index(color):continue
  x,y,z=b['from'];w,h,d=b['size'];power=b['power'];qy=(yy-y-h/2)/(h/2);factor=1+b.get('taper',0)*qy
  if factor<=0 or abs(qy)>=1:continue
  qx=(xx-x-w/2)/(w/2*factor);left=1-abs(qx)**(2/power)-abs(qy)**(2/power)
  if left>0:hits.append(z+d/2+(1 if rear else -1)*d/2*left**(power/2)*factor)
 return (max(hits) if rear else min(hits)) if hits else None
p=models['squidward']['parts']
for yy,width in [(-6.3,2.8),(-5.8,3.3),(-5.3,3.6)]:
 for j in range(7):
  xx=-width/2+j*width/7;zz=surface(p['head'],'aqua',xx+width/14,yy+.05)
  if zz is not None:global_head(p,xx,yy,zz-.045,width/7+.06,.095,.09,'aqua_crease',.9)
p=models['sandy']['parts']
for side in [-1,1]:
 for j in range(3):
  xx=side*3.05-.28;yy=-2.2+j*.55;zz=surface(p['head'],'sandy_brown',xx+.28,yy+.2)
  if zz is not None:global_head(p,xx,yy,zz-.12,.56,.43,.32,'sandy_light',.85)
# Bend thin mouths/creases onto the actual skin: no floating face cards.
def conform(head,shape,skin,position=None,bias=.09):
 pos=position or shape['from'];x,y,z=pos;w,h,d=shape['size'];grid=[]
 for row in range(7):
  values=[]
  for column in range(13):
   zz=surface(head,skin,x+w*column/12,y+h*row/6)
   values.append(round((zz-bias-z) if zz is not None else 0,6))
  grid.append(values)
 shape['conform']=grid
for name,spec in models.items():
 head=spec['parts']['head'];skin=FACE[name][0]
 for shape in head['boxes']:
  color=names[shape['color']]
  if color in ['mouth','aqua_crease'] or name=='drdonutt' and color=='hair' and shape['size'][1]<.3:conform(head,shape,skin)
  if name=='drdonutt' and color=='white' and shape['size'][1]<.25 and shape['size'][0]>1:conform(head,shape,skin,bias=.14)
 for shape in head['details']:
  if shape['effect']=='mouth':conform(head,shape,'cream' if name=='sandy' else skin,shape['position'])
# Keep Patrick's flower applique visible and fitted to the reshaped shorts.
body=models['patrick']['parts']['body']
for shape in body['boxes']:
 if names[shape['color']]=='purple':conform(body,shape,'green',bias=.12)
# Sweat follows the actual curved skin silhouette, rather than floating in front of it.
for name,spec in models.items():
 head=spec['parts']['head'];skin=FACE[name][0]
 for d in head['details']:
  if d['effect']!='sweat':continue
  path=[]
  for step in range(9):
   xx=d['position'][0]+d['size'][0]*.5;yy=d['position'][1]+d['size'][1]*.5+step/8*.9;hits=[]
   for b in head['boxes']:
    if b['color']!=names.index(skin):continue
    x,y,z=b['from'];w,h,depth=b['size'];power=b['power'];qy=(yy-y-h/2)/(h/2);factor=1+b.get('taper',0)*qy
    if factor<=0 or abs(qy)>=1:continue
    qx=(xx-x-w/2)/(w/2*factor);left=1-abs(qx)**(2/power)-abs(qy)**(2/power)
    if left>0:hits.append(z+depth/2-depth/2*left**(power/2)*factor)
   path.append(round(min(hits)-.13 if hits else d['position'][2],5))
  d['surfacePath']=path
# Gentle material grain across skin and clothing is baked into cached vertex colours.
for name,spec in models.items():
 for bone,part in spec['parts'].items():
  for shape in part['boxes']:
   color=names[shape['color']]
   if color in ['skin','skin_shadow','pink','aqua','krab_red','sandy_brown']:shape.setdefault('material','skin')
   elif bone!='head' and color in ['white','brown','denim','suit','shirt_brown','light_blue','pants_blue','green','hoodie','hoodie_light','hoodie_shadow','hoodie_stitch']:shape.setdefault('material','fabric')
# Shared solid-color texture atlas: a 64px tile per color accommodates cube UV unfolding.
size=512;scan=bytearray()
for y in range(size):
 scan.append(0)
 for x in range(size):
  i=(y//64)*8+x//64;c=palette[i] if i<len(palette) else 'FFFFFF';scan.extend(bytes.fromhex(c)+(b'\xff' if len(c)==6 else b''))
def chunk(tag,data):return struct.pack('>I',len(data))+tag+data+struct.pack('>I',zlib.crc32(tag+data)&0xffffffff)
png=b'\x89PNG\r\n\x1a\n'+chunk(b'IHDR',struct.pack('>IIBBBBB',size,size,8,6,0,0,0))+chunk(b'IDAT',zlib.compress(scan,9))+chunk(b'IEND',b'')
texture=ROOT/'textures/entity/characters.png';texture.parent.mkdir(parents=True,exist_ok=True);texture.write_bytes(png)
(ROOT/'textures/item/character_palette.png').write_bytes(png)
(ROOT/'characters/models.json').write_text(json.dumps({'palette':palette,'models':models},indent=2)+'\n')
# Matching 3D GUI previews, scaled to fit the native item-model element limits.
def preview(name,parts,icon=False):
 elements=[];bones=['head'] if icon else list(parts)
 for bone in bones:
  part=parts[bone]
  for b in part['boxes']:
   x,y,z=b['from'];w,h,d=b['size'];px,py,pz=part['pivot'];k=.64
   lo=[8+(x+px)*k,(24-y-py-h)*k,8+(z+pz)*k];hi=[lo[0]+w*k,lo[1]+h*k,lo[2]+d*k]
   tile=b['color'];u=(tile%8)*2+.2;v=(tile//8)*2+.2
   faces={face:{'uv':[u,v,u+.3,v+.3],'texture':'#body'} for face in ['north','south','west','east','up','down']}
   elements.append({'from':lo,'to':hi,'faces':faces})
 ident=name+('_icon' if icon else '')
 model={'textures':{'body':'astra-client:item/character_palette','particle':'astra-client:item/character_palette'},'elements':elements,'gui_light':'front','display':{'gui':{'rotation':[8,205,0],'translation':[0,-1 if not icon else -13,0],'scale':[.78 if not icon else 1.6]*3}}}
 # GUI rotation looks at the face (negative Z) with one side visible.
 (ROOT/'models/character').mkdir(parents=True,exist_ok=True);(ROOT/'items/character').mkdir(parents=True,exist_ok=True)
 (ROOT/'models/character'/f'{ident}.json').write_text(json.dumps(model,separators=(',',':'))+'\n')
 (ROOT/'items/character'/f'{ident}.json').write_text(json.dumps({'model':{'type':'minecraft:model','model':'astra-client:character/'+ident}})+'\n')
for name,spec in models.items():preview(name,spec['parts'])
preview('spongebob',models['spongebob']['parts'],True)
print('Authored',len(models),'curved characters,',sum(len(p['boxes']) for m in models.values() for p in m['parts'].values()),'rounded primitives and',len(palette),'atlas colors.')
