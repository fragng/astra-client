"""Astra-authored casual-game content. No official paid/daily question bank."""
from pathlib import Path
import json,re,unicodedata
root=Path(__file__).resolve().parents[1]/'src/main/resources/assets/astra-client/puzzles'
answers='''about above actor acute adapt admit adopt adore adult after again agent agile agree ahead aisle alarm album alert alien align alike alive allow alone along alter amber ample amuse angel anger angle angry ankle apart apple apply apron arena argue arise aroma array arrow aside asset atlas attic audio audit avoid awake award aware badly baker basic basin basis batch beach beard beast begin being below bench berry birth black blade blame bland blank blast blaze bleak blend bless blind blink block bloom blush board boast bonus boost booth bound brain brake brand brass brave bread break breed brick bride brief bring brisk broad broke brook broom brown brush build built bunch buyer cable cabin camel canal candy canoe carry carve catch cause cedar chain chair chalk charm chart chase cheap check cheek cheer chess chest chief child chili chill chime china choir chose chunk cider cigar claim clamp clash class clean clear clerk click cliff climb cling cloak clock clone close cloth cloud clown coach coast cocoa coral couch count court cover craft crane crash crate crawl crazy cream creek crest crime crisp cross crowd crown cruel crush crust curve cycle daily dairy daisy dance dealt debug decay delay delta dense depth diary diner dirty ditch dizzy dodge doing doubt dough draft drain drama drank drawn dream dress drift drill drink drive drone drove drown eager early earth easel eaten eater ebony elbow elder elect elite empty enjoy enter entry equal equip erupt essay event every exact excel exist extra fable fairy faith false fancy fatal fault favor feast fence ferry fetch fever fiber field fiery fifth fifty fight final finch first fixed flair flame flank flash flask fleet flesh flick fling flint float flock flood floor flora flour flown flute focus force forge forth forty forum found frame frank fraud fresh fried front frost fruit fully fuzzy giant given giver glass glide globe glory glove going goose grace grade grain grand grape graph grasp grass grate grave great greed green greet grief grill grind groan groom group grove grown guard guess guest guide guild guilt habit happy hardy haste hatch haven hazel heard heart heavy hedge heron honey honor horse hotel house human humid humor ideal image imply inbox index inner input intro issue ivory jelly jewel joint joker jolly judge juice juicy karma kayak kebab knack knead kneel knife knock known label labor laden ladle large laser later laugh layer learn lease leash least leave legal lemon level light lilac limit linen liner lingo liver llama local lodge logic loose lotus lover lower loyal lucky lunar lunch lyric magic major maker mango manor maple march marry marsh match medal media mercy merge merit merry metal meter metro might mimic miner minor minus model modem money month moral motor mount mourn mouse mouth moved movie music naive named nasal nasty naval needy nerve never newly nicer niece night ninja noble noise north notch novel nurse nylon oasis ocean offer often olive omega onion opera orbit organ other otter ought outer owned owner oxide ozone paint panel panic paper party pasta patch patio pause peach pearl pecan pedal penny perch phase phone photo piano piece pilot pinch pitch pixel pizza place plain plane plant plate plaza plead pluck plume plush point polar porch poser pound power press price pride prime print prior prize probe prone proof prose proud prove proxy prune pulse punch pupil puppy purse queen query quest queue quick quiet quilt quite quota quote radio rainy raise rally ranch range rapid ratio raven reach react ready realm rebel recap redid refer relax relay renew reply reset resin rhyme rider ridge rifle right rigid rinse risen rival river roast robin robot rocky rogue roman roomy roots rough round route rover royal ruler rumor rural rusty sadly saint salad salon salsa sandy satin sauce scale scarf scary scene scent score scout screw scrub sense serve seven shade shaft shake shaky shall shame shape share shark sharp shave sheep sheer sheet shelf shell shift shine shiny shirt shock shore short shout shown shrug sight sigma silky silly since siren sixty skate skill skirt skull slate sleep slice slide slope small smart smile smoke smoky snack snail snake sneak snowy sober solid solve sonar sonic sorry sound south space spare spark speak spear speed spell spend spice spike spill spine spite split spoke spoon sport spray squad stack staff stage stain stair stake stale stalk stamp stand stare stark start state steam steel steep steer stern stick stiff still sting stock stone stood stool store storm story stout stove strap straw strip stuck study stuff style sugar suite sunny super surge swamp swear sweep sweet swept swift swing swirl table taken taste tasty teach teddy teeth tempo tense tenth thank their theme there these thick thief thigh thing think third thorn those three threw throw thumb tiger tight timer timid tired title toast today token tonal tooth topic torch total touch tough towel tower trace track trade trail train trait treat trend trial tribe trick tried truck truly trunk trust truth tulip tutor twice twist tying uncle under undue union unite unity until upper upset urban usage usual utter valid value valve vapor vault venue verse video vigil vigor villa viola virus visit vivid vocal voice voter vouch vowel wagon waist watch water weary weave wedge weird whale wheat wheel where which while white whole whose widen width wiser witch woman women world worry worse worst worth would wound woven wreck wrist write wrong wrote yacht yield young youth zebra zesty zonal'''.split()
known=set((root/'wordle-guesses.txt').read_text().split())
selected=sorted({w for w in answers if len(w)==5 and w in known})
assert len(selected)>500
(root/'wordle-answers.txt').write_text('\n'.join(selected)+'\n')
# Each non-empty line: point tier = accepted answers, with slash-separated aliases.
text=r'''
[africa] Name a country in Africa.
10=Egypt,South Africa,Kenya,Morocco,Nigeria
15=Algeria,Ghana,Tunisia,Ethiopia,Tanzania
30=Angola,Cameroon,Uganda,Zambia,Zimbabwe,Senegal,Somalia,Madagascar,Sudan,Libya
60=Benin,Botswana,Gabon,Guinea,Liberia,Malawi,Mali,Mauritania,Mozambique,Namibia,Niger,Rwanda,Sierra Leone,Togo
85=Burkina Faso,Burundi,Cabo Verde/Cape Verde,Central African Republic,Chad,Comoros,Djibouti,Equatorial Guinea,Eritrea,Eswatini/Swaziland,Gambia,Guinea-Bissau,Ivory Coast/Cote d'Ivoire,Lesotho,Mauritius,Republic of the Congo,Democratic Republic of the Congo/DRC,South Sudan
100=Sao Tome and Principe,Seychelles
[europe] Name a country in Europe, including transcontinental countries.
10=France,Germany,Italy,Spain,United Kingdom/UK/Britain
15=Greece,Portugal,Ireland,Netherlands/Holland,Sweden,Norway,Switzerland
30=Austria,Belgium,Denmark,Finland,Poland,Ukraine,Russia,Turkey/Turkiye,Iceland,Croatia,Czechia/Czech Republic
60=Albania,Bulgaria,Estonia,Hungary,Latvia,Lithuania,Luxembourg,Malta,Moldova,Romania,Serbia,Slovakia,Slovenia,Georgia,Armenia,Azerbaijan
85=Andorra,Belarus,Bosnia and Herzegovina,Bosnia,Liechtenstein,Montenegro,North Macedonia,Kazakhstan
100=San Marino,Vatican City/ Vatican,Monaco
[fruit] Name an edible fruit commonly eaten as fruit.
10=apple,banana,orange,grape,strawberry
15=pear,peach,lemon,lime,cherry,watermelon,pineapple,mango
30=apricot,blueberry,blackberry,raspberry,plum,nectarine,kiwi/kiwifruit,coconut,papaya,grapefruit
60=lychee,guava,pomegranate,passion fruit,fig,date,tangerine,cantaloupe,honeydew,persimmon,dragon fruit
85=durian,rambutan,mangosteen,quince,star fruit/carambola,custard apple,soursop,jackfruit,gooseberry,cranberry,currant
100=salak,jabuticaba,feijoa,cherimoya
[birds] Name a type of bird.
10=chicken,duck,eagle,pigeon,parrot
15=owl,penguin,swan,sparrow,seagull/gull,robin,flamingo,crow,goose/geese,turkey
30=hawk,falcon,heron,pelican,stork,ostrich,emu,kiwi,peacock,woodpecker,toucan,hummingbird
60=albatross,puffin,kingfisher,kestrel,magpie,raven,finch,canary,wren,swift,swallow,sandpiper
85=avocet,bittern,curlew,dipper,egret,hoopoe,ibis,jay,lapwing,merlin,nuthatch,osprey,quail,rail,tern,wagtail
100=shoebill,kakapo,lyrebird,quetzal
[mammals] Name a kind of mammal.
10=dog,cat,horse,lion,elephant
15=tiger,bear,wolf,fox,whale,dolphin,monkey,rabbit,cow,pig
30=deer,giraffe,hippopotamus/hippo,rhinoceros/rhino,zebra,kangaroo,koala,panda,otter,seal,goat,sheep
60=badger,bat,beaver,bison,camel,cheetah,chimpanzee,gorilla,hedgehog,leopard,llama,moose,porcupine,raccoon,sloth,tapir,wombat,yak
85=aardvark,armadillo,babirusa,capybara,caracal,colugo,dugong,echidna,fossa,manatee,meerkat,narwhal,okapi,pangolin,quokka,serval,tarsier
100=solenodon,tenrec,saola,aye-aye
[reptiles] Name a type of reptile.
10=snake,crocodile,turtle,lizard,tortoise
15=alligator,gecko,chameleon,iguana,python,cobra
30=boa,anaconda,rattlesnake,viper,komodo dragon,monitor lizard,skink
60=bearded dragon,gila monster,slow worm,garter snake,caiman,leopard gecko,green anole
85=tuatara,gharial,basilisk lizard,frilled lizard,glass lizard,thorny devil
100=earless monitor,Mary River turtle
[fish] Name a kind of fish.
10=shark,salmon,tuna,goldfish,cod
15=trout,carp,clownfish,catfish,swordfish,seahorse
30=anchovy,bass,bream,eel,haddock,herring,mackerel,pike,plaice,sardine,sole,tilapia
60=arowana,barracuda,flounder,grouper,halibut,marlin,moray eel,mullet,perch,pufferfish,sturgeon,turbot
85=anglerfish,coelacanth,gar,hatchetfish,lungfish,mudskipper,oarfish,parrotfish,remora,sunfish,wrasse
100=barreleye,blobfish,tripod fish
[instruments] Name a musical instrument.
10=piano,guitar,drum/drums,violin,flute
15=trumpet,saxophone,cello,clarinet,harp,keyboard
30=accordion,banjo,bass guitar,bassoon,oboe,organ,trombone,tuba,ukulele,viola,xylophone
60=bagpipes,balalaika,bouzouki,castanets,didgeridoo,erhu,glockenspiel,harmonica,mandolin,marimba,ocarina,sitar,tabla,tambourine
85=bandoneon,cimbalom,clavichord,dulcimer,glass harmonica,guzheng,kalimba,kora,oud,shamisen,theremin,zither
100=nyckelharpa,ondes martenot,crwth
[tools] Name a hand tool or workshop power tool.
10=hammer,screwdriver,drill,saw,wrench/spanner
15=pliers,chisel,axe,plane,mallet,clamp
30=awl,file,hacksaw,level,rasp,ratchet,sander,socket wrench,tape measure,vise/vice
60=adze,auger,brace,coping saw,drawknife,gimlet,gouge,lathe,punch,riveter,router,scraper,spokeshave
85=ball-peen hammer,broach,caliper,deburring tool,dividers,froe,marking gauge,nail set,reamer,try square
100=travisher,scorp,sticking board
[kitchen] Name an item used to prepare or cook food.
10=knife,pan,pot,spoon,oven
15=fork,spatula,whisk,blender,grater,kettle
30=colander,cutting board/chopping board,ladle,peeler,rolling pin,sieve,skillet,tongs,wok
60=blowtorch,cleaver,food processor,juicer,mandoline,mortar and pestle,pasta machine,pressure cooker,rice cooker,steamer,zester
85=chinois,fish slice,food mill,gnocchi board,melon baller,pastry brush,potato ricer,salad spinner,spider strainer,tamis
100=spurtle,mezzaluna,molinillo
[elements] Name a chemical element.
10=oxygen,gold,iron,hydrogen,carbon
15=silver,copper,helium,nitrogen,calcium,sodium,uranium
30=aluminium/aluminum,argon,chlorine,fluorine,iodine,lead,lithium,magnesium,mercury,neon,nickel,phosphorus,platinum,potassium,silicon,sulfur/sulphur,tin,zinc
60=antimony,arsenic,barium,beryllium,bismuth,boron,bromine,cadmium,chromium,cobalt,gallium,germanium,krypton,manganese,molybdenum,palladium,radium,selenium,strontium,titanium,tungsten,xenon,zirconium
85=actinium,astatine,cerium,cesium/caesium,dysprosium,erbium,europium,francium,gadolinium,hafnium,holmium,indium,iridium,lanthanum,lutetium,neodymium,niobium,osmium,polonium,praseodymium,promethium,protactinium,rhenium,rhodium,rubidium,ruthenium,samarium,scandium,tantalum,tellurium,terbium,thallium,thorium,thulium,vanadium,ytterbium,yttrium
100=seaborgium,darmstadtium,meitnerium,roentgenium,copernicium,nihonium,flerovium,moscovium,livermorium,tennessine,oganesson,bohrium,hassium,dubnium,rutherfordium,lawrencium,nobelium,mendelevium,fermium,einsteinium,californium,berkelium,curium,americium,plutonium,neptunium,technetium
[languages] Name a human language.
10=English,Spanish,French,Chinese/Mandarin Chinese/Mandarin,German
15=Arabic,Japanese,Russian,Italian,Hindi,Korean,Portuguese
30=Bengali,Dutch,Greek,Hebrew,Indonesian,Polish,Punjabi,Swahili,Swedish,Tamil,Thai,Turkish,Urdu,Vietnamese
60=Afrikaans,Albanian,Amharic,Armenian,Basque,Catalan,Czech,Danish,Finnish,Georgian,Hungarian,Icelandic,Irish,Latin,Maltese,Nepali,Persian/Farsi,Romanian,Somali,Tagalog,Ukrainian,Welsh
85=Aymara,Breton,Cherokee,Guarani,Hausa,Inuktitut,Kazakh,Khmer,Lao,Mongolian,Navajo,Occitan,Quechua,Sami,Sanskrit,Tigrinya,Yoruba,Zulu
100=Manx,Cornish,Livonian,Ladin
[coding] Name a programming language.
10=Python,Java,JavaScript,C,C++
15=C#,Ruby,PHP,Swift,Kotlin
30=Go,Rust,TypeScript,Perl,Scala,R,SQL,Lua,Dart,Visual Basic
60=Assembly,Bash,Clojure,Cobol,Elixir,Erlang,Fortran,F#,Haskell,Julia,Lisp,MATLAB,Objective-C,Pascal,Prolog,Scheme,Smalltalk
85=Ada,APL,Ballerina,Crystal,D,Elm,Forth,Groovy,Logo,Nim,OCaml,Racket,Solidity,Tcl,Vala,Zig
100=Chapel,Idris,Io,Raku
[sports] Name a sport.
10=football/soccer,basketball,tennis,golf,swimming
15=baseball,cricket,rugby,volleyball,boxing,cycling,hockey
30=archery,athletics,badminton,fencing,gymnastics,handball,judo,rowing,sailing,skiing,table tennis,wrestling
60=biathlon,bobsleigh,canoeing,curling,diving,equestrian,field hockey,ice hockey,lacrosse,netball,polo,squash,surfing,taekwondo,triathlon,water polo
85=bandy,bocce,camogie,disc golf,gaelic football,hurling,kabaddi,korfball,luge,pesapallo,racquetball,sepak takraw,shinty,skeleton,ultimate frisbee
100=underwater hockey,cycle ball,bossaball
[minerals] Name a mineral or gemstone.
10=diamond,ruby,emerald,sapphire,quartz
15=amethyst,opal,topaz,jade,garnet,turquoise
30=agate,aquamarine,calcite,citrine,corundum,feldspar,fluorite,gypsum,hematite,jasper,malachite,mica,onyx,pyrite,talc
60=alexandrite,apatite,azurite,beryl,carnelian,celestine,chalcedony,chrysoberyl,diopside,lapis lazuli,magnetite,moonstone,olivine,peridot,spinel,tourmaline,zircon
85=andalusite,benitoite,chrysocolla,danburite,euclase,grandidierite,howlite,iolite,kunzite,labradorite,larimar,morganite,prehnite,rhodochrosite,sodalite,sphene,tanzanite,zoisite
100=taaffeite,serendibite,poudretteite
[moons] Name a natural moon in the Solar System.
10=Moon/Luna,Europa,Titan,Ganymede,Io
15=Callisto,Enceladus,Phobos,Deimos,Triton
30=Charon,Mimas,Miranda,Oberon,Rhea,Tethys,Titania,Umbriel,Iapetus
60=Amalthea,Ariel,Dione,Hyperion,Nereid,Phoebe,Proteus
85=Adrastea,Caliban,Carme,Desdemona,Elara,Epimetheus,Galatea,Himalia,Janus,Leda,Metis,Pan,Pandora,Pasiphae,Prometheus,Thebe
100=Kiviuq,Siarnaq,Ijiraq
[flowers] Name a flowering plant commonly grown for its flowers.
10=rose,tulip,daisy,sunflower,lily
15=orchid,daffodil,lavender,lotus,poppy
30=azalea,begonia,bluebell,carnation,chrysanthemum,narcissus,dahlia,geranium,hibiscus,hydrangea,iris,jasmine,marigold,peony,petunia,violet
60=anemone,aster,camellia,clematis,cosmos,crocus,delphinium,foxglove,freesia,gardenia,gladiolus,hollyhock,hyacinth,lupin,primrose,snapdragon,sweet pea,zinnia
85=agapanthus,alstroemeria,amaryllis,astilbe,calendula,ceanothus,echinacea,hellebores/hellebore,lantana,lisianthus,monarda,nemesia,nicotiana,penstemon,ranunculus,salvia,scabiosa,verbena
100=nerine,tigridia,leucojum
[trees] Name a type of tree.
10=oak,pine,palm,maple,apple
15=birch,willow,cherry,cedar,elm,spruce
30=ash,aspen,beech,cypress,eucalyptus,fir,hazel,holly,magnolia,olive,poplar,redwood,sycamore,walnut,yew
60=acacia,alder,araucaria,baobab,catalpa,chestnut,dogwood,ginkgo,hawthorn,hemlock,hickory,larch,rowan,sequoia,tamarind,teak
85=albizia,banyan,dawn redwood,douglas fir,hornbeam,ironwood,jacaranda,kapok,katsura,madrone,monkey puzzle,paulownia,sassafras,silver wattle,sweetgum,tupelo
100=dragon blood tree,quiver tree,Wollemi pine
[ranges] Name a mountain range.
10=Himalayas,Alps,Andes,Rocky Mountains/Rockies
15=Appalachians,Atlas,Pyrenees,Ural Mountains/Urals
30=Alaska Range,Carpathians,Caucasus,Drakensberg,Hindu Kush,Karakoram,Sierra Nevada,Tian Shan
60=Apennines,Cascade Range/Cascades,Dinaric Alps,Great Dividing Range,Kunlun,Scandinavian Mountains,Vosges,Zagros
85=Altai,Anti-Atlas,Brooks Range,Cantabrian Mountains,Chersky Range,Elburz/Alborz,Jura,Patkai,Ruwenzori,Sayan,Simien,Stanovoy,Verkhoyansk
100=Kaikoura Ranges,Byrranga,Aravalli
[capitals] Name a national capital in Europe.
10=London,Paris,Rome,Madrid,Berlin
15=Athens,Amsterdam,Dublin,Lisbon,Vienna,Stockholm
30=Belgrade,Brussels,Bern,Budapest,Copenhagen,Helsinki,Oslo,Prague,Reykjavik,Warsaw,Zagreb
60=Ankara,Bratislava,Bucharest,Chisinau,Kyiv/Kiev,Ljubljana,Luxembourg City,Luxembourg,Monaco City,Podgorica,Riga,Sarajevo,Skopje,Sofia,Tallinn,Tirana,Vilnius
85=Andorra la Vella,Minsk,San Marino,Valletta,Vaduz,Vatican City
100=Pristina
[breads] Name a kind of bread.
10=white bread,brown bread,sourdough,baguette,bagel
15=pita/pitta,naan,rye bread,brioche,cornbread
30=ciabatta,focaccia,flatbread,chapati,roti,wholemeal bread,whole wheat bread,tortilla,crumpet,English muffin
60=challah,damper,frybread,injera,lavash,manakish,panettone,paratha,pumpernickel,soda bread,stollen
85=arepa,barmbrack,bing,broa,casabe,kaiser roll,luchi,matzo,pa de queijo,pain de campagne,pan de muerto,piadina,rieska,tiger bread
100=mosbolletjies,bazlama,lefse
[pasta] Name a pasta shape.
10=spaghetti,penne,macaroni,fusilli,lasagne/lasagna
15=farfalle,tagliatelle,linguine,ravioli,tortellini
30=bucatini,cannelloni,conchiglie,fettuccine,gnocchi,orzo,pappardelle,rigatoni,vermicelli
60=capellini,cavatappi,ditalini,gemelli,orecchiette,paccheri,rotini,stelline,trofie,ziti
85=anelletti,calamarata,campanelle,casarecce,cavatelli,garganelli,mafaldine,malloreddus,radiatori,scialatielli,strozzapreti
100=lorighittas,corzetti,testaroli
[clothes] Name an item of clothing.
10=shirt,trousers/pants,dress,skirt,coat
15=jeans,jacket,hoodie,shorts,socks,sweater/jumper,hat
30=blazer,cardigan,gloves,raincoat,robe,scarf,shawl,suit,tie,tights,vest,waistcoat
60=anorak,balaclava,blouse,bolero,cape,chemise,kaftan,kimono,leggings,poncho,sari,sarong,smock,tunic
85=dirndl,dhoti,djellaba,hanbok,haori,kilt,lederhosen,qipao,tabard,toga,yukata
100=chapan,deel,boubou
[sea-life] Name a marine invertebrate.
10=jellyfish,octopus,crab,shrimp,prawn
15=lobster,squid,starfish/sea star,clam,oyster
30=barnacle,coral,cuttlefish,mussel,scallop,sea anemone,sea cucumber,sea urchin,sea sponge,sea snail
60=abalone,brittle star,chiton,conch,hermit crab,krill,mantis shrimp,nautilus,nudibranch,sand dollar,sea slug
85=basket star,bobbit worm,by-the-wind sailor,comb jelly,feather star,fireworm,giant isopod,peanut worm,sea hare,tunicate
100=sea pig,venus flower basket,blue dragon sea slug
[shapes] Name a two-dimensional geometric shape or curve.
10=circle,square,triangle,rectangle,oval
15=pentagon,hexagon,octagon,diamond,rhombus
30=decagon,ellipse,heptagon,kite,nonagon,parallelogram,semicircle,trapezoid/trapezium
60=annulus,crescent,dodecagon,henagon,lune,parabola,quadrant,sector,star,superellipse
85=cardioid,deltoid,epicycloid,hypocycloid,lemniscate,nephroid,reuleaux triangle,rose curve,spiral
100=astroid,limacon,vesica piscis
[currencies] Name a current currency or its commonly used unit name.
10=dollar,euro,pound,yen,yuan
15=rupee,ruble/rouble,won,peso,franc
30=baht,dinar,dirham,forint,krona,krone,rand,riyal,shekel,zloty
60=afghani,ariary,balboa,birr,boliviano,cedi,colón/colon,cordoba,dalasi,dobra,dong,dram,gourde,guarani,hryvnia,kina,kip,kwacha,lempira,leu,lira,manat,metical,naira,nakfa,quetzal,rufiyaa,som,somoni,taka,tala,tenge,tugrik/tögrög,vatu
85=lek,leone,lilangeni,loti,pula,ringgit,rupiah,shilling,sol
100=ngultrum,pataca,paanga
[dinosaurs] Name a dinosaur, excluding modern birds.
10=tyrannosaurus/tyrannosaurus rex/t rex,triceratops,stegosaurus,velociraptor,brachiosaurus
15=allosaurus,ankylosaurus,apatosaurus,diplodocus,spinosaurus
30=argentinosaurus,carnotaurus,compsognathus,deinonychus,giganotosaurus,iguanodon,parasaurolophus,pachycephalosaurus
60=albertosaurus,baryonyx,camarasaurus,ceratosaurus,coelophysis,edmontosaurus,gallimimus,hadrosaurus,maiasaura,oviraptor,saurolophus,therizinosaurus,troodon,utahraptor
85=acanthopholis,amargasaurus,archaeopteryx,conchoraptor,cryolophosaurus,dilophosaurus,euoplocephalus,guanlong,kentrosaurus,microraptor,monolophosaurus,protoceratops,psittacosaurus,saltasaurus,suchomimus
100=yi,megaraptor,masiakasaurus
[board-games] Name a tabletop board game.
10=chess,monopoly,scrabble,checkers/draughts,cluedo/clue
15=backgammon,catan/settlers of catan,risk,trivial pursuit,connect four
30=carcassonne,go,othello/reversi,pandemic,stratego,ticket to ride,azul,battleship
60=agricola,ark nova,brass,barrage,calico,concordia,dixit,dominion,everdell,kingdomino,patchwork,root,scythe,splendor,terraforming mars,wingspan
85=anachrony,blood rage,castles of burgundy,coimbra,el grande,gaia project,great western trail,istanbul,le havre,lisboa,on mars,power grid,rococo,spirit island,tigris and euphrates,viticulture
100=hansa teutonica,trickerion,bus
[spices] Name a culinary herb or spice.
10=pepper,black pepper,basil,cinnamon,ginger
15=chili/chilli,cumin,oregano,paprika,parsley,rosemary,thyme
30=allspice,anise,cardamom,chives,cilantro/coriander leaf,clove,cloves,coriander,curry leaf,dill,fennel,mint,nutmeg,saffron,sage,turmeric,vanilla
60=caraway,chervil,fenugreek,galangal,juniper,lemongrass,lovage,mace,marjoram,mustard seed,star anise,sumac,tarragon
85=ajwain,annatto,asafoetida,epazote,grains of paradise,hyssop,lemon verbena,nigella,pandan,perilla,savory,sichuan pepper,sorrel,tonka bean
100=mahlab,voatsiperifery,urfa biber
[minecraft-mobs] Name a Minecraft mob found in Java Edition.
10=creeper,zombie,skeleton,pig,cow
15=sheep,chicken,enderman,spider,villager,wolf,cat
30=allay,axolotl,bat,bee,blaze,camel,happy ghast,cave spider,cod,dolphin,drowned,ender dragon,fox,ghast,goat,horse,iron golem,llama,panda,parrot,phantom,piglin,pillager,rabbit,salmon,slime,snow golem,squid,strider,turtle,warden,witch,wither
60=armadillo,bogged,breeze,donkey,nautilus,elder guardian,endermite,evoker,frog,glow squid,guardian,hoglin,husk,magma cube,mooshroom,mule,ocelot,pufferfish,ravager,shulker,silverfish,sniffer,stray,tadpole,trader llama,tropical fish,vex,vindicator,wandering trader,wither skeleton,zoglin,zombie horse,zombie villager,zombified piglin
85=creaking,skeleton horse,giant,illusioner,camel husk,parched,zombie nautilus
100=the killer bunny/killer bunny
[minecraft-biomes] Name a Minecraft Overworld biome in Java Edition.
10=plains,desert,forest,swamp,jungle
15=badlands,savanna,snowy plains,taiga,ocean,beach
30=birch forest,cherry grove,dark forest,deep ocean,flower forest,frozen ocean,grove,lush caves,mangrove swamp,meadow,snowy taiga,sunflower plains,warm ocean
60=bamboo jungle,cold ocean,deep cold ocean,deep frozen ocean,deep lukewarm ocean,dripstone caves,eroded badlands,frozen peaks,ice spikes,jagged peaks,lukewarm ocean,old growth birch forest,old growth pine taiga,old growth spruce taiga,pale garden,snowy beach,snowy slopes,sparse jungle,stony peaks,stony shore,wooded badlands
85=deep dark,windswept forest,windswept gravelly hills,windswept hills,windswept savanna
100=frozen river
[minecraft-blocks] Name a Minecraft block found in Java Edition.
10=stone,dirt,grass block,oak log,cobblestone
15=bedrock,diamond block,glass,gravel,obsidian,sand,wooden planks/oak planks
30=andesite,anvil,barrel,bookshelf,bricks,cactus,calcite,chest,clay,crafting table,deepslate,diorite,dripstone block,enchanting table,end stone,farmland,furnace,granite,hay bale,ice,iron block,magma block,moss block,netherrack,pumpkin,quartz block,snow block,sponge,terracotta,tnt,wool/white wool
60=amethyst block,ancient debris,bamboo block,basalt,beacon,bee nest,blast furnace,brewing stand,cartography table,chiseled bookshelf,conduit,copper block,crying obsidian,fletching table,frogspawn,glowstone,honey block,jukebox,lectern,lodestone,loom,mud,packed mud,piston,prismarine,redstone lamp,respawn anchor,scaffolding,sculk,sea lantern,shroomlight,smithing table,smoker,soul sand,stonecutter,target,trapped chest,tuff,vault
85=calibrated sculk sensor,crafter,creaking heart,decorated pot,hanging roots,heavy core,jigsaw block,light block,ochre froglight,pearlescent froglight,reinforced deepslate,resin block,sculk catalyst,sculk shrieker,structure block,verdant froglight
100=structure void,trial spawner,ominous vault
[minecraft-enchants] Name a Minecraft Java enchantment.
10=sharpness,protection,mending,unbreaking,fortune
15=efficiency,fire aspect,infinity,looting,power,punch,silk touch
30=aqua affinity,blast protection,channeling,depth strider,feather falling,fire protection,flame,frost walker,impaling,knockback,loyalty,luck of the sea,lure,projectile protection,respiration,riptide,smite,thorns
60=bane of arthropods,breach,density,multishot,piercing,quick charge,soul speed,sweeping edge,swift sneak
85=curse of binding,curse of vanishing
100=wind burst
[minecraft-wood] Name a Minecraft wood type, including Nether stems and bamboo.
10=oak,birch,spruce
15=jungle,acacia
30=dark oak,mangrove,cherry
60=bamboo
85=crimson,warped
100=pale oak
[maths] Name a mathematical term or concept.
10=addition,subtraction,multiplication,division,fraction
15=algebra,angle,area,average,circle,equation,percent,triangle
30=calculus,cosine,decimal,denominator,diameter,differentiation,exponent,factor,geometry,gradient,integer,integral,logarithm,matrix,numerator,prime number,probability,radius,ratio,sine,square root,tangent,vector,volume
60=asymptote,binomial,cardinality,complex number,derivative,determinant,eigenvalue,factorial,group,hyperbola,identity,limit,median,modulus,polynomial,quadratic,sequence,set,topology,trigonometry,variance
85=abelian group,bijection,convolution,covariance,divergence,homomorphism,isomorphism,jacobian,laplacian,manifold,permutation,quaternion,tensor,torus,vector space
100=homeomorphism,cohomology,ultrafilter
'''
questions=[];current=None
for line in text.splitlines():
 line=line.strip()
 if not line:continue
 if line.startswith('['):
  match=re.match(r'\[([^]]+)\] (.+)',line);assert match,line;current={'id':match[1],'question':match[2],'tiers':{}};questions.append(current)
 else:
  score,entries=line.split('=',1);current['tiers'][score]=[v.strip() for v in entries.split(',') if v.strip()]
def norm(v):return re.sub('[^a-z0-9]','',unicodedata.normalize('NFKD',v.replace('+','plus').replace('#','sharp')).encode('ascii','ignore').decode().lower())
for question in questions:
 aliases={}
 for score,entries in question['tiers'].items():
  for entry in entries:
   for alias in entry.split('/'):
    key=norm(alias)
    # Keep aliases consistent with the Java normalizer, including C++ and C#.
    if key in aliases and aliases[key]!=(entry,score):raise ValueError((question['id'],alias,aliases[key]))
    aliases[key]=(entry,score)
(root/'trivia.json').write_text(json.dumps(questions,ensure_ascii=False,indent=2)+'\n')
print(len(selected),'originally selected Wordle answers;',len(questions),'practice categories;',sum(len(v) for q in questions for v in q['tiers'].values()),'accepted trivia answers')
