package client.astra;

import net.minecraft.resources.Identifier;
import net.minecraft.world.item.ItemStack;
import net.minecraft.world.item.Items;

public enum TotemStyle {
    NONE("Minecraft", "none"),
    DRDONUT("Drdonut", "drdonut"),
    JETTISM("Jettism", "jettism"),
    FAREX("Farex", "farex"),
    HOOZAR0("Hoozar0", "hoozar0"),
    JACK("Jack", "jack");
    public static final TotemStyle[] PACK={DRDONUT,JETTISM,FAREX,HOOZAR0,JACK};
    public final String creator,id;
    public final Identifier model,texture;
    TotemStyle(String creator,String id){
        this.creator=creator;this.id=id;
        model=Identifier.fromNamespaceAndPath(AstraClient.MOD_ID,"totem/"+id);
        texture=Identifier.fromNamespaceAndPath(AstraClient.MOD_ID,"textures/item/totem/"+id+".png");
    }
    public String label(){return creator+"'s Totem";}
    /** Render-only model choice; never alters the original stack or its components. */
    public static Identifier resolve(Identifier original,ItemStack stack){
        if(stack.is(Items.TOTEM_OF_UNDYING)&&CaseGames.skinTotem())return PersonalTotemRenderer.ITEM;
        TotemStyle style=AstraConfig.totemStyle();
        return PremiumEdition.premium() && style!=NONE && stack.is(Items.TOTEM_OF_UNDYING)?style.model:original;
    }
    private ItemStack previewStack;
    public void preview(net.minecraft.client.gui.GuiGraphics g,int x,int y,int size){
        if(this==NONE)MenuArt.icon(g,"Customize Totem",x,y,size,0xFFFFFFFF);
        else {
            // A private preview stack uses its own model, independent of the equipped skin.
            if(previewStack==null){previewStack=new ItemStack(Items.PAPER);previewStack.set(net.minecraft.core.component.DataComponents.ITEM_MODEL,model);}
            g.pose().pushMatrix();g.pose().translate(x,y);g.pose().scale(size/16f,size/16f);
            g.renderFakeItem(previewStack,0,0);g.pose().popMatrix();
        }
    }
}
