package client.astra;

/** Visual-only descent. Points and puzzle results remain owned by KrillionGame. */
public final class KrillionDive {
    private boolean initialized;
    private double from,to;
    private long started;
    private double duration;
    public void update(int metres,long now,boolean animate){
        double target=Math.clamp(metres,0,7000);
        if(!initialized||!animate||target<to){initialized=true;from=to=target;started=now;duration=0;return;}
        if(target!=to){from=depth(now);to=target;started=now;duration=.75+.9*Math.min(1,(to-from)/1000);}
    }
    public double progress(long now){return duration==0?1:Math.clamp((now-started)/(duration*1e9),0,1);}
    public double depth(long now){double p=progress(now);return from+(to-from)*p*p*(3-2*p);}
    public boolean moving(long now){return to>from&&progress(now)<1;}
    public boolean ready(int target,long now){return initialized&&to==target&&!moving(now);}
    public double flow(long now){double p=progress(now);return moving(now)?4*p*(1-p):0;}
    public static double camera(double depth){return Math.max(0,Math.clamp(depth,0,7000)*.10-96);}
    public static double fishY(double depth){return 182+Math.clamp(depth,0,7000)*.10-camera(depth);}
}
