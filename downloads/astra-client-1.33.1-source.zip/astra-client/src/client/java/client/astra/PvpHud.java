package client.astra;

import net.minecraft.client.Minecraft;
import net.minecraft.client.gui.GuiGraphics;
import net.minecraft.world.entity.EquipmentSlot;
import net.minecraft.world.item.*;
import net.minecraft.network.chat.Component;
import java.util.*;
import static client.astra.PvpSettings.Feature.*;

/** Tick-cached, own-player information; rendering never scans an inventory. */
public final class PvpHud {
    public record Row(String label,String value){}
    private static List<Row> rows=List.of();
    private static Object player;
    private static final IdentityHashMap<Item,Integer> COUNTS=new IdentityHashMap<>();
    private static long nextSample;
    private static final int WIDTH=218;
    private static final EquipmentSlot[] ARMOR_SLOTS={EquipmentSlot.HEAD,EquipmentSlot.CHEST,EquipmentSlot.LEGS,EquipmentSlot.FEET};
    public record Bounds(float x,float y,float width,float height,float scale){}
    public static List<Row> rows(){return rows;}
    private static String decimal(double n){long tenths=Math.round(n*10);return tenths/10+"."+Math.abs(tenths%10);}
    private static String durability(ItemStack s){return s.isDamageableItem()?(s.getMaxDamage()-s.getDamageValue())+" / "+s.getMaxDamage():"";}
    public static void tick(Minecraft client){
        var p=client.player;
        if(p==null || !PvpSettings.anyHud()){rows=List.of();player=null;return;}
        long now=System.nanoTime();
        if(PerformanceMode.enabled() && player==p && now<nextSample)return;
        player=p;nextSample=now+100_000_000L;
        var next=new ArrayList<Row>();
        var counts=COUNTS;counts.clear();
        var inventory=p.getInventory();
        if(CRYSTALS.enabled()||TOTEMS.enabled()||WIND.enabled()||PEARLS.enabled()||APPLES.enabled()||POTIONS.enabled()||ARROWS.enabled())
            for(int i=0;i<inventory.getContainerSize();i++){var stack=inventory.getItem(i);if(!stack.isEmpty())counts.merge(stack.getItem(),stack.getCount(),Integer::sum);}
        count(next,counts,CRYSTALS,"Crystals",Items.END_CRYSTAL);count(next,counts,TOTEMS,"Totems",Items.TOTEM_OF_UNDYING);
        count(next,counts,WIND,"Wind charges",Items.WIND_CHARGE);count(next,counts,PEARLS,"Ender pearls",Items.ENDER_PEARL);
        if(APPLES.enabled())next.add(new Row("Golden apples",counts.getOrDefault(Items.GOLDEN_APPLE,0)+" / "+counts.getOrDefault(Items.ENCHANTED_GOLDEN_APPLE,0)+" ench."));
        count(next,counts,POTIONS,"Potions",Items.POTION,Items.SPLASH_POTION,Items.LINGERING_POTION);
        count(next,counts,ARROWS,"Arrows",Items.ARROW,Items.TIPPED_ARROW,Items.SPECTRAL_ARROW);
        ItemStack main=p.getMainHandItem(),off=p.getOffhandItem();
        if(COOLDOWN.enabled())next.add(new Row("Attack ready",Math.round(p.getAttackStrengthScale(0)*100)+"%"));
        if(DURABILITY.enabled()){
            String d=durability(main);if(!d.isEmpty())next.add(new Row("Held durability",d));
        }
        if(ARMOR.enabled()){
            StringBuilder value=new StringBuilder();String[] names={"H","C","L","B"};
            for(int i=0;i<4;i++){var s=p.getItemBySlot(ARMOR_SLOTS[i]);if(s.isDamageableItem()){if(!value.isEmpty())value.append("  ");value.append(names[i]).append(Math.round((s.getMaxDamage()-s.getDamageValue())*100.0/s.getMaxDamage())).append('%');}}
            if(!value.isEmpty())next.add(new Row("Armor",value.toString()));
        }
        if(FALL.enabled())next.add(new Row("Fall distance",decimal(Math.max(0,p.fallDistance))+" blocks"));
        if(USE.enabled() && p.isUsingItem())next.add(new Row("Using item",decimal(p.getTicksUsingItem()/20.0)+" s"));
        if(ABSORPTION.enabled())next.add(new Row("Absorption",decimal(p.getAbsorptionAmount()/2.0)+" hearts"));
        if(SHIELD.enabled()){
            var shield=main.is(Items.SHIELD)?main:off.is(Items.SHIELD)?off:ItemStack.EMPTY;
            if(!shield.isEmpty())next.add(new Row(p.isBlocking()?"Shield raised":"Shield",durability(shield)));
        }
        if(FOOD.enabled())next.add(new Row("Food / saturation",p.getFoodData().getFoodLevel()+" / "+decimal(p.getFoodData().getSaturationLevel())));
        if(DRAW.enabled() && p.isUsingItem() && p.getUseItem().is(Items.BOW))next.add(new Row("Bow draw",Math.round(BowItem.getPowerForTime(p.getTicksUsingItem())*100)+"%"));
        if(CROSSBOW.enabled()){
            var crossbow=main.is(Items.CROSSBOW)?main:off.is(Items.CROSSBOW)?off:ItemStack.EMPTY;
            if(!crossbow.isEmpty())next.add(new Row("Crossbow",CrossbowItem.isCharged(crossbow)?"Loaded":"Unloaded"));
        }
        if(EFFECTS.enabled())p.getActiveEffects().stream().sorted(Comparator.comparing(e->e.getEffect().value().getDescriptionId())).limit(3).forEach(e->{
            String label=e.getEffect().value().getDisplayName().getString()+(e.getAmplifier()>0?" "+(e.getAmplifier()+1):"");
            int seconds=Math.max(0,(e.getDuration()+19)/20);
            next.add(new Row(label,e.isInfiniteDuration()?"Infinite":seconds/60+":"+String.format(Locale.ROOT,"%02d",seconds%60)));
        });
        rows=List.copyOf(next);
    }
    private static void count(List<Row> rows,Map<Item,Integer> counts,PvpSettings.Feature feature,String label,Item... items){if(feature.enabled()){int n=0;for(var item:items)n+=counts.getOrDefault(item,0);rows.add(new Row(label,Integer.toString(n)));}}
    private static List<Row> shown(boolean preview){
        var selected=rows.isEmpty() && preview?List.of(new Row("Attack ready","100%"),new Row("Held durability","1561 / 1561"),new Row("Crystals","64")):rows;
        return PerformanceMode.enabled() && selected.size()>6?selected.subList(0,6):selected;
    }
    public static Bounds bounds(int width,int height,boolean preview){
        int h=23+shown(preview).size()*14;
        float scale=(float)Math.min(PvpSettings.scale,Math.min((width-12.0)/WIDTH,(height-12.0)/h));
        return new Bounds(6+(float)PvpSettings.x*Math.max(0,width-12-WIDTH*scale),6+(float)PvpSettings.y*Math.max(0,height-12-h*scale),WIDTH*scale,h*scale,scale);
    }
    public static void place(double px,double py,int width,int height){
        var b=bounds(width,height,true);
        PvpSettings.x=Math.clamp((px-6)/Math.max(1,width-12-b.width),0,1);PvpSettings.y=Math.clamp((py-6)/Math.max(1,height-12-b.height),0,1);AstraConfig.changed();
    }
    public static void draw(GuiGraphics g,boolean preview){
        if(!preview && (rows.isEmpty() || Minecraft.getInstance().screen!=null))return;
        var shown=shown(preview);var b=bounds(g.guiWidth(),g.guiHeight(),preview);var font=Minecraft.getInstance().font;
        g.pose().pushMatrix();g.pose().translate(b.x,b.y);g.pose().scale(b.scale,b.scale);
        if(!PerformanceMode.enabled())Ui.round(g,-1,-1,WIDTH+2,25+shown.size()*14,8,0x807A6398);
        Ui.round(g,0,0,WIDTH,23+shown.size()*14,7,0xDB141723);
        Ui.animated(g,font,PerformanceMode.enabled() && rows.size()>6?"ASTRA / PVP  •  +"+(rows.size()-6)+" hidden":"ASTRA / PVP",9,7,0xFFD4B7EF);
        int y=23;
        for(var row:shown){
            var value=Ui.text(row.value);int valueWidth=font.width(value);
            // Shrink each column independently, never overlap long translated effect names.
            drawFit(g,row.label,9,y,102,.85f,0xFFAEA6BC);
            drawFit(g,row.value,WIDTH-9-Math.min(valueWidth,94),y,94,1,0xFFE6DAF3);y+=14;
        }
        g.pose().popMatrix();
    }
    private static void drawFit(GuiGraphics g,String label,int x,int y,int width,float preferred,int color){
        var font=Minecraft.getInstance().font;var text=Ui.text(label);float scale=Math.min(preferred,width/(float)Math.max(1,font.width(text)));
        g.pose().pushMatrix();g.pose().translate(x,y);g.pose().scale(scale,scale);Ui.animated(g,font,text,0,0,color);g.pose().popMatrix();
    }
    private PvpHud(){}
}
