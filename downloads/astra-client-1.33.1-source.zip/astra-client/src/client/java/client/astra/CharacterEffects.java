package client.astra;

import net.minecraft.client.Minecraft;

/** One local-player exertion sample per tick, smoothly interpolated during rendering. */
public final class CharacterEffects {
    private static Object player;
    private static int exertion;
    private static float previous,sweat;
    private CharacterEffects(){}
    public static void tick(Minecraft mc){
        if(mc.player==null || mc.player!=player){player=mc.player;exertion=0;previous=sweat=0;}
        if(mc.player==null || mc.isPaused())return;
        if(PerformanceMode.enabled() || AstraConfig.characterStyle()==CharacterStyle.NONE || !AstraConfig.characterDetails){previous=sweat=0;exertion=0;return;}
        previous=sweat;
        exertion=mc.player.isSprinting()?Math.min(240,exertion+1):Math.max(0,exertion-2);
        float target=mc.player.isOnFire()||mc.player.getHealth()<=6?1:exertion>50?.8f:0;
        sweat=CharacterAnimation.approach(sweat,target,.05f);
    }
    public static float sweat(){var mc=Minecraft.getInstance();return previous+(sweat-previous)*Math.clamp(mc.getDeltaTracker().getGameTimeDeltaPartialTick(false),0,1);}
}
