package client.astra;

import com.google.gson.*;
import com.mojang.brigadier.arguments.StringArgumentType;
import net.fabricmc.fabric.api.client.command.v2.*;
import net.fabricmc.loader.api.FabricLoader;
import net.minecraft.client.Minecraft;
import net.minecraft.network.chat.Component;
import java.net.URI;
import java.net.http.*;
import java.nio.charset.StandardCharsets;
import java.nio.file.*;
import java.time.*;
import java.util.*;
import java.util.concurrent.*;
import java.util.concurrent.atomic.AtomicBoolean;

/** Only the owner's launcher UUID AND separate private key can issue grants. */
public final class PremiumIssuer {
    private static final AtomicBoolean BUSY=new AtomicBoolean();
    private static final ExecutorService WORKER=Executors.newSingleThreadExecutor(r->{var t=new Thread(r,"Astra Premium issuing");t.setDaemon(true);return t;});
    private PremiumIssuer(){}
    public static void initialize(){
        ClientCommandRegistrationCallback.EVENT.register((dispatcher,registry)->dispatcher.register(ClientCommandManager.literal("client")
            .requires(source->PremiumLicense.owner(source.getClient().getUser().getProfileId()))
            .executes(context->{context.getSource().sendFeedback(Component.literal("Astra owner: /client <Java username>. Creates a new account-bound JAR in astra-premium-exports. Install your separate owner key in config/astra-owner/issuer.pk8."));return 1;})
            .then(ClientCommandManager.argument("username",StringArgumentType.word()).executes(context->issue(context.getSource(),StringArgumentType.getString(context,"username"),false))
                .then(ClientCommandManager.literal("lifetime").executes(context->issue(context.getSource(),StringArgumentType.getString(context,"username"),true))))));
    }
    private static int issue(FabricClientCommandSource source,String name,boolean lifetime){
        if(!PremiumLicense.owner(source.getClient().getUser().getProfileId()))return 0;
        if(!PremiumLicense.username(name)){source.sendError(Component.literal("Use a Minecraft Java username (3-16 letters, numbers or underscores)."));return 0;}
        if(!BUSY.compareAndSet(false,true)){source.sendError(Component.literal("A Premium file is already being prepared."));return 0;}
        source.sendFeedback(Component.literal("Preparing "+(lifetime?"Lifetime Premium":"a fresh 30-day Premium file")+" for "+name+"..."));
        WORKER.execute(()->{
            try{
                var mc=source.getClient();Path keyFile=FabricLoader.getInstance().getConfigDir().resolve("astra-owner/issuer.pk8");
                if(!Files.isRegularFile(keyFile) || Files.size(keyFile)>4096)throw new java.io.IOException("Install your private owner setup first: config/astra-owner/issuer.pk8.");
                byte[] keyData=Files.readAllBytes(keyFile);java.security.PrivateKey key;
                try{key=PremiumLicense.privateKey(keyData);}finally{Arrays.fill(keyData,(byte)0);}
                var profile=lookup(name);long now=System.currentTimeMillis();var grant=new PremiumLicense.Grant(PremiumLicense.fingerprint(profile.id()),profile.name(),UUID.randomUUID(),now,lifetime?Long.MAX_VALUE:now+PremiumLicense.PERIOD);
                String license=PremiumLicense.issue(grant,key);
                if(PremiumLicense.verify(license,PremiumEdition.trustedKey(),profile.id(),now).status()!=PremiumLicense.Status.ACTIVE)throw new java.io.IOException("The owner key does not match this Astra build.");
                if(!PremiumLicense.owner(mc.getUser().getProfileId()))throw new java.io.IOException("The owner account changed. No file was created.");
                Path installed=Path.of(PremiumIssuer.class.getProtectionDomain().getCodeSource().getLocation().toURI());
                Path folder=FabricLoader.getInstance().getGameDir().resolve("astra-premium-exports");
                String file="astra-premium-"+profile.name()+"-"+grant.serial()+".jar";Path output=folder.resolve(file);
                PremiumJar.write(installed,output,license);
                mc.execute(()->source.sendFeedback(Component.literal("Created "+file+" in astra-premium-exports. Only "+profile.name()+" can use its Premium. "+(grant.lifetime()?"Lifetime access":"Expires "+Instant.ofEpochMilli(grant.expiresAt()))+". Share the JAR, never your owner key.")));
            }catch(Exception e){source.getClient().execute(()->source.sendError(Component.literal("Premium file not created: "+message(e))));}
            finally{BUSY.set(false);}
        });return 1;
    }
    public record Profile(UUID id,String name){}
    public static Profile parseProfile(String json,String requested){
        var j=JsonParser.parseString(json).getAsJsonObject();String id=j.get("id").getAsString(),name=j.get("name").getAsString();
        if(!id.matches("[0-9a-fA-F]{32}") || !PremiumLicense.username(name) || !name.equalsIgnoreCase(requested))throw new IllegalArgumentException("Minecraft returned an invalid profile.");
        return new Profile(UUID.fromString(id.substring(0,8)+"-"+id.substring(8,12)+"-"+id.substring(12,16)+"-"+id.substring(16,20)+"-"+id.substring(20)),name);
    }
    private static Profile lookup(String name)throws Exception{
        try(var http=HttpClient.newBuilder().connectTimeout(Duration.ofSeconds(5)).followRedirects(HttpClient.Redirect.NEVER).build()){
            var request=HttpRequest.newBuilder(URI.create("https://api.minecraftservices.com/minecraft/profile/lookup/name/"+name)).timeout(Duration.ofSeconds(12)).header("User-Agent","AstraClient/1.28.0").GET().build();
            var response=http.send(request,HttpResponse.BodyHandlers.ofInputStream());
            try(var in=response.body()){
                if(response.statusCode()==404)throw new java.io.IOException("No Minecraft Java account named "+name+".");
                if(response.statusCode()!=200)throw new java.io.IOException("Minecraft profile lookup failed (HTTP "+response.statusCode()+"). Try again later.");
                byte[] bytes=in.readNBytes(4097);if(bytes.length>4096)throw new java.io.IOException("Minecraft profile response was too large.");return parseProfile(new String(bytes,StandardCharsets.UTF_8),name);
            }
        }
    }
    private static String message(Exception e){String text=e.getMessage();return text==null || text.length()>180?"Check the owner key and your connection, then try again.":text;}
}
