package client.astra;

import net.minecraft.client.gui.GuiGraphics;

/** Fixed client surface; no selectable scenery, particles or image sampling. */
public final class Backgrounds {
    private Backgrounds(){}
    public static void drawMenu(GuiGraphics graphics,int width,int height){
        Ui.round(graphics,0,0,width,height,18,AstraConfig.colour().background);
    }
}
