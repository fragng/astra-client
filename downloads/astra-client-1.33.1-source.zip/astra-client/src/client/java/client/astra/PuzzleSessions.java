package client.astra;

import com.google.gson.*;
import net.fabricmc.loader.api.FabricLoader;
import net.minecraft.client.Minecraft;
import java.nio.file.*;
import java.util.*;

/** Separate account-local practice saves. No access to cases, prizes or Premium issuance. */
public final class PuzzleSessions {
    public static final Random RANDOM=new Random();
    private static UUID account;private static Path file;private static WordleGame wordle;private static KrillionGame krillion;
    private static String warning="";
    private PuzzleSessions(){}
    public static void load(){
        UUID next=Minecraft.getInstance().getUser().getProfileId();if(next.equals(account))return;
        save();account=next;warning="";file=FabricLoader.getInstance().getConfigDir().resolve("astra-puzzles/"+PremiumLicense.fingerprint(next)+".json");wordle=new WordleGame(RANDOM);krillion=new KrillionGame();
        try{if(Files.exists(file)){if(Files.size(file)>65536)throw new IllegalArgumentException("Puzzle save size");var j=JsonParser.parseString(Files.readString(file)).getAsJsonObject();if(j.get("schema").getAsInt()!=1||!j.get("accountHash").getAsString().equals(PremiumLicense.fingerprint(next)))throw new IllegalArgumentException("Puzzle account");var w=WordleGame.restore(j.getAsJsonObject("wordle"),RANDOM);var k=KrillionGame.restore(j.getAsJsonObject("krillion"));wordle=w;krillion=k;}}
        catch(Exception e){warning="Practice save could not be loaded; a fresh session is ready.";}
    }
    public static WordleGame wordle(){return wordle;}
    public static KrillionGame krillion(){return krillion;}
    public static String warning(){return warning;}
    public static void save(){
        if(file==null||wordle==null||krillion==null)return;
        try{var j=new JsonObject();j.addProperty("schema",1);j.addProperty("accountHash",PremiumLicense.fingerprint(account));j.add("wordle",wordle.json());j.add("krillion",krillion.json());Files.createDirectories(file.getParent());var temp=file.resolveSibling(file.getFileName()+".tmp");Files.writeString(temp,new GsonBuilder().setPrettyPrinting().create().toJson(j));try{Files.move(temp,file,StandardCopyOption.ATOMIC_MOVE,StandardCopyOption.REPLACE_EXISTING);}catch(AtomicMoveNotSupportedException e){Files.move(temp,file,StandardCopyOption.REPLACE_EXISTING);}}
        catch(Exception e){warning="Could not save practice progress. This session still works.";}
    }
    public static void pause(){if(krillion!=null)krillion.pause();save();}
}
