package client.astra;

import com.google.gson.*;
import java.util.*;

/** Account-local game state. It is not a server-verified prize entitlement. */
public final class CaseLedger {
    public static final long WINDOW=12*60*60*1000L;
    public record Draw(UUID id,CaseReward reward,long at,int line,boolean duplicate){}
    public final String accountHash;
    public long windowStarted,spent,total,lastSeen;
    public boolean crown,wings,skinTotem;
    public final EnumSet<CaseReward> owned=EnumSet.noneOf(CaseReward.class);
    public final List<Draw> claims=new ArrayList<>();
    public Draw lastDraw;public UUID seenWin;
    public CaseLedger(String accountHash){if(accountHash==null||!accountHash.matches("[0-9a-f]{64}"))throw new IllegalArgumentException("Account binding");this.accountHash=accountHash;}
    public boolean unlimited(){return owned.contains(CaseReward.INFINITE_CASES);}
    public int allowance(boolean premium){return premium?200:100;}
    public boolean roll(long now){
        now=Math.max(now,lastSeen);lastSeen=now;
        if(windowStarted>0 && now-windowStarted>=WINDOW){windowStarted=0;spent=0;return true;}return false;
    }
    public int remaining(boolean premium,long now){roll(now);return unlimited()?Integer.MAX_VALUE:Math.max(0,allowance(premium)-(int)spent);}
    public long refillIn(long now){return windowStarted==0?WINDOW:Math.max(0,WINDOW-(Math.max(now,lastSeen)-windowStarted));}
    public Draw open(boolean premium,long now,int ticket,int line,UUID id){
        if(remaining(premium,now)==0)return null;
        if(!unlimited()&&windowStarted==0)windowStarted=lastSeen;
        var reward=CaseReward.pick(ticket);boolean duplicate=reward.unlock()&&owned.contains(reward);
        if(!unlimited())spent++;total=Math.addExact(total,1);lastDraw=new Draw(Objects.requireNonNull(id),reward,lastSeen,Math.floorMod(line,CaseReward.MISS_LINES.length),duplicate);
        if(reward.unlock())owned.add(reward);
        if(reward.ticketClaim){claims.add(0,lastDraw);if(claims.size()>200)claims.removeLast();}
        return lastDraw;
    }
    public CaseLedger copy(){return decode(encode(),accountHash);}
    public String encode(){
        var j=new JsonObject();j.addProperty("schema",1);j.addProperty("accountHash",accountHash);j.addProperty("windowStarted",windowStarted);j.addProperty("spent",spent);j.addProperty("total",total);j.addProperty("lastSeen",lastSeen);j.addProperty("crown",crown);j.addProperty("wings",wings);j.addProperty("skinTotem",skinTotem);if(seenWin!=null)j.addProperty("seenWin",seenWin.toString());
        var list=new JsonArray();for(var reward:owned)list.add(reward.name());j.add("owned",list);if(lastDraw!=null)j.add("lastDraw",drawJson(lastDraw));
        var recent=new JsonArray();for(var claim:claims)recent.add(drawJson(claim));j.add("claims",recent);return new GsonBuilder().setPrettyPrinting().create().toJson(j);
    }
    public static JsonObject drawJson(Draw draw){var j=new JsonObject();j.addProperty("id",draw.id().toString());j.addProperty("reward",draw.reward().name());j.addProperty("at",draw.at());j.addProperty("line",draw.line());j.addProperty("duplicate",draw.duplicate());return j;}
    private static Draw readDraw(JsonObject j){var d=new Draw(UUID.fromString(j.get("id").getAsString()),CaseReward.valueOf(j.get("reward").getAsString()),j.get("at").getAsLong(),j.get("line").getAsInt(),j.get("duplicate").getAsBoolean());if(d.at()<0||d.line()<0||d.line()>=CaseReward.MISS_LINES.length)throw new IllegalArgumentException("Draw data");return d;}
    public static CaseLedger decode(String text,String account){
        if(text.length()>1_048_576)throw new IllegalArgumentException("Case data size");
        var j=JsonParser.parseString(text).getAsJsonObject();if(j.get("schema").getAsInt()!=1||!account.equals(j.get("accountHash").getAsString()))throw new IllegalArgumentException("Case account/schema");
        var value=new CaseLedger(account);value.windowStarted=j.get("windowStarted").getAsLong();value.spent=j.get("spent").getAsLong();value.total=j.get("total").getAsLong();value.lastSeen=j.get("lastSeen").getAsLong();
        if(value.spent<0||value.spent>200||value.total<value.spent||value.windowStarted<0||value.lastSeen<value.windowStarted||value.windowStarted==0&&value.spent!=0)throw new IllegalArgumentException("Case counter");
        for(var item:j.getAsJsonArray("owned")){var reward=CaseReward.valueOf(item.getAsString());if(!reward.unlock())throw new IllegalArgumentException("Unlock data");value.owned.add(reward);}
        value.crown=j.get("crown").getAsBoolean()&&value.owned.contains(CaseReward.CROWN);value.wings=j.get("wings").getAsBoolean()&&value.owned.contains(CaseReward.WINGS);value.skinTotem=j.get("skinTotem").getAsBoolean()&&value.owned.contains(CaseReward.SKIN_TOTEM);
        if(j.has("seenWin"))value.seenWin=UUID.fromString(j.get("seenWin").getAsString());
        if(j.has("lastDraw"))value.lastDraw=readDraw(j.getAsJsonObject("lastDraw"));
        var claims=j.getAsJsonArray("claims");if(claims.size()>200)throw new IllegalArgumentException("Claim list");for(var item:claims){var d=readDraw(item.getAsJsonObject());if(!d.reward().ticketClaim)throw new IllegalArgumentException("Claim reward");value.claims.add(d);}
        return value;
    }
}
