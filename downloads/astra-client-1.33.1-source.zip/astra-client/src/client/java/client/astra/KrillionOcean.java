package client.astra;

import net.minecraft.client.Minecraft;
import net.minecraft.client.gui.GuiGraphics;

/** Original vector fish and bounded underwater scenery; no copied artwork or web runtime. */
public final class KrillionOcean {
    private KrillionOcean(){}
    public static void draw(GuiGraphics g,KrillionDive dive,long now,boolean motion){
        double depth=dive.depth(now),camera=KrillionDive.camera(depth),seconds=now/1e9,flow=dive.flow(now);
        float dark=(float)(depth/7000);
        Ui.gradient(g,153,120,178,212,14,Ui.blend(0xFF257B93,0xFF211844,dark),Ui.blend(0xFF172D52,0xFF070C20,dark));
        g.enableScissor(155,122,329,330);
        try{
            for(int i=0;i<3;i++)g.fillGradient(166+i*54,122,176+i*54,330,Ui.tint(0x1849D7E3),Ui.tint(0x0049D7E3));
            int surface=(int)Math.round(147-camera);
            if(surface>=120){Ui.round(g,155,surface,174,3,1,0x887FE6EF);for(int i=0;i<5;i++){int y=surface+(motion?(int)Math.round(Math.sin(seconds*.8+i)*2):0);Ui.round(g,157+i*37,y,27,3,1,0x778BD9F1);}}
            int first=Math.max(0,(int)Math.floor((camera-62)/50));
            for(int n=first;n<first+7;n++){
                int y=(int)Math.round(182+n*50-camera);if(y<150||y>299)continue;
                g.fill(160,y,326,y+1,Ui.tint(0x2757ABC6));GamesPanel.small(g,n*500+" m",160,y+3,.55f,0xFF87BACF);
            }
            if(motion)for(int i=0;i<13;i++){
                double phase=seconds*(5+i%3)+i*19+camera*(.35+flow*.25);int y=127+Math.floorMod((int)(199-phase),195),x=169+Math.floorMod(i*47,145),r=2+i%3;
                Ui.round(g,x,y,r,r,r/2,Ui.alpha(0xFFAFE7EC,.18f+(float)flow*.16f));
            }
            int floor=(int)Math.round(182+700-camera+30);
            if(floor<332){g.fill(155,floor,329,332,Ui.tint(0xFF292140));for(int i=0;i<7;i++)Ui.round(g,156+i*27,floor-5-i%3*3,32,13,6,i%2==0?0xFF59405E:0xFF3F3557);}
            float bob=motion&&!dive.moving(now)?(float)Math.sin(seconds*1.6)*1.2f:0;
            fish(g,241,(float)KrillionDive.fishY(depth)+bob,(float)(flow*1.15),motion?(float)Math.sin(seconds*(dive.moving(now)?12:4))*.17f:0);
        }finally{g.disableScissor();}
        GamesPanel.small(g,"DEPTH",164,129,.65f,0xFFB6EDF0);
        Ui.round(g,198,304,88,20,7,0xB8151A35);
        Ui.centered(g,Minecraft.getInstance().font,Math.round(depth)+" m",242,309,.85f,0xFFD9F6F4);
    }
    private static void fish(GuiGraphics g,float x,float y,float pitch,float tail){
        g.pose().pushMatrix();g.pose().translate(x,y);g.pose().rotate(pitch);
        try{
            Ui.round(g,-25,-16,53,34,16,0x194DD8F1);
            g.pose().pushMatrix();g.pose().translate(-18,0);g.pose().rotate(tail);
            for(int row=-10;row<=10;row++){int wide=11-Math.abs(row)/2;g.fill(-wide-9,row,-3,row+1,Ui.tint(row<0?0xFF8AE8DD:0xFF498DCA));}g.pose().popMatrix();
            Ui.round(g,-11,-16,17,8,4,0xFF8D83E5);
            Ui.gradient(g,-22,-13,48,28,13,0xFFF4ADC8,0xFFAF64C2);
            Ui.round(g,-16,5,33,8,4,0xFFD59DDA);
            Ui.round(g,-9,2,13,12,5,0xFF8CDDD6);
            Ui.round(g,9,-9,13,14,6,0xFFF7F5FC);Ui.round(g,16,-6,6,8,3,0xFF25213B);Ui.round(g,17,-6,2,2,1,0xFFFFFFFF);
            Ui.round(g,15,6,7,3,1,0xFFEBC4E0);g.fill(23,3,27,4,Ui.tint(0xFF744B91));
            Ui.round(g,-13,-6,5,3,1,0x47FFFFFF);Ui.round(g,-5,-9,9,3,1,0x47FFFFFF);
        }finally{g.pose().popMatrix();}
    }
}
