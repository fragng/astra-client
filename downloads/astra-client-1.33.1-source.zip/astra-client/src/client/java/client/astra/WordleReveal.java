package client.astra;

/** Time-based tile flips; game scoring/saves commit once, presentation reveals gradually. */
public final class WordleReveal {
    public static final double FLIP=.48,STAGGER=.20,DURATION=FLIP+4*STAGGER;
    private int row=-1;
    private long started;
    public void start(int row,long now){this.row=row;started=now;}
    public boolean moving(long now,boolean animate){return animate && row>=0 && (now-started)/1e9<DURATION;}
    public boolean colourVisible(int testRow,int column,long now,boolean animate){return !animate || testRow!=row || (now-started)/1e9>=column*STAGGER+FLIP/2;}
    public float scale(int testRow,int column,long now,boolean animate){
        if(!animate || testRow!=row)return 1;
        double t=Math.clamp(((now-started)/1e9-column*STAGGER)/FLIP,0,1);
        return Math.max(.04f,(float)Math.abs(Math.cos(t*Math.PI)));
    }
    public int visibleRows(int rows,long now,boolean animate){return moving(now,animate)?Math.min(rows,row):rows;}
    public void reset(){row=-1;}
}
