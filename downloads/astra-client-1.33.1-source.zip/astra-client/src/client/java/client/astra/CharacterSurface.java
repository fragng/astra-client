package client.astra;

import java.util.List;

/** Small, closed surface recesses: the back of a sponge stays solid. Built once. */
public final class CharacterSurface {
    public record Pore(float x,float y,float radius,float depth){
        public Pore {if(!(radius>0 && depth>0 && depth<=radius))throw new IllegalArgumentException("pore dimensions");}
    }
    private CharacterSurface(){}
    public static CharacterMesh.Mesh recess(CharacterMesh.Mesh original,List<Pore> pores){
        if(pores.isEmpty())return original;
        float[] v=original.vertices().clone();float middle=(original.minZ()+original.maxZ())/2;
        for(int i=0;i<v.length;i+=6){
            if(v[i+2]>=middle || v[i+5]>-.5f)continue;
            double displacement=0,dx=0,dy=0;
            for(Pore p:pores){
                double x=v[i]-p.x,y=v[i+1]-p.y,r2=(x*x+y*y)/(p.radius*p.radius);
                if(r2>=1)continue;
                double f=1-r2;displacement+=p.depth*f*f;
                dx+=-4*p.depth*f*x/(p.radius*p.radius);dy+=-4*p.depth*f*y/(p.radius*p.radius);
            }
            // Always leave a solid back, even if a custom resource pack supplies large pores.
            displacement=Math.min(displacement,(original.maxZ()-v[i+2])*.2);
            v[i+2]+=(float)displacement;
            double nx=v[i+3]-v[i+5]*dx,ny=v[i+4]-v[i+5]*dy,nz=v[i+5],length=Math.sqrt(nx*nx+ny*ny+nz*nz);
            v[i+3]=(float)(nx/length);v[i+4]=(float)(ny/length);v[i+5]=(float)(nz/length);
        }
        return new CharacterMesh.Mesh(v,original.minX(),original.minY(),original.minZ(),original.maxX(),original.maxY(),original.maxZ());
    }
    /** Bend a thin closed facial patch onto a precomputed skin-height grid. */
    public static CharacterMesh.Mesh drape(CharacterMesh.Mesh source,float x,float y,float width,float height,float[][] grid){
        int rows=grid.length,cols=grid[0].length;
        if(rows<2||cols<2||width<=0||height<=0)throw new IllegalArgumentException("surface grid");
        for(float[] row:grid){if(row.length!=cols)throw new IllegalArgumentException("ragged surface");for(float z:row)if(!Float.isFinite(z))throw new IllegalArgumentException("surface value");}
        float[] v=source.vertices().clone();float minZ=Float.POSITIVE_INFINITY,maxZ=Float.NEGATIVE_INFINITY;
        for(int i=0;i<v.length;i+=6){
            float u=Math.clamp((v[i]-x)/width,0,1)*(cols-1),t=Math.clamp((v[i+1]-y)/height,0,1)*(rows-1);
            int cx=Math.min((int)u,cols-2),cy=Math.min((int)t,rows-2);float fu=u-cx,fv=t-cy;
            float a=grid[cy][cx],b=grid[cy][cx+1],c=grid[cy+1][cx],d=grid[cy+1][cx+1];
            float offset=(a+(b-a)*fu)*(1-fv)+(c+(d-c)*fu)*fv;
            float dx=((b-a)*(1-fv)+(d-c)*fv)*(cols-1)/width,dy=((c-a)*(1-fu)+(d-b)*fu)*(rows-1)/height;
            v[i+2]+=offset;float nx=v[i+3]-v[i+5]*dx,ny=v[i+4]-v[i+5]*dy,nz=v[i+5];float length=(float)Math.sqrt(nx*nx+ny*ny+nz*nz);
            v[i+3]=nx/length;v[i+4]=ny/length;v[i+5]=nz/length;minZ=Math.min(minZ,v[i+2]);maxZ=Math.max(maxZ,v[i+2]);
        }
        return new CharacterMesh.Mesh(v,source.minX(),source.minY(),minZ,source.maxX(),source.maxY(),maxZ);
    }
    public static int shade(float x,float y,float z,String material,List<Pore> pores){
        if(material.isEmpty())return 255;
        double grain=(Math.sin(x*41+y*29+z*53)*Math.sin(x*17-y*37+z*19)+1)*.5;
        double value=1-(material.equals("fabric")?.055:.035)*grain;
        if(material.equals("sponge") && z<0)for(Pore p:pores){
            double r2=((x-p.x)*(x-p.x)+(y-p.y)*(y-p.y))/(p.radius*p.radius);
            if(r2<1)value-=.23*(1-r2)*(1-r2);
        }
        return (int)Math.clamp(Math.round(value*255),0,255);
    }
}
