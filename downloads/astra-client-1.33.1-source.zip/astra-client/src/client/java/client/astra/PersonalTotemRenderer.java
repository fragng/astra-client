package client.astra;

import com.mojang.blaze3d.vertex.PoseStack;
import com.mojang.serialization.MapCodec;
import net.minecraft.client.Minecraft;
import net.minecraft.client.model.player.PlayerModel;
import net.minecraft.client.model.geom.ModelLayers;
import net.minecraft.client.renderer.SubmitNodeCollector;
import net.minecraft.client.renderer.entity.state.AvatarRenderState;
import net.minecraft.client.renderer.rendertype.RenderTypes;
import net.minecraft.client.renderer.special.*;
import net.minecraft.client.renderer.texture.OverlayTexture;
import net.minecraft.resources.Identifier;
import net.minecraft.world.entity.HumanoidArm;
import net.minecraft.world.entity.player.*;
import net.minecraft.world.item.*;
import net.minecraft.core.component.DataComponents;
import org.joml.*;
import java.util.function.Consumer;

/** Native 3D player geometry samples the already-loaded skin; no downloads/readback/reloads. */
public final class PersonalTotemRenderer implements SpecialModelRenderer<PlayerSkin> {
    public static final Identifier ID=Identifier.fromNamespaceAndPath(AstraClient.MOD_ID,"personal_totem"),ITEM=Identifier.fromNamespaceAndPath(AstraClient.MOD_ID,"totem/personal");
    private final PlayerModel wide,slim;
    private static ItemStack preview;
    private PersonalTotemRenderer(BakingContext context){wide=new PlayerModel(context.entityModelSet().bakeLayer(ModelLayers.PLAYER),false);slim=new PlayerModel(context.entityModelSet().bakeLayer(ModelLayers.PLAYER_SLIM),true);}
    public static void initialize(){SpecialModelRenderers.ID_MAPPER.put(ID,Unbaked.CODEC);}
    public record Unbaked() implements SpecialModelRenderer.Unbaked {
        public static final MapCodec<Unbaked> CODEC=MapCodec.unit(new Unbaked());
        public SpecialModelRenderer<?> bake(BakingContext context){return new PersonalTotemRenderer(context);}
        public MapCodec<Unbaked> type(){return CODEC;}
    }
    public PlayerSkin extractArgument(ItemStack stack){var mc=Minecraft.getInstance();return mc.player==null?net.minecraft.client.resources.DefaultPlayerSkin.get(mc.getUser().getProfileId()):mc.player.getSkin();}
    public void submit(PlayerSkin skin,ItemDisplayContext context,PoseStack pose,SubmitNodeCollector collector,int light,int overlay,boolean foil,int outline){
        if(skin==null)return;
        var model=skin.model()==PlayerModelType.SLIM?slim:wide;var state=new AvatarRenderState();state.skin=skin;state.scale=state.ageScale=state.speedValue=1;state.mainArm=state.attackArm=HumanoidArm.RIGHT;
        state.rightArmPose=state.leftArmPose=net.minecraft.client.model.HumanoidModel.ArmPose.EMPTY;
        state.showHat=state.showJacket=state.showLeftSleeve=state.showRightSleeve=state.showLeftPants=state.showRightPants=true;
        pose.pushPose();
        try{pose.translate(.5,.72,.5);pose.scale(.44f,-.44f,-.44f);collector.submitModel(model,state,pose,RenderTypes.entityCutoutNoCull(skin.body().texturePath()),light,OverlayTexture.NO_OVERLAY,0xFFFFFFFF,null,outline,null);}finally{pose.popPose();}
    }
    public void getExtents(Consumer<Vector3fc> consumer){for(float x:new float[]{.22f,.78f})for(float y:new float[]{.02f,.98f})for(float z:new float[]{.32f,.68f})consumer.accept(new Vector3f(x,y,z));}
    public static void preview(net.minecraft.client.gui.GuiGraphics g,int x,int y,int size){
        if(preview==null){preview=new ItemStack(Items.PAPER);preview.set(DataComponents.ITEM_MODEL,ITEM);}
        g.pose().pushMatrix();g.pose().translate(x,y);g.pose().scale(size/16f,size/16f);g.renderFakeItem(preview,0,0);g.pose().popMatrix();
    }
}
