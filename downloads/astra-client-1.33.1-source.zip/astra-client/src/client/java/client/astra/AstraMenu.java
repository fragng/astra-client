package client.astra;

import net.fabricmc.fabric.api.client.screen.v1.Screens;
import net.minecraft.client.Minecraft;
import net.minecraft.client.gui.GuiGraphics;
import net.minecraft.client.gui.components.AbstractWidget;
import net.minecraft.client.gui.screens.TitleScreen;
import java.util.ArrayList;

public final class AstraMenu {
    private AstraMenu() {}
    public static int margin(int width) { return width < 480 ? 12 : 20; }
    public static int center(int width) { return width / 2; }
    public static int menuTop(int height) { return height / 4 + 32; }
    public static int buttonWidth(int width,int center,int preferred){
        return Math.max(1,Math.min(preferred,Math.max(1,Math.min(center-12,width-12-center))*2));
    }

    private static String key(AbstractWidget widget) {
        return widget.getMessage().getContents() instanceof net.minecraft.network.chat.contents.TranslatableContents t ? t.getKey() : "";
    }
    private static boolean vanilla(AbstractWidget widget) {
        return java.util.Set.of("menu.singleplayer", "menu.multiplayer", "menu.online", "menu.options", "menu.quit",
            "options.language", "options.accessibility", "narrator.button.language", "narrator.button.accessibility").contains(key(widget));
    }
    private static AbstractWidget mods(TitleScreen screen) {
        for (AbstractWidget widget : Screens.getButtons(screen)) {
            if (key(widget).equals("modmenu.title") || key(widget).startsWith("modmenu.mods") || widget.getMessage().getString().equalsIgnoreCase("Mods")) return widget;
        }
        return null;
    }
    public static void alignToMods(TitleScreen screen) {
        AbstractWidget anchor = mods(screen);
        if(anchor!=null && screen.width<480) {
            // Keep Mods' original x/y, but shrink its width on narrow windows.
            anchor.setWidth(Math.min(anchor.getWidth(),Math.max(90,screen.width-margin(screen.width)-anchor.getX())));
        }
        int c=anchor==null?center(screen.width):anchor.getX()+anchor.getWidth()/2;
        int buttonWidth=buttonWidth(screen.width,c,anchor==null || anchor.getWidth()<90?200:anchor.getWidth()),half=(buttonWidth-6)/2;
        for(AbstractWidget widget:Screens.getButtons(screen)) {
            String id=key(widget);
            switch(id) {
                case "menu.singleplayer", "menu.multiplayer", "menu.online" -> {
                    widget.setX(c-buttonWidth/2);widget.setWidth(buttonWidth);
                    if(anchor!=null)widget.setY(anchor.getY()-(id.equals("menu.singleplayer")?78:id.equals("menu.multiplayer")?52:26));
                }
                case "menu.options", "menu.quit" -> {
                    widget.setWidth(half);widget.setX(id.equals("menu.options")?c-buttonWidth/2:c+3);
                    if(anchor!=null)widget.setY(anchor.getY()+anchor.getHeight()+10);
                }
                case "options.language", "options.accessibility", "narrator.button.language", "narrator.button.accessibility" -> {
                    boolean language=id.contains("language");
                    widget.setX(screen.width<480?(language?12:36):(language?c-24:c+4));
                    if(anchor!=null)widget.setY(anchor.getY()+anchor.getHeight()+(screen.width<480?11:38));
                }
            }
        }
    }
    public static void initialize(TitleScreen screen) {
        int center = center(screen.width), menuWidth = Math.min(200, center * 2 - 24);
        int oldTop = screen.height / 4 + 48, top = menuTop(screen.height);
        var buttons = Screens.getButtons(screen);
        for (AbstractWidget widget : new ArrayList<>(buttons)) {
            int oldX = widget.getX(), oldY = widget.getY(), oldWidth = widget.getWidth();
            if (oldY >= screen.height - 30 || !vanilla(widget)) continue;
            if (oldWidth >= 200) {
                widget.setX(center - menuWidth / 2);
                widget.setWidth(menuWidth);
                widget.setHeight(22);
                widget.setY(top + Math.round((oldY - oldTop) / 24f) * 26);
            } else if (oldWidth >= 90) {
                int half = (menuWidth - 6) / 2;
                widget.setX(oldX < screen.width / 2 ? center - menuWidth / 2 : center + 3);
                widget.setWidth(half);
                widget.setHeight(22);
                widget.setY(top + 82);
            } else if (oldWidth == 20) {
                widget.setX(oldX < screen.width / 2 ? center - 24 : center + 4);
                widget.setY(top + 110);
            }
            if (oldWidth >= 90) widget.setMessage(widget.getMessage().copy().withStyle(s -> s.withFont(Ui.FONT)));
        }
    }

    public static void drawHeading(GuiGraphics g, int width, int height, float alpha) {
        var font = Minecraft.getInstance().font;
        int center = center(width);
        if (Minecraft.getInstance().screen instanceof TitleScreen title) {
            AbstractWidget anchor = mods(title);
            if (anchor != null) center = anchor.getX() + anchor.getWidth() / 2;
        }
        int y = Math.max(12, menuTop(height) - 90);
        float titleScale=Math.min(width<400?1.9f:2.5f,Math.max(80,Math.min(center-12,width-12-center)*2)/(float)font.width(Ui.heading(AstraClient.NAME)));
        Ui.centered(g, font, AstraClient.NAME, center, y, titleScale, Ui.alpha(0xFFF7F5FF, alpha));
        Ui.centered(g, font, "Get Client Free at", center, y + 33, 1f, Ui.alpha(0xFFC2C5D9, alpha));
        Ui.centered(g, font, ".gg/astrayt", center, y + 47, 1.15f, Ui.alpha(AstraConfig.colour().accent, alpha));
    }
}
