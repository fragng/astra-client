package client.astra;

import net.minecraft.client.gui.GuiGraphics;
import net.minecraft.client.gui.screens.Screen;
import net.minecraft.client.input.CharacterEvent;
import net.minecraft.client.input.KeyEvent;
import net.minecraft.client.input.MouseButtonEvent;
import net.minecraft.network.chat.Component;
import org.lwjgl.glfw.GLFW;

/** Larger dedicated puzzle board. Cosmetic reveals never reroll or defer the saved result. */
public final class WordleScreen extends Screen {
    private static final int W=500,H=500;
    private final Screen parent;
    private final WordleReveal reveal=new WordleReveal();
    private final int[] feedback=new int[26];
    private int cachedRows=-1;
    private float scale,ox,oy;
    private boolean revealing;
    public WordleScreen(Screen parent){super(Component.literal("Astra Wordle"));this.parent=parent;}
    private void fit(){scale=Math.min(1.4f,Math.min((width-18f)/W,(height-18f)/H));ox=(width-W*scale)/2;oy=(height-H*scale)/2;}
    @Override protected void init(){
        PuzzleSessions.load();fit();
        addRenderableWidget(new MenuButton(12,12,105,26,"Back to Games","",()->false,false,this::onClose));
        addRenderableWidget(new MenuButton(460,12,28,26,"X","",()->false,false,this::onClose));
        String[] rows={"QWERTYUIOP","ASDFGHJKL","ZXCVBNM"};
        for(int row=0;row<rows.length;row++)for(int n=0;n<rows[row].length();n++){
            char c=rows[row].charAt(n);int x=row==0?37+n*43:row==1?59+n*43:102+n*43;
            addRenderableWidget(new WordKey(x,346+row*33,39,28,String.valueOf(c),()->feedback[c-'A'],this::inputAllowed,()->type(c)));
        }
        addRenderableWidget(new WordKey(37,412,61,28,"ENTER",()->0,this::inputAllowed,this::submit));
        addRenderableWidget(new WordKey(403,412,61,28,"DEL",()->0,this::inputAllowed,this::backspace));
        addRenderableWidget(new MenuButton(170,456,160,27,"New Word","Wordle",()->false,false,()->{
            PuzzleSessions.wordle().newWord(PuzzleSessions.RANDOM);reveal.reset();cachedRows=-1;PuzzleSessions.save();
        }).available(()->!reveal.moving(System.nanoTime(),AstraConfig.animations)));
    }
    private boolean inputAllowed(){return !revealing && !PuzzleSessions.wordle().finished();}
    private void type(int codepoint){if(!reveal.moving(System.nanoTime(),AstraConfig.animations)){PuzzleSessions.wordle().type(codepoint);PuzzleSessions.save();}}
    private void backspace(){if(!reveal.moving(System.nanoTime(),AstraConfig.animations)){PuzzleSessions.wordle().backspace();PuzzleSessions.save();}}
    private void submit(){
        if(reveal.moving(System.nanoTime(),AstraConfig.animations))return;
        var game=PuzzleSessions.wordle();if(game.submit()){reveal.start(game.guesses().size()-1,System.nanoTime());cachedRows=-1;PuzzleSessions.save();}
    }
    private void updateFeedback(long now){
        var game=PuzzleSessions.wordle();int rows=reveal.visibleRows(game.guesses().size(),now,AstraConfig.animations);if(rows==cachedRows)return;
        java.util.Arrays.fill(feedback,0);
        for(int i=0;i<rows;i++){int[] marks=game.row(i);String word=game.guesses().get(i);for(int n=0;n<5;n++){int c=word.charAt(n)-'A';feedback[c]=Math.max(feedback[c],marks[n]);}}
        cachedRows=rows;
    }
    @Override public void render(GuiGraphics g,int mouseX,int mouseY,float delta){
        fit();long now=System.nanoTime();revealing=reveal.moving(now,AstraConfig.animations);updateFeedback(now);
        g.fill(0,0,width,height,0xBF000000);g.pose().pushMatrix();g.pose().translate(ox,oy);g.pose().scale(scale,scale);
        try{
            var p=AstraConfig.colour();Ui.round(g,-1,-1,W+2,H+2,18,p.border);Ui.round(g,0,0,W,H,17,p.background);
            Ui.centered(g,font,"WORDLE",250,18,1.75f,0xFFFFFFFF);Ui.centered(g,font,"Five letters / six guesses",250,53,.9f,0xFFCCCCCC);
            var game=PuzzleSessions.wordle();var guesses=game.guesses();
            for(int row=0;row<6;row++){
                String letters=row<guesses.size()?guesses.get(row):row==guesses.size()?game.input():"";int[] marks=row<guesses.size()?game.row(row):null;
                for(int col=0;col<5;col++){
                    int x=113+col*56,y=75+row*39;float flip=reveal.scale(row,col,now,AstraConfig.animations);
                    int mark=marks!=null && reveal.colourVisible(row,col,now,AstraConfig.animations)?marks[col]:0;
                    g.pose().pushMatrix();g.pose().translate(x+25,y+17);g.pose().scale(1,flip);
                    Ui.round(g,-25,-17,50,34,5,mark==0?p.border:WordKey.color(mark));Ui.round(g,-24,-16,48,32,4,mark==0?p.panelBottom:WordKey.color(mark));
                    if(col<letters.length())Ui.centered(g,font,String.valueOf(letters.charAt(col)),0,-7,1.65f,0xFFFFFFFF);
                    g.pose().popMatrix();
                }
            }
            String status=revealing?"Revealing guess...":game.message();
            float messageScale=Math.min(.88f,472f/Math.max(1,font.width(Ui.text(status))));Ui.centered(g,font,status,250,319,messageScale,game.solved()&&!revealing?0xFFA9EAC0:0xFFD9D9DE);
            for(var element:children())if(element instanceof net.minecraft.client.gui.components.Renderable child)child.render(g,(int)((mouseX-ox)/scale),(int)((mouseY-oy)/scale),delta);
            Ui.centered(g,font,"Unlimited puzzles / saved automatically",250,487,.7f,0xFFAAAAAA);
        }finally{g.pose().popMatrix();}
    }
    @Override public boolean mouseClicked(MouseButtonEvent e,boolean doubled){return super.mouseClicked(new MouseButtonEvent((e.x()-ox)/scale,(e.y()-oy)/scale,e.buttonInfo()),doubled);}
    @Override public boolean mouseReleased(MouseButtonEvent e){return super.mouseReleased(new MouseButtonEvent((e.x()-ox)/scale,(e.y()-oy)/scale,e.buttonInfo()));}
    @Override public boolean keyPressed(KeyEvent e){if(e.key()==GLFW.GLFW_KEY_ESCAPE){onClose();return true;}if(e.key()==GLFW.GLFW_KEY_ENTER||e.key()==GLFW.GLFW_KEY_KP_ENTER){submit();return true;}if(e.key()==GLFW.GLFW_KEY_BACKSPACE){backspace();return true;}return super.keyPressed(e);}
    @Override public boolean charTyped(CharacterEvent e){type(e.codepoint());return true;}
    @Override public void removed(){PuzzleSessions.save();}
    @Override public void onClose(){minecraft.setScreen(parent);}
}
