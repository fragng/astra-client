package client.astra.mixin;

import client.astra.ClientMenuScreen;
import client.astra.PerformanceMode;
import net.minecraft.client.gui.GuiGraphics;
import net.minecraft.client.gui.screens.Screen;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;

@Mixin(Screen.class)
public abstract class ScreenMixin {
    @Inject(method="renderBlurredBackground",at=@At("HEAD"),cancellable=true)
    private void astra$performanceBlur(GuiGraphics graphics,CallbackInfo ci){
        if((Object)this instanceof ClientMenuScreen && PerformanceMode.enabled())ci.cancel();
    }
}
