package client.astra;

import org.lwjgl.glfw.GLFW;
import java.awt.Component;
import java.awt.event.InputEvent;
import java.awt.event.KeyEvent;

/** GLFW emits no character callback for these text editing keys; Chromium needs one. */
public final class BrowserInput {
    private BrowserInput(){}
    public static int controlCharacter(int key){return switch(key){
        case GLFW.GLFW_KEY_ENTER,GLFW.GLFW_KEY_KP_ENTER -> '\r';
        case GLFW.GLFW_KEY_BACKSPACE -> '\b';
        case GLFW.GLFW_KEY_DELETE -> 0x7F;
        case GLFW.GLFW_KEY_TAB -> '\t';
        default -> -1;
    };}

    /** JCEF reads this field from the event's runtime class on Windows. No reflective JDK access. */
    public static final class NativeKeyEvent extends KeyEvent {
        public final long scancode;
        private NativeKeyEvent(Component source,int kind,int modifiers,int keyCode,char character,int scancode){
            super(source,kind,System.currentTimeMillis(),modifiers,keyCode,character);
            this.scancode=scancode;
        }
    }
    public static NativeKeyEvent event(Component source,boolean pressed,int key,int scan,int modifiers,boolean linux){
        int awt=keyCode(key);char character=character(key,linux);int mask=0;
        if((modifiers&GLFW.GLFW_MOD_SHIFT)!=0)mask|=InputEvent.SHIFT_DOWN_MASK;
        if((modifiers&GLFW.GLFW_MOD_CONTROL)!=0)mask|=InputEvent.CTRL_DOWN_MASK;
        if((modifiers&GLFW.GLFW_MOD_ALT)!=0)mask|=InputEvent.ALT_DOWN_MASK;
        if((modifiers&GLFW.GLFW_MOD_SUPER)!=0)mask|=InputEvent.META_DOWN_MASK;
        return new NativeKeyEvent(source,pressed?KeyEvent.KEY_PRESSED:KeyEvent.KEY_RELEASED,mask,awt,character,scan);
    }
    private static char character(int key,boolean linux){
        int control=controlCharacter(key);if(control>=0)return (char)control;
        if(key>=32&&key<=126)return (char)key;
        if(key>=GLFW.GLFW_KEY_KP_0&&key<=GLFW.GLFW_KEY_KP_9)return (char)('0'+key-GLFW.GLFW_KEY_KP_0);
        // JCEF's Linux adapter uses an X keysym for keys not in its explicit editing-key table.
        if(linux)return switch(key){
            case GLFW.GLFW_KEY_HOME -> '\uFF50';case GLFW.GLFW_KEY_END -> '\uFF57';
            case GLFW.GLFW_KEY_PAGE_UP -> '\uFF55';case GLFW.GLFW_KEY_PAGE_DOWN -> '\uFF56';case GLFW.GLFW_KEY_INSERT -> '\uFF63';
            case GLFW.GLFW_KEY_LEFT_SHIFT -> '\uFFE1';case GLFW.GLFW_KEY_RIGHT_SHIFT -> '\uFFE2';
            case GLFW.GLFW_KEY_LEFT_CONTROL -> '\uFFE3';case GLFW.GLFW_KEY_RIGHT_CONTROL -> '\uFFE4';
            case GLFW.GLFW_KEY_LEFT_ALT -> '\uFFE9';case GLFW.GLFW_KEY_RIGHT_ALT -> '\uFFEA';
            case GLFW.GLFW_KEY_LEFT_SUPER -> '\uFFEB';case GLFW.GLFW_KEY_RIGHT_SUPER -> '\uFFEC';
            default -> key>=GLFW.GLFW_KEY_F1&&key<=GLFW.GLFW_KEY_F25?(char)(0xFFBE+key-GLFW.GLFW_KEY_F1):KeyEvent.CHAR_UNDEFINED;
        };
        return KeyEvent.CHAR_UNDEFINED;
    }
    private static int keyCode(int key){
        if(key>=32&&key<=126)return KeyEvent.getExtendedKeyCodeForChar(key);
        if(key>=GLFW.GLFW_KEY_KP_0&&key<=GLFW.GLFW_KEY_KP_9)return KeyEvent.VK_NUMPAD0+key-GLFW.GLFW_KEY_KP_0;
        if(key>=GLFW.GLFW_KEY_F1&&key<=GLFW.GLFW_KEY_F12)return KeyEvent.VK_F1+key-GLFW.GLFW_KEY_F1;
        if(key>=GLFW.GLFW_KEY_F13&&key<=GLFW.GLFW_KEY_F24)return KeyEvent.VK_F13+key-GLFW.GLFW_KEY_F13;
        return switch(key){
            case GLFW.GLFW_KEY_ESCAPE -> KeyEvent.VK_ESCAPE;case GLFW.GLFW_KEY_ENTER,GLFW.GLFW_KEY_KP_ENTER -> KeyEvent.VK_ENTER;
            case GLFW.GLFW_KEY_BACKSPACE -> KeyEvent.VK_BACK_SPACE;case GLFW.GLFW_KEY_DELETE -> KeyEvent.VK_DELETE;case GLFW.GLFW_KEY_TAB -> KeyEvent.VK_TAB;
            case GLFW.GLFW_KEY_LEFT -> KeyEvent.VK_LEFT;case GLFW.GLFW_KEY_RIGHT -> KeyEvent.VK_RIGHT;case GLFW.GLFW_KEY_UP -> KeyEvent.VK_UP;case GLFW.GLFW_KEY_DOWN -> KeyEvent.VK_DOWN;
            case GLFW.GLFW_KEY_HOME -> KeyEvent.VK_HOME;case GLFW.GLFW_KEY_END -> KeyEvent.VK_END;case GLFW.GLFW_KEY_INSERT -> KeyEvent.VK_INSERT;
            case GLFW.GLFW_KEY_PAGE_UP -> KeyEvent.VK_PAGE_UP;case GLFW.GLFW_KEY_PAGE_DOWN -> KeyEvent.VK_PAGE_DOWN;
            case GLFW.GLFW_KEY_LEFT_SHIFT,GLFW.GLFW_KEY_RIGHT_SHIFT -> KeyEvent.VK_SHIFT;
            case GLFW.GLFW_KEY_LEFT_CONTROL,GLFW.GLFW_KEY_RIGHT_CONTROL -> KeyEvent.VK_CONTROL;
            case GLFW.GLFW_KEY_LEFT_ALT,GLFW.GLFW_KEY_RIGHT_ALT -> KeyEvent.VK_ALT;
            case GLFW.GLFW_KEY_LEFT_SUPER,GLFW.GLFW_KEY_RIGHT_SUPER -> KeyEvent.VK_META;
            case GLFW.GLFW_KEY_KP_ADD -> KeyEvent.VK_ADD;case GLFW.GLFW_KEY_KP_SUBTRACT -> KeyEvent.VK_SUBTRACT;case GLFW.GLFW_KEY_KP_MULTIPLY -> KeyEvent.VK_MULTIPLY;
            case GLFW.GLFW_KEY_KP_DIVIDE -> KeyEvent.VK_DIVIDE;case GLFW.GLFW_KEY_KP_DECIMAL -> KeyEvent.VK_DECIMAL;case GLFW.GLFW_KEY_KP_EQUAL -> KeyEvent.VK_EQUALS;
            default -> KeyEvent.VK_UNDEFINED;
        };
    }
}
