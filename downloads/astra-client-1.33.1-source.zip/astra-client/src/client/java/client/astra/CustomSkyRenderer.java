package client.astra;

import com.mojang.blaze3d.buffers.GpuBuffer;
import com.mojang.blaze3d.pipeline.*;
import com.mojang.blaze3d.platform.DepthTestFunction;
import com.mojang.blaze3d.shaders.UniformType;
import com.mojang.blaze3d.systems.RenderSystem;
import com.mojang.blaze3d.vertex.*;
import net.minecraft.client.Minecraft;
import net.minecraft.resources.Identifier;
import org.joml.*;
import java.util.OptionalDouble;
import java.util.OptionalInt;

/** A cached upper-hemisphere panorama drawn in vanilla's Overworld sky pass. */
public final class CustomSkyRenderer {
    private static final int SEGMENTS=48,BANDS=12,INDICES=SEGMENTS*BANDS*6;
    private static final RenderPipeline PIPELINE=RenderPipeline.builder()
        .withLocation(Identifier.fromNamespaceAndPath(AstraClient.MOD_ID,"pipeline/custom_sky"))
        .withVertexShader("core/position_tex_color").withFragmentShader("core/position_tex_color")
        .withSampler("Sampler0").withUniform("DynamicTransforms",UniformType.UNIFORM_BUFFER).withUniform("Projection",UniformType.UNIFORM_BUFFER)
        .withVertexFormat(DefaultVertexFormat.POSITION_TEX_COLOR,VertexFormat.Mode.QUADS)
        .withDepthTestFunction(DepthTestFunction.NO_DEPTH_TEST).withDepthWrite(false).withCull(false).withBlend(BlendFunction.TRANSLUCENT).build();
    private static GpuBuffer vertices;
    private static long last=System.nanoTime();
    private static float angle;
    private CustomSkyRenderer(){}
    public static boolean active(){return PremiumEdition.premium() && AstraConfig.skyTheme()!=SkyTheme.VANILLA;}
    private static void vertex(BufferBuilder b,int longitude,int latitude){
        double a=longitude/(double)SEGMENTS*java.lang.Math.PI*2,p=latitude/(double)BANDS*java.lang.Math.PI/2;
        float r=(float)java.lang.Math.cos(p)*100;
        int alpha=java.lang.Math.round(java.lang.Math.clamp((float)(p/(java.lang.Math.PI/12)),0,1)*255);
        b.addVertex((float)java.lang.Math.cos(a)*r,(float)java.lang.Math.sin(p)*100,(float)java.lang.Math.sin(a)*r)
            .setUv(longitude/(float)SEGMENTS,1-latitude/(float)BANDS).setColor(255,255,255,alpha);
    }
    private static void ensureMesh(){
        if(vertices!=null)return;
        try(var bytes=new ByteBufferBuilder(SEGMENTS*BANDS*4*24)){
            var b=new BufferBuilder(bytes,VertexFormat.Mode.QUADS,DefaultVertexFormat.POSITION_TEX_COLOR);
            for(int y=0;y<BANDS;y++)for(int x=0;x<SEGMENTS;x++){
                vertex(b,x,y);vertex(b,x+1,y);vertex(b,x+1,y+1);vertex(b,x,y+1);
            }
            try(var mesh=b.buildOrThrow()){
                vertices=RenderSystem.getDevice().createBuffer(()->"Astra sky dome",GpuBuffer.USAGE_VERTEX,mesh.vertexBuffer());
            }
        }
    }
    public static void draw(){
        if(!active())return;
        ensureMesh();var mc=Minecraft.getInstance();var target=mc.getMainRenderTarget();
        var texture=mc.getTextureManager().getTexture(AstraConfig.skyTheme().texture);
        var indices=RenderSystem.getSequentialBuffer(VertexFormat.Mode.QUADS);
        var indexBuffer=indices.getBuffer(INDICES);
        long now=System.nanoTime();float dt=java.lang.Math.clamp((now-last)/1e9f,0,.1f);last=now;
        if(AstraConfig.animations && !PerformanceMode.enabled())angle=(angle+dt*.002f)%(float)(java.lang.Math.PI*2);
        var transform=RenderSystem.getDynamicUniforms().writeTransform(new Matrix4f(RenderSystem.getModelViewMatrix()).rotateY(angle),new Vector4f(1),new Vector3f(),new Matrix4f());
        try(var pass=RenderSystem.getDevice().createCommandEncoder().createRenderPass(()->"Astra custom sky",target.getColorTextureView(),OptionalInt.empty(),target.getDepthTextureView(),OptionalDouble.empty())){
            pass.setPipeline(PIPELINE);RenderSystem.bindDefaultUniforms(pass);pass.setUniform("DynamicTransforms",transform);
            pass.bindTexture("Sampler0",texture.getTextureView(),texture.getSampler());
            pass.setVertexBuffer(0,vertices);pass.setIndexBuffer(indexBuffer,indices.type());pass.drawIndexed(0,0,INDICES,1);
        }
    }
    public static void close(){if(vertices!=null){vertices.close();vertices=null;}}
}
