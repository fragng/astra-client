package client.astra;

import com.google.gson.*;
import java.nio.charset.StandardCharsets;
import java.util.*;
import java.util.random.RandomGenerator;

/** Unlimited local word puzzles. No rewards, case ledger or external service. */
public final class WordleGame {
    public static final int ABSENT=1,PRESENT=2,CORRECT=3;
    private static List<String> lines(String file){
        try(var in=WordleGame.class.getResourceAsStream("/assets/astra-client/puzzles/"+file)){
            if(in==null)throw new IllegalStateException("Missing puzzle dictionary");
            return new String(in.readAllBytes(),StandardCharsets.UTF_8).lines().filter(s->!s.isBlank()).map(s->s.toUpperCase(Locale.ROOT)).toList();
        }catch(java.io.IOException e){throw new IllegalStateException(e);}
    }
    public static final Set<String> DICTIONARY=Set.copyOf(lines("wordle-guesses.txt"));
    public static final List<String> ANSWERS=lines("wordle-answers.txt");
    private String answer,input="",message="Type five letters, then press Enter.";
    private final List<String> guesses=new ArrayList<>();
    public WordleGame(RandomGenerator random){newWord(random);}
    public void newWord(RandomGenerator random){String before=answer;do{answer=ANSWERS.get(random.nextInt(ANSWERS.size()));}while(ANSWERS.size()>1&&answer.equals(before));guesses.clear();input="";message="Type five letters, then press Enter.";}
    public String input(){return input;}
    public String message(){return message;}
    public List<String> guesses(){return List.copyOf(guesses);}
    public boolean solved(){return !guesses.isEmpty()&&guesses.getLast().equals(answer);}
    public boolean finished(){return solved()||guesses.size()==6;}
    public String revealed(){return finished()?answer:"";}
    public void type(int codepoint){if(!finished()&&input.length()<5&&(codepoint>='a'&&codepoint<='z'||codepoint>='A'&&codepoint<='Z')){input+=(char)Character.toUpperCase(codepoint);message="Enter to submit / Backspace to delete.";}}
    public void backspace(){if(!finished()&&!input.isEmpty())input=input.substring(0,input.length()-1);}
    public boolean submit(){
        if(finished())return false;
        if(input.length()!=5){message="Enter five letters.";return false;}
        if(!DICTIONARY.contains(input)){message="Not in the English word list. Try another word.";return false;}
        guesses.add(input);input="";
        message=solved()?"Solved! Play another word whenever you like.":finished()?"The word was "+answer+". Try a fresh puzzle.":(6-guesses.size())+" guesses left.";return true;
    }
    public int[] row(int index){return evaluate(answer,guesses.get(index));}
    public int letter(char c){int best=0;for(int i=0;i<guesses.size();i++){var mark=row(i);for(int n=0;n<5;n++)if(guesses.get(i).charAt(n)==c)best=Math.max(best,mark[n]);}return best;}
    public static int[] evaluate(String answer,String guess){
        if(answer.length()!=5||guess.length()!=5)throw new IllegalArgumentException("Five-letter words required");
        int[] result=new int[5],left=new int[26];
        for(int i=0;i<5;i++){char a=answer.charAt(i),g=guess.charAt(i);if(a<'A'||a>'Z'||g<'A'||g>'Z')throw new IllegalArgumentException("English letters required");if(a==g)result[i]=CORRECT;else left[a-'A']++;}
        for(int i=0;i<5;i++)if(result[i]!=CORRECT){int c=guess.charAt(i)-'A';result[i]=left[c]>0?PRESENT:ABSENT;if(left[c]>0)left[c]--;}
        return result;
    }
    public JsonObject json(){var j=new JsonObject();j.addProperty("answer",answer);j.addProperty("input",input);var a=new JsonArray();guesses.forEach(a::add);j.add("guesses",a);return j;}
    public static WordleGame restore(JsonObject j,RandomGenerator random){
        var value=new WordleGame(random);String answer=j.get("answer").getAsString();if(!ANSWERS.contains(answer))throw new IllegalArgumentException("Puzzle answer");value.answer=answer;
        for(var item:j.getAsJsonArray("guesses")){value.input=item.getAsString();if(value.finished()||!value.submit())throw new IllegalArgumentException("Puzzle guess");}
        String input=j.get("input").getAsString();if(!input.matches("[A-Z]{0,5}")||value.finished()&&!input.isEmpty())throw new IllegalArgumentException("Puzzle input");value.input=input;return value;
    }
}
