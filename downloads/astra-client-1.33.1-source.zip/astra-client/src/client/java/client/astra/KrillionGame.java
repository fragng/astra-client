package client.astra;

import com.google.gson.*;
import java.util.*;
import java.util.random.RandomGenerator;

/** Seven timed open-answer rounds. Fixed local practice scores never award prizes. */
public final class KrillionGame {
    public enum Phase {READY,QUESTION,RESULT,COMPLETE}
    public record Round(String answer,int points){}
    private List<String> prompts=List.of();private final List<Round> results=new ArrayList<>();
    private Phase phase=Phase.READY;private int index;private double seconds=25;private long previous=-1;
    private String message="Find unusual answers in seven timed categories.",draft="";
    public String draft(){return draft;}
    public void draft(String value){draft=value.length()>64?value.substring(0,64):value;}
    public Phase phase(){return phase;}
    public int index(){return index;}
    public double seconds(){return seconds;}
    public int score(){return results.stream().mapToInt(Round::points).sum();}
    public int depth(){return score()*10;}
    public String message(){return message;}
    public List<Round> results(){return List.copyOf(results);}
    public TriviaBank.Prompt prompt(){return prompts.isEmpty()?null:TriviaBank.find(prompts.get(index));}
    public void start(RandomGenerator random){
        var ids=new ArrayList<>(TriviaBank.PROMPTS.stream().map(TriviaBank.Prompt::id).toList());
        for(int n=ids.size()-1;n>0;n--){int pick=random.nextInt(n+1);Collections.swap(ids,n,pick);}prompts=List.copyOf(ids.subList(0,7));results.clear();index=0;phase=Phase.QUESTION;seconds=25;previous=-1;draft="";message="Type one answer. Unusual valid answers score more.";
    }
    public void pause(){previous=-1;}
    public boolean tick(long nanos,boolean active){
        if(!active||phase!=Phase.QUESTION){pause();return false;}
        if(previous>=0)seconds=Math.max(0,seconds-Math.max(0,nanos-previous)/1e9);previous=nanos;
        if(seconds<=0){finish("Time ran out",0);return true;}return false;
    }
    public boolean submit(String input){
        if(phase!=Phase.QUESTION)return false;var answer=prompt().match(input);
        if(answer==null){message="Not in this practice list. Try another answer.";return false;}
        finish(answer.name(),answer.points());return true;
    }
    public void skip(){if(phase==Phase.QUESTION)finish("Skipped",0);}
    private void finish(String answer,int points){results.add(new Round(answer,points));phase=Phase.RESULT;draft="";pause();message=points==0?answer:TriviaBank.tier(points)+" / +"+points+" points";}
    public void next(){
        if(phase!=Phase.RESULT)return;
        if(index==6){phase=Phase.COMPLETE;message="Dive complete! Play again whenever you like.";}
        else{index++;phase=Phase.QUESTION;seconds=25;message="A fresh category. Find an unusual answer.";}pause();
    }
    public JsonObject json(){var j=new JsonObject();j.addProperty("phase",phase.name());j.addProperty("index",index);j.addProperty("seconds",seconds);j.addProperty("draft",draft);var ids=new JsonArray();prompts.forEach(ids::add);j.add("prompts",ids);var rows=new JsonArray();for(var result:results){var row=new JsonObject();row.addProperty("answer",result.answer());row.addProperty("points",result.points());rows.add(row);}j.add("results",rows);return j;}
    public static KrillionGame restore(JsonObject j){
        var game=new KrillionGame();game.phase=Phase.valueOf(j.get("phase").getAsString());game.index=j.get("index").getAsInt();game.seconds=j.get("seconds").getAsDouble();game.draft=j.has("draft")?j.get("draft").getAsString():"";if(game.draft.length()>64)throw new IllegalArgumentException("Practice input");
        var ids=new ArrayList<String>();for(var id:j.getAsJsonArray("prompts")){TriviaBank.find(id.getAsString());ids.add(id.getAsString());}game.prompts=List.copyOf(ids);
        if(game.index<0||game.index>6||!Double.isFinite(game.seconds)||game.seconds<0||game.seconds>25||game.phase!=Phase.READY&&(ids.size()!=7||new HashSet<>(ids).size()!=7))throw new IllegalArgumentException("Practice round");
        for(var row:j.getAsJsonArray("results")){var r=row.getAsJsonObject();String answer=r.get("answer").getAsString();int points=r.get("points").getAsInt();int n=game.results.size();if(n>=7||answer.length()>100)throw new IllegalArgumentException("Practice results");if(points!=0){var match=TriviaBank.find(ids.get(n)).match(answer);if(match==null||match.points()!=points)throw new IllegalArgumentException("Practice answer");}game.results.add(new Round(answer,points));}
        int expected=switch(game.phase){case READY->0;case QUESTION->game.index;case RESULT->game.index+1;case COMPLETE->7;};if(game.results.size()!=expected)throw new IllegalArgumentException("Practice history");
        game.message=game.phase==Phase.RESULT?TriviaBank.tier(game.results.getLast().points()):game.phase==Phase.COMPLETE?"Dive complete! Play again whenever you like.":"Continue your practice dive.";return game;
    }
}
