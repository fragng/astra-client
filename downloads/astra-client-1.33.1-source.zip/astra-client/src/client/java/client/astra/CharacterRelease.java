package client.astra;

import java.time.Instant;

/** One shared release window; progress follows elapsed calendar time, including restarts. */
public final class CharacterRelease {
    public static final long START=Instant.parse("2026-11-22T21:00:48Z").toEpochMilli();
    public static final long READY=Instant.parse("2026-12-15T00:00:00Z").toEpochMilli();
    public static final String DATE="15 December 2026";
    private CharacterRelease(){}
    public static boolean available(){return available(System.currentTimeMillis());}
    public static boolean available(long now){return now>=READY;}
    public static double progress(){return progress(System.currentTimeMillis());}
    public static double progress(long now){return Math.clamp((now-START)/(double)(READY-START),0,1);}
    public static CharacterStyle effective(CharacterStyle saved,long now){return available(now)?saved:CharacterStyle.NONE;}
}
