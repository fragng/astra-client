package client.astra.mixin;

import client.astra.BrowserOptions;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.ModifyArg;

/** Leave the dependency byte-identical while removing its unnecessary insecure defaults. */
@Mixin(targets="net.dimaskama.mcef.impl.MCEFApiImpl",remap=false)
public abstract class McefSecurityMixin {
    @ModifyArg(method="<init>",at=@At(value="INVOKE",target="Lme/friwi/jcefmaven/CefAppBuilder;addJcefArgs([Ljava/lang/String;)V"),index=0,remap=false)
    private String[] astra$secureBrowserOptions(String[] original){return BrowserOptions.secure(original);}
}
