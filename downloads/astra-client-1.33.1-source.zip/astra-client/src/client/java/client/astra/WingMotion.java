package client.astra;

/** Stateless, continuous pose: walking and inventory previews cannot reset a flap. */
public final class WingMotion {
    public record Pose(float fold,float lift,float pitch){}
    private static final Pose REST=new Pose(.22f,0,.04f);
    private WingMotion(){}
    private static long hash(long value){value=(value^(value>>>30))*0xbf58476d1ce4e5b9L;value=(value^(value>>>27))*0x94d049bb133111ebL;return value^(value>>>31);}
    public static Pose sample(double ticks,long seed,boolean animate){
        if(!animate||!Double.isFinite(ticks))return REST;
        ticks=Math.max(0,ticks);long cycle=(long)Math.floor(ticks/260),bits=hash(seed+cycle);
        double start=28+Math.floorMod(bits,56),duration=90+Math.floorMod(bits>>>8,30),p=(ticks-cycle*260-start)/duration;
        double burst=0;
        if(p>0&&p<1){double envelope=Math.sin(Math.PI*p);int beats=2+(int)Math.floorMod(bits>>>16,2);burst=envelope*envelope*(.5-.5*Math.cos(p*beats*Math.PI*2));}
        double phase=Math.floorMod(seed,6283)/1000.0,idle=Math.sin(ticks*.037+phase);
        return new Pose((float)(.22+.025*idle+.37*burst),(float)(.012*idle+.065*burst),(float)(.04+.09*burst));
    }
}
