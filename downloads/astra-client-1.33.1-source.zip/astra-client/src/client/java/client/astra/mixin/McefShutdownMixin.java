package client.astra.mixin;

import net.dimaskama.mcef.impl.MCEFApiImpl;
import net.minecraft.client.Minecraft;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;

/** Failed optional browser startup must not turn closing Minecraft into an exception. */
@Mixin(targets="net.dimaskama.mcef.impl.MCEFModern",remap=false)
public abstract class McefShutdownMixin {
    @Inject(method="onClientStopping",at=@At("HEAD"),cancellable=true,remap=false)
    private static void astra$failedBrowserShutdown(Minecraft client,CallbackInfo ci){
        var state=MCEFApiImpl.getInitialization();
        if(state!=null && (!state.getFuture().isDone() || state.getFuture().isCompletedExceptionally() || state.getFuture().isCancelled()))ci.cancel();
    }
}
