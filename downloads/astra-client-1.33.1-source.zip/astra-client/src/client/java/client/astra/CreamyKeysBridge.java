package client.astra;

import net.minecraft.client.Minecraft;
import net.minecraft.client.gui.screens.Screen;

/** Opens the exact user-supplied CreamyKeys 0.0.5. Astra has no second sound engine. */
public final class CreamyKeysBridge {
    private static java.lang.reflect.Field configField,enabledField;
    private CreamyKeysBridge(){}
    public static boolean enabled(){
        try{if(configField==null)configField=Class.forName("me.cutebow.creamykeys.client.CreamyKeysClient").getField("CONFIG");Object config=configField.get(null);if(config==null)return false;if(enabledField==null)enabledField=config.getClass().getField("enabled");return enabledField.getBoolean(config);}
        catch(ReflectiveOperationException e){return false;}
    }
    public static void open(Screen parent){
        try{
            Class<?> type=Class.forName("me.cutebow.creamykeys.screen.v121.CKSettingsScreen");
            Minecraft.getInstance().setScreen((Screen)type.getConstructor(Screen.class).newInstance(parent));
        }catch(ReflectiveOperationException e){
            org.slf4j.LoggerFactory.getLogger("Astra Client").error("Could not open bundled CreamyKeys settings",e);
        }
    }
}
