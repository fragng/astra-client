package client.astra;

import java.util.*;

/** Cached closed tubes and curved feather surfaces, with finite outward unit normals. */
public final class CaseMesh {
    public record Point(double x,double y,double z){
        Point add(Point b){return new Point(x+b.x,y+b.y,z+b.z);}Point scale(double a){return new Point(x*a,y*a,z*a);}Point sub(Point b){return add(b.scale(-1));}
        Point cross(Point b){return new Point(y*b.z-z*b.y,z*b.x-x*b.z,x*b.y-y*b.x);}double length(){return Math.sqrt(x*x+y*y+z*z);}Point unit(){double n=length();if(n<1e-8)throw new IllegalArgumentException("Mesh tangent");return scale(1/n);}
    }
    private CaseMesh(){}
    public static Point p(double x,double y,double z){return new Point(x,y,z);}
    private static Point path(Point[] c,double t){double u=1-t;return c[0].scale(u*u*u).add(c[1].scale(3*u*u*t)).add(c[2].scale(3*u*t*t)).add(c[3].scale(t*t*t));}
    private static Point tangent(Point[] c,double t){double u=1-t;return c[1].sub(c[0]).scale(3*u*u).add(c[2].sub(c[1]).scale(6*u*t)).add(c[3].sub(c[2]).scale(3*t*t)).unit();}
    public static CharacterMesh.Mesh tube(Point a,Point b,Point c,Point d,double radius,double endRadius,boolean feather,double width){
        Point[] control={a,b,c,d};int steps=feather?10:14,sides=feather?8:6;Point[][] points=new Point[steps+1][sides],normals=new Point[steps+1][sides];
        for(int i=0;i<=steps;i++){
            double t=i/(double)steps;Point center=path(control,t),along=tangent(control,t);Point across=along.cross(p(0,0,1));if(across.length()<.05)across=along.cross(p(0,1,0));across=across.unit();Point depth=along.cross(across).unit();
            double bulb=feather?Math.pow(Math.sin(Math.PI*t),.68):1;double rw=feather?.025+width*bulb*(1-.28*t):radius+(endRadius-radius)*t,rd=feather?.025+radius*bulb:rw;
            for(int j=0;j<sides;j++){double angle=j*Math.PI*2/sides,co=Math.cos(angle),si=Math.sin(angle);points[i][j]=center.add(across.scale(rw*co)).add(depth.scale(rd*si));normals[i][j]=across.scale(co/rw).add(depth.scale(si/rd)).unit();}
        }
        List<Float> data=new ArrayList<>();
        for(int i=0;i<steps;i++)for(int j=0;j<sides;j++){int k=(j+1)%sides;add(data,points[i][j],normals[i][j]);add(data,points[i][k],normals[i][k]);add(data,points[i+1][k],normals[i+1][k]);add(data,points[i+1][j],normals[i+1][j]);}
        for(int end:new int[]{0,steps}){
            Point center=path(control,end/(double)steps),normal=tangent(control,end/(double)steps).scale(end==0?-1:1);
            for(int j=0;j<sides;j++){int k=(j+1)%sides;add(data,center,normal);add(data,points[end][end==0?k:j],normal);add(data,points[end][end==0?j:k],normal);add(data,center,normal);}
        }
        return finish(data);
    }
    public static CharacterMesh.Mesh ring(double radius,double y,double thickness){
        List<Float> data=new ArrayList<>();int around=48,sides=6;
        for(int i=0;i<around;i++)for(int j=0;j<sides;j++)for(int k=0;k<4;k++){
            double angle=(i+(k>=2?1:0))*Math.PI*2/around,phi=(j+(k==1||k==2?1:0))*Math.PI*2/sides;
            Point normal=p(Math.sin(angle)*Math.cos(phi),Math.sin(phi),-Math.cos(angle)*Math.cos(phi));Point point=p(Math.sin(angle)*radius,y,-Math.cos(angle)*radius).add(normal.scale(thickness));add(data,point,normal);
        }return finish(data);
    }
    public static CharacterMesh.Mesh rotateY(CharacterMesh.Mesh source,double angle){
        float[] data=source.vertices().clone();double c=Math.cos(angle),s=Math.sin(angle);for(int i=0;i<data.length;i+=6){float x=data[i],z=data[i+2],nx=data[i+3],nz=data[i+5];data[i]=(float)(c*x+s*z);data[i+2]=(float)(-s*x+c*z);data[i+3]=(float)(c*nx+s*nz);data[i+5]=(float)(-s*nx+c*nz);}return bounds(data);
    }
    private static void add(List<Float> data,Point p,Point n){data.add((float)p.x);data.add((float)p.y);data.add((float)p.z);data.add((float)n.x);data.add((float)n.y);data.add((float)n.z);}
    private static CharacterMesh.Mesh finish(List<Float> values){float[] data=new float[values.size()];for(int i=0;i<data.length;i++)data[i]=values.get(i);return bounds(data);}
    private static CharacterMesh.Mesh bounds(float[] data){float x=Float.POSITIVE_INFINITY,y=x,z=x,X=Float.NEGATIVE_INFINITY,Y=X,Z=X;for(int i=0;i<data.length;i+=6){x=Math.min(x,data[i]);y=Math.min(y,data[i+1]);z=Math.min(z,data[i+2]);X=Math.max(X,data[i]);Y=Math.max(Y,data[i+1]);Z=Math.max(Z,data[i+2]);}return new CharacterMesh.Mesh(data,x,y,z,X,Y,Z);}
}
