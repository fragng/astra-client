package client.astra;

import net.minecraft.client.model.geom.*;
import java.util.*;
import static client.astra.CaseMesh.p;

/** Original gold filigree/cyan gems and layered magenta/gold feathers, built once. */
public final class CaseCosmeticMeshes {
    private CaseCosmeticMeshes(){}
    private static ModelPart part(List<CharacterMesh.Mesh> meshes){List<ModelPart.Cube> cubes=new ArrayList<>();for(var mesh:meshes)cubes.add(new CurvedCharacterCube(mesh,0,"",List.of()));return new ModelPart(cubes,Map.of());}
    private static CaseMesh.Point radial(double theta,double radius,double y){return p(Math.sin(theta)*radius,y,-Math.cos(theta)*radius);}
    public static ModelPart crown(){
        var gold=new ArrayList<CharacterMesh.Mesh>();var gems=new ArrayList<CharacterMesh.Mesh>();var glints=new ArrayList<CharacterMesh.Mesh>();
        gold.add(CaseMesh.ring(5.9,-8.7,.24));gold.add(CaseMesh.ring(5.84,-9.45,.14));
        for(int i=0;i<10;i++){
            double a=i*Math.PI*2/10,top=-13.4-.9*Math.cos(a);
            for(int sign:new int[]{-1,1})gold.add(CaseMesh.tube(radial(a+sign*.29,5.88,-8.7),radial(a+sign*.20,6.1,-10.6),radial(a+sign*.12,6.55,top+1),radial(a,6.28,top),.20,.025,false,0));
            gold.add(CaseMesh.tube(radial(a,5.9,-9.1),radial(a+.025,6.2,-11.2),radial(a+.06,6.5,top+.5),radial(a,6.28,top),.12,.025,true,.65));
            gold.add(CaseMesh.tube(radial(a-.22,5.95,-9.2),radial(a+.19,6,-10.8),radial(a-.12,6.12,-11.3),radial(a+.08,6.02,-10.5),.10,.075,false,0));
            gold.add(CaseMesh.tube(radial(a+.22,5.95,-9.2),radial(a-.19,6,-10.8),radial(a+.12,6.12,-11.3),radial(a-.08,6.02,-10.5),.10,.075,false,0));
        }
        for(double a:new double[]{0,-.95,.95,Math.PI}){
            double size=a==0?1:.74;
            gold.add(CaseMesh.rotateY(CharacterMesh.build((float)(-1.55*size),-13.7f,-6.5f,(float)(3.1*size),4.5f,1.0f,.8,.62,false,.2),-a));
            gems.add(CaseMesh.rotateY(CharacterMesh.build((float)(-1.19*size),-13.35f,-6.83f,(float)(2.38*size),3.8f,.79f,.95,.65,false,.2),-a));
            glints.add(CaseMesh.rotateY(CharacterMesh.build((float)(-.52*size),-11.92f,-6.96f,.32f,.42f,.18f,1,0,false,.1),-a));
            gold.add(CaseMesh.rotateY(CharacterMesh.build(-.49f,-9.65f,-6.25f,.98f,.92f,.45f,1,0,false,.1),-a));
            gems.add(CaseMesh.rotateY(CharacterMesh.build(-.30f,-9.48f,-6.47f,.60f,.58f,.32f,1,0,false,.1),-a));
        }
        return new ModelPart(List.of(),Map.of("gold",part(gold),"gems",part(gems),"glints",part(glints)));
    }
    public static ModelPart wings(){
        Map<String,ModelPart> sides=new LinkedHashMap<>();
        for(int sign:new int[]{-1,1}){
            var dark=new ArrayList<CharacterMesh.Mesh>();var pink=new ArrayList<CharacterMesh.Mesh>();var gold=new ArrayList<CharacterMesh.Mesh>();var cream=new ArrayList<CharacterMesh.Mesh>();
            gold.add(CaseMesh.tube(p(0,6,0),p(sign*1.2,-1,0),p(sign*7,-5,0),p(sign*7.9,-12.5,0),.55,.12,false,0));
            gold.add(CaseMesh.tube(p(0,5,-.15),p(sign*3,5,-.3),p(sign*3.1,-1,-.25),p(sign*1.2,-.7,-.2),.24,.11,false,0));
            for(int i=0;i<13;i++){
                double t=i/12.0,bx=1+t*6.7,by=5-t*15,ex=11+Math.sin(t*Math.PI)*3.7-t*2.6,ey=10-t*25;
                var list=i%3==0?dark:pink;
                list.add(CaseMesh.tube(p(sign*bx,by,.2),p(sign*(bx+3),by+1.8,.45),p(sign*(ex+1),ey+3,.35),p(sign*ex,ey,.05),.19,.03,true,1.15));
                dark.add(CaseMesh.tube(p(sign*bx,by,.02),p(sign*(bx+2.9),by+1.5,.22),p(sign*(ex+.7),ey+2.7,.2),p(sign*ex,ey,.03),.038,.018,false,0));
            }
            for(int i=0;i<9;i++){
                double t=i/8.0,bx=.4+t*4.5,by=5-t*8,ex=7.2+t*2,ey=11-t*13;
                dark.add(CaseMesh.tube(p(sign*bx,by,-.1),p(sign*(bx+2),by+2,-.25),p(sign*(ex+1),ey+1,-.25),p(sign*ex,ey,0),.18,.025,true,.95));
            }
            for(int i=0;i<9;i++){
                double t=i/8.0,bx=.35+t*4.7,by=5-t*10.5,ex=3+t*6.1,ey=5.8-t*13;
                cream.add(CaseMesh.tube(p(sign*bx,by,.55),p(sign*(bx+1.5),by-.8,.85),p(sign*(ex+.4),ey+1.6,.65),p(sign*ex,ey,.35),.12,.025,true,.65));
                gold.add(CaseMesh.tube(p(sign*bx,by,.76),p(sign*(bx+1.4),by-.9,.96),p(sign*ex,ey+1.5,.85),p(sign*ex,ey,.43),.055,.02,false,0));
            }
            var wing=new ModelPart(List.of(),Map.of("dark",part(dark),"pink",part(pink),"gold",part(gold),"cream",part(cream)));var pose=PartPose.offset(sign*2.3f,3,2.65f);wing.setInitialPose(pose);wing.loadPose(pose);sides.put(sign<0?"right":"left",wing);
        }
        return new ModelPart(List.of(),sides);
    }
}
