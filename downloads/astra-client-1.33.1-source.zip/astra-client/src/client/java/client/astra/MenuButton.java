package client.astra;

import net.minecraft.client.Minecraft;
import net.minecraft.client.gui.GuiGraphics;
import net.minecraft.client.gui.components.Button;
import java.util.function.BooleanSupplier;

public final class MenuButton extends Button {
    private final String label, icon;
    private final BooleanSupplier selected;
    private final boolean toggle;
    private float hover;
    private BooleanSupplier available=()->true;
    public MenuButton available(BooleanSupplier test) { available=test;active=test.getAsBoolean();return this; }
    private long last=System.nanoTime();
    public MenuButton(int x,int y,int w,int h,String label,String icon,BooleanSupplier selected,boolean toggle,Runnable action) {
        super(x,y,w,h,Ui.text(label),b->action.run(),DEFAULT_NARRATION);
        this.label=label;this.icon=icon;this.selected=selected;this.toggle=toggle;
    }
    @Override protected void renderContents(GuiGraphics g,int mx,int my,float delta) {
        active=available.getAsBoolean();
        long now=System.nanoTime();float dt=Math.min(.1f,(now-last)/1e9f);last=now;
        float target=isHoveredOrFocused()?1:0;
        hover=AstraConfig.animations?hover+(target-hover)*(1-(float)Math.exp(-dt*14)):target;
        var palette=AstraConfig.colour();
        boolean on=selected.getAsBoolean();int x=getX(),y=getY(),w=getWidth(),h=getHeight();
        Ui.round(g,x,y+2,w,h,13,Ui.alpha(palette.background,.94f));
        if(on) Ui.round(g,x-2,y-2,w+4,h+4,15,Ui.alpha(palette.accent,.16f));
        Ui.round(g,x,y,w,h,13,Ui.blend(on?palette.accent:palette.border,palette.accent,hover*.6f));
        Ui.gradient(g,x+2,y+2,w-4,h-4,11,
            on?palette.activeTop:Ui.blend(palette.panelTop,palette.hoverTop,hover),on?palette.activeBottom:palette.panelBottom);
        Ui.round(g,x+4,y+3,w-8,Math.max(3,h/4),6,on?0x25FFFFFF:0x12FFFFFF);
        if(!icon.isEmpty()) MenuArt.icon(g,icon,x+(w<40?(w-14)/2:9),y+(h-14)/2,14,on?palette.accent:palette.border);
        var font=Minecraft.getInstance().font;
        int textX=x+(icon.isEmpty()?10:30);
        var text=on?Ui.heading(label):Ui.text(label);
        boolean releaseLocked=icon.equals("3D Characters") && !CharacterRelease.available();
        int room=x+w-(toggle?42:releaseLocked?19:9)-textX;
        float labelScale=Math.min(1,Math.max(1,room)/(float)Math.max(1,font.width(text)));
        g.pose().pushMatrix();g.pose().translate(textX,y+(h-9*labelScale)/2f);g.pose().scale(labelScale,labelScale);
        Ui.animated(g,font,text,0,0,on?0xFFF7F0FF:active?0xFFD5D5E8:0xFF73788E);g.pose().popMatrix();
        if(releaseLocked)MenuArt.lock(g,x+w-15,y+(h-10)/2,10,palette.accent);
        if(toggle) {
            int tx=x+w-34,ty=y+(h-16)/2;
            Ui.round(g,tx,ty+1,28,16,8,palette.background);
            Ui.round(g,tx,ty,28,16,8,on?palette.accent:palette.border);
            Ui.round(g,tx+2,ty+2,24,12,6,on?palette.activeTop:palette.panelBottom);
            int knob=on?tx+14:tx+2;
            Ui.round(g,knob,ty+2,12,12,6,0xFFFFF3FF);
            Ui.round(g,knob+2,ty+3,5,3,1,0xFFFFFFFF);

        }
    }
    @Override protected net.minecraft.network.chat.MutableComponent createNarrationMessage() {
        return net.minecraft.network.chat.Component.literal(label+(toggle?(selected.getAsBoolean()?", on":", off"):selected.getAsBoolean()?", selected":""));
    }
}
