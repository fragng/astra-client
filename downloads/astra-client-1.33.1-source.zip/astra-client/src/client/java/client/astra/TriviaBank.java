package client.astra;

import com.google.gson.*;
import java.nio.charset.StandardCharsets;
import java.text.Normalizer;
import java.util.*;

/** Independently authored practice prompts and fixed tiers, not live population rarity. */
public final class TriviaBank {
    public record Answer(String name,int points){}
    public record Prompt(String id,String question,Map<String,Answer> answers){
        public Answer match(String input){
            String key=normalize(input);if(key.isEmpty())return null;var exact=answers.get(key);if(exact!=null)return exact;
            String singular=key.endsWith("ies")?key.substring(0,key.length()-3)+"y":key.endsWith("s")?key.substring(0,key.length()-1):key;var plural=answers.get(singular);if(plural!=null)return plural;
            if(key.length()<5)return null;Answer candidate=null;
            for(var entry:answers.entrySet())if(oneEdit(key,entry.getKey())){if(candidate!=null&&!candidate.equals(entry.getValue()))return null;candidate=entry.getValue();}return candidate;
        }
    }
    public static final List<Prompt> PROMPTS=load();
    private TriviaBank(){}
    public static String normalize(String value){return Normalizer.normalize(value.replace("+","plus").replace("#","sharp"),Normalizer.Form.NFKD).toLowerCase(Locale.ROOT).replaceAll("\\p{M}","").replaceAll("[^a-z0-9]","");}
    private static boolean oneEdit(String a,String b){
        if(Math.abs(a.length()-b.length())>1)return false;if(a.length()>b.length())return oneEdit(b,a);
        int i=0,j=0,edits=0;while(i<a.length()&&j<b.length()){if(a.charAt(i)==b.charAt(j)){i++;j++;}else{if(++edits>1)return false;if(a.length()==b.length())i++;j++;}}return edits+b.length()-j<=1;
    }
    public static Prompt find(String id){return PROMPTS.stream().filter(p->p.id().equals(id)).findFirst().orElseThrow(()->new IllegalArgumentException("Unknown practice prompt"));}
    public static String tier(int points){return switch(points){case 10->"Familiar";case 15->"Bright idea";case 30->"Unusual";case 60->"Rare";case 85->"Deep cut";case 100->"Astra gem";default->"No points";};}
    private static List<Prompt> load(){
        try(var in=TriviaBank.class.getResourceAsStream("/assets/astra-client/puzzles/trivia.json")){
            if(in==null)throw new IllegalStateException("Missing practice prompts");var list=new ArrayList<Prompt>();var ids=new HashSet<String>();
            for(var element:JsonParser.parseString(new String(in.readAllBytes(),StandardCharsets.UTF_8)).getAsJsonArray()){
                var j=element.getAsJsonObject();String id=j.get("id").getAsString();if(!ids.add(id))throw new IllegalArgumentException("Duplicate prompt");var answers=new LinkedHashMap<String,Answer>();
                for(var group:j.getAsJsonObject("tiers").entrySet()){
                    int points=Integer.parseInt(group.getKey());if(points!=10&&points!=15&&points!=30&&points!=60&&points!=85&&points!=100)throw new IllegalArgumentException("Practice score");
                    for(var item:group.getValue().getAsJsonArray()){String[] aliases=item.getAsString().split("/");var answer=new Answer(aliases[0],points);for(var alias:aliases){var prior=answers.putIfAbsent(normalize(alias),answer);if(prior!=null&&!prior.equals(answer))throw new IllegalArgumentException("Duplicate practice alias: "+alias);}}
                }
                list.add(new Prompt(id,j.get("question").getAsString(),Map.copyOf(answers)));
            }return List.copyOf(list);
        }catch(java.io.IOException e){throw new IllegalStateException(e);}
    }
}
