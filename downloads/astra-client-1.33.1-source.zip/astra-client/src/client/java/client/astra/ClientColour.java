package client.astra;

import java.util.Locale;

/** Client chrome only: never a world/sky/image tint. */
public enum ClientColour {
    BLACK("Black",0xFF09090B,0xFF242427,0xFF131316,0xFF73737C,0xFFD1D1DA,0xFF53535B,0xFF33333B,0xFF383840),
    BLUE("Blue",0xFF080D16,0xFF162B49,0xFF0D1B30,0xFF436FAD,0xFF93BEFF,0xFF3267AC,0xFF1D3B6B,0xFF25466E),
    RED("Red",0xFF14090C,0xFF402027,0xFF261117,0xFFA34A59,0xFFFFA1AD,0xFFA84658,0xFF662938,0xFF60303A),
    PINK("Pink",0xFF150A12,0xFF3C2335,0xFF261524,0xFFAB6A98,0xFFFFB9E4,0xFFA4548F,0xFF65335B,0xFF5A3551),
    PURPLE("Purple",0xFF0F0B18,0xFF302240,0xFF1C152A,0xFF8963AD,0xFFD8B7FF,0xFF8755B5,0xFF512F79,0xFF49325F);

    public final String label;
    public final int background,panelTop,panelBottom,border,accent,activeTop,activeBottom,hoverTop;
    ClientColour(String label,int background,int panelTop,int panelBottom,int border,int accent,int activeTop,int activeBottom,int hoverTop){
        this.label=label;this.background=background;this.panelTop=panelTop;this.panelBottom=panelBottom;this.border=border;this.accent=accent;this.activeTop=activeTop;this.activeBottom=activeBottom;this.hoverTop=hoverTop;
    }
    public static ClientColour parse(String value){try{return value==null?BLACK:valueOf(value.toUpperCase(Locale.ROOT));}catch(IllegalArgumentException e){return BLACK;}}
    public String id(){return name().toLowerCase(Locale.ROOT);}
    /** Old pale purple text becomes neutral; semantic gold/red/green/cyan is retained. */
    public static int readableText(int argb){
        int r=argb>>>16&255,g=argb>>>8&255,b=argb&255;
        return b>=r && r>=g?(argb&0xFF000000)|(b<<16)|(b<<8)|b:argb;
    }
}
