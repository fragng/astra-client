package client.astra;

import java.util.ArrayList;

/** Krillion needs normal web security and no DRM or automatic media playback exceptions. */
public final class BrowserOptions {
    private BrowserOptions(){}
    public static String[] secure(String[] original){
        var result=new ArrayList<String>();
        for(String option:original)if(!option.equals("--disable-web-security") && !option.equals("--enable-widevine-cdm") && !option.startsWith("--autoplay-policy="))result.add(option);
        // Respect an explicitly configured JVM deployment proxy, including the cloud test host.
        String host=System.getProperty("https.proxyHost"),port=System.getProperty("https.proxyPort");
        if(host!=null && host.matches("[A-Za-z0-9.-]+") && port!=null && port.matches("[0-9]{1,5}"))result.add("--proxy-server=http://"+host+":"+port);
        return result.toArray(String[]::new);
    }
    public static boolean gameUrl(String value){
        try{var uri=java.net.URI.create(value);String host=uri.getHost();return "https".equalsIgnoreCase(uri.getScheme()) && host!=null && (host.equalsIgnoreCase("krillion.io") || host.toLowerCase(java.util.Locale.ROOT).endsWith(".krillion.io"));}
        catch(IllegalArgumentException e){return false;}
    }
}
