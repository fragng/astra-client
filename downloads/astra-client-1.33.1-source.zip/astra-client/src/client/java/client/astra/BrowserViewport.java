package client.astra;

/** Bound off-screen Chromium work independently of a 4K/ultrawide Minecraft window. */
public record BrowserViewport(int width,int height) {
    public static BrowserViewport fit(int logicalWidth,int logicalHeight,double guiScale){
        double w=Math.max(1,logicalWidth)*Math.max(1,guiScale),h=Math.max(1,logicalHeight)*Math.max(1,guiScale);
        double ratio=Math.min(1,Math.min(BrowserFrames.MAX_WIDTH/w,BrowserFrames.MAX_HEIGHT/h));
        return new BrowserViewport(Math.max(1,(int)Math.round(w*ratio)),Math.max(1,(int)Math.round(h*ratio)));
    }
    public int x(double logical,int logicalWidth){return (int)Math.round(logical*width/Math.max(1,logicalWidth));}
    public int y(double logical,int logicalHeight){return (int)Math.round(logical*height/Math.max(1,logicalHeight));}
}
