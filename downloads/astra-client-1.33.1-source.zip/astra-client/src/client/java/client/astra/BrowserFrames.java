package client.astra;

import java.nio.ByteBuffer;

/** Two reusable staging buffers; a slow render loop always consumes the newest paint. */
public final class BrowserFrames implements AutoCloseable {
    public static final int MAX_WIDTH=1280,MAX_HEIGHT=800;
    public record Frame(ByteBuffer pixels,int width,int height){}
    private ByteBuffer pending,upload;
    private int width,height;
    private boolean dirty,closed;
    private long received,consumed,allocations;

    public synchronized void publish(ByteBuffer source,int width,int height){
        if(closed || width<1 || height<1 || width>MAX_WIDTH || height>MAX_HEIGHT)return;
        int bytes=width*height*4;
        if(source.remaining()<bytes)return;
        if(pending==null || pending.capacity()<bytes){pending=ByteBuffer.allocateDirect(bytes);allocations++;}
        var data=source.duplicate();data.limit(data.position()+bytes);
        pending.clear();pending.put(data);pending.flip();
        this.width=width;this.height=height;dirty=true;received++;
    }
    /** Render thread only: finish using the returned frame before calling take again. */
    public synchronized Frame take(){
        if(closed || !dirty)return null;
        ByteBuffer swap=upload;upload=pending;pending=swap;dirty=false;consumed++;
        return new Frame(upload,width,height);
    }
    public synchronized long received(){return received;}
    public synchronized long consumed(){return consumed;}
    public synchronized long allocations(){return allocations;}
    @Override public synchronized void close(){closed=true;dirty=false;pending=null;upload=null;}
}
