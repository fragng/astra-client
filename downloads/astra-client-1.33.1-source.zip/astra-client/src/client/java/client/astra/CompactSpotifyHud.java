package client.astra;

import net.minecraft.client.gui.Font;
import net.minecraft.client.gui.GuiGraphics;
import net.minecraft.network.chat.Component;

/** Performance HUD: two atlas panels, two flat progress fills and at most four text lines. */
final class CompactSpotifyHud {
    static final int WIDTH=264;
    private static final Text TITLE=new Text(),ARTIST=new Text(),LYRIC=new Text(),STAMP=new Text();
    static int height(){return AstraConfig.lyricsEnabled?60:45;}
    static void draw(GuiGraphics g,Font font,SpotifyBridge.State media,float opacity){
        boolean song=media.connected() && !media.title().isBlank();
        int accent=AstraConfig.spotifyTheme().accent;
        Ui.round(g,0,0,WIDTH,height(),7,Ui.alpha(accent,opacity*.65f));
        Ui.round(g,1,1,WIDTH-2,height()-2,6,Ui.alpha(0xF2141723,opacity));
        line(g,font,TITLE,song?media.title():"Spotify HUD",9,7,WIDTH-18,0xFFF1E7FF,opacity);
        line(g,font,ARTIST,song?media.artist():media.status(),9,20,WIDTH-18,0xFFC1B7D1,opacity);
        double elapsed=media.elapsed(),duration=media.duration();
        String stamp=duration>0?SpotifyHud.format(elapsed)+" / "+SpotifyHud.format(duration):"--:-- / --:--";
        Component time=STAMP.get(font,stamp,90);int right=WIDTH-9-font.width(time);
        g.fill(9,36,right-7,38,Ui.tint(Ui.alpha(0xFF454255,opacity)));
        if(duration>0)g.fill(9,36,9+(int)((right-16)*Math.clamp(elapsed/duration,0,1)),38,Ui.tint(Ui.alpha(accent,opacity)));
        g.drawString(font,time,right,31,Ui.tint(Ui.alpha(0xFFD5CADF,opacity)),false);
        if(AstraConfig.lyricsEnabled){
            var lyrics=LyricsService.current();int index=song?lyrics.index(elapsed):-1;
            String value=index>=0 && !lyrics.lines().isEmpty()?lyrics.lines().get(index).text():song?lyrics.status():"Play a song to show lyrics";
            line(g,font,LYRIC,value.isBlank()?"…":value,9,47,WIDTH-18,0xFFD9C7F1,opacity);
        }
    }
    private static void line(GuiGraphics g,Font font,Text cache,String value,int x,int y,int width,int color,float opacity){g.drawString(font,cache.get(font,value,width),x,y,Ui.tint(Ui.alpha(color,opacity)),false);}
    private static final class Text {
        private String last;private Font font;private boolean bubble;private Component text=Component.empty();
        Component get(Font next,String value,int width){
            if(next!=font || bubble!=AstraConfig.bubbleFont || !value.equals(last)){
                font=next;bubble=AstraConfig.bubbleFont;last=value;
                Component full=Ui.text(value);
                text=font.width(full)<=width?full:Ui.text(font.substrByWidth(full,Math.max(0,width-font.width(Ui.text("…")))).getString()+"…");
            }
            return text;
        }
    }
    private CompactSpotifyHud(){}
}
