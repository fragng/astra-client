package client.astra;

import com.google.gson.*;
import net.fabricmc.loader.api.FabricLoader;
import net.minecraft.client.Minecraft;
import java.nio.file.*;
import java.nio.charset.StandardCharsets;
import java.security.SecureRandom;
import java.util.*;

/** Cached, account-scoped cases/cosmetics. No I/O or image decoding in item hover/render. */
public final class CaseGames {
    private static final SecureRandom RANDOM=new SecureRandom();
    private static UUID account;private static CaseLedger ledger;private static Path file;
    private static long baseline,nanos,saveAt;private static String error="";
    private CaseGames(){}
    public static void tick(Minecraft mc){
        var id=mc.getUser().getProfileId();
        if(!Objects.equals(id,account)){
            account=id;ledger=null;error="";file=FabricLoader.getInstance().getConfigDir().resolve("astra-games").resolve(PremiumLicense.fingerprint(id)+".json");
            try{if(Files.exists(file)&&Files.size(file)>1_048_576)throw new IllegalArgumentException("Case data size");ledger=Files.exists(file)?CaseLedger.decode(Files.readString(file,StandardCharsets.UTF_8),PremiumLicense.fingerprint(id)):new CaseLedger(PremiumLicense.fingerprint(id));}catch(Exception e){error="Case data could not be read. Keep the file and restart.";}
            baseline=Math.max(System.currentTimeMillis(),ledger==null?0:ledger.lastSeen);nanos=System.nanoTime();saveAt=nanos+60_000_000_000L;
        }
        if(ledger!=null){boolean refill=ledger.roll(now());if(error.isEmpty()&&(refill||ledger.windowStarted>0&&System.nanoTime()>=saveAt))save(ledger);}
    }
    public static long now(){return Math.max(System.currentTimeMillis(),baseline+Math.max(0,(System.nanoTime()-nanos)/1_000_000));}
    public static CaseLedger data(){return ledger;}
    public static String status(){return error;}
    public static boolean unlimited(){return ledger!=null&&ledger.unlimited();}
    public static int remaining(){return ledger==null?0:unlimited()?Integer.MAX_VALUE:Math.max(0,ledger.allowance(PremiumEdition.premium())-(int)ledger.spent);}
    public static String balance(){return unlimited()?"Infinite Cases":remaining()+" / "+(PremiumEdition.premium()?200:100)+" cases";}
    public static String refill(){if(ledger==null)return "Cases unavailable";if(unlimited())return "Unlimited opens unlocked";if(ledger.windowStarted==0)return "Refills every 12 hours";long s=ledger.refillIn(now())/1000;return String.format(Locale.ROOT,"Refill in %02d:%02d:%02d",s/3600,s/60%60,s%60);}
    public static boolean owned(CaseReward reward){return ledger!=null&&ledger.owned.contains(reward);}
    public static boolean crown(){return ledger!=null&&ledger.crown&&owned(CaseReward.CROWN);}
    public static boolean wings(){return ledger!=null&&ledger.wings&&owned(CaseReward.WINGS);}
    public static boolean skinTotem(){return ledger!=null&&ledger.skinTotem&&owned(CaseReward.SKIN_TOTEM);}
    public static void toggle(CaseReward reward){
        if(!owned(reward)||!error.isEmpty())return;var next=ledger.copy();switch(reward){case CROWN->next.crown=!next.crown;case WINGS->next.wings=!next.wings;case SKIN_TOTEM->next.skinTotem=!next.skinTotem;default->{return;}}
        if(save(next))ledger=next;
    }
    public static void acknowledgeWin(UUID id){if(ledger==null||id==null)return;var next=ledger.copy();next.seenWin=id;if(save(next))ledger=next;}
    public static void disableSkinTotem(){if(skinTotem())toggle(CaseReward.SKIN_TOTEM);}
    public static void resetPreferences(){if(ledger==null)return;var next=ledger.copy();next.crown=next.wings=next.skinTotem=false;if(save(next))ledger=next;}
    public static CaseLedger.Draw open(){
        var mc=Minecraft.getInstance();if(ledger==null||!error.isEmpty()||mc.player==null||!Objects.equals(account,mc.getUser().getProfileId()))return null;
        var next=ledger.copy();var draw=next.open(PremiumEdition.premium(),now(),RANDOM.nextInt(CaseReward.TICKETS),RANDOM.nextInt(CaseReward.MISS_LINES.length),UUID.randomUUID());if(draw==null)return null;
        if(!save(next))return null;ledger=next;
        if(draw.reward().ticketClaim)archive(draw);return draw;
    }
    private static boolean save(CaseLedger next){
        try{
            Files.createDirectories(file.getParent());Path temp=file.resolveSibling(file.getFileName()+".tmp");Files.writeString(temp,next.encode(),StandardCharsets.UTF_8);
            try{Files.move(temp,file,StandardCopyOption.ATOMIC_MOVE,StandardCopyOption.REPLACE_EXISTING);}catch(AtomicMoveNotSupportedException e){Files.move(temp,file,StandardCopyOption.REPLACE_EXISTING);}
            saveAt=System.nanoTime()+60_000_000_000L;return true;
        }catch(Exception e){error="Couldn't save your cases. Opening is paused.";return false;}
    }
    private static void archive(CaseLedger.Draw draw){
        try{var j=CaseLedger.drawJson(draw);j.addProperty("accountHash",ledger.accountHash);j.addProperty("playerName",Minecraft.getInstance().getUser().getName());j.addProperty("origin","local-client / manual ticket review");Path folder=file.getParent().resolve("claims");Files.createDirectories(folder);Files.writeString(folder.resolve(draw.id()+".json"),new GsonBuilder().setPrettyPrinting().create().toJson(j),StandardCharsets.UTF_8,StandardOpenOption.CREATE_NEW);}
        catch(Exception e){org.slf4j.LoggerFactory.getLogger("Astra Client").warn("Could not archive case claim; its reference remains in the account case history.");}
    }
}
