package client.astra.mixin;

import client.astra.AstraBranding;
import client.astra.AstraMenu;
import net.minecraft.client.Minecraft;
import net.minecraft.client.gui.Font;
import net.minecraft.client.gui.GuiGraphics;
import net.minecraft.client.gui.components.LogoRenderer;
import net.minecraft.client.gui.components.SplashRenderer;
import net.minecraft.client.gui.screens.TitleScreen;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Redirect;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;

@Mixin(TitleScreen.class)
public abstract class TitleScreenMixin {
    @Inject(method = "render", at = @At(value = "INVOKE", target =
        "Lnet/minecraft/client/gui/screens/Screen;render(Lnet/minecraft/client/gui/GuiGraphics;IIF)V"))
    private void astra$panel(GuiGraphics graphics, int mouseX, int mouseY, float delta, CallbackInfo ci) {
        AstraMenu.alignToMods((TitleScreen) (Object) this);
    }

    @Redirect(method = "render", at = @At(value = "INVOKE", target =
        "Lnet/minecraft/client/gui/components/LogoRenderer;renderLogo(Lnet/minecraft/client/gui/GuiGraphics;IF)V"))
    private void astra$renderLogo(LogoRenderer original, GuiGraphics graphics, int width, float alpha) {
        AstraBranding.drawTitle(graphics, Minecraft.getInstance().font, width, alpha);
    }

    @Redirect(method = "render", at = @At(value = "INVOKE", target =
        "Lnet/minecraft/client/gui/components/SplashRenderer;render(Lnet/minecraft/client/gui/GuiGraphics;ILnet/minecraft/client/gui/Font;F)V"))
    private void astra$hideSplash(SplashRenderer splash, GuiGraphics graphics, int width, Font font, float alpha) {
        // The vanilla angled splash would overlap the custom logo panel.
    }
}
