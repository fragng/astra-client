package client.astra;

import com.google.gson.*;
import net.minecraft.client.CloudStatus;
import net.minecraft.client.Minecraft;
import net.minecraft.client.Options;
import net.minecraft.server.level.ParticleStatus;

/** Reversible native video settings. Nullable extras preserve pre-1.31 backups. */
public final class PerformanceMode {
    private static final Gson GSON=new Gson();
    private static Saved saved;
    private PerformanceMode(){}
    private record Video(int render,int simulation,double entities,String clouds,String particles,boolean shadows,int blend,
                         Boolean occlusion,Boolean leaves,Boolean transparency,Boolean vignette) {
        static Video read(Options o){return new Video(o.renderDistance().get(),o.simulationDistance().get(),o.entityDistanceScaling().get(),o.cloudStatus().get().name(),o.particles().get().name(),o.entityShadows().get(),o.biomeBlendRadius().get(),o.ambientOcclusion().get(),o.cutoutLeaves().get(),o.improvedTransparency().get(),o.vignette().get());}
        Video fast(){return new Video(Math.min(render,6),Math.min(simulation,5),Math.min(entities,.5),"OFF","MINIMAL",false,0,false,true,false,false);}
        boolean valid(){try{CloudStatus.valueOf(clouds);ParticleStatus.valueOf(particles);}catch(Exception e){return false;}return render>=2 && render<=1024 && simulation>=2 && simulation<=1024 && Double.isFinite(entities) && entities>0 && entities<=16 && clouds!=null && particles!=null && blend>=0 && blend<=128;}
        void apply(Options o){
            o.renderDistance().set(render);o.simulationDistance().set(simulation);o.entityDistanceScaling().set(entities);
            o.cloudStatus().set(CloudStatus.valueOf(clouds));o.particles().set(ParticleStatus.valueOf(particles));o.entityShadows().set(shadows);o.biomeBlendRadius().set(blend);
            if(occlusion!=null)o.ambientOcclusion().set(occlusion);
            if(leaves!=null)o.cutoutLeaves().set(leaves);
            if(transparency!=null)o.improvedTransparency().set(transparency);
            if(vignette!=null)o.vignette().set(vignette);
        }
        void restoreMatching(Options o,Video applied){
            // Preserve any deliberate Video Settings edits made while the mode was on.
            if(o.renderDistance().get()==applied.render)o.renderDistance().set(render);
            if(o.simulationDistance().get()==applied.simulation)o.simulationDistance().set(simulation);
            if(Double.compare(o.entityDistanceScaling().get(),applied.entities)==0)o.entityDistanceScaling().set(entities);
            if(o.cloudStatus().get().name().equals(applied.clouds))o.cloudStatus().set(CloudStatus.valueOf(clouds));
            if(o.particles().get().name().equals(applied.particles))o.particles().set(ParticleStatus.valueOf(particles));
            if(o.entityShadows().get()==applied.shadows)o.entityShadows().set(shadows);
            if(o.biomeBlendRadius().get()==applied.blend)o.biomeBlendRadius().set(blend);
            if(occlusion!=null && o.ambientOcclusion().get().equals(applied.occlusion))o.ambientOcclusion().set(occlusion);
            if(leaves!=null && o.cutoutLeaves().get().equals(applied.leaves))o.cutoutLeaves().set(leaves);
            if(transparency!=null && o.improvedTransparency().get().equals(applied.transparency))o.improvedTransparency().set(transparency);
            if(vignette!=null && o.vignette().get().equals(applied.vignette))o.vignette().set(vignette);
        }
    }
    private record Saved(Video original,Video applied){}
    public static boolean enabled(){return saved!=null;}
    public static void toggle(){if(enabled())disable();else enable();}
    public static void initialize(){
        // Upgrade an enabled legacy preset without losing its original restoration values.
        if(saved==null || saved.original.occlusion!=null)return;
        var o=Minecraft.getInstance().options;
        saved.original.restoreMatching(o,saved.applied);
        var original=Video.read(o);var next=original.fast();saved=new Saved(original,next);
        AstraConfig.changed();AstraConfig.flush();next.apply(o);AstraConfig.nativeChanged();AstraConfig.flush();
    }
    public static void enable(){
        if(enabled())return;
        var options=Minecraft.getInstance().options;Video before=Video.read(options);saved=new Saved(before,before.fast());
        // Persist the original values before native callbacks change them.
        AstraConfig.changed();AstraConfig.flush();saved.applied.apply(options);
        AstraConfig.nativeChanged();AstraConfig.flush();
    }
    public static void disable(){
        if(!enabled())return;
        var previous=saved;previous.original.restoreMatching(Minecraft.getInstance().options,previous.applied);
        // Save restored native options before discarding their backup.
        AstraConfig.nativeChanged();AstraConfig.flush();saved=null;AstraConfig.changed();AstraConfig.flush();
    }
    public static JsonElement json(){return saved==null?JsonNull.INSTANCE:GSON.toJsonTree(saved);}
    public static void load(JsonElement value){
        saved=null;if(value==null || value.isJsonNull())return;
        try{var state=GSON.fromJson(value,Saved.class);if(state==null || state.original==null || state.applied==null || !state.original.valid() || !state.applied.valid())throw new IllegalArgumentException();saved=state;}
        catch(Exception e){org.slf4j.LoggerFactory.getLogger("Astra Client").warn("Could not read Performance Mode backup; leaving native video settings unchanged.");}
    }
}
