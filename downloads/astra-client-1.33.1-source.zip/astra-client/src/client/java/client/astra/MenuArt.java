package client.astra;

import net.minecraft.client.gui.GuiGraphics;

public final class MenuArt {
    public static void lock(net.minecraft.client.gui.GuiGraphics g,int x,int y,int size,int color){
        int band=Math.max(2,size/9),shackle=Math.max(5,size*3/5),sx=x+(size-shackle)/2;
        Ui.round(g,sx,y,shackle,Math.max(6,size*3/5),Math.max(2,size/5),color);
        Ui.round(g,sx+band,y+band,shackle-2*band,Math.max(2,size*3/5-band),Math.max(1,size/8),0xFF242035);
        Ui.round(g,x,y+size*2/5,size,size*3/5,Math.max(2,size/7),color);
        Ui.round(g,x+size/2-band/2,y+size*3/5,band,Math.max(2,size/5),1,0xFF29213E);
    }

    private MenuArt() {}
    private static void line(GuiGraphics g,float x,float y,float x2,float y2,int color) {
        int steps=Math.max(1,(int)Math.ceil(Math.hypot(x2-x,y2-y)*2));
        for(int i=0;i<=steps;i++) {
            float t=i/(float)steps;int px=Math.round(x+(x2-x)*t),py=Math.round(y+(y2-y)*t);
            g.fill(px,py,px+1,py+1,Ui.tint(color));
        }
    }
    private static final java.util.Map<String,net.minecraft.resources.Identifier> ICONS=java.util.Map.of(
        "Visuals",asset("visuals"),"Jamble",asset("jamble"),"HUD",asset("hud"),"Spotify HUD",asset("spotify"),"Music",asset("spotify"),"Essentials",asset("essentials"),"Buy Premium",asset("discord"));
    private static net.minecraft.resources.Identifier asset(String name){return net.minecraft.resources.Identifier.fromNamespaceAndPath(AstraClient.MOD_ID,"textures/icons/"+name+".png");}
    private static final net.minecraft.resources.Identifier TOTEM=net.minecraft.resources.Identifier.withDefaultNamespace("textures/item/totem_of_undying.png");
    public static void icon(GuiGraphics g,String name,int x,int y,int size,int color) {
        if(name.equals("3D Characters")){CharacterStyle.SPONGEBOB.icon(g,x,y,size);return;}
        var mode=PvpMode.find(name);
        if(mode!=null){g.pose().pushMatrix();g.pose().translate(x,y);g.pose().scale(size/16f,size/16f);g.renderItem(mode.icon,0,0);g.pose().popMatrix();return;}
        if(name.equals("Customize Totem")) {Ui.texture(g,TOTEM,x,y,size,size,0,1,0,1,16,16);return;}
        var texture=ICONS.get(name);
        if(texture!=null){if(name.equals("HUD"))Ui.round(g,x,y,size,size,3,0xFFE0D9ED);Ui.texture(g,texture,x,y,size,size,0,1,0,1,128,128);return;}
        g.pose().pushMatrix();g.pose().translate(x,y);g.pose().scale(size/16f,size/16f);
        switch(name) {
            case "Games"->{Ui.round(g,1,5,14,8,3,color);Ui.round(g,0,8,5,6,2,color);Ui.round(g,11,8,5,6,2,color);g.fill(3,7,5,12,Ui.tint(0xFF29203D));g.fill(2,8,7,10,Ui.tint(0xFF29203D));Ui.round(g,10,7,2,2,1,0xFFDAA4FF);Ui.round(g,12,10,2,2,1,0xFF8DE1EA);}
            case "Wordle"->{for(int row=0;row<2;row++)for(int col=0;col<3;col++)Ui.round(g,1+col*5,2+row*6,4,5,1,row==0&&col==1?0xFFE8C75B:0xFF8CDBAC);}
            case "Krillion"->{Ui.round(g,3,4,10,8,4,0xFF9DCFE8);line(g,1,2,5,5,color);line(g,15,2,11,5,color);line(g,4,11,1,14,color);line(g,12,11,15,14,color);Ui.round(g,5,6,2,2,1,0xFF25203D);Ui.round(g,10,6,2,2,1,0xFF25203D);}
            case "Case Opening"->{Ui.round(g,2,5,12,9,2,0xFFAE864C);Ui.round(g,3,6,10,7,1,0xFF58402E);Ui.round(g,2,3,12,4,1,color);Ui.round(g,7,6,2,4,1,0xFFFFD875);}

            case "Settings" -> {Ui.round(g,3,3,10,10,5,color);Ui.round(g,5,5,6,6,3,0xFF23213A);for(int i=0;i<8;i++){double a=i*Math.PI/4;line(g,8+(float)Math.cos(a)*5,8+(float)Math.sin(a)*5,8+(float)Math.cos(a)*8,8+(float)Math.sin(a)*8,color);}}
            case "General" -> {for(int i=0;i<3;i++){line(g,0,3+i*5,16,3+i*5,color);Ui.round(g,i==1?9:3,1+i*5,4,4,2,color);}}
            default -> {line(g,8,0,8,16,color);line(g,0,8,16,8,color);line(g,3,3,13,13,color);line(g,3,13,13,3,color);}
        }
        g.pose().popMatrix();
    }
    public static void background(GuiGraphics g,int w,int h) {Backgrounds.drawMenu(g,w,h);}
}
