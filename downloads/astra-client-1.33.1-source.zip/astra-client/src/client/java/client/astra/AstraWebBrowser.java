package client.astra;

import com.mojang.blaze3d.opengl.GlConst;
import com.mojang.blaze3d.opengl.GlStateManager;
import com.mojang.blaze3d.opengl.GlTexture;
import com.mojang.blaze3d.systems.RenderSystem;
import com.mojang.blaze3d.textures.*;
import net.dimaskama.mcef.impl.MCEFBrowserImpl;
import org.cef.CefBrowserSettings;
import org.cef.CefClient;
import org.cef.browser.CefBrowser;
import org.cef.browser.CefRequestContext;
import java.awt.Rectangle;
import java.nio.ByteBuffer;

/** Astra's bounded upload path, using MCEF's unchanged native browser and input implementation. */
public final class AstraWebBrowser extends MCEFBrowserImpl {
    private final BrowserFrames frames=new BrowserFrames();
    private GpuTexture texture;
    private GpuTextureView textureView;
    private int frameRate;
    public AstraWebBrowser(CefClient client,String url){super(client,url,false,CefRequestContext.getGlobalContext(),settings());frameRate=rate();}
    private static int rate(){return PerformanceMode.enabled()?30:60;}
    private static CefBrowserSettings settings(){var settings=new CefBrowserSettings();settings.windowless_frame_rate=rate();return settings;}
    public BrowserFrames frames(){return frames;}
    private static final boolean LINUX=System.getProperty("os.name","").toLowerCase(java.util.Locale.ROOT).contains("linux");
    @Override public void onKeyPressed(net.minecraft.client.input.KeyEvent event){sendKeyEvent(BrowserInput.event(component,true,event.key(),event.scancode(),event.modifiers(),LINUX));}
    @Override public void onKeyReleased(net.minecraft.client.input.KeyEvent event){sendKeyEvent(BrowserInput.event(component,false,event.key(),event.scancode(),event.modifiers(),LINUX));}
    public void updateFrameRate(){int next=rate();if(next!=frameRate){frameRate=next;setWindowlessFrameRate(next);}}
    @Override public void onPaint(CefBrowser browser,boolean popup,Rectangle[] dirtyRects,ByteBuffer pixels,int width,int height){
        if(!popup && dirtyRects.length>0)frames.publish(pixels,width,height);
    }
    /** Called once per Minecraft render, never schedules one main-thread task per CEF frame. */
    public void uploadFrame(){
        var frame=frames.take();if(frame==null)return;
        if(texture==null || texture.getWidth(0)!=frame.width() || texture.getHeight(0)!=frame.height()){
            closeTexture();
            texture=RenderSystem.getDevice().createTexture("Astra Krillion",GpuTexture.USAGE_COPY_DST|GpuTexture.USAGE_TEXTURE_BINDING,TextureFormat.RGBA8,frame.width(),frame.height(),1,1);
            textureView=RenderSystem.getDevice().createTextureView(texture);
        }
        GlStateManager._bindTexture(((GlTexture)texture).glId());
        GlStateManager._pixelStore(GlConst.GL_UNPACK_ROW_LENGTH,frame.width());
        GlStateManager._pixelStore(GlConst.GL_UNPACK_SKIP_PIXELS,0);
        GlStateManager._pixelStore(GlConst.GL_UNPACK_SKIP_ROWS,0);
        GlStateManager._pixelStore(GlConst.GL_UNPACK_ALIGNMENT,4);
        GlStateManager._texSubImage2D(GlConst.GL_TEXTURE_2D,0,0,0,frame.width(),frame.height(),org.lwjgl.opengl.GL12.GL_BGRA,GlConst.GL_UNSIGNED_BYTE,frame.pixels());
    }
    @Override public GpuTexture getTexture(){return texture;}
    @Override public GpuTextureView getTextureView(){return textureView;}
    private void closeTexture(){if(textureView!=null){textureView.close();textureView=null;}if(texture!=null){texture.close();texture=null;}}
    @Override public void close(){frames.close();closeTexture();super.close();}
}
