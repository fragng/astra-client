package client.astra.mixin;

import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.Unique;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;

/** JCEF's late client-disposal callbacks may request native shutdown more than once. */
@Mixin(targets="org.cef.CefApp",remap=false)
public abstract class CefShutdownOnceMixin {
    @Unique private final java.util.concurrent.atomic.AtomicBoolean astra$shutdownScheduled=new java.util.concurrent.atomic.AtomicBoolean();
    @Inject(method="shutdown",at=@At("HEAD"),cancellable=true,remap=false)
    private void astra$shutdownOnce(CallbackInfo ci){if(!astra$shutdownScheduled.compareAndSet(false,true))ci.cancel();}
}
