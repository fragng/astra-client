package client.astra;

import java.util.function.BooleanSupplier;
import java.util.function.IntSupplier;
import net.minecraft.client.Minecraft;
import net.minecraft.client.gui.GuiGraphics;
import net.minecraft.client.gui.components.Button;

/** Native focusable keyboard key, with feedback supplied by the revealed rows only. */
public final class WordKey extends Button {
    private final String label;
    private final IntSupplier mark;
    private final BooleanSupplier enabled;
    public WordKey(int x,int y,int width,int height,String label,IntSupplier mark,BooleanSupplier enabled,Runnable action){
        super(x,y,width,height,Ui.text(label),b->action.run(),DEFAULT_NARRATION);this.label=label;this.mark=mark;this.enabled=enabled;
    }
    public static int color(int mark){return switch(mark){case WordleGame.CORRECT->0xFF427E65;case WordleGame.PRESENT->0xFFB38B37;case WordleGame.ABSENT->0xFF514C60;default->AstraConfig.colour().panelTop;};}
    @Override protected void renderContents(GuiGraphics g,int mx,int my,float delta){
        active=enabled.getAsBoolean();int colour=color(mark.getAsInt());
        Ui.round(g,getX(),getY()+1,getWidth(),getHeight(),6,AstraConfig.colour().background);
        Ui.round(g,getX(),getY(),getWidth(),getHeight()-1,6,Ui.blend(colour,AstraConfig.colour().accent,isHoveredOrFocused()&&active?.22f:0));
        Ui.centered(g,Minecraft.getInstance().font,label,getX()+getWidth()/2,getY()+(getHeight()-9)/2,label.length()==1?1.15f:.78f,active?0xFFFFFFFF:0xFFAAAAAA);
    }
}
