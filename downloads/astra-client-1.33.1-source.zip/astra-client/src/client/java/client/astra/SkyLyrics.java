package client.astra;

import net.fabricmc.fabric.api.client.rendering.v1.world.WorldRenderEvents;
import net.fabricmc.fabric.api.resource.ResourceManagerHelper;
import net.fabricmc.fabric.api.resource.SimpleSynchronousResourceReloadListener;
import net.minecraft.client.Minecraft;
import net.minecraft.resources.Identifier;
import net.minecraft.server.packs.PackType;
import net.minecraft.server.packs.resources.ResourceManager;
import net.minecraft.world.effect.MobEffects;
import net.minecraft.world.level.material.FogType;
import org.joml.Matrix4f;
import com.mojang.blaze3d.systems.RenderSystem;
import java.util.*;

/** Lyrics are a fixed celestial object in the native sky pass, not a camera-facing HUD. */
public final class SkyLyrics {
    private record Line(String text,float offset,int color){}
    private record Frame(List<Line> lines,boolean bubble,float yaw,float elevation){}
    private static final LyricMotion MOTION=new LyricMotion();
    private static volatile Frame frame;
    private static long last=System.nanoTime();
    private static boolean warned;
    private SkyLyrics(){}
    public static boolean enabled(){return !PerformanceMode.enabled() && PremiumEdition.premium() && AstraConfig.lyricsInSky;}
    public static String positionLabel(){
        String[] directions={"South","SW","West","NW","North","NE","East","SE"};
        return directions[(int)Math.floor((AstraConfig.skyLyricsYaw+22.5)/45)%8]+" / "+Math.round(AstraConfig.skyLyricsElevation)+" degrees up";
    }
    public static void initialize(){
        ResourceManagerHelper.get(PackType.CLIENT_RESOURCES).registerReloadListener(new SimpleSynchronousResourceReloadListener(){
            public Identifier getFabricId(){return Identifier.fromNamespaceAndPath(AstraClient.MOD_ID,"sky_lyrics");}
            public void onResourceManagerReload(ResourceManager resources){close();}
        });
        WorldRenderEvents.END_EXTRACTION.register(context->{
            var mc=Minecraft.getInstance();long now=System.nanoTime();double dt=(now-last)/1e9;last=now;
            var media=SpotifyBridge.state();var lyrics=LyricsService.current();
            if(!enabled() || mc.player==null || mc.level==null || mc.screen!=null || mc.options.hideGui || mc.getDebugOverlay().showDebugScreen()
                || mc.level.dimensionType().skybox()!=net.minecraft.world.level.dimension.DimensionType.Skybox.OVERWORLD
                || mc.player.hasEffect(MobEffects.BLINDNESS) || mc.player.hasEffect(MobEffects.DARKNESS)
                || mc.gameRenderer.getMainCamera().getFluidInCamera()!=FogType.NONE
                || !media.connected() || media.duration()<=0 || !lyrics.synced() || lyrics.lines().isEmpty()) {close();return;}
            int index=lyrics.index(media.elapsed());if(index<0){close();return;}
            double shown=MOTION.update(lyrics,index,dt,AstraConfig.animations);int base=(int)Math.floor(shown);
            var lines=new ArrayList<Line>();
            for(int i=Math.max(0,base-1);i<Math.min(lyrics.lines().size(),base+3);i++){
                String text=lyrics.lines().get(i).text();if(text.isBlank())continue;
                if(text.length()>120)text=text.substring(0,text.offsetByCodePoints(0,Math.min(100,text.codePointCount(0,text.length()))))+"...";
                float distance=(float)(i-shown);
                float opacity=Math.clamp(distance<0?1+distance:1-distance*.75f,0,1);if(opacity<.005f)continue;
                float emphasis=Math.clamp(1-Math.abs(distance),0,1);
                lines.add(new Line(text,distance*16,Ui.alpha(Ui.blend(0xFF9185BA,0xFFF5EEFF,emphasis),opacity)));
            }
            frame=lines.isEmpty()?null:new Frame(List.copyOf(lines),AstraConfig.bubbleFont,(float)AstraConfig.skyLyricsYaw,(float)AstraConfig.skyLyricsElevation);
        });
    }
    /** Called after sun/moon/stars, before terrain. Terrain/roofs naturally cover it. */
    public static void draw(){
        Frame current=frame;if(current==null || !enabled())return;
        try {
            var meshes=new ArrayList<SkyGlyphMeshes.Line>(current.lines.size());int maxWidth=1;
            for(Line line:current.lines){var mesh=SkyGlyphMeshes.line(line.text,current.bubble);meshes.add(mesh);maxWidth=Math.max(maxWidth,mesh.width);}
            float yaw=(float)Math.toRadians(current.yaw),elevation=(float)Math.toRadians(current.elevation);
            float horizontal=(float)Math.cos(elevation)*100,scale=Math.min(.6f,100f/maxWidth);
            var sky=new Matrix4f(RenderSystem.getModelViewMatrix())
                .translate(-(float)Math.sin(yaw)*horizontal,(float)Math.sin(elevation)*100,(float)Math.cos(yaw)*horizontal)
                .rotateY((float)Math.PI-yaw).rotateX(elevation).scale(scale,-scale,scale);
            for(int i=0;i<current.lines.size();i++){
                var line=current.lines.get(i);SkyGlyphMeshes.draw(meshes.get(i),new Matrix4f(sky).translate(0,line.offset-4,0),line.color);
            }
        }catch(RuntimeException e){
            frame=null;SkyGlyphMeshes.clear();
            if(!warned){warned=true;org.slf4j.LoggerFactory.getLogger(AstraClient.NAME).warn("Sky lyric rendering unavailable; check shader/resource compatibility",e);}
        }
    }
    public static void close(){frame=null;MOTION.reset();SkyGlyphMeshes.clear();warned=false;}
}
