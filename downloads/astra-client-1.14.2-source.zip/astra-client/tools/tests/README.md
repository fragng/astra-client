Run `./gradlew testWindowsMediaAbi` with Java 21. The same test is included in `check`.

This standalone test uses real JNA callback pointers and COM-style vtables to exercise the production WindowsMediaSession class. It covers interface GUIDs/slots, Spotify-only selection, UTF-16 metadata, timeline and controls, command results, timeout/cancellation, bounded vectors, thread affinity and reference/HSTRING/apartment cleanup. It never loads Windows DLLs, launches a process or contacts Spotify.

These are ABI-contract tests with a synthetic Windows runtime, not a live Windows desktop/Defender validation. Test classes do not enter the mod JAR.
