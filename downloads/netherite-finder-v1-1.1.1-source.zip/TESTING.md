# Netherite Finder V1 / 1.1.1 validation

27 November 2026. Minecraft Java 1.21.11, Fabric Loader 0.19.3, Java 21.
Tests used the final remapped release JAR with its unchanged nested Fabric API,
an external observer and an isolated local survival world on Linux/X11/Mesa.
No public Minecraft server was connected to or modified.

The Gradle build and contracts pass. Contracts cover bounded search, safe
steps, protected item classification, inventory-confirmed pickup, smooth
turn convergence/rate bounds/angle wraparound, movement progress and local recovery.

Additional contracts verify sprinting past a waypoint without a centre hit,
corner/floor separation, A/D camera basis directions, diagonal speed, and
scroll bounds. Native Minecraft checks passed:

- F6 menu, all three categories, instructions and ON toggle.
- direct survival mining, real hotbar lava plug, inventory cleanup and confirmed debris pickup.
- walk to externally broken debris and confirm pickup.
- recover around a chest obstruction with bounded smooth aim.
- lava detour with no hotbar plug blocks stays enabled and reaches debris.
- clear corridor route reaches debris without a false obstruction or abandoned approach.
- clear diagonal route reaches debris without a false obstruction or abandoned approach.
- clear angle route reaches debris without a false obstruction or abandoned approach.
- lava source plugged with cobblestone brought from main inventory, followed by debris pickup.
- while immersed in lava, place inventory blocks outside the body and swim clear without disabling.
- server-confirmed Mending with pickaxe in OFFHAND and XP in MAIN HAND; OFF restores totem.
- totem refill after a real pop while F6 controls are open.
- 64 debris does not trigger a deposit while more player storage is available.
- real ender-chest transfer fills 27 stacks and keeps automation enabled.
- stop only when both usable player storage and ender chest are full.
- freecam A/D strafe correctly relative to the camera while the idle body stays fixed.
- actual scroll wheel changes freecam speed, clamps at 0.25x/4x and leaves hotbar selection unchanged.
- F4/Z request more view distance, restore it on exit, and preserve freelook body yaw and disable controls.
- base finder stays off a storage cluster within 30 blocks of a loaded trial spawner.
- open empty storage, skip raided cluster, navigate to another cluster and verify actual loot.
- 128-block player boundary and actual logout with automation disabled.

Storage tests provide debris stacks deliberately, so they verify actual
server transfers and capacity handling, rather than claiming thousands of
blocks were mined in the test. Ender storage is confirmed as 1,728 debris.
XP tests confirm the actual server tool damage decreased while the tool was
in the offhand; OFF and menu interruption restore the original totem.
Base tests create real empty and item-filled chests plus a trial spawner,
verify trial exclusion and an actually inspected empty cluster, then stop
at another container with server-supplied loot. This is a loaded-clue
heuristic, not reliable identification of all bases or raids.

The immersed-lava fixture supplies Fire Resistance only to keep that test
deterministic; the release does not grant it or promise lava immunity.
Clear straight and diagonal paths verify pickup without false obstruction
or abandoned-approach statuses. Main-inventory cobblestone is confirmed
as an actual lava plug. Camera checks use actual keyboard/mouse input,
verify wheel events clamp at 0.25x/4x without changing hotbar slots, and
confirm the server receives a larger client view-distance request. The
local test server caps delivery at six chunks; remote chunk loading is
not claimed. The original distance is restored on exit. Tests measure camera/body positions
and yaw, verify the physical body stays still with idle freecam, and test
the category's disable setting. Menu layout is visibly checked at a
480x300 scaled GUI in a 1440x900 game window.

Archive checks verify metadata, Java 21 classes, nested upstream Fabric API
identity, and exclusion of the observer, saves, user accounts and OS helpers.
ClamAV 1.5.4 scanned the final complete JAR: zero infected files. This is
not Windows Defender certification. See the exact release SHA-256 and scan report.
Windows hardware, other mods, public-server anti-cheat/protection rules,
server-hidden data, arbitrary lava layouts and abrupt network-loss restoration
were not validated. No invulnerability or anti-cheat guarantee is made.
