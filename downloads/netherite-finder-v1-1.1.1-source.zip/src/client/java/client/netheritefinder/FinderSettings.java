package client.netheritefinder;

import com.google.gson.*;
import net.fabricmc.loader.api.FabricLoader;
import java.nio.file.*;

public final class FinderSettings {
    public static boolean esp=true,freecamAllowed=true,freelookAllowed=true;
    public static double cameraSpeed=.35,cameraMultiplier=1,lookDistance=4;
    public static int baseContainers=2,baseDepth=24,cameraChunks=20;
    private static final Path FILE=FabricLoader.getInstance().getConfigDir().resolve("netherite-finder.json");
    public static void load(){try{if(!Files.exists(FILE)||Files.size(FILE)>65536)return;var j=JsonParser.parseString(Files.readString(FILE)).getAsJsonObject();freecamAllowed=!j.has("freecamAllowed")||j.get("freecamAllowed").getAsBoolean();freelookAllowed=!j.has("freelookAllowed")||j.get("freelookAllowed").getAsBoolean();esp=!j.has("esp")||j.get("esp").getAsBoolean();if(j.has("cameraChunks"))cameraChunks=Math.clamp(j.get("cameraChunks").getAsInt(),12,32);if(j.has("cameraMultiplier"))cameraMultiplier=Math.clamp(j.get("cameraMultiplier").getAsDouble(),.25,4);if(j.has("cameraSpeed"))cameraSpeed=Math.clamp(j.get("cameraSpeed").getAsDouble(),.1,1);if(j.has("lookDistance"))lookDistance=Math.clamp(j.get("lookDistance").getAsDouble(),1,12);if(j.has("baseContainers"))baseContainers=Math.clamp(j.get("baseContainers").getAsInt(),1,8);if(j.has("baseDepth"))baseDepth=Math.clamp(j.get("baseDepth").getAsInt(),-50,100);}catch(Exception e){org.slf4j.LoggerFactory.getLogger("Netherite Finder").warn("Could not read preferences; using defaults.");}}
    public static void save(){try{Files.createDirectories(FILE.getParent());var j=new JsonObject();j.addProperty("esp",esp);j.addProperty("freecamAllowed",freecamAllowed);j.addProperty("freelookAllowed",freelookAllowed);j.addProperty("cameraChunks",cameraChunks);j.addProperty("cameraSpeed",cameraSpeed);j.addProperty("cameraMultiplier",cameraMultiplier);j.addProperty("lookDistance",lookDistance);j.addProperty("baseContainers",baseContainers);j.addProperty("baseDepth",baseDepth);var p=FILE.resolveSibling(FILE.getFileName()+".tmp");Files.writeString(p,new GsonBuilder().setPrettyPrinting().create().toJson(j));Files.move(p,FILE,StandardCopyOption.REPLACE_EXISTING);}catch(Exception e){org.slf4j.LoggerFactory.getLogger("Netherite Finder").warn("Could not save preferences",e);}}
}
