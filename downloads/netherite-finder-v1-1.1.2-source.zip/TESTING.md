# Netherite Finder V1 / 1.1.2 validation

27 November 2026. Minecraft Java 1.21.11, Fabric Loader 0.19.3, Java 21.
The final remapped JAR, including unchanged nested Fabric API, was installed
in an isolated local survival world on Linux/X11/Mesa with an external
observer. No public Minecraft server was connected to or modified.

Build and contracts pass. New contracts cover normal sprint-jump gates:
minimum distance, alignment, hunger, grounding, flatness and full clear
landing/headroom. They also verify short sprint stopping margins and the
faster mining aim's convergence, angular rate bounds and lack of overshoot.
Earlier route, waypoint, pickup, protected-item and recovery contracts remain.

Native movement and retained-feature checks passed:

- F6 menu, all three categories, instructions and ON toggle.
- direct survival mining, real hotbar lava plug, inventory cleanup and confirmed debris pickup.
- walk to externally broken debris and confirm pickup.
- recover around a chest obstruction with bounded smooth aim.
- lava detour with no hotbar plug blocks stays enabled and reaches debris.
- clear corridor route reaches debris without a false obstruction or abandoned approach.
- clear diagonal route reaches debris without a false obstruction or abandoned approach.
- clear angle route reaches debris without a false obstruction or abandoned approach.
- lava source plugged with cobblestone brought from main inventory, followed by debris pickup.
- while immersed in lava, place inventory blocks outside the body and swim clear without disabling.
- server-confirmed Mending with pickaxe in OFFHAND and XP in MAIN HAND; OFF restores totem.
- totem refill after a real pop while F6 controls are open.
- 64 debris does not trigger a deposit while more player storage is available.
- real ender-chest transfer fills 27 stacks and keeps automation enabled.
- stop only when both usable player storage and ender chest are full.
- base finder stays off a storage cluster within 30 blocks of a loaded trial spawner.
- open empty storage, skip raided cluster, navigate to another cluster and verify actual loot.
- 128-block player boundary and actual logout with automation disabled.

The Fast approach button is clicked OFF and ON in the actual F6 menu.
Movement cases cover lava plugging and pickup, a drop broken elsewhere,
chest obstruction recovery, a lava detour without blocks, straight/equal-
diagonal/unequal-diagonal clear routes, inventory-only cobblestone plugging,
and immersed-lava recovery. The immersed-lava fixture supplies Fire
Resistance solely for deterministic testing; the release does not grant it.

XP tests verify server-side pickaxe repair in the offhand, and restoration
of the totem on OFF. A real totem pop is refilled with F6 open. Storage
fixtures deliberately supply stacks: they verify no early deposit at 64,
a real 1,728-debris ender transfer, continued use of player storage and
stopping only when usable storage is full. Base tests inspect real empty
and item-filled chests, exclude a trial marker, then verify loaded-player
logout with the moving bot paused so the radius boundary stays fixed.

A separate timing comparison runs three open and three low-tunnel cases
on each of 1.1.1 and 1.1.2. Native sprint-jumps are observed only in the
high open lane; the low tunnel remains grounded. All candidate samples
confirm server-side debris collection and zero airborne attack ticks.
The raw samples and median comparisons are in the benchmark JSON.
Open approach-to-first-hit: 91 -> 76 ticks median (16.5% less time).
Open full pickup cycle: 134 -> 114 ticks median (14.9% less time).
Low-tunnel full pickup cycle: 135 -> 130 ticks median (3.7% less time).
These local fixture numbers are not a general server, terrain or FPS claim.

Camera code is unchanged from 1.1.1 and was not re-tested for this movement
update. Menu geometry is checked in a 480x300 scaled GUI / 1440x900 window.
Archive checks verify Java 21 classes, compatible metadata, unchanged
upstream Fabric API and exclusion of the observer, saves and OS helpers.
ClamAV 1.5.4 scanned the final complete JAR: zero infected files. This is
not Microsoft Defender certification. See exact release SHA-256 and scan report.
Windows hardware, other mods, public-server anti-cheat/protection rules,
server-hidden data, arbitrary terrain/lava and abrupt network-loss
restoration were not validated. No invulnerability or anti-cheat guarantee.
