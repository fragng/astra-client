package client.netheritefinder;

/** Vanilla movement policy: speed comes from sprinting and ordinary jump impulses, never modified velocity. */
public final class ApproachPace {
    private ApproachPace(){}
    public static boolean sprint(double remaining,double yawError,int food,boolean grounded,boolean collision){return remaining>1.8&&Math.abs(yawError)<10&&food>6&&grounded&&!collision;}
    public static boolean hop(double remaining,double yawError,int food,boolean grounded,boolean sprinting,boolean flat,boolean clear){return remaining>=10&&Math.abs(yawError)<6&&food>6&&grounded&&sprinting&&flat&&clear;}
    public static double sprintProbe(double remaining){return Math.clamp(remaining-1.35,.35,1.6);}
}
