package client.netheritefinder;

/** Waypoint progress uses the travelled segment, so a sprint cannot skip a tiny centre hitbox. */
public final class NavigationMath {
    private NavigationMath(){}
    public static boolean progressed(double x,double z,double originX,double originZ,double targetX,double targetZ){
        return Math.hypot(targetX-originX,targetZ-originZ)-Math.hypot(targetX-x,targetZ-z)>=.7;
    }
    public static boolean reached(double x,double y,double z,double originX,double originZ,int goalX,int goalY,int goalZ){
        if(Math.abs(y-goalY)>.6)return false;
        double tx=goalX+.5,tz=goalZ+.5,ex=x-tx,ez=z-tz;
        if(ex*ex+ez*ez<=.22*.22)return true;
        double dx=tx-originX,dz=tz-originZ,len2=dx*dx+dz*dz;
        if(len2<.01)return false;
        double projected=((x-originX)*dx+(z-originZ)*dz)/len2;
        double sideways=Math.abs(ex*dz-ez*dx)/Math.sqrt(len2);
        return projected>=1&&sideways<=.42;
    }
}
