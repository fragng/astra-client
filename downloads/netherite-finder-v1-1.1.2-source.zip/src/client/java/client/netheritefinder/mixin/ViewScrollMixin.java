package client.netheritefinder.mixin;

import client.netheritefinder.ViewModes;
import net.minecraft.client.MouseHandler;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.*;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;

@Mixin(MouseHandler.class)
public abstract class ViewScrollMixin {
    @Inject(method="onScroll",at=@At("HEAD"),cancellable=true)
    private void finder$speed(long window,double horizontal,double vertical,CallbackInfo ci){if(ViewModes.scroll(vertical))ci.cancel();}
}
