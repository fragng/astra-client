package client.netheritefinder;

import net.minecraft.client.Minecraft;
import net.minecraft.core.component.DataComponents;
import net.minecraft.tags.ItemTags;
import net.minecraft.world.inventory.ClickType;
import net.minecraft.world.item.*;
import net.minecraft.world.item.enchantment.Enchantments;
import net.minecraft.world.level.block.Blocks;
import java.util.function.Predicate;

/** Uses normal container clicks; no cursor pickup, item creation or packet bursts. */
public final class InventoryActions {
    private final Minecraft mc=Minecraft.getInstance();private long nextClick;
    public int pickSlot=-1;
    public int count(Item item){return count(stack->stack.is(item));}
    public int count(Predicate<ItemStack> matches){if(mc.player==null)return 0;int result=0;for(int i=0;i<36;i++){var stack=mc.player.getInventory().getItem(i);if(matches.test(stack))result+=stack.getCount();}return result;}
    public int find(Predicate<ItemStack> matches){if(mc.player==null)return -1;for(int i=0;i<36;i++)if(matches.test(mc.player.getInventory().getItem(i)))return i;return -1;}
    public static boolean goodPick(ItemStack stack){return stack.is(ItemTags.PICKAXES)&&stack.isCorrectToolForDrops(Blocks.ANCIENT_DEBRIS.defaultBlockState())&&(!stack.isDamageableItem()||stack.getMaxDamage()-stack.getDamageValue()>16);}
    public static boolean mending(ItemStack stack){return stack.getEnchantments().keySet().stream().anyMatch(e->e.is(Enchantments.MENDING));}
    public static boolean silk(ItemStack stack){return stack.getEnchantments().keySet().stream().anyMatch(e->e.is(Enchantments.SILK_TOUCH));}
    public static double damage(ItemStack stack){return stack.isDamageableItem()?(double)stack.getDamageValue()/stack.getMaxDamage():0;}
    public int bestPick(){
        int found=-1;double best=-1;
        for(int i=0;i<36;i++){var stack=mc.player.getInventory().getItem(i);if(!goodPick(stack))continue;double score=stack.getDestroySpeed(Blocks.NETHERRACK.defaultBlockState())+(mending(stack)?4:0)+(silk(stack)?1:0)-damage(stack)*2;if(score>best){best=score;found=i;}}
        return found;
    }
    private int menuSlot(int inventoryIndex){var menu=mc.player.containerMenu;for(int i=0;i<menu.slots.size();i++){var slot=menu.slots.get(i);if(slot.container==mc.player.getInventory()&&slot.getContainerSlot()==inventoryIndex)return i;}return -1;}
    private boolean click(int slot,int button,ClickType type,long tick){
        if(tick<nextClick||slot<0||mc.player==null||mc.gameMode==null||!mc.player.containerMenu.getCarried().isEmpty())return false;
        mc.gameMode.handleInventoryMouseClick(mc.player.containerMenu.containerId,slot,button,type,mc.player);nextClick=tick+6;return true;
    }
    /** Move a main-inventory item to a hotbar slot with one swap, then select it. */
    public boolean equip(int index,long tick){
        if(index<0)return false;var inv=mc.player.getInventory();
        if(index>=9){int hotbar=8;while(hotbar==pickSlot||hotbar==hotbarBuildingSlot())hotbar--;int slot=menuSlot(index);if(!click(slot,hotbar,ClickType.SWAP,tick))return false;index=hotbar;}
        inv.setSelectedSlot(index);return true;
    }
    public boolean equipPick(long tick){int slot=bestPick();if(slot<0)return false;if(!equip(slot,tick))return false;pickSlot=mc.player.getInventory().getSelectedSlot();return true;}
    public boolean swapOffhand(int index,long tick){return index>=0&&click(menuSlot(index),40,ClickType.SWAP,tick);}
    public int buildingSlot(){int hotbar=hotbarBuildingSlot();return hotbar>=0?hotbar:find(InventoryActions::buildingBlock);}
    public int hotbarBuildingSlot(){for(int i=0;i<9;i++)if(buildingBlock(mc.player.getInventory().getItem(i)))return i;return -1;}
    /** Capacity after discarding only expendable blocks, preserving one hotbar building stack. */
    public int debrisCapacity(){int capacity=0,reserve=hotbarBuildingSlot();for(int i=0;i<36;i++){var stack=mc.player.getInventory().getItem(i);if(stack.isEmpty()||i!=reserve&&disposable(stack))capacity+=64;else if(stack.is(Items.ANCIENT_DEBRIS))capacity+=stack.getMaxStackSize()-stack.getCount();}return capacity;}
    public boolean refillTotem(long tick){int slot=find(stack->stack.is(Items.TOTEM_OF_UNDYING));return slot>=0&&click(menuSlot(slot),40,ClickType.SWAP,tick);}
    public boolean hasDebrisSpace(){return find(stack->stack.isEmpty()||stack.is(Items.ANCIENT_DEBRIS)&&stack.getCount()<stack.getMaxStackSize())>=0;}
    public boolean hasPickupReserve(){
        if(find(stack->stack.is(Items.ANCIENT_DEBRIS)&&stack.getCount()<stack.getMaxStackSize())>=0)return true;
        int empty=0;for(int i=0;i<36;i++)if(mc.player.getInventory().getItem(i).isEmpty())empty++;return empty>=1;
    }
    public static boolean disposable(ItemStack stack){
        var lore=stack.get(DataComponents.LORE);
        if(stack.isEmpty()||stack.has(DataComponents.CUSTOM_NAME)||stack.has(DataComponents.CUSTOM_DATA)||lore!=null&&!lore.lines().isEmpty()||!stack.getEnchantments().isEmpty())return false;
        return stack.is(Items.NETHERRACK)||stack.is(Items.BASALT)||stack.is(Items.BLACKSTONE)||stack.is(Items.GRAVEL)||stack.is(Items.SOUL_SAND)||stack.is(Items.SOUL_SOIL);
    }
    public static boolean buildingBlock(ItemStack stack){if(stack.isEmpty()||stack.has(DataComponents.CUSTOM_NAME)||stack.has(DataComponents.CUSTOM_DATA)||!stack.getEnchantments().isEmpty())return false;
        var lore=stack.get(DataComponents.LORE);if(lore!=null&&!lore.lines().isEmpty())return false;
        return stack.is(Items.NETHERRACK)||stack.is(Items.BASALT)||stack.is(Items.BLACKSTONE)||stack.is(Items.COBBLESTONE)||stack.is(Items.COBBLED_DEEPSLATE)||stack.is(Items.STONE)||stack.is(Items.DEEPSLATE)||stack.is(Items.DIRT)||stack.is(Items.END_STONE);}
    public boolean discardOne(long tick){int slot=-1,count=-1;for(int i=0;i<36;i++){var stack=mc.player.getInventory().getItem(i);if(i!=hotbarBuildingSlot()&&disposable(stack)&&stack.getCount()>count){slot=i;count=stack.getCount();}}return slot>=0&&click(menuSlot(slot),1,ClickType.THROW,tick);}
    public boolean depositOne(long tick){
        var menu=mc.player.containerMenu;
        for(int i=0;i<menu.slots.size();i++){var slot=menu.slots.get(i);if(slot.container==mc.player.getInventory()&&slot.getItem().is(Items.ANCIENT_DEBRIS))return click(i,0,ClickType.QUICK_MOVE,tick);}
        return false;
    }
    public boolean chestHasSpace(){
        for(var slot:mc.player.containerMenu.slots)if(slot.container!=mc.player.getInventory()&&(slot.getItem().isEmpty()||slot.getItem().is(Items.ANCIENT_DEBRIS)&&slot.getItem().getCount()<slot.getMaxStackSize(slot.getItem())))return true;
        return false;
    }
}
