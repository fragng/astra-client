package client.netheritefinder;

/** Critically damped camera movement. Rates stay bounded across angle wraparound. */
public final class SmoothLook {
    private final Axis yaw,pitch;
    public SmoothLook(){this(.14f,240,.14f,180);}
    public SmoothLook(float yawTime,float yawRate,float pitchTime,float pitchRate){yaw=new Axis(yawTime,yawRate);pitch=new Axis(pitchTime,pitchRate);}
    public void reset(){yaw.velocity=pitch.velocity=0;}
    public float yaw(float current,float target){return yaw.step(current,current+wrap(target-current));}
    public float pitch(float current,float target){return pitch.step(current,Math.clamp(target,-89.5f,89.5f));}
    public static float wrap(float value){value%=360;if(value>=180)value-=360;if(value< -180)value+=360;return value;}
    private static final class Axis {
        private final float time,maxSpeed;private float velocity;
        private Axis(float time,float maxSpeed){this.time=time;this.maxSpeed=maxSpeed;}
        private float step(float current,float target){
            float original=target,omega=2/time,x=omega*.05f,decay=1/(1+x+.48f*x*x+.235f*x*x*x);
            float change=Math.clamp(current-target,-maxSpeed*time,maxSpeed*time);target=current-change;
            float temporary=(velocity+omega*change)*.05f;velocity=(velocity-omega*temporary)*decay;
            float output=target+(change+temporary)*decay;
            if((original-current>0)==(output>original)){output=original;velocity=0;}
            return output;
        }
    }
}
