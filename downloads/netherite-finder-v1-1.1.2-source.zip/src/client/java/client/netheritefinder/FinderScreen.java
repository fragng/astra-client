package client.netheritefinder;

import net.minecraft.client.gui.GuiGraphics;
import net.minecraft.client.gui.components.Button;
import net.minecraft.client.gui.screens.Screen;
import net.minecraft.client.input.MouseButtonEvent;
import net.minecraft.network.chat.Component;
import net.minecraft.util.FormattedCharSequence;
import java.util.*;

public final class FinderScreen extends Screen {
    private static final int W=600,H=410;
    private final MiningEngine engine;private int tab;private boolean instructions;private int scroll;
    private float scale,ox,oy;
    private final List<FormattedCharSequence> lines=new ArrayList<>();
    private static final String[] HELP={
        "You must have XP bottles in your inventory and a good diamond or netherite pickaxe. Mending is required for automatic repair.",
        "Carry spare Totems of Undying, an ender chest, and plain netherrack, basalt or blackstone for lava plugs and bridges (hotbar is preferred; inventory blocks can be brought into the hotbar). One hotbar building stack is protected from cleanup.",
        "Press F6, choose MINER or AUTO BASE FINDER, switch ON, then close the menu. Modes are mutually exclusive. Any menu pauses travel; OFF releases the controls.",
        "The miner heads directly toward loaded ancient debris, mines with normal tool speed, walks to each drop and confirms pickup. Fast approach is ON by default. It uses normal sprinting and sprint-jumps only where a full flat landing corridor and headroom are loaded and clear. It lands before mining, and can walk closer while a valid native crosshair mines a block. Tight tunnels, obstacles, lava and nearby targets disable jumping. Toggle Fast approach OFF for the earlier movement style. Tool mining speed is unchanged.",
        "Lava does not disable the miner. It tries actual hotbar-block placements, then short safe walking or digging detours. Rejected placements are never treated as solid ground. If it falls into lava it tries to swim to a loaded safe shore; this cannot guarantee survival.",
        "Debris fills all available or expendable inventory slots, then is transferred to a real ender chest. It continues filling the player inventory if the ender chest is full, and stops when both are full. Tools, supplies, customised items and the reserved building stack are protected. Empty your chest and click Recheck storage to clear the remembered full state.",
        "Silk Touch lets the miner recover its own placed ender chest. Without Silk Touch it leaves the chest in place. Missing supplies or denied server interactions pause the current task.",
        "At 70% durability, the Mending pickaxe is moved INTO THE OFFHAND. XP bottles are thrown from the MAIN HAND, with the pickaxe remaining equipped while XP lands. Repair ends near 92% durability. The previous offhand item is then restored with normal inventory swaps, including after OFF or opening a menu. The offhand totem is temporarily displaced during repair. A network disconnect can prevent the final swap; check your inventory after reconnecting.",
        "Auto totem uses a spare when the offhand totem is consumed while ON, including with this menu open. No spare after a pop stops automation. Repairs own the offhand until restoration completes.",
        "ESP/CHEATS: toggle red debris highlights independently. F4 toggles freecam; WASD, Space and left Shift move its camera while your body stays in place when automation is OFF. When automation is ON the bot may continue moving the body. Z toggles collision-free orbit freelook; mouse moves the camera without turning your body. Turn both camera features off in this category if desired. Scroll changes freecam speed from 0.25x to 4x and does not scroll your hotbar. Cameras temporarily request a larger render distance (20 chunks by default, adjustable to 32) and restore your previous distance on exit. Servers still control the chunks sent around your actual player; cameras cannot force remote chunks to load. Both cameras are render-only and reveal only loaded world data.",
        "AUTO BASE FINDER scans loaded underground storage clusters. It opens reachable containers to check actual contents, stops at a potential base containing items, and changes direction after checking an empty cluster. Inaccessible storage is unknown, not proof of a raid. It never transfers or steals contents.",
        "Base targets within 30 blocks of a LOADED trial spawner or vault are excluded. A client cannot detect a chamber or base that the server has not sent. Container clusters can be natural structures; clues are not a guaranteed player base. Minimum storage count and search depth are configurable.",
        "Another loaded non-spectator player within 128 horizontal blocks (8 chunks) triggers logout. Reconnecting never restarts automation or cameras. Server reach, permissions and tool mining speed still apply. Monitor the bot; no anti-cheat bypass or guarantee is included."
    };
    public FinderScreen(MiningEngine engine){super(Component.literal("Netherite Finder"));this.engine=engine;}
    private void fit(){scale=Math.max(.1f,Math.min(1.15f,Math.min((width-20f)/W,(height-20f)/H)));ox=(width-W*scale)/2;oy=(height-H*scale)/2;}
    private void button(int x,int y,int w,String title,Runnable action){addRenderableWidget(new Control(x,y,w,title,action));}
    private void refresh(){rebuildWidgets();}
    @Override protected void init(){
        fit();lines.clear();for(var text:HELP){lines.addAll(font.split(Component.literal(text),382));lines.add(FormattedCharSequence.EMPTY);}
        String[] names={"MINER","ESP/CHEATS","AUTO BASE FINDER"};for(int i=0;i<3;i++){final int n=i;button(16,88+i*42,144,(tab==i?"> ":"")+names[i],()->{tab=n;instructions=false;scroll=0;refresh();});}
        button(16,300,144,"Instructions",()->{instructions=!instructions;scroll=0;refresh();});button(16,350,144,"Close / F6",this::onClose);
        if(instructions)return;
        if(tab==0){
            button(184,106,392,(engine.enabled()&&engine.mode()==MiningEngine.Mode.NETHERITE?"ON — turn miner OFF":"OFF — turn miner ON"),()->{engine.enableMode(MiningEngine.Mode.NETHERITE);refresh();});
            button(184,280,392,"Recheck ender-chest capacity",()->{engine.recheckStorage();refresh();});
            button(184,322,392,"Fast approach: "+(FinderSettings.fastApproach?"ON":"OFF"),()->{FinderSettings.fastApproach=!FinderSettings.fastApproach;FinderSettings.save();refresh();});
        }else if(tab==1){
            button(184,106,392,"Ancient debris ESP: "+(FinderSettings.esp?"ON":"OFF"),()->{FinderSettings.esp=!FinderSettings.esp;FinderSettings.save();refresh();});
            button(184,148,190,"F4 freecam: "+(FinderSettings.freecamAllowed?"enabled":"disabled"),()->{FinderSettings.freecamAllowed=!FinderSettings.freecamAllowed;if(ViewModes.freecam())ViewModes.reset();FinderSettings.save();refresh();});
            button(386,148,190,ViewModes.freecam()?"Exit freecam":"Enter freecam",()->{if(FinderSettings.freecamAllowed)ViewModes.toggleFreecam();refresh();});
            button(184,190,190,"Z freelook: "+(FinderSettings.freelookAllowed?"enabled":"disabled"),()->{FinderSettings.freelookAllowed=!FinderSettings.freelookAllowed;if(ViewModes.freelook())ViewModes.reset();FinderSettings.save();refresh();});
            button(386,190,190,ViewModes.freelook()?"Exit freelook":"Enter freelook",()->{if(FinderSettings.freelookAllowed)ViewModes.toggleFreelook();refresh();});
            button(184,244,392,"Freecam speed: "+String.format(java.util.Locale.ROOT,"%.2fx",FinderSettings.cameraMultiplier),()->{FinderSettings.cameraMultiplier=FinderSettings.cameraMultiplier>=4?.25:FinderSettings.cameraMultiplier+.25;FinderSettings.save();refresh();});
            button(184,282,392,"Freelook distance: "+(int)FinderSettings.lookDistance+" blocks",()->{FinderSettings.lookDistance=FinderSettings.lookDistance>=8?2:FinderSettings.lookDistance+2;FinderSettings.save();refresh();});
            button(184,320,392,"Camera view distance: "+FinderSettings.cameraChunks+" chunks",()->{FinderSettings.cameraChunks=FinderSettings.cameraChunks>=32?12:FinderSettings.cameraChunks+4;ViewModes.updateDistance();FinderSettings.save();refresh();});
        }else{
            button(184,106,392,(engine.enabled()&&engine.mode()==MiningEngine.Mode.BASE?"ON — turn base finder OFF":"OFF — turn base finder ON"),()->{engine.enableMode(MiningEngine.Mode.BASE);refresh();});
            button(184,162,392,"Minimum storage blocks: "+FinderSettings.baseContainers,()->{FinderSettings.baseContainers=FinderSettings.baseContainers>=6?1:FinderSettings.baseContainers+1;FinderSettings.save();engine.bases.routeBlocked();refresh();});
            button(184,204,392,"Exploration depth: Y "+FinderSettings.baseDepth,()->{FinderSettings.baseDepth=FinderSettings.baseDepth>=48?-32:FinderSettings.baseDepth+8;FinderSettings.save();engine.resetRoute();refresh();});
            button(184,246,392,"Rescan / forget excluded bases",()->{engine.bases.reset();engine.resetRoute();refresh();});
        }
    }
    @Override public void renderBackground(GuiGraphics g,int x,int y,float d){}
    @Override public void render(GuiGraphics g,int mx,int my,float delta){
        fit();g.fill(0,0,width,height,0xA0060811);g.pose().pushMatrix();g.pose().translate(ox,oy);g.pose().scale(scale,scale);
        FinderUi.round(g,0,0,W,H,18,0xFF642F43);FinderUi.round(g,1,1,W-2,H-2,17,0xFF111420);
        g.drawString(font,"NETHERITE FINDER",20,22,0xFFFF7384,false);g.drawString(font,"1.1.2   /   F6 controls",20,43,0xFFAAAEBF,false);g.fill(16,67,W-16,68,0xFF313443);g.fill(172,83,173,H-22,0xFF313443);
        g.drawString(font,instructions?"Instructions":tab==0?"Ancient debris":tab==1?"ESP / camera controls":"AUTO BASE FINDER",184,84,0xFFF2F3FA,false);
        if(instructions){g.enableScissor(184,104,580,380);for(int i=0;i<lines.size();i++)g.drawString(font,lines.get(i),188,106+i*11-scroll,0xFFE2E4ED,false);g.disableScissor();}
        else if(tab==0){
            FinderUi.round(g,184,154,392,108,12,0xFF1B2030);g.drawWordWrap(font,Component.literal(engine.status()),196,166,366,0xFFF1F2F6);
            g.drawString(font,"Loaded debris: "+engine.scanner.positions().size()+"   Stored: "+engine.stored,196,214,0xFFB2B7CA,false);
            g.drawString(font,"Lava plugs: "+engine.plugs.placed+"   Ender full: "+(engine.enderFull?"yes":"no"),196,238,0xFFB2B7CA,false);
            note(g,"Fast approach uses normal sprint-jumps only on long, flat, clear paths. Tool and server mining limits still apply.",365);
        }else if(tab==1)note(g,"Scroll: 0.25x–4x speed. More chunks use more memory. View distance resets on exit; server chunk limits still apply.",365);
        else{note(g,"Loaded underground containers are clues. Empty storage is checked in game. Targets near loaded trial chambers are excluded.",302);g.drawString(font,"Storage clues: "+engine.bases.clues()+"   Empty clusters: "+engine.bases.raidedClusters,184,364,0xFFB2B7CA,false);g.drawString(font,"Trial-chamber exclusions: "+engine.bases.trialClusters,184,379,0xFFB2B7CA,false);}
        for(var child:children())if(child instanceof net.minecraft.client.gui.components.Renderable v)v.render(g,(int)((mx-ox)/scale),(int)((my-oy)/scale),delta);g.pose().popMatrix();
    }
    private void note(GuiGraphics g,String text,int y){g.drawWordWrap(font,Component.literal(text),184,y,390,0xFF9CA8BE);}
    @Override public boolean mouseClicked(MouseButtonEvent e,boolean doubled){return super.mouseClicked(new MouseButtonEvent((e.x()-ox)/scale,(e.y()-oy)/scale,e.buttonInfo()),doubled);}
    @Override public boolean mouseReleased(MouseButtonEvent e){return super.mouseReleased(new MouseButtonEvent((e.x()-ox)/scale,(e.y()-oy)/scale,e.buttonInfo()));}
    @Override public boolean mouseScrolled(double x,double y,double dx,double dy){if(instructions){scroll=Math.clamp(scroll-(int)(dy*25),0,Math.max(0,lines.size()*11-265));return true;}return super.mouseScrolled(x,y,dx,dy);}
    @Override public boolean isPauseScreen(){return false;}
    @Override public void onClose(){FinderSettings.save();minecraft.setScreen(null);}
    private static class Control extends Button {
        Control(int x,int y,int w,String title,Runnable action){super(x,y,w,32,Component.literal(title),b->action.run(),DEFAULT_NARRATION);}
        @Override protected void renderContents(GuiGraphics g,int mx,int my,float dt){FinderUi.round(g,getX(),getY(),width,height,9,isHoveredOrFocused()?0xFFB44059:0xFF642F43);var f=net.minecraft.client.Minecraft.getInstance().font;g.drawCenteredString(f,getMessage(),getX()+width/2,getY()+12,0xFFFFFFFF);}
    }
}
