package client.netheritefinder;

import net.minecraft.world.phys.Vec3;

public final class FreecamMotion {
    private FreecamMotion(){}
    public static Vec3 direction(float yaw,double forward,double right,double up){
        double a=Math.toRadians(yaw);
        var v=new Vec3(-Math.sin(a)*forward-Math.cos(a)*right,up,Math.cos(a)*forward-Math.sin(a)*right);
        return v.lengthSqr()>1?v.normalize():v;
    }
    public static double scrollSpeed(double current,double amount){return Math.round(Math.clamp(current+amount*.25,.25,4)*100)/100d;}
}
