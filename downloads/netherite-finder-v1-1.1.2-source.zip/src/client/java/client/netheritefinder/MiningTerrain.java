package client.netheritefinder;

import net.minecraft.client.Minecraft;
import net.minecraft.core.*;
import net.minecraft.tags.FluidTags;
import net.minecraft.world.level.block.Blocks;
import net.minecraft.world.phys.shapes.CollisionContext;

/** Every route and every actual mining action is checked against current world data. */
public final class MiningTerrain implements RouteSearch.Terrain {
    private final Minecraft mc=Minecraft.getInstance();
    public static BlockPos pos(RouteSearch.Cell cell){return new BlockPos(cell.x(),cell.y(),cell.z());}
    public static RouteSearch.Cell cell(BlockPos pos){return new RouteSearch.Cell(pos.getX(),pos.getY(),pos.getZ());}
    public boolean loaded(BlockPos p){return mc.level!=null&&p.getY()>=mc.level.getMinY()&&p.getY()<mc.level.getMaxY()&&mc.level.hasChunkAt(p);}
    public boolean danger(BlockPos p){
        if(!loaded(p))return true;
        for(var d:Direction.values())if(!loaded(p.relative(d))||mc.level.getFluidState(p.relative(d)).is(FluidTags.LAVA))return true;
        var state=mc.level.getBlockState(p);
        return !state.getFluidState().isEmpty()||state.is(Blocks.FIRE)||state.is(Blocks.SOUL_FIRE)||state.is(Blocks.MAGMA_BLOCK)||state.is(Blocks.CAMPFIRE)||state.is(Blocks.SOUL_CAMPFIRE);
    }
    public boolean solidFloor(BlockPos p){return loaded(p)&&!danger(p)&&mc.level.getBlockState(p).isCollisionShapeFullBlock(mc.level,p);}
    public boolean clear(BlockPos p){return loaded(p)&&mc.level.getBlockState(p).getCollisionShape(mc.level,p).isEmpty();}
    public boolean safeBreak(BlockPos p){
        if(!loaded(p)||danger(p)||mc.level.getBlockState(p).hasBlockEntity())return false;
        var feet=mc.player.blockPosition();if(p.equals(feet.below()))return false;
        var state=mc.level.getBlockState(p);return state.getDestroySpeed(mc.level,p)>=0&&!state.is(Blocks.BEDROCK)&&!state.is(Blocks.OBSIDIAN)&&!state.is(Blocks.CRYING_OBSIDIAN);
    }
    public boolean safeBreakDirect(BlockPos p){
        if(!loaded(p)||!mc.level.getFluidState(p).isEmpty()||mc.level.getBlockState(p).hasBlockEntity()||p.equals(mc.player.blockPosition().below()))return false;
        var state=mc.level.getBlockState(p);return state.getDestroySpeed(mc.level,p)>=0&&!state.is(Blocks.BEDROCK)&&!state.is(Blocks.OBSIDIAN)&&!state.is(Blocks.CRYING_OBSIDIAN);
    }
    public boolean solidFloorDirect(BlockPos p){return loaded(p)&&mc.level.getFluidState(p).isEmpty()&&!mc.level.getBlockState(p).is(Blocks.MAGMA_BLOCK)&&mc.level.getBlockState(p).isCollisionShapeFullBlock(mc.level,p);}
    public boolean walkableDirect(BlockPos feet){return loaded(feet)&&mc.level.getFluidState(feet).isEmpty()&&mc.level.getFluidState(feet.above()).isEmpty()&&solidFloorDirect(feet.below())&&clear(feet)&&clear(feet.above());}
    /** Actual player-sized collision and support, rather than requiring every corner to have a full cube below. */
    public boolean bodyClearAt(net.minecraft.world.phys.Vec3 p){
        double half=mc.player.getBbWidth()/2-.015;
        var body=new net.minecraft.world.phys.AABB(p.x-half,p.y+.035,p.z-half,p.x+half,p.y+mc.player.getBbHeight()-.025,p.z+half);
        for(var cell:BlockPos.betweenClosed(BlockPos.containing(body.minX,body.minY,body.minZ),BlockPos.containing(body.maxX,body.maxY,body.maxZ))){
            if(!loaded(cell)||!mc.level.getFluidState(cell).isEmpty())return false;
            var state=mc.level.getBlockState(cell);if(state.is(Blocks.FIRE)||state.is(Blocks.SOUL_FIRE))return false;
        }
        if(!mc.level.noBlockCollision(mc.player,body))return false;
        var support=new net.minecraft.world.phys.AABB(body.minX,p.y-1.05,body.minZ,body.maxX,p.y+.015,body.maxZ);
        return !mc.level.noBlockCollision(mc.player,support);
    }
    /** Full flat landing corridor and headroom for one normal sprint-jump. */
    public boolean jumpLane(net.minecraft.world.phys.Vec3 start,net.minecraft.world.phys.Vec3 direction){
        double half=mc.player.getBbWidth()/2+.02;
        for(double distance=.25;distance<=5.01;distance+=.25){
            var at=start.add(direction.scale(distance));
            var body=new net.minecraft.world.phys.AABB(at.x-half,start.y+.03,at.z-half,at.x+half,start.y+3.15,at.z+half);
            for(var p:BlockPos.betweenClosed(BlockPos.containing(body.minX,body.minY,body.minZ),BlockPos.containing(body.maxX,body.maxY,body.maxZ)))if(!loaded(p)||!mc.level.getFluidState(p).isEmpty())return false;
            if(!mc.level.noBlockCollision(mc.player,body))return false;
            for(double x:new double[]{-half,half})for(double z:new double[]{-half,half}){
                var feet=BlockPos.containing(at.x+x,start.y+.01,at.z+z);
                if(!solidFloorDirect(feet.below())||danger(feet)||danger(feet.above()))return false;
            }
        }
        return true;
    }
    public boolean cellSafe(BlockPos feet){return loaded(feet)&&!danger(feet)&&!danger(feet.above())&&solidFloor(feet.below())&&(clear(feet)||safeBreak(feet))&&(clear(feet.above())||safeBreak(feet.above()));}
    public boolean walkable(BlockPos feet){return cellSafe(feet)&&clear(feet)&&clear(feet.above());}
    private double breakCost(BlockPos p){if(clear(p))return 0;var state=mc.level.getBlockState(p);return state.is(Blocks.NETHERRACK)?1.1:Math.min(18,2+state.getDestroySpeed(mc.level,p)*2);}
    public double cost(RouteSearch.Cell from,RouteSearch.Cell to){
        var dest=pos(to);if(!cellSafe(dest))return Double.POSITIVE_INFINITY;
        // A stair requires space above the old cell as well as the destination.
        if(to.y()>from.y()&&(!loaded(pos(from).above(2))||danger(pos(from).above(2))||!clear(pos(from).above(2))&&!safeBreak(pos(from).above(2))))return Double.POSITIVE_INFINITY;
        return 1+breakCost(dest)+breakCost(dest.above())+(to.y()!=from.y()?1.5:0);
    }
}
