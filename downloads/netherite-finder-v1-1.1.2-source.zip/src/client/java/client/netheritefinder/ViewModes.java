package client.netheritefinder;

import com.mojang.blaze3d.platform.InputConstants;
import net.minecraft.client.Minecraft;
import net.minecraft.world.phys.Vec3;
import org.lwjgl.glfw.GLFW;

/** Render-only cameras; the camera never becomes the player's network position. */
public final class ViewModes {
    private static boolean freecam,freelook;
    private static Vec3 position=Vec3.ZERO,previous=Vec3.ZERO,velocity=Vec3.ZERO;
    private static float yaw,pitch;
    private static int previousDistance=-1,boostedDistance;
    public static boolean freecam(){return freecam;}
    public static boolean freelook(){return freelook;}
    public static boolean active(){return freecam||freelook;}
    public static void reset(){
        freecam=freelook=false;velocity=Vec3.ZERO;var mc=Minecraft.getInstance();
        if(previousDistance>=0&&mc.options.renderDistance().get()==boostedDistance){mc.options.renderDistance().set(previousDistance);if(mc.getConnection()!=null)mc.options.broadcastOptions();mc.options.save();}previousDistance=-1;
    }
    public static void updateDistance(){
        if(!active())return;var mc=Minecraft.getInstance();if(previousDistance<0)previousDistance=mc.options.renderDistance().get();
        boostedDistance=Math.max(previousDistance,FinderSettings.cameraChunks);mc.options.renderDistance().set(boostedDistance);if(mc.getConnection()!=null)mc.options.broadcastOptions();
    }
    private static void start(){var mc=Minecraft.getInstance();if(mc.player==null)return;position=previous=mc.player.getEyePosition();yaw=mc.player.getYRot();pitch=mc.player.getXRot();velocity=Vec3.ZERO;}
    public static void toggleFreecam(){var mc=Minecraft.getInstance();if(mc.player==null)return;if(freecam){reset();return;}freecam=freelook=false;start();freecam=true;updateDistance();}
    public static void toggleFreelook(){var mc=Minecraft.getInstance();if(mc.player==null)return;if(freelook){reset();return;}freecam=freelook=false;start();freelook=true;updateDistance();}
    public static void turn(double dx,double dy){yaw+=(float)(dx*.15);pitch=Math.clamp(pitch+(float)(dy*.15),-89.5f,89.5f);}
    public static float yaw(){return yaw;}
    public static float pitch(){return pitch;}
    private static boolean key(int code){return InputConstants.isKeyDown(Minecraft.getInstance().getWindow(),code);}
    public static void tick(){
        var mc=Minecraft.getInstance();if(mc.player==null){reset();return;}previous=position;
        if(!freecam||mc.screen!=null){velocity=Vec3.ZERO;return;}
        double forward=(key(GLFW.GLFW_KEY_W)?1:0)-(key(GLFW.GLFW_KEY_S)?1:0),side=(key(GLFW.GLFW_KEY_D)?1:0)-(key(GLFW.GLFW_KEY_A)?1:0),up=(key(GLFW.GLFW_KEY_SPACE)?1:0)-(key(GLFW.GLFW_KEY_LEFT_SHIFT)?1:0);
        var desired=FreecamMotion.direction(yaw,forward,side,up).scale(FinderSettings.cameraSpeed*FinderSettings.cameraMultiplier);
        velocity=velocity.scale(.55).add(desired.scale(.45));position=position.add(velocity);
        var offset=position.subtract(mc.player.getEyePosition());if(offset.lengthSqr()>96*96){position=mc.player.getEyePosition().add(offset.normalize().scale(96));velocity=Vec3.ZERO;}
    }
    public static boolean scroll(double amount){
        var mc=Minecraft.getInstance();if(!freecam||mc.player==null||mc.screen!=null||amount==0)return false;
        FinderSettings.cameraMultiplier=FreecamMotion.scrollSpeed(FinderSettings.cameraMultiplier,amount);FinderSettings.save();
        mc.player.displayClientMessage(net.minecraft.network.chat.Component.literal(String.format(java.util.Locale.ROOT,"Freecam speed: %.2fx",FinderSettings.cameraMultiplier)),true);return true;
    }
    public static Vec3 camera(float delta){var mc=Minecraft.getInstance();if(freecam)return previous.lerp(position,delta);return mc.player.getEyePosition(delta).subtract(Vec3.directionFromRotation(pitch,yaw).scale(FinderSettings.lookDistance));}
}
