package client.crystal;

import net.minecraft.client.gui.GuiGraphics;
import net.minecraft.client.gui.screens.Screen;
import net.minecraft.network.chat.Component;
import net.minecraft.client.input.MouseButtonEvent;
import net.minecraft.client.gui.screens.worldselection.SelectWorldScreen;
import net.minecraft.client.gui.screens.multiplayer.JoinMultiplayerScreen;
import net.minecraft.client.gui.screens.multiplayer.SafetyScreen;
import net.minecraft.client.gui.screens.options.OptionsScreen;

public final class CrystalHomeScreen extends Screen {
    static final int W=760,H=470;
    private final String greeting=Greetings.now(),welcome=Greetings.next();
    private float scale,ox,oy;
    public CrystalHomeScreen(){super(Component.literal("Crystal Client"));}
    private void fit(){scale=Math.max(.1f,Math.min(1.25f,Math.min((width-24f)/W,(height-20f)/H)));ox=(width-W*scale)/2;oy=(height-H*scale)/2;}
    @Override protected void init(){fit();
        addRenderableWidget(new CrystalButton(42,241,290,43,"Singleplayer",true,()->minecraft.setScreen(new SelectWorldScreen(this))));
        var multiplayer=new CrystalButton(42,294,290,43,"Multiplayer",false,()->minecraft.setScreen(minecraft.options.skipMultiplayerWarning?new JoinMultiplayerScreen(this):new SafetyScreen(this)));multiplayer.active=minecraft.allowsMultiplayer();addRenderableWidget(multiplayer);
        addRenderableWidget(new CrystalButton(42,347,140,37,"Settings",false,()->minecraft.setScreen(new OptionsScreen(this,minecraft.options))));
        addRenderableWidget(new CrystalButton(192,347,140,37,"Quit",false,()->minecraft.stop()));
        addRenderableWidget(new CrystalButton(423,330,260,39,"Performance settings",false,()->minecraft.setScreen(new CrystalSettingsScreen(this))));
    }
    @Override public void renderBackground(GuiGraphics g,int x,int y,float d){}
    @Override public void render(GuiGraphics g,int mouseX,int mouseY,float delta){fit();g.fill(0,0,width,height,CrystalUi.BACKGROUND);g.pose().pushMatrix();g.pose().translate(ox,oy);g.pose().scale(scale,scale);
        CrystalUi.label(g,font,"PRIVATE / JACK",42,29,.8f,CrystalUi.MUTED);
        CrystalUi.round(g,540,14,42,42,11,0xFFE2D7F1);CrystalUi.logo(g,541,15,40);CrystalUi.label(g,font,"Crystal Client",594,28,1.2f,CrystalUi.INK);
        g.fill(42,76,718,77,0xFFE4E1E9);
        CrystalUi.label(g,font,greeting,42,115,1.9f,CrystalUi.INK);CrystalUi.label(g,font,"Jack.",42,148,2.65f,CrystalUi.PURPLE);CrystalUi.label(g,font,welcome,43,201,.9f,CrystalUi.MUTED);
        CrystalUi.round(g,390,102,328,289,18,0xFFEAE7EF);CrystalUi.round(g,391,103,326,287,17,0xFFFFFFFF);
        CrystalUi.label(g,font,"PERFORMANCE",423,127,.75f,CrystalUi.MUTED);CrystalUi.label(g,font,"A lighter way to play.",423,151,1.25f,CrystalUi.INK);
        CrystalUi.round(g,423,184,260,34,8,0xFFF3EEF8);CrystalUi.label(g,font,"Preset: "+CrystalSettingsScreen.name(CrystalPerformance.preset()),437,194,.92f,CrystalUi.PURPLE);
        int y=237;for(var mod:CrystalClient.optimizations()){
            CrystalUi.round(g,423,y+2,6,6,3,mod.loaded()?0xFF39A781:0xFFC99B4B);CrystalUi.label(g,font,mod.name(),438,y,.85f,CrystalUi.INK);CrystalUi.label(g,font,mod.loaded()?"Active":"Not installed",607,y,.75f,mod.loaded()?0xFF598873:CrystalUi.MUTED);y+=21;
        }
        g.fill(42,420,718,421,0xFFE4E1E9);CrystalUi.round(g,42,434,21,21,6,0xFFE2D7F1);CrystalUi.logo(g,42,434,21);CrystalUi.label(g,font,"Crystal Client",72,440,.85f,CrystalUi.INK);CrystalUi.label(g,font,"1.21.11  /  FABRIC  /  PERSONAL",486,441,.7f,CrystalUi.MUTED);
        for(var child:children())if(child instanceof net.minecraft.client.gui.components.Renderable r)r.render(g,(int)((mouseX-ox)/scale),(int)((mouseY-oy)/scale),delta);
        g.pose().popMatrix();
    }
    @Override public boolean mouseClicked(MouseButtonEvent e,boolean doubled){return super.mouseClicked(new MouseButtonEvent((e.x()-ox)/scale,(e.y()-oy)/scale,e.buttonInfo()),doubled);}
    @Override public boolean mouseReleased(MouseButtonEvent e){return super.mouseReleased(new MouseButtonEvent((e.x()-ox)/scale,(e.y()-oy)/scale,e.buttonInfo()));}
    @Override public boolean shouldCloseOnEsc(){return false;}
}
