package client.crystal;

import java.time.LocalTime;
import java.util.List;

public final class Greetings {
    private Greetings(){}
    public static String timeGreeting(int hour){return hour>=5&&hour<12?"Good morning,":hour>=12&&hour<18?"Good afternoon,":hour>=18&&hour<23?"Good evening,":"Welcome back,";}
    public static String now(){return timeGreeting(LocalTime.now().getHour());}
    public static final List<String> WELCOMES=List.of(
        "Welcome back, Jack.","Ready when you are, Jack.","A fresh start, Jack.","Make yourself at home, Jack.",
        "Good to see you, Jack.","Your world is waiting, Jack.","Keep it simple, Jack.","A little smoother, Jack.",
        "Take it easy, Jack.","Pick up where you left off, Jack.","A clean slate, Jack.","Hello again, Jack.",
        "Settle in, Jack.","Make this one yours, Jack.","One world at a time, Jack.","Find your rhythm, Jack.",
        "Welcome to your space, Jack.","A brighter start, Jack.","Your next chapter, Jack.","Enjoy the view, Jack.",
        "Less clutter, more room, Jack.","Made for your pace, Jack.","Good things start small, Jack.","Fresh air, fresh world, Jack.",
        "It's your adventure, Jack.","A moment to reset, Jack.","Keep it comfortable, Jack.","Let's make it a good one, Jack."
    );
    private static int visit=(int)(System.currentTimeMillis()%WELCOMES.size());
    public static String next(){return WELCOMES.get(Math.floorMod(visit++,WELCOMES.size()));}
}
