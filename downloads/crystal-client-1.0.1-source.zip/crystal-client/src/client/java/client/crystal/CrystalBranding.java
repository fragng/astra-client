package client.crystal;

import com.mojang.blaze3d.platform.NativeImage;
import org.lwjgl.glfw.GLFW;
import org.lwjgl.glfw.GLFWImage;
import org.lwjgl.system.MemoryStack;
import org.lwjgl.system.MemoryUtil;
import org.slf4j.LoggerFactory;
import java.io.IOException;
import java.nio.ByteBuffer;
import java.util.ArrayList;
import java.util.List;

/** Native application branding, applied once during window creation, not each frame. */
public final class CrystalBranding {
    private static final String LOGO="/assets/crystal-client/textures/logo.png";
    private static final int[] ICON_SIZES={16,32,48,64,128,256};
    private CrystalBranding(){}

    /** GLFW copies the pixels; all temporary image/native buffers are then released. */
    public static boolean applyIcon(long window){
        int platform=GLFW.glfwGetPlatform();
        if(platform!=GLFW.GLFW_PLATFORM_WIN32 && platform!=GLFW.GLFW_PLATFORM_X11)return false;
        List<ByteBuffer> pixels=new ArrayList<>(ICON_SIZES.length);
        try(var input=CrystalBranding.class.getResourceAsStream(LOGO)) {
            if(input==null)throw new IOException("Missing bundled Crystal logo");
            try(var source=NativeImage.read(input);var stack=MemoryStack.stackPush()){
                var icons=GLFWImage.malloc(ICON_SIZES.length,stack);
                for(int i=0;i<ICON_SIZES.length;i++){
                    int size=ICON_SIZES[i];
                    try(var image=new NativeImage(size,size,false)){
                        source.resizeSubRectTo(0,0,source.getWidth(),source.getHeight(),image);
                        var bytes=MemoryUtil.memAlloc(size*size*4);pixels.add(bytes);
                        bytes.asIntBuffer().put(image.getPixelsABGR());
                        icons.position(i).width(size).height(size).pixels(bytes);
                    }
                }
                GLFW.glfwSetWindowIcon(window,icons.position(0));
                return true;
            }
        }catch(IOException | RuntimeException e){
            LoggerFactory.getLogger(CrystalClient.NAME).warn("Could not apply Crystal's window icon; retaining the default icon.",e);
            return false;
        }finally{pixels.forEach(MemoryUtil::memFree);}
    }
}
