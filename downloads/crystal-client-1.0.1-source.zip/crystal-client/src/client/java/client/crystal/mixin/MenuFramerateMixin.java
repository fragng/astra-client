package client.crystal.mixin;

import client.crystal.*;
import com.mojang.blaze3d.platform.FramerateLimitTracker;
import net.minecraft.client.Minecraft;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.*;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfoReturnable;

@Mixin(FramerateLimitTracker.class)
public abstract class MenuFramerateMixin {
    @Inject(method="getFramerateLimit",at=@At("RETURN"),cancellable=true)
    private void crystal$quietMenus(CallbackInfoReturnable<Integer> cir){
        if(!CrystalPerformance.limitMenus)return;var mc=Minecraft.getInstance();
        if(!mc.isWindowActive())cir.setReturnValue(Math.min(30,cir.getReturnValue()));
        else if(mc.screen instanceof CrystalHomeScreen || mc.screen instanceof CrystalSettingsScreen)cir.setReturnValue(Math.min(60,cir.getReturnValue()));
    }
}
