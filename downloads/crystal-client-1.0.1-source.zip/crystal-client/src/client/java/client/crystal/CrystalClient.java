package client.crystal;

import net.fabricmc.api.ClientModInitializer;
import net.fabricmc.loader.api.FabricLoader;
import net.fabricmc.fabric.api.client.event.lifecycle.v1.*;
import net.fabricmc.fabric.api.client.keybinding.v1.KeyBindingHelper;
import net.fabricmc.fabric.api.client.rendering.v1.hud.*;
import net.minecraft.client.Minecraft;
import net.minecraft.client.KeyMapping;
import net.minecraft.resources.Identifier;
import java.util.*;

public final class CrystalClient implements ClientModInitializer {
    public static final String NAME="Crystal Client";
    public record Optimization(String name,boolean loaded,String version){}
    private static List<Optimization> optimizations=List.of();
    public static List<Optimization> optimizations(){return optimizations;}
    private static String fpsLabel="";private static int lastFps=-1;
    public void onInitializeClient(){
        CrystalPerformance.load();var mods=new ArrayList<Optimization>();String[] ids={"sodium","lithium","ferritecore","immediatelyfast"},names={"Sodium","Lithium","FerriteCore","ImmediatelyFast"};
        for(int i=0;i<ids.length;i++){var mod=FabricLoader.getInstance().getModContainer(ids[i]);mods.add(new Optimization(names[i],mod.isPresent(),mod.map(m->m.getMetadata().getVersion().getFriendlyString()).orElse("not installed")));}optimizations=List.copyOf(mods);
        ClientLifecycleEvents.CLIENT_STOPPING.register(mc->CrystalPerformance.save());
        var key=KeyBindingHelper.registerKeyBinding(new KeyMapping("Crystal performance",org.lwjgl.glfw.GLFW.GLFW_KEY_RIGHT_SHIFT,KeyMapping.Category.MISC));
        ClientTickEvents.END_CLIENT_TICK.register(mc->{
            // Renderer mods finish normalising their options during initial resource loading.
            // Back up the usable settings after that work, before applying our first preset.
            if(mc.screen instanceof CrystalHomeScreen && mc.getOverlay()==null)CrystalPerformance.started();
            while(key.consumeClick())if(mc.player!=null&&mc.screen==null)mc.setScreen(new CrystalSettingsScreen(null));
        });
        HudElementRegistry.attachElementBefore(VanillaHudElements.CHAT,Identifier.fromNamespaceAndPath("crystal-client","fps"),(g,dt)->{
            var mc=Minecraft.getInstance();if(!CrystalPerformance.showFps||mc.player==null||mc.screen!=null||mc.getDebugOverlay().showDebugScreen())return;
            int fps=mc.getFps();if(fps!=lastFps){lastFps=fps;fpsLabel="Crystal Client / "+fps+" FPS";}
            int y=g.guiHeight()-18,w=mc.font.width(fpsLabel)+25;g.fill(5,y-3,5+w,y+12,0xEFFFFFFF);CrystalUi.logo(g,8,y-3,15);g.drawString(mc.font,fpsLabel,26,y,CrystalUi.INK,false);
        });
    }
}
