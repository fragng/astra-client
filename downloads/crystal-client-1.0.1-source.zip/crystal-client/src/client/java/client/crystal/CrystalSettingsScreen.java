package client.crystal;

import net.minecraft.client.gui.GuiGraphics;
import net.minecraft.client.gui.screens.Screen;
import net.minecraft.network.chat.Component;
import net.minecraft.client.input.MouseButtonEvent;

public final class CrystalSettingsScreen extends Screen {
    private final Screen parent;private float scale,ox,oy;
    public CrystalSettingsScreen(Screen parent){super(Component.literal("Crystal performance"));this.parent=parent;}
    public static String name(CrystalPerformance.Preset p){return switch(p){case BALANCED->"Balanced";case FAST->"Fast";case MAXIMUM->"Maximum FPS";};}
    private void fit(){scale=Math.max(.1f,Math.min(1.2f,Math.min((width-24f)/660,(height-20f)/470)));ox=(width-660*scale)/2;oy=(height-470*scale)/2;}
    @Override protected void init(){fit();
        int i=0;for(var preset:CrystalPerformance.Preset.values()){var p=preset;addRenderableWidget(new CrystalButton(414,113+i*69,185,37,name(p),false,()->{CrystalPerformance.select(p);rebuildWidgets();}));i++;}
        addRenderableWidget(new CrystalButton(42,328,274,36,"FPS counter: "+(CrystalPerformance.showFps?"On":"Off"),false,()->{CrystalPerformance.showFps=!CrystalPerformance.showFps;CrystalPerformance.save();rebuildWidgets();}));
        addRenderableWidget(new CrystalButton(328,328,274,36,"Quiet menus: "+(CrystalPerformance.limitMenus?"On":"Off"),false,()->{CrystalPerformance.limitMenus=!CrystalPerformance.limitMenus;CrystalPerformance.save();rebuildWidgets();}));
        addRenderableWidget(new CrystalButton(42,403,560,37,"Done",true,this::onClose));
    }
    @Override public void renderBackground(GuiGraphics g,int x,int y,float d){}
    @Override public void render(GuiGraphics g,int mx,int my,float delta){fit();g.fill(0,0,width,height,CrystalUi.BACKGROUND);g.pose().pushMatrix();g.pose().translate(ox,oy);g.pose().scale(scale,scale);
        CrystalUi.label(g,font,"Performance",42,31,1.8f,CrystalUi.INK);CrystalUi.label(g,font,"Choose how much scenery to trade for less rendering work.",43,69,.85f,CrystalUi.MUTED);
        String[] descriptions={"Restores your previous video settings.","Up to 8 chunks, lighter effects, VSync off.","Up to 4 chunks, minimal effects, no FPS cap."};int i=0;
        for(var preset:CrystalPerformance.Preset.values()){
            boolean selected=CrystalPerformance.preset()==preset;int y=105+i*69;CrystalUi.round(g,42,y,560,57,12,selected?0xFFEDE4F7:0xFFFFFFFF);CrystalUi.label(g,font,name(preset)+(selected?" / selected":""),58,y+10,1,selected?CrystalUi.PURPLE:CrystalUi.INK);CrystalUi.label(g,font,descriptions[i],58,y+33,.77f,CrystalUi.MUTED);i++;
        }
        CrystalUi.label(g,font,"FOV, brightness, controls and audio stay yours.",43,378,.8f,CrystalUi.MUTED);
        CrystalUi.label(g,font,"Quiet menus: 60 FPS in these menus / 30 when inactive.",43,391,.7f,CrystalUi.MUTED);
        for(var child:children())if(child instanceof net.minecraft.client.gui.components.Renderable r)r.render(g,(int)((mx-ox)/scale),(int)((my-oy)/scale),delta);
        g.pose().popMatrix();
    }
    @Override public boolean mouseClicked(MouseButtonEvent e,boolean doubled){return super.mouseClicked(new MouseButtonEvent((e.x()-ox)/scale,(e.y()-oy)/scale,e.buttonInfo()),doubled);}
    @Override public boolean mouseReleased(MouseButtonEvent e){return super.mouseReleased(new MouseButtonEvent((e.x()-ox)/scale,(e.y()-oy)/scale,e.buttonInfo()));}
    @Override public void onClose(){minecraft.setScreen(parent);}
}
