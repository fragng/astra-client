package client.crystal.mixin;

import client.crystal.CrystalBranding;
import com.mojang.blaze3d.platform.IconSet;
import com.mojang.blaze3d.platform.Window;
import net.minecraft.server.packs.PackResources;
import org.spongepowered.asm.mixin.Final;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.Shadow;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;

@Mixin(Window.class)
public abstract class WindowIconMixin {
    @Shadow @Final private long handle;
    @Inject(method="setIcon",at=@At("HEAD"),cancellable=true)
    private void crystal$windowIcon(PackResources resources,IconSet icons,CallbackInfo ci){
        if(CrystalBranding.applyIcon(handle))ci.cancel();
    }
}
