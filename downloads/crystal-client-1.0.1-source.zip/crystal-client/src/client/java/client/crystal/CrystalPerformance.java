package client.crystal;

import com.google.gson.*;
import net.fabricmc.loader.api.FabricLoader;
import net.minecraft.client.*;
import net.minecraft.server.level.ParticleStatus;
import java.nio.file.*;
import java.nio.charset.StandardCharsets;

/** Local video preferences only. Restore respects settings deliberately edited during a preset. */
public final class CrystalPerformance {
    public enum Preset {BALANCED,FAST,MAXIMUM}
    public record Video(int render,int simulation,double entities,String clouds,String particles,boolean shadows,int blend,
            boolean occlusion,boolean leaves,boolean transparency,boolean vignette,boolean vsync,int limit,int mipmaps){
        public static Video read(Options o){return new Video(o.renderDistance().get(),o.simulationDistance().get(),o.entityDistanceScaling().get(),o.cloudStatus().get().name(),o.particles().get().name(),o.entityShadows().get(),o.biomeBlendRadius().get(),o.ambientOcclusion().get(),o.cutoutLeaves().get(),o.improvedTransparency().get(),o.vignette().get(),o.enableVsync().get(),o.framerateLimit().get(),o.mipmapLevels().get());}
        public Video fast(boolean maximum){return new Video(Math.min(render,maximum?4:8),Math.min(simulation,5),Math.min(entities,maximum?.5:.75),"OFF",maximum||particles.equals("MINIMAL")?"MINIMAL":"DECREASED",false,0,false,true,false,false,false,maximum?260:limit,maximum?0:Math.min(mipmaps,2));}
        public boolean valid(){try{CloudStatus.valueOf(clouds);ParticleStatus.valueOf(particles);}catch(Exception e){return false;}return render>=2&&render<=1024&&simulation>=2&&simulation<=1024&&Double.isFinite(entities)&&entities>0&&entities<=16&&blend>=0&&blend<=128&&limit>=10&&limit<=1000&&mipmaps>=0&&mipmaps<=4;}
        public void apply(Options o){
            o.renderDistance().set(render);o.simulationDistance().set(simulation);o.entityDistanceScaling().set(entities);o.cloudStatus().set(CloudStatus.valueOf(clouds));o.particles().set(ParticleStatus.valueOf(particles));o.entityShadows().set(shadows);o.biomeBlendRadius().set(blend);o.ambientOcclusion().set(occlusion);o.cutoutLeaves().set(leaves);o.improvedTransparency().set(transparency);o.vignette().set(vignette);o.enableVsync().set(vsync);o.framerateLimit().set(limit);o.mipmapLevels().set(mipmaps);
        }
        public void restoreMatching(Options o,Video applied){
            if(o.renderDistance().get()==applied.render)o.renderDistance().set(render);
            if(o.simulationDistance().get()==applied.simulation)o.simulationDistance().set(simulation);
            if(Double.compare(o.entityDistanceScaling().get(),applied.entities)==0)o.entityDistanceScaling().set(entities);
            if(o.cloudStatus().get().name().equals(applied.clouds))o.cloudStatus().set(CloudStatus.valueOf(clouds));
            if(o.particles().get().name().equals(applied.particles))o.particles().set(ParticleStatus.valueOf(particles));
            if(o.entityShadows().get()==applied.shadows)o.entityShadows().set(shadows);
            if(o.biomeBlendRadius().get()==applied.blend)o.biomeBlendRadius().set(blend);
            if(o.ambientOcclusion().get()==applied.occlusion)o.ambientOcclusion().set(occlusion);
            if(o.cutoutLeaves().get()==applied.leaves)o.cutoutLeaves().set(leaves);
            if(o.improvedTransparency().get()==applied.transparency)o.improvedTransparency().set(transparency);
            if(o.vignette().get()==applied.vignette)o.vignette().set(vignette);
            if(o.enableVsync().get()==applied.vsync)o.enableVsync().set(vsync);
            if(o.framerateLimit().get()==applied.limit)o.framerateLimit().set(limit);
            if(o.mipmapLevels().get()==applied.mipmaps)o.mipmapLevels().set(mipmaps);
        }
    }
    private static final Gson JSON=new GsonBuilder().setPrettyPrinting().create();
    private static final Path FILE=FabricLoader.getInstance().getConfigDir().resolve("crystal-client.json");
    public static boolean showFps=true,limitMenus=true;
    private static Preset preset=Preset.BALANCED;private static Video original,applied;private static boolean first=true;
    private CrystalPerformance(){}
    public static Preset preset(){return preset;}
    public static void load(){
        if(!Files.exists(FILE))return;
        try{
            if(Files.size(FILE)>262144)throw new IllegalArgumentException("Configuration size");
            var j=JsonParser.parseString(Files.readString(FILE,StandardCharsets.UTF_8)).getAsJsonObject();
            showFps=!j.has("showFps")||j.get("showFps").getAsBoolean();limitMenus=!j.has("limitMenus")||j.get("limitMenus").getAsBoolean();
            preset=Preset.valueOf(j.get("preset").getAsString());
            if(preset!=Preset.BALANCED){original=JSON.fromJson(j.get("original"),Video.class);applied=JSON.fromJson(j.get("applied"),Video.class);if(original==null||applied==null||!original.valid()||!applied.valid())throw new IllegalArgumentException("Video backup");}
            first=false;
        }catch(Exception e){first=false;preset=Preset.BALANCED;original=applied=null;org.slf4j.LoggerFactory.getLogger("Crystal Client").warn("Could not read Crystal preferences. Existing Minecraft video settings are preserved; choose a preset to save a new backup.");}
    }
    public static void started(){if(first){first=false;select(Preset.FAST);} }
    public static void select(Preset next){
        if(next==preset)return;var mc=Minecraft.getInstance();var options=mc.options;var before=Video.read(options);var oldPreset=preset;var oldOriginal=original;var oldApplied=applied;int oldMip=options.mipmapLevels().get();
        if(original!=null&&applied!=null)original.restoreMatching(options,applied);
        // Save restored native values before discarding their only persistent backup.
        if(next==Preset.BALANCED)options.save();
        original=applied=null;preset=next;
        if(next!=Preset.BALANCED){original=Video.read(options);applied=original.fast(next==Preset.MAXIMUM);}
        if(!save()){before.apply(options);preset=oldPreset;original=oldOriginal;applied=oldApplied;return;}
        if(applied!=null){applied.apply(options);applied=Video.read(options);}
        options.save();save();if(options.mipmapLevels().get()!=oldMip)mc.delayTextureReload();
    }
    public static boolean save(){
        try{Files.createDirectories(FILE.getParent());var j=new JsonObject();j.addProperty("preset",preset.name());j.addProperty("showFps",showFps);j.addProperty("limitMenus",limitMenus);if(original!=null){j.add("original",JSON.toJsonTree(original));j.add("applied",JSON.toJsonTree(applied));}
            var temp=FILE.resolveSibling(FILE.getFileName()+".tmp");Files.writeString(temp,JSON.toJson(j),StandardCharsets.UTF_8);try{Files.move(temp,FILE,StandardCopyOption.REPLACE_EXISTING,StandardCopyOption.ATOMIC_MOVE);}catch(AtomicMoveNotSupportedException e){Files.move(temp,FILE,StandardCopyOption.REPLACE_EXISTING);}
            return true;
        }catch(Exception e){org.slf4j.LoggerFactory.getLogger("Crystal Client").warn("Could not save Crystal preferences",e);return false;}
    }
}
