package client.crystal;

import net.minecraft.client.gui.components.Button;
import net.minecraft.client.gui.GuiGraphics;
import net.minecraft.client.Minecraft;

public final class CrystalButton extends Button {
    private final String label;private final boolean primary;private float hover;private long last=System.nanoTime();
    public CrystalButton(int x,int y,int w,int h,String label,boolean primary,Runnable action){super(x,y,w,h,CrystalUi.text(label),b->action.run(),DEFAULT_NARRATION);this.label=label;this.primary=primary;}
    @Override protected void renderContents(GuiGraphics g,int mx,int my,float delta){long now=System.nanoTime();double dt=Math.clamp((now-last)/1e9,0,1);last=now;hover+=(isHoveredOrFocused()?1-hover:-hover)*(float)(-Math.expm1(-dt*16));int x=getX(),y=getY(),w=getWidth(),h=getHeight();
        CrystalUi.round(g,x,y,w,h,12,primary?CrystalUi.mix(CrystalUi.PURPLE,0xFF7350A6,hover):CrystalUi.mix(0xFFE4E1EA,0xFFC3ACDE,hover));
        if(!primary)CrystalUi.round(g,x+1,y+1,w-2,h-2,11,CrystalUi.mix(0xFFFFFFFF,0xFFF4EDF9,hover));
        CrystalUi.label(g,Minecraft.getInstance().font,label,x+17,y+(h-12)/2f,1,active?(primary?0xFFFFFFFF:CrystalUi.INK):0xFFAAA6B0);
    }
}
