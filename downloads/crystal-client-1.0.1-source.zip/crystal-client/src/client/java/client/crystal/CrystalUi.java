package client.crystal;

import net.minecraft.client.gui.GuiGraphics;
import net.minecraft.client.gui.Font;
import net.minecraft.network.chat.*;
import net.minecraft.resources.Identifier;
import net.minecraft.client.renderer.RenderPipelines;
import org.joml.Matrix3x2f;
import net.minecraft.client.gui.navigation.ScreenRectangle;
import net.minecraft.client.gui.render.state.GuiElementRenderState;
import net.minecraft.client.gui.render.TextureSetup;
import com.mojang.blaze3d.vertex.VertexConsumer;

public final class CrystalUi {
    public static final int BACKGROUND=0xFFF6F6F9,INK=0xFF262430,MUTED=0xFF777381,PURPLE=0xFF8960BE;
    private static final Identifier LOGO=Identifier.fromNamespaceAndPath("crystal-client","textures/logo.png");
    private static final FontDescription FONT=new FontDescription.Resource(Identifier.fromNamespaceAndPath("crystal-client","ui"));
    private static final java.util.LinkedHashMap<String,Component> LABELS=new java.util.LinkedHashMap<>(128,.75f,true);
    private CrystalUi(){}
    public static Component text(String value){var cached=LABELS.get(value);if(cached!=null)return cached;var next=Component.literal(value).withStyle(s->s.withFont(FONT));if(LABELS.size()>=256)LABELS.remove(LABELS.keySet().iterator().next());LABELS.put(value,next);return next;}
    public static void label(GuiGraphics g,Font f,String value,float x,float y,float scale,int color){g.pose().pushMatrix();g.pose().translate(x,y);g.pose().scale(scale,scale);g.drawString(f,text(value),0,0,color,false);g.pose().popMatrix();}
    public static int mix(int a,int b,float t){int c=0;for(int s=0;s<=24;s+=8)c|=Math.round(((a>>>s)&255)+(((b>>>s)&255)-((a>>>s)&255))*t)<<s;return c;}
    public static void logo(GuiGraphics g,int x,int y,int size){g.blit(RenderPipelines.GUI_TEXTURED,LOGO,x,y,0f,0f,size,size,1254,1254,1254,1254);}
    public static void round(GuiGraphics g,int x,int y,int w,int h,int radius,int color){if(w<1||h<1)return;var pose=new Matrix3x2f(g.pose()).translate(x,y);var area=new ScreenRectangle(0,0,w,h).transformMaxBounds(pose);var clip=g.scissorStack.peek();g.guiRenderState.submitGuiElement(new Rounded(pose,w,h,Math.clamp(radius,0,Math.min(w,h)/2),color,clip,clip==null?area:clip.intersection(area)));}
    private record Rounded(Matrix3x2f pose,int w,int h,int r,int color,ScreenRectangle scissorArea,ScreenRectangle bounds) implements GuiElementRenderState {
        private static final float[] X=new float[36],Y=new float[36];
        static{for(int corner=0;corner<4;corner++)for(int i=0;i<9;i++){double angle=(-Math.PI/2-corner*Math.PI/2)-i*Math.PI/16;X[corner*9+i]=(float)Math.cos(angle);Y[corner*9+i]=(float)Math.sin(angle);}}
        public com.mojang.blaze3d.pipeline.RenderPipeline pipeline(){return RenderPipelines.GUI;}
        public TextureSetup textureSetup(){return TextureSetup.noTexture();}
        private float x(int n){int c=n/9;return(c==0||c==1?r:w-r)+X[n]*r;}
        private float y(int n){int c=n/9;return(c==0||c==3?r:h-r)+Y[n]*r;}
        public void buildVertices(VertexConsumer v){for(int i=0;i<36;i++){int next=(i+1)%36;v.addVertexWith2DPose(pose,w/2f,h/2f).setColor(color);v.addVertexWith2DPose(pose,x(i),y(i)).setColor(color);v.addVertexWith2DPose(pose,x(next),y(next)).setColor(color);v.addVertexWith2DPose(pose,x(next),y(next)).setColor(color);}}
    }
}
