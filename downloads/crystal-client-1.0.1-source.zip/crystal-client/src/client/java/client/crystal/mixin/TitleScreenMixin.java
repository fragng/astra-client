package client.crystal.mixin;

import client.crystal.CrystalHomeScreen;
import net.minecraft.client.Minecraft;
import net.minecraft.client.gui.screens.TitleScreen;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.*;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;

@Mixin(TitleScreen.class)
public abstract class TitleScreenMixin {
    @Inject(method="init",at=@At("TAIL"))
    private void crystal$home(CallbackInfo ci){Minecraft.getInstance().setScreen(new CrystalHomeScreen());}
}
