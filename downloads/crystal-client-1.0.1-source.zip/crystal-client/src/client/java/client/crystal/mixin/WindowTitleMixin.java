package client.crystal.mixin;

import client.crystal.CrystalClient;
import net.minecraft.client.Minecraft;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfoReturnable;

@Mixin(Minecraft.class)
public abstract class WindowTitleMixin {
    @Inject(method="createTitle",at=@At("HEAD"),cancellable=true)
    private void crystal$windowTitle(CallbackInfoReturnable<String> cir){
        cir.setReturnValue(CrystalClient.NAME);
    }
}
