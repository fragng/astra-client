from pathlib import Path
from fontTools.ttLib import TTFont
from fontTools.varLib.instancer import instantiateVariableFont
root=Path(__file__).resolve().parents[1]
font=instantiateVariableFont(TTFont(root/'tools/font-source/Quicksand[wght].ttf'),{'wght':550},inplace=False)
# OFL's Reserved Font Name is retained in attribution, not used by this derived static font.
values={1:'Crystal UI',2:'Medium',3:'Crystal UI Medium 1.0',4:'Crystal UI Medium',6:'CrystalUI-Medium',16:'Crystal UI',17:'Medium',21:'Crystal UI',22:'Medium'}
for entry in font['name'].names:
 if entry.nameID in values:entry.string=values[entry.nameID].encode(entry.getEncoding())
font.save(root/'src/main/resources/assets/crystal-client/font/ui.ttf')
print('Built Crystal UI Medium: static weight550 from OFL Quicksand; reserved family name replaced.')
