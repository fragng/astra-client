package client.crystal;

import java.util.*;

public final class CrystalContracts {
    private static void check(boolean b,String m){if(!b)throw new AssertionError(m);}
    public static void main(String[] args){
        check(Greetings.WELCOMES.size()>=28 && new HashSet<>(Greetings.WELCOMES).size()==Greetings.WELCOMES.size(),"At least28 unique personal welcomes");
        for(String greeting:Greetings.WELCOMES)check(greeting.contains("Jack"),"Every welcome is personal");
        check(Greetings.timeGreeting(10).equals("Good morning,")&&Greetings.timeGreeting(15).equals("Good afternoon,")&&Greetings.timeGreeting(20).equals("Good evening,"),"Local morning/afternoon/evening greetings");
        var seen=new HashSet<String>();for(int i=0;i<Greetings.WELCOMES.size();i++)seen.add(Greetings.next());check(seen.size()==Greetings.WELCOMES.size(),"Every welcome rotates before repetition");
        var original=new CrystalPerformance.Video(20,12,1.5,"FANCY","ALL",true,5,true,false,true,true,true,120,4);
        var fast=original.fast(false);var maximum=original.fast(true);check(original.valid()&&fast.valid()&&maximum.valid(),"All video snapshots validate");
        check(fast.render()==8&&fast.simulation()==5&&fast.entities()==.75&&!fast.vsync()&&fast.limit()==120,"Fast reduces actual work and retains world frame cap");
        check(maximum.render()==4&&maximum.simulation()==5&&maximum.entities()==.5&&maximum.limit()==260&&maximum.mipmaps()==0,"Maximum selects aggressive documented native values");
        var low=new CrystalPerformance.Video(2,2,.25,"OFF","MINIMAL",false,0,false,true,false,false,false,60,0);check(low.fast(false).render()==2&&low.fast(true).simulation()==2&&low.fast(false).entities()==.25,"Presets never increase lower distance settings");
        check(low.fast(false).particles().equals("MINIMAL")&&low.fast(false).mipmaps()==0,"Keep already-minimal particle and texture settings");
        check(!new CrystalPerformance.Video(0,2,1,"OFF","MINIMAL",false,0,false,true,false,false,false,60,0).valid(),"Reject invalid backups");
        System.out.println("PASS28 rotating Jack welcomes, time-of-day selection, native profile bounds and preservation of lower distance/cap values");
    }
}
