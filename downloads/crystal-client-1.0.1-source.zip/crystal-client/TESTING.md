# Crystal Client 1.0.1 validation

Test date: 27 November 2026.

Version 1.0.1 packages the same client code and original performance mods
as a single installable Fabric JAR. The functional checks below were run
for 1.0.0; a separate installed production run checks 1.0.1's nested-mod
discovery, menu navigation, actual world loading and Right Shift settings.

The Java 21 / Gradle build and the greeting/preset contract checks pass.
The installed, remapped release JAR was launched in actual Minecraft
1.21.11 with Fabric Loader 0.19.3 and the complete supplied mod set.
Tests used Linux, X11 and Mesa software rendering in an isolated instance.

Verified in Minecraft:

- The white home screen, Crystal branding and bundled font/logo load.
- All four optimization mods report their actual installed versions.
- There are 28 unique personalised welcome lines, with local-time morning,
  afternoon and evening greetings.
- First launch selects Fast after backing up native video settings.
- Balanced restores the previous native options, including entity distance.
- Maximum FPS changes the real video settings, including Minecraft's
  unlimited world-FPS option, minimal particles and mipmaps 0.
- Both presets use simulation distance 5, Minecraft 1.21.11's normal
  minimum.
- Manual video changes are preserved when returning to Balanced.
- FOV and world brightness are unchanged by the presets.
- FPS footer and quiet-menu controls change their actual saved preferences.
- Native Singleplayer, Multiplayer/safety and Settings navigation works.
- Home and settings remain usable at 800x600 and 1440x900.
- An actual saved world loads with Sodium, Lithium, FerriteCore and
  ImmediatelyFast. Right Shift opens performance settings in that world;
  changing preset and returning to play works.
- A fresh Minecraft process retains Fast and its saved native settings,
  preferences and original backup. Balanced restores that saved backup.
- The native window title is Crystal Client and its X11 window icon
  contains the six supplied sizes from 16 to 256 pixels.
- The actual Quit button shuts down the game cleanly.

Release assembly checks verify dependency hashes against the acquisition
manifest, correct Fabric metadata, Java class version 65 (Java 21), archive
integrity, five unchanged nested mod JARs and absence of test-fixture classes from
the shipped Crystal JAR. Third-party JARs are unchanged. No installer,
browser engine, PowerShell helper or executable is added to Crystal.

This is a functional compatibility check, not a hardware FPS benchmark.
Windows-specific taskbar grouping and actual Windows Defender detection
were not tested in this Linux environment. No fixed FPS gain or universal
antivirus result is promised. The separate scan report documents the exact
scanner and release files checked.
