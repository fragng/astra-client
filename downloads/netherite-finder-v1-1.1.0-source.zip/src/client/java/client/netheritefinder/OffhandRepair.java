package client.netheritefinder;

import net.minecraft.world.InteractionHand;
import net.minecraft.world.item.*;

/** Keep the Mending tool eligible for the entire XP flight, not just the throw. */
final class OffhandRepair {
    private final MiningEngine engine;
    private ItemStack original=ItemStack.EMPTY;
    private boolean active,finishing;private long lastBottle;private int initialDamage,bottles,source=-1;
    OffhandRepair(MiningEngine e){engine=e;}
    boolean active(){return active;}
    void finish(){if(active)finishing=true;}
    void disconnect(){active=finishing=false;source=-1;original=ItemStack.EMPTY;}
    boolean begin(int slot){
        var mc=engine.mc;if(active)return true;
        var stack=mc.player.getInventory().getItem(slot);if(!InventoryActions.mending(stack))return false;
        var before=mc.player.getOffhandItem().copy();int damage=stack.getDamageValue();
        if(!engine.inventory.swapOffhand(slot,engine.ticks()))return false;
        original=before;source=slot;initialDamage=damage;bottles=0;lastBottle=engine.ticks()-20;active=true;finishing=false;return true;
    }
    /** Runs even after OFF so the original offhand is not stranded by an interruption. */
    void tick(){
        if(!active)return;var mc=engine.mc;if(mc.player==null||mc.gameMode==null){disconnect();return;}
        engine.stopMining();var pick=mc.player.getOffhandItem();
        if(!InventoryActions.mending(pick)||!pick.isDamageableItem()){disconnect();return;}
        if(mc.screen!=null||!engine.enabled()||InventoryActions.damage(pick)<=.08)finishing=true;
        int xp=engine.inventory.find(s->s.is(Items.EXPERIENCE_BOTTLE));
        if(xp<0){finishing=true;engine.status("XP depleted — restoring the offhand item");}
        if(bottles>=24&&pick.getDamageValue()>=initialDamage){finishing=true;engine.status("No repair progress — check Mending and damaged armour");}
        if(finishing){restore();return;}
        engine.status("Repairing: pickaxe in offhand / XP in main hand");
        if(engine.ticks()-lastBottle<20)return;
        if(!engine.inventory.equip(xp,engine.ticks())||!engine.aim(mc.player.getEyePosition().add(0,-4,.1),5))return;
        mc.gameMode.useItem(mc.player,InteractionHand.MAIN_HAND);mc.player.swing(InteractionHand.MAIN_HAND);lastBottle=engine.ticks();bottles++;engine.thrownBottles++;
    }
    private void restore(){
        var mc=engine.mc;int slot=-1;
        // The previous offhand may have moved when XP was brought into the hotbar.
        if(!original.isEmpty())slot=engine.inventory.find(s->ItemStack.isSameItemSameComponents(s,original));
        if(slot<0&&original.is(Items.TOTEM_OF_UNDYING))slot=engine.inventory.find(s->s.is(Items.TOTEM_OF_UNDYING));
        if(slot<0)slot=engine.inventory.find(ItemStack::isEmpty);
        if(slot<0){engine.status("Repair finished — free a slot to restore the offhand safely");return;}
        if(engine.inventory.swapOffhand(slot,engine.ticks())){disconnect();engine.inventory.equipPick(engine.ticks());}
    }
}
