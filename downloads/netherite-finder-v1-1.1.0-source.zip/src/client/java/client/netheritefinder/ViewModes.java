package client.netheritefinder;

import com.mojang.blaze3d.platform.InputConstants;
import net.minecraft.client.Minecraft;
import net.minecraft.world.phys.Vec3;
import org.lwjgl.glfw.GLFW;

/** Render-only cameras; the camera never becomes the player's network position. */
public final class ViewModes {
    private static boolean freecam,freelook;
    private static Vec3 position=Vec3.ZERO,previous=Vec3.ZERO,velocity=Vec3.ZERO;
    private static float yaw,pitch;
    public static boolean freecam(){return freecam;}
    public static boolean freelook(){return freelook;}
    public static boolean active(){return freecam||freelook;}
    public static void reset(){freecam=freelook=false;velocity=Vec3.ZERO;}
    private static void start(){var mc=Minecraft.getInstance();if(mc.player==null)return;position=previous=mc.player.getEyePosition();yaw=mc.player.getYRot();pitch=mc.player.getXRot();velocity=Vec3.ZERO;}
    public static void toggleFreecam(){var mc=Minecraft.getInstance();if(mc.player==null)return;if(freecam){reset();return;}reset();start();freecam=true;}
    public static void toggleFreelook(){var mc=Minecraft.getInstance();if(mc.player==null)return;if(freelook){reset();return;}reset();start();freelook=true;}
    public static void turn(double dx,double dy){yaw+=(float)(dx*.15);pitch=Math.clamp(pitch+(float)(dy*.15),-89.5f,89.5f);}
    public static float yaw(){return yaw;}
    public static float pitch(){return pitch;}
    private static boolean key(int code){return InputConstants.isKeyDown(Minecraft.getInstance().getWindow(),code);}
    public static void tick(){
        var mc=Minecraft.getInstance();if(mc.player==null){reset();return;}previous=position;
        if(!freecam||mc.screen!=null){velocity=Vec3.ZERO;return;}
        double forward=(key(GLFW.GLFW_KEY_W)?1:0)-(key(GLFW.GLFW_KEY_S)?1:0),side=(key(GLFW.GLFW_KEY_D)?1:0)-(key(GLFW.GLFW_KEY_A)?1:0),up=(key(GLFW.GLFW_KEY_SPACE)?1:0)-(key(GLFW.GLFW_KEY_LEFT_SHIFT)?1:0);
        double a=Math.toRadians(yaw);var desired=new Vec3(-Math.sin(a)*forward+Math.cos(a)*side,up,Math.cos(a)*forward+Math.sin(a)*side);
        if(desired.lengthSqr()>1)desired=desired.normalize();desired=desired.scale(FinderSettings.cameraSpeed);velocity=velocity.scale(.55).add(desired.scale(.45));position=position.add(velocity);
        var offset=position.subtract(mc.player.getEyePosition());if(offset.lengthSqr()>96*96){position=mc.player.getEyePosition().add(offset.normalize().scale(96));velocity=Vec3.ZERO;}
    }
    public static Vec3 camera(float delta){var mc=Minecraft.getInstance();if(freecam)return previous.lerp(position,delta);return mc.player.getEyePosition(delta).subtract(Vec3.directionFromRotation(pitch,yaw).scale(FinderSettings.lookDistance));}
}
