package client.netheritefinder;

import net.minecraft.core.*;
import net.minecraft.world.InteractionHand;
import net.minecraft.world.inventory.ChestMenu;
import net.minecraft.world.item.Items;
import net.minecraft.world.level.block.Blocks;
import net.minecraft.world.phys.*;

/** Place/use an actual ender chest, await its menu, and transfer real debris stacks. */
final class StorageTask {
    private enum Phase {OFF,FIND,PLACE_WAIT,OPEN,WAIT_MENU,TRANSFER,RECOVER}
    private final MiningEngine engine;private Phase phase=Phase.OFF;private BlockPos chest;private boolean placed;
    private long waitUntil,nextAction;private int previousCount;private boolean pending;
    StorageTask(MiningEngine engine){this.engine=engine;}
    boolean running(){return phase!=Phase.OFF;}
    void reset(){phase=Phase.OFF;chest=null;placed=pending=false;}
    void start(){reset();phase=Phase.FIND;}
    void tick(){
        var mc=engine.mc;var inventory=engine.inventory;long now=engine.ticks();engine.status("Storing ancient debris in an ender chest");
        if(mc.player==null||mc.level==null){reset();return;}
        if(phase!=Phase.RECOVER)engine.stopMining();
        if(mc.screen instanceof FinderScreen){engine.menuOpened();return;}
        if(phase==Phase.FIND){
            var feet=mc.player.blockPosition();
            for(var p:BlockPos.betweenClosed(feet.offset(-3,-1,-3),feet.offset(3,1,3)))if(mc.level.getBlockState(p).is(Blocks.ENDER_CHEST)&&engine.reachable(p)&&engine.visibleFirst(p).equals(p)&&engine.terrain.clear(p.above())){chest=p.immutable();phase=Phase.OPEN;break;}
            if(phase==Phase.FIND){
                int item=inventory.find(stack->stack.is(Items.ENDER_CHEST));if(item<0){engine.status("Inventory at capacity — carry an ender chest to deposit");return;}
                if(chest==null){
                    for(var p:BlockPos.betweenClosed(feet.offset(-2,0,-2),feet.offset(2,0,2)))if(engine.terrain.clear(p)&&engine.terrain.clear(p.above())&&engine.terrain.solidFloor(p.below())&&!engine.terrain.danger(p)&&!mc.player.getBoundingBox().intersects(new AABB(p))&&engine.reachable(p)&&engine.visibleFirst(p.below()).equals(p.below())){chest=p.immutable();break;}
                }
                if(chest==null){engine.stop("No safe visible place for an ender chest");return;}
                if(!inventory.equip(item,now)||!engine.aim(Vec3.atBottomCenterOf(chest),4))return;
                mc.gameMode.useItemOn(mc.player,InteractionHand.MAIN_HAND,new BlockHitResult(Vec3.atBottomCenterOf(chest),Direction.UP,chest.below(),false));mc.player.swing(InteractionHand.MAIN_HAND);placed=true;waitUntil=now+60;phase=Phase.PLACE_WAIT;return;
            }
        }
        if(phase==Phase.PLACE_WAIT){if(mc.level.getBlockState(chest).is(Blocks.ENDER_CHEST))phase=Phase.OPEN;else if(now>waitUntil)engine.stop("Ender-chest placement was not confirmed");return;}
        if(phase==Phase.OPEN){
            if(mc.screen!=null){engine.stop("Unexpected menu — ender-chest deposit stopped");return;}
            if(!inventory.equipPick(now)||!engine.aim(Vec3.atCenterOf(chest),4))return;
            mc.gameMode.useItemOn(mc.player,InteractionHand.MAIN_HAND,new BlockHitResult(Vec3.atCenterOf(chest),Direction.UP,chest,false));mc.player.swing(InteractionHand.MAIN_HAND);waitUntil=now+60;phase=Phase.WAIT_MENU;return;
        }
        if(phase==Phase.WAIT_MENU){
            if(mc.player.containerMenu instanceof ChestMenu menu&&menu.getRowCount()==3){phase=Phase.TRANSFER;previousCount=inventory.count(Items.ANCIENT_DEBRIS);nextAction=now+6;}
            else if(now>waitUntil)engine.stop("Ender chest did not open — check access and space above it");return;
        }
        if(phase==Phase.TRANSFER){
            if(!(mc.player.containerMenu instanceof ChestMenu menu)||menu.getRowCount()!=3){engine.stop("Ender-chest screen closed before deposit finished");return;}
            if(now<nextAction)return;
            int count=inventory.count(Items.ANCIENT_DEBRIS);
            if(pending){int moved=previousCount-count;if(moved<=0){mc.player.closeContainer();engine.stop("Deposit was not confirmed — check ender-chest space");return;}engine.stored+=moved;pending=false;}
            if(count==0){engine.enderFull=!inventory.chestHasSpace();mc.player.closeContainer();phase=Phase.RECOVER;nextAction=now+8;waitUntil=now+240;return;}
            if(!inventory.chestHasSpace()){engine.enderFull=true;mc.player.closeContainer();phase=Phase.RECOVER;nextAction=now+8;waitUntil=now+240;return;}
            if(inventory.depositOne(now)){previousCount=count;pending=true;nextAction=now+12;}return;
        }
        if(phase==Phase.RECOVER){
            if(now<nextAction)return;
            int slot=inventory.bestPick();
            if(!placed||slot<0||!InventoryActions.silk(mc.player.getInventory().getItem(slot))){reset();engine.resetRoute();return;}
            if(mc.level.getBlockState(chest).is(Blocks.ENDER_CHEST)){
                if(now>waitUntil){reset();engine.resetRoute();return;}
                engine.mine(chest,true);return;
            }
            engine.stopMining();
            // The chest is recovered only with Silk Touch. Move onto a checked safe cell for pickup.
            if(inventory.count(Items.ENDER_CHEST)>0||now>waitUntil){reset();engine.resetRoute();return;}
            engine.status("Collecting the recovered ender chest");
            if(engine.terrain.walkable(chest)&&engine.aim(new Vec3(chest.getX()+.5,mc.player.getEyeY(),chest.getZ()+.5),12))mc.options.keyUp.setDown(true);
        }
    }
}
