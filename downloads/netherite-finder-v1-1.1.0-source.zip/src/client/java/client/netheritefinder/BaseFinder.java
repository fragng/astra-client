package client.netheritefinder;

import net.minecraft.core.*;
import net.minecraft.world.InteractionHand;
import net.minecraft.world.level.block.Blocks;
import net.minecraft.world.phys.*;
import java.util.*;

/** Bounded loaded-chunk clues, followed by actual container inspection. No guessed loot. */
final class BaseFinder {
    private enum Phase {SEARCH,APPROACH,WAIT,INSPECT}
    private final MiningEngine engine;private Phase phase=Phase.SEARCH;
    private final List<int[]> offsets=new ArrayList<>();private int cursor,checked;
    private final Set<BlockPos> containers=new HashSet<>(),trials=new HashSet<>();
    private final Map<BlockPos,Long> excluded=new HashMap<>();
    private List<BlockPos> cluster=List.of();private int index,empty;private long deadline;private BlockPos target;
    int raidedClusters,trialClusters;
    private int sweepX=Integer.MIN_VALUE,sweepZ;
    BaseFinder(MiningEngine e){engine=e;for(int x=-4;x<=4;x++)for(int z=-4;z<=4;z++)offsets.add(new int[]{x,z});offsets.sort(Comparator.comparingInt(a->a[0]*a[0]+a[1]*a[1]));}
    boolean ownsMenu(){return phase==Phase.WAIT||phase==Phase.INSPECT;}
    void interrupt(){phase=Phase.SEARCH;cluster=List.of();target=null;index=empty=0;}
    void reset(){interrupt();containers.clear();trials.clear();excluded.clear();cursor=checked=raidedClusters=trialClusters=0;sweepX=Integer.MIN_VALUE;}
    void routeBlocked(){if(target!=null)excluded.put(target,engine.ticks()+1200);interrupt();}
    int clues(){return containers.size();}
    private boolean container(BlockPos p){var state=engine.mc.level.getBlockState(p);return state.is(Blocks.CHEST)||state.is(Blocks.TRAPPED_CHEST)||state.is(Blocks.BARREL)||state.is(net.minecraft.tags.BlockTags.SHULKER_BOXES);}
    private void scan(){
        var mc=engine.mc;int cx=mc.player.chunkPosition().x,cz=mc.player.chunkPosition().z;
        if(cx!=sweepX||cz!=sweepZ){sweepX=cx;sweepZ=cz;checked=0;cursor=0;}
        containers.removeIf(p->Math.abs((p.getX()>>4)-cx)>5||Math.abs((p.getZ()>>4)-cz)>5||!mc.level.hasChunkAt(p)||!container(p));
        trials.removeIf(p->Math.abs((p.getX()>>4)-cx)>6||Math.abs((p.getZ()>>4)-cz)>6||!mc.level.hasChunkAt(p)||!mc.level.getBlockState(p).is(Blocks.TRIAL_SPAWNER)&&!mc.level.getBlockState(p).is(Blocks.VAULT));
        var offset=offsets.get(cursor++%offsets.size());checked=Math.min(offsets.size(),checked+1);int x=cx+offset[0],z=cz+offset[1];
        if(!mc.level.getChunkSource().hasChunk(x,z))return;
        for(var p:mc.level.getChunk(x,z).getBlockEntities().keySet()){
            var state=mc.level.getBlockState(p);
            if(state.is(Blocks.TRIAL_SPAWNER)||state.is(Blocks.VAULT))trials.add(p.immutable());
            else if(containers.size()<2048&&container(p)&&p.getY()<=Math.max(48,mc.player.getY()+16))containers.add(p.immutable());
        }
        excluded.entrySet().removeIf(e->e.getValue()<=engine.ticks());
    }
    private boolean nearTrial(BlockPos p){
        // Also consult every loaded neighbour within the full 30-block margin before choosing.
        var level=engine.mc.level;int cx=p.getX()>>4,cz=p.getZ()>>4;
        for(int x=cx-2;x<=cx+2;x++)for(int z=cz-2;z<=cz+2;z++)if(level.getChunkSource().hasChunk(x,z))
            for(var b:level.getChunk(x,z).getBlockEntities().keySet())if(b.distSqr(p)<=900){var state=level.getBlockState(b);if(state.is(Blocks.TRIAL_SPAWNER)||state.is(Blocks.VAULT))return true;}
        return trials.stream().anyMatch(t->t.distSqr(p)<=900);
    }
    void tick(){
        scan();var mc=engine.mc;long now=engine.ticks();
        if(phase==Phase.SEARCH){
            if(checked<offsets.size()){engine.status("Checking loaded chunks for underground storage clues");return;}
            var candidates=containers.stream().filter(p->!excluded.containsKey(p)&&p.distToCenterSqr(mc.player.position())<72*72).sorted(Comparator.comparingDouble(p->p.distToCenterSqr(mc.player.position()))).toList();
            for(var p:candidates){
                var group=containers.stream().filter(c->c.distSqr(p)<=12*12&&!excluded.containsKey(c)).sorted(Comparator.comparingDouble(c->c.distToCenterSqr(mc.player.position()))).limit(12).toList();
                if(group.size()<FinderSettings.baseContainers)continue;
                if(group.stream().anyMatch(this::nearTrial)){trialClusters++;for(var c:group)excluded.put(c,now+2400);continue;}
                cluster=group;index=empty=0;target=group.getFirst();phase=Phase.APPROACH;engine.resetRoute();break;
            }
            if(phase==Phase.SEARCH){engine.explore(FinderSettings.baseDepth,"Exploring for loaded underground base clues");return;}
        }
        if(index>=cluster.size()){
            for(var p:cluster)excluded.put(p,now+12000);interrupt();engine.changeDirection();engine.status("Accessible storage appears raided — searching another direction");return;
        }
        target=cluster.get(index);
        if(!container(target)||nearTrial(target)){skip(false);return;}
        if(phase==Phase.APPROACH){
            if(!engine.reachable(target)||!engine.visibleFirst(target).equals(target)){
                var blocker=engine.visibleFirst(target);
                if(engine.reachable(target)&&engine.reachable(blocker)&&engine.terrain.safeBreakDirect(blocker)){engine.mine(blocker,false);return;}
                engine.approach(target);engine.status("Digging toward a potential underground base");return;
            }
            engine.stopMining();
            if(!engine.inventory.equipPick(now)||!engine.aim(Vec3.atCenterOf(target),5))return;
            if(mc.screen!=null)return;
            mc.gameMode.useItemOn(mc.player,InteractionHand.MAIN_HAND,new BlockHitResult(Vec3.atCenterOf(target),Direction.UP,target,false));mc.player.swing(InteractionHand.MAIN_HAND);deadline=now+60;phase=Phase.WAIT;return;
        }
        if(phase==Phase.WAIT){
            if(mc.player.containerMenu!=mc.player.inventoryMenu){phase=Phase.INSPECT;deadline=now+20;return;}
            if(now>=deadline){excluded.put(target,now+2400);skip(false);}else engine.status("Opening storage to check whether the base is raided");return;
        }
        if(phase==Phase.INSPECT){
            if(mc.player.containerMenu==mc.player.inventoryMenu){skip(false);return;}
            if(now<deadline)return;
            boolean loot=false;int slots=0;
            for(var slot:mc.player.containerMenu.slots)if(slot.container!=mc.player.getInventory()){slots++;if(!slot.getItem().isEmpty())loot=true;}
            mc.player.closeContainer();
            if(loot){var found=target;interrupt();engine.stop("Potential unraided base at "+found.getX()+", "+found.getY()+", "+found.getZ()+" — storage contains items");return;}
            if(slots>0)empty++;skip(slots>0);
        }
    }
    private void skip(boolean inspected){
        if(target!=null)excluded.put(target,engine.ticks()+12000);index++;engine.resetRoute();
        if(index>=cluster.size()&&empty==cluster.size()){for(var p:cluster)excluded.put(p,engine.ticks()+12000);raidedClusters++;interrupt();engine.changeDirection();engine.status("Empty storage — appears raided; taking a different route");}
        else if(index>=cluster.size()){interrupt();engine.changeDirection();engine.status("Storage inaccessible or unknown — searching elsewhere");}
        else{target=cluster.get(index);phase=Phase.APPROACH;}
    }
}
