package client.netheritefinder;

import net.minecraft.core.*;
import net.minecraft.tags.FluidTags;
import net.minecraft.world.InteractionHand;
import net.minecraft.world.phys.*;

/** A real block placement into encountered lava, confirmed before movement resumes. */
final class LavaPlugs {
    private final MiningEngine engine;private BlockPos pending;private long sent,next;private int attempts;
    private boolean pendingLava;
    private boolean geometryBlocked;
    int placed;
    LavaPlugs(MiningEngine engine){this.engine=engine;}
    void reset(){pending=null;attempts=0;}
    boolean geometryBlocked(){return geometryBlocked;}
    boolean tickPending(){
        if(pending==null||attempts==0)return false;
        if(engine.ticks()-sent<8){engine.status("Waiting for the placed block");return true;}
        if(engine.terrain.solidFloorDirect(pending)){if(pendingLava)placed++;pending=null;attempts=0;return false;}
        if(attempts>=3){geometryBlocked=true;return false;}
        return fill(pending,pendingLava);
    }
    boolean lava(BlockPos p){return engine.terrain.loaded(p)&&engine.mc.level.getFluidState(p).is(FluidTags.LAVA);}
    BlockPos encountered(BlockPos feet){
        for(var p:new BlockPos[]{feet,feet.above(),feet.below()})if(lava(p))return p;
        if(!engine.terrain.clear(feet)||!engine.terrain.clear(feet.above()))return null;
        for(var p:new BlockPos[]{feet,feet.above()})for(var d:Direction.values())if(lava(p.relative(d)))return p.relative(d);
        return null;
    }
    /** True means still waiting: the caller must not walk into this position. */
    boolean fill(BlockPos target,boolean isLava){
        var mc=engine.mc;long tick=engine.ticks();engine.stopMining();geometryBlocked=false;
        engine.status(isLava?"Blocking lava with a hotbar block":"Placing a supported step toward debris");
        if(!engine.terrain.loaded(target)){engine.status("Waiting for the next chunk");return true;}
        if(engine.terrain.solidFloorDirect(target)){
            if(target.equals(pending)){placed++;pending=null;attempts=0;}return false;
        }
        if(target.equals(pending)&&tick-sent<20)return true;
        if(!target.equals(pending)){pending=target;attempts=0;}pendingLava=isLava;
        if(attempts>=3){geometryBlocked=true;engine.status("Plug rejected — finding a detour");return true;}
        if(new AABB(target).intersects(mc.player.getBoundingBox())){geometryBlocked=true;engine.status("Moving clear to place the lava plug");return true;}
        int slot=engine.inventory.hotbarBuildingSlot();
        if(slot<0){geometryBlocked=true;engine.status("No hotbar blocks — finding a lava detour");return true;}
        BlockPos support=null;Direction face=null;Vec3 point=null;double nearest=Double.MAX_VALUE;
        for(var toward:Direction.values()){
            var base=target.relative(toward);if(!engine.terrain.solidFloorDirect(base))continue;
            var outward=toward.getOpposite();var hit=Vec3.atCenterOf(base).add(outward.getStepX()*.5,outward.getStepY()*.5,outward.getStepZ()*.5);
            if(hit.distanceToSqr(mc.player.getEyePosition())>Math.pow(Math.min(4.2,mc.player.blockInteractionRange()-.2),2))continue;
            var ray=mc.level.clip(new net.minecraft.world.level.ClipContext(mc.player.getEyePosition(),hit.add(-outward.getStepX()*.002,-outward.getStepY()*.002,-outward.getStepZ()*.002),net.minecraft.world.level.ClipContext.Block.COLLIDER,net.minecraft.world.level.ClipContext.Fluid.NONE,mc.player));
            if(!ray.getBlockPos().equals(base))continue;
            double distance=hit.distanceToSqr(mc.player.getEyePosition());if(distance<nearest){nearest=distance;support=base;face=outward;point=hit;}
        }
        if(support==null){geometryBlocked=true;engine.status("Approach blocked — no visible face for a lava plug");return true;}
        if(tick<next||!engine.inventory.equip(slot,tick)||!engine.aim(point,5))return true;
        mc.gameMode.useItemOn(mc.player,InteractionHand.MAIN_HAND,new BlockHitResult(point,face,support,false));mc.player.swing(InteractionHand.MAIN_HAND);sent=tick;next=tick+6;attempts++;return true;
    }
}
