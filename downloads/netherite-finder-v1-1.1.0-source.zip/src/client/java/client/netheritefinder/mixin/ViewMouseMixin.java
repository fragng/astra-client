package client.netheritefinder.mixin;

import client.netheritefinder.ViewModes;
import net.minecraft.client.Minecraft;
import net.minecraft.world.entity.Entity;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.*;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;

@Mixin(Entity.class)
public abstract class ViewMouseMixin {
    @Inject(method="turn",at=@At("HEAD"),cancellable=true)
    private void finder$look(double dx,double dy,CallbackInfo ci){if(ViewModes.active()&&(Object)this==Minecraft.getInstance().player){ViewModes.turn(dx,dy);ci.cancel();}}
}
