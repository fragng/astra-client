package client.netheritefinder.mixin;

import client.netheritefinder.*;
import net.minecraft.client.player.*;
import net.minecraft.world.entity.player.Input;
import net.minecraft.world.phys.Vec2;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.*;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;

@Mixin(KeyboardInput.class)
public abstract class ViewInputMixin extends ClientInput {
    @Inject(method="tick",at=@At("TAIL"))
    private void finder$holdBody(CallbackInfo ci){if(ViewModes.freecam()&&!NetheriteFinder.ENGINE.enabled()){keyPresses=Input.EMPTY;moveVector=Vec2.ZERO;}}
}
