package client.netheritefinder.mixin;

import client.netheritefinder.ViewModes;
import net.minecraft.client.Camera;
import net.minecraft.world.entity.Entity;
import net.minecraft.world.level.Level;
import net.minecraft.world.phys.Vec3;
import org.spongepowered.asm.mixin.*;
import org.spongepowered.asm.mixin.injection.*;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;

@Mixin(Camera.class)
public abstract class ViewCameraMixin {
    @Shadow protected abstract void setPosition(Vec3 position);
    @Shadow protected abstract void setRotation(float yaw,float pitch);
    @Shadow private boolean detached;
    @Inject(method="setup",at=@At("TAIL"))
    private void finder$camera(Level level,Entity entity,boolean thirdPerson,boolean inverse,float delta,CallbackInfo ci){if(ViewModes.active()){detached=true;setRotation(ViewModes.yaw(),ViewModes.pitch());setPosition(ViewModes.camera(delta));}}
}
