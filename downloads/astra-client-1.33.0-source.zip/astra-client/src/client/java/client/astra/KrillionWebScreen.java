package client.astra;

import net.dimaskama.mcef.api.MCEFApi;
import net.dimaskama.mcef.api.MCEFBrowser;
import net.minecraft.client.gui.GuiGraphics;
import net.minecraft.client.gui.screens.Screen;
import net.minecraft.client.gui.screens.ConfirmLinkScreen;
import net.minecraft.client.input.CharacterEvent;
import net.minecraft.client.input.KeyEvent;
import net.minecraft.client.input.MouseButtonEvent;
import net.minecraft.client.renderer.RenderPipelines;
import net.minecraft.network.chat.Component;
import org.lwjgl.glfw.GLFW;
import org.cef.browser.CefBrowser;
import org.cef.browser.CefFrame;
import org.cef.handler.*;
import org.cef.network.CefRequest;

/** The real HTTPS website, rendered by Chromium; no copied game code or Minecraft JavaScript bridge. */
public final class KrillionWebScreen extends Screen {
    public static final String URL="https://krillion.io/";
    private final Screen parent;
    private MCEFApi.Initialization startup;
    private MCEFBrowser browser;
    private boolean failed,draggingBrowser;
    private String error="";
    private org.cef.CefClient ownedClient;
    public KrillionWebScreen(Screen parent){super(Component.literal("Krillion.io"));this.parent=parent;}
    private int viewWidth(){return Math.max(1,width-20);}
    private int viewHeight(){return Math.max(1,height-64);}
    private int pixelWidth(){return Math.max(1,Math.round(viewWidth()*minecraft.getWindow().getGuiScale()));}
    private int pixelHeight(){return Math.max(1,Math.round(viewHeight()*minecraft.getWindow().getGuiScale()));}
    @Override protected void init(){
        addRenderableWidget(new MenuButton(width-224,8,96,26,"Back to Games","",()->false,false,this::onClose));
        addRenderableWidget(new MenuButton(width-120,8,68,26,"Reload","",()->false,false,()->{if(browser!=null){error="";browser.getCefBrowser().reload();}}).available(()->browser!=null));
        addRenderableWidget(new MenuButton(width-44,8,32,26,"X","",()->false,false,this::onClose));
        if(startup==null){failed=false;startup=MCEFApi.initialize();}
        if(browser!=null)browser.resize(pixelWidth(),pixelHeight());
    }
    @Override public void tick(){
        if(failed || browser!=null || startup==null || !startup.getFuture().isDone())return;
        try{
            startup.getFuture().join();
            ownedClient=org.cef.CefApp.getInstance().createClient();
            var created=new net.dimaskama.mcef.impl.MCEFBrowserImpl(ownedClient,URL,false,org.cef.browser.CefRequestContext.getGlobalContext(),null);
            created.setCloseAllowed();created.createImmediately();browser=created;browser.resize(pixelWidth(),pixelHeight());
            var nativeBrowser=browser.getCefBrowser();var client=ownedClient;
            client.addRequestHandler(new CefRequestHandlerAdapter(){
                @Override public boolean onBeforeBrowse(CefBrowser b,CefFrame frame,CefRequest request,boolean gesture,boolean redirect){
                    if(!ours(b)||frame==null||!frame.isMain()||BrowserOptions.gameUrl(request.getURL()))return false;
                    if(gesture)external(request.getURL());return true;
                }
            });
            client.addLifeSpanHandler(new CefLifeSpanHandlerAdapter(){
                @Override public boolean onBeforePopup(CefBrowser b,CefFrame frame,String url,String name){if(ours(b))external(url);return true;}
            });
            client.addDownloadHandler(new CefDownloadHandlerAdapter(){
                @Override public boolean onBeforeDownload(CefBrowser b,org.cef.callback.CefDownloadItem item,String name,org.cef.callback.CefBeforeDownloadCallback callback){return ours(b);}
                @Override public void onDownloadUpdated(CefBrowser b,org.cef.callback.CefDownloadItem item,org.cef.callback.CefDownloadItemCallback callback){if(ours(b))callback.cancel();}
            });
            var loadHandler=new CefLoadHandlerAdapter(){
                @Override public void onLoadError(CefBrowser b,CefFrame frame,ErrorCode code,String text,String url){if(ours(b)&&frame!=null&&frame.isMain()&&code!=ErrorCode.ERR_ABORTED)minecraft.execute(()->error="Could not load Krillion: "+code.name()+". Try Reload.");}
            };client.addLoadHandler(loadHandler);browser.setFocus(true);
        }catch(RuntimeException|LinkageError e){failed=true;error="Browser could not start. Check your connection and Minecraft log.";org.slf4j.LoggerFactory.getLogger("Astra Browser").error("Krillion browser initialization failed",e);}
    }
    private boolean ours(CefBrowser b){return browser!=null && b!=null && b.getIdentifier()==browser.getCefBrowser().getIdentifier();}
    private void external(String url){
        if(!url.startsWith("https://"))return;
        minecraft.execute(()->{if(minecraft.screen==this)ConfirmLinkScreen.confirmLinkNow(this,url);});
    }
    @Override public void render(GuiGraphics g,int mouseX,int mouseY,float delta){
        var palette=AstraConfig.colour();g.fill(0,0,width,height,palette.background);
        float titleScale=Math.min(1,Math.max(1,width-240)/(float)Math.max(1,font.width(Ui.heading("KRILLION.IO"))));
        g.pose().pushMatrix();g.pose().translate(12,16);g.pose().scale(titleScale,titleScale);Ui.animated(g,font,Ui.heading("KRILLION.IO"),0,0,0xFFFFFFFF);g.pose().popMatrix();
        Ui.round(g,9,41,viewWidth()+2,viewHeight()+2,5,palette.border);
        if(browser!=null && browser.getTextureView()!=null){
            // Submit a genuine textured quad; a coloured rectangle has no browser UV coordinates.
            var setup=net.minecraft.client.gui.render.TextureSetup.singleTexture(browser.getTextureView(),com.mojang.blaze3d.systems.RenderSystem.getSamplerCache().getClampToEdge(com.mojang.blaze3d.textures.FilterMode.LINEAR));
            g.guiRenderState.submitGuiElement(new net.minecraft.client.gui.render.state.BlitRenderState(RenderPipelines.GUI_TEXTURED,setup,new org.joml.Matrix3x2f(g.pose()),10,42,10+viewWidth(),42+viewHeight(),0,1,0,1,0xFFFFFFFF,g.scissorStack.peek()));
        }else{
            g.fill(10,42,10+viewWidth(),42+viewHeight(),palette.panelBottom);
            String progress=startup==null?"Preparing browser...":failed?"Browser unavailable":startup.getStage().name().toLowerCase(java.util.Locale.ROOT).replace('_',' ');
            if(startup!=null && startup.getPercentage()>=0 && !failed)progress+=" / "+Math.round(startup.getPercentage())+"%";
            Ui.centered(g,font,progress,width/2,height/2-12,1,0xFFE0E0E5);
            Ui.centered(g,font,"First use downloads the browser components.",width/2,height/2+12,.8f,0xFFB8B8C0);
        }
        String status=error.isBlank()?"Live krillion.io / internet required / Esc to return":error;
        float textScale=Math.min(.8f,(width-24f)/Math.max(1,font.width(Ui.text(status))));
        g.pose().pushMatrix();g.pose().translate(12,height-15);g.pose().scale(textScale,textScale);Ui.animated(g,font,status,0,0,error.isBlank()?0xFFBDBDC5:0xFFFFB3BE);g.pose().popMatrix();
        super.render(g,mouseX,mouseY,delta);
    }
    private boolean inside(double x,double y){return x>=10 && x<10+viewWidth() && y>=42 && y<42+viewHeight();}
    private int px(double x){return (int)Math.round((x-10)*minecraft.getWindow().getGuiScale());}
    private int py(double y){return (int)Math.round((y-42)*minecraft.getWindow().getGuiScale());}
    private MouseButtonEvent translated(MouseButtonEvent e){return new MouseButtonEvent(px(e.x()),py(e.y()),e.buttonInfo());}
    @Override public boolean mouseClicked(MouseButtonEvent e,boolean doubled){if(super.mouseClicked(e,doubled))return true;if(browser==null||!inside(e.x(),e.y()))return false;draggingBrowser=true;browser.onMouseClicked(translated(e),doubled);browser.setFocus(true);return true;}
    @Override public boolean mouseReleased(MouseButtonEvent e){if(browser!=null&&draggingBrowser){draggingBrowser=false;browser.onMouseReleased(translated(e));return true;}return super.mouseReleased(e);}
    @Override public void mouseMoved(double x,double y){if(browser!=null&&(inside(x,y)||draggingBrowser))browser.onMouseMoved(px(x),py(y));super.mouseMoved(x,y);}
    @Override public boolean mouseDragged(MouseButtonEvent e,double dx,double dy){if(browser!=null&&draggingBrowser){browser.onMouseMoved(px(e.x()),py(e.y()));return true;}return super.mouseDragged(e,dx,dy);}
    @Override public boolean mouseScrolled(double x,double y,double dx,double dy){if(browser!=null&&inside(x,y)){browser.onMouseScrolled(px(x),py(y),dy);return true;}return super.mouseScrolled(x,y,dx,dy);}
    @Override public boolean keyPressed(KeyEvent e){if(e.key()==GLFW.GLFW_KEY_ESCAPE||e.key()==GLFW.GLFW_KEY_RIGHT_SHIFT){onClose();return true;}if(browser!=null){browser.onKeyPressed(e);return true;}return super.keyPressed(e);}
    @Override public boolean keyReleased(KeyEvent e){if(browser!=null){browser.onKeyReleased(e);return true;}return super.keyReleased(e);}
    @Override public boolean charTyped(CharacterEvent e){if(browser!=null){browser.onCharTyped(e);return true;}return super.charTyped(e);}
    @Override public void onClose(){minecraft.setScreen(parent);}
    @Override public void removed(){
        draggingBrowser=false;
        if(browser!=null){browser.close();browser=null;}
        if(ownedClient!=null){ownedClient.dispose();ownedClient=null;}
    }
}
