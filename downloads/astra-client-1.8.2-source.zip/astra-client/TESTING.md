# Astra Client 1.8.2 validation

- Built with Java 21 for Minecraft 1.21.11 / Fabric Loader 0.19.3.
- Removed the standalone Music category, its music-volume and mute controls, and the unused restoreMusic preference. Native Minecraft sound settings are untouched.
- Opened the real Minecraft client with a separate development-only chest fixture containing 54 named items and multiline lore (90 rendered slots including player inventory).
- Measured the same chest before/after the rendering change, hovering one item and sweeping across all 54 items. The test fixture counted GuiRenderState.submitGuiElement submissions per frame; these are GUI elements, not GPU draw calls or a universal FPS measurement.

| Scenario | Before elements/frame | After elements/frame |
| --- | ---: | ---: |
| Pointer outside slots | 8651 | 868 |
| Hover one item | 8810 | 881 |
| Sweep across items | 8810 | 881 |

The hover scenario submitted 90% fewer GUI elements. This is a diagnostic measurement from a software-rendered Linux development environment, not a hardware FPS guarantee. Item/tooltip content, styles and rounded corners were visually compared.

- Checked cached sprites after F3+T resource reload. No missing sprites or metadata errors appeared, and the tooltip remained opaque over items.
- Navigated all seven remaining categories, including Spotify HUD and General. Verified the existing Spotify HUD theme preference remains saved.
- The atlas sprites use fixed/stretch and stretched-nine-slice scaling; stretch_inner is explicitly enabled to avoid tiling the small panel centre into many quads.
- The optional Python/Pillow asset generator is included; Pillow is not a Minecraft runtime dependency.

The chest fixture and performance instrumentation are outside the project and excluded from the jar/source archive. Spotify playback and lyric handling are unchanged; live Windows Spotify remains unverified from this Linux host.

## Menu transitions and reactive scene (1.7.0)

- Built on Java 21 and exercised the title screen and a real singleplayer world with Mod Menu installed, without a media/performance fixture.
- Verified the title Reactive Background toggle saves and causes visible scene/background movement; the world-menu toggle reads the same saved preference.
- Checked the exact requested description and controls fit below Menu Background on Visuals.
- Exercised all seven categories, Spotify customisation, FOV input and the shared reactive toggle after page transitions.
- Checked open/close paths through Right Shift, Escape and X. Captured transition frames and rapid category retargeting; verified the final page remains usable.
- Disabled Smooth animations and compared static Astra background captures: no movement. Closing/reopening and category changes are immediate with the preference Off.
- Menu tween tests covered elapsed time, smooth midpoint, reversals, settling without overshoot, reduced motion, frame-rate independence and a long frame spanning the page-swap boundary.
- Rechecked rapid page retargeting after the long-frame fix by toggling a control on the final HUD page; it remained interactive.
- Checked Normal title mode with the optional reactive overlay and a 640×480 title window. Main controls and the new panel no longer overlap, and the compact title toggle saves correctly.

Inventory caching from 1.6.1 is preserved. Live Windows Spotify remains unverified; that bridge is unchanged in this release.

## Essentials, badge and motion (1.8.0)

- Java 21 clean build for Minecraft 1.21.11 and Fabric Loader 0.19.3, with the original MIT FreeLook 1.6.0 nested dependency.
- Opened a real singleplayer world with Mod Menu, loaded saved preferences, and navigated the renamed Essentials page. No client/mixin or atlas loading errors appeared.
- Captured Fake Media beside the local player's name in both rear and front F5 views. First person hides it. It changes only the local render state's text and attachment, never the entity's name/team or network state.
- Exercised Freelook enable, keyboard binding (B), Escape cancellation, Delete unbinding, middle-mouse binding, rebind and saved configuration/native options. No crash opening Right Shift.
- A separate development-only observer recorded real player and camera state while synthesizing key/mouse input. In rear F5 view, held B moved the camera from yaw/pitch 0/0 to 100/90 while the player's yaw/pitch remained 0/0 and position remained (8.3740336928, 70, 10.9076492264). Release restored camera 0/0. Camera distance stayed approximately 4 blocks in open space. First-person input retained the native camera/player relationship.
- Upstream FreeLook supports rear third person; front-facing third person is gated off as well as first person. The integration clears upstream state on menus, disabled preference, lost focus or unsupported perspective. Native Camera placement/collision code is retained; no detached/free camera is implemented.
- Re-ran MenuTween elapsed-time, no-overshoot, reversal, settling, reduced-motion and frame-rate-independence checks after changing to quintic easing.
- Verified the new rounded-mask atlas assets render in Minecraft and compacted Visuals controls to keep Fake Media within the background card. Inventory slot/tooltip atlas rendering from the previous release is retained.

The input/state observer is outside the project and excluded from the distributed files. These checks establish the implemented camera behaviour, not server approval or a hardware FPS claim. Live Windows Spotify is unchanged and remains unverified on this Linux host.

Final runtime checks also passed fresh camera-state activation after opening/closing the menu, disabling Freelook while testing mouse input, Fake Media on/off and F1 visibility, reset-to-defaults, and the 640×480 client layout. The final nested-jar hash matches the original FreeLook artifact exactly; both MIT notice and badge/round-mask assets are present.

## Freelook activation and Escape clearing (1.8.1)

- Built the 1.8.1 release jar with Java 21. Ran that packaged, remapped jar with Fabric Loader 0.19.3, Fabric API and its actual nested FreeLook dependency using Loom's production client runner. A separately remapped observation fixture was loaded only for testing; it is excluded from the release and source archive.
- Held a real keyboard bind from FIRST_PERSON, THIRD_PERSON_BACK and THIRD_PERSON_FRONT. All entered rear third-person Freelook and returned to the exact prior perspective after release. Camera yaw changed by 100 degrees under the upstream clamp while player yaw, pitch and position stayed constant. Native camera collision/placement remains intact.
- Repeated activation with a middle-mouse bind. Confirmed disabled Freelook and an unbound mapping cannot activate it.
- Opened the client menu during a held bind and verified perspective restoration. Loss of window focus also restored the prior view. Manual F5 changes during a hold were respected on release.
- Bound B, reopened key capture and pressed Escape. Verified the menu stayed open, the label became `Set a key: Not bound`, custom configuration saved `key.keyboard.unknown`, and B no longer activated Freelook. Escape outside capture still closes the client menu.
- Rechecked the Essentials layout and updated instructions in the actual production client. No mod/mixin errors occurred.

- Restarted the production jar with Escape deliberately saved in both Astra JSON and Minecraft Controls. Startup migrated both files to the native unknown key; Essentials displayed `Not bound`, remained usable, and Freelook stayed inactive.

## Supplied Celibistrial Freelook replacement (1.8.2)

- Removed the jmilthedude FreeLook dependency and all net.ninjadev integration code. Built against and nested the exact user-uploaded `freelook-1.2.8 (1).jar`, SHA-256 `fe1a32d9e4b8894122f52985c9d81b5cefa7bb7b67e67d17e8d03c495f8ba1e4`. Only this Freelook JAR is nested in the release.
- Kept its camera and entity-turn mixins unchanged. Astra accesses its real registered activation key and uses its native stop method for menu/focus/disabled/unbound guards. The native server block list and blocked flag are respected; no blocked-state override was introduced.
- Built on Java 21 and launched the packaged, remapped 1.8.2 JAR in the production Minecraft 1.21.11 / Fabric Loader 0.19.3 runner with Fabric API. Confirmed the nested mod loads as Freelook 1.2.8, with no previous Freelook implementation.
- Tested saved Astra binding B against a deliberately conflicting saved native default Left Alt: the final native activation mapping was B after startup. Initialization runs after the supplied mod registers its mappings and again after Minecraft finishes loading its options.
- Exercised first-person, rear F5 and front F5 holds. Camera yaw moved while player yaw/pitch and position stayed constant. Release restored each original perspective and facing. The uploaded mod retains its native F5 perspective behaviour. Rear camera distance remained about 4 blocks; terrain shortened the front-view camera distance to about 1.5 blocks through normal collision handling.
- Repeated activation with a middle-mouse binding. Verified enable/disable, active menu interruption, loss of window focus, clearing to unbound, Escape keeping the picker screen open while clearing, and Escape outside capture closing Astra normally.
- Exercised the mod's blocked state during an active hold: native Freelook stopped, the previous perspective returned, further presses stayed inactive, and Essentials displayed the blocked-server notice. Unblocking the development fixture restored normal behaviour. This simulates the upstream runtime flag; the actual server list was never cleared or modified.
- Exercised native toggle mode and opened the supplied mod's actual Freelook settings page with M. The native mode/perspective/server controls remain provided by that mod.
- Retained the original JAR metadata/license verbatim. Included the matching upstream 1.2.8 source and build scripts at commit e9415883af0fb031a0f3bb49c4e701e9b575bb8f in the complete source archive, alongside Astra's integration.

The separately remapped state observer and synthetic-input helpers are excluded from both distributable archives. Runtime checks were performed on the Linux test host; live Windows Spotify remains unchanged and unverified here. Server approval and hardware FPS are not claimed.
