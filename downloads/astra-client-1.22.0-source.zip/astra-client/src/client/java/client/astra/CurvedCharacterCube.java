package client.astra;

import com.mojang.blaze3d.vertex.PoseStack;
import com.mojang.blaze3d.vertex.VertexConsumer;
import net.minecraft.client.model.geom.ModelPart;
import net.minecraft.core.Direction;
import java.util.EnumSet;

/** Native articulated primitive with a curved surface instead of six flat faces. */
final class CurvedCharacterCube extends ModelPart.Cube {
    private final float[] mesh;
    private final float u,v;
    CurvedCharacterCube(CharacterMesh.Mesh shape,int color){
        super(0,0,shape.minX(),shape.minY(),shape.minZ(),shape.maxX()-shape.minX(),shape.maxY()-shape.minY(),shape.maxZ()-shape.minZ(),0,0,0,false,512,512,EnumSet.allOf(Direction.class));
        mesh=shape.vertices().clone();for(int i=0;i<mesh.length;i+=6){mesh[i]/=16;mesh[i+1]/=16;mesh[i+2]/=16;}
        u=(color%8*64+32)/512f;v=(color/8*64+32)/512f;
    }
    @Override public void compile(PoseStack.Pose pose,VertexConsumer consumer,int light,int overlay,int tint){
        for(int i=0;i<mesh.length;i+=6)consumer.addVertex(pose,mesh[i],mesh[i+1],mesh[i+2]).setColor(tint).setUv(u,v).setOverlay(overlay).setLight(light).setNormal(pose,mesh[i+3],mesh[i+4],mesh[i+5]);
    }
}
