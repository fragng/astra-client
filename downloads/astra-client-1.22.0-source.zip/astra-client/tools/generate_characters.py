"""Author original rounded character surfaces, swatch atlas and sidebar icon.
No downloaded models or pictures are used. Run with Python 3 (stdlib only).
"""
from pathlib import Path
import json,struct,zlib
ROOT=Path(__file__).resolve().parents[1]/'src/main/resources/assets/astra-client'
COLORS={'yellow':'F5D53C','sponge_shadow':'C5A226','white':'FFF8E9','black':'171A20','blue':'53A9ED','pink':'ED97AD','brown':'8B542E','red':'D43732','dark_red':'9B2928','cream':'F5D5A2','green':'A5D55C','purple':'A168BB','aqua':'87B7A7','aqua_dark':'568C83','eye_red':'9D4A37','shirt_brown':'A97C42','krab_red':'D74C46','light_blue':'A0CFE6','pants_blue':'647DAE','belt':'513E36','gold':'F5CE59','sandy_brown':'A87546','sandy_light':'C99C65','suit':'E7E6DF','suit_shadow':'A5ADB5','glass':'B9E5EC24','glass_edge':'9AC5D6','flower':'ED80C2','skin':'E2B58F','skin_shadow':'C78F69','hair':'61402E','hair_light':'79543B','denim':'344C6A','shoe':'34363E','sole':'DBDED9','mouth':'813B32','sock_blue':'72A8CA','headset':'272932','headset_trim':'4C5362'}
names=list(COLORS);palette=[COLORS[n] for n in names];assert len(palette)<=64
models={}
PIVOTS={'head':[0,0,0],'body':[0,0,0],'right_arm':[-5,2,0],'left_arm':[5,2,0],'right_leg':[-1.9,12,0],'left_leg':[1.9,12,0]}
def actor(name,spread=5,head_y=0):
 parts={n:{'pivot':list(p),'boxes':[]} for n,p in PIVOTS.items()};parts['head']['pivot'][1]=head_y;parts['right_arm']['pivot'][0]=-spread;parts['left_arm']['pivot'][0]=spread
 models[name]={'parts':parts};return parts
def box(parts,bone,x,y,z,w,h,d,color,power=.35,taper=0,ring=False,band=.28):
 assert min(w,h,d)>0
 parts[bone]['boxes'].append({'from':[x,y,z],'size':[w,h,d],'color':names.index(color),'power':power,**({'taper':taper} if taper else {}),**({'ring':True,'band':band} if ring else {})})
def global_head(p,x,y,z,w,h,d,c,power=.8,taper=0,ring=False,band=.28):box(p,'head',x,y-p['head']['pivot'][1],z,w,h,d,c,power,taper,ring,band)
def eye(p,x,y,z,w=3,h=3,iris='black'):
 global_head(p,x,y,z,w,h,.75,'white',1);global_head(p,x+w*.35,y+h*.25,z-.22,w*.34,h*.55,.4,iris,1)
def limb_pair(p,bone,y,h,w,d,c):
 for side in ['right','left']:box(p,side+'_'+bone,-w/2,y,-d/2,w,h,d,c,.85)
# SpongeBob: projecting eyes/nose/teeth, porous square sponge, shirt/shorts and shoes.
p=actor('spongebob',8,5);global_head(p,-7,-7,-3,14,12,6,'yellow',.19)
for x,y in [(-6,-6),(-6,1),(4,-6),(5,2),(-4,3),(3,3)]:global_head(p,x,y,-3.15,1.4,1,.22,'sponge_shadow')
for x in [-6.5,5.2]:
 for y in [-5,0]:global_head(p,x,y,2.8,1.2,1.5,.35,'sponge_shadow')
for x in [-4.7,.7]:
 global_head(p,x,-5,-3.5,4,4.7,1.25,'white',1);global_head(p,x+.9,-4,-4.1,2.2,2.5,.85,'blue',1);global_head(p,x+1.5,-3.7,-4.5,1,1.7,.6,'black',1)
 for dx in [.4,1.8,3.2]:global_head(p,x+dx,-6,-3.4,.45,1.3,.45,'black')
global_head(p,-.85,-2.4,-5,1.7,3,2.2,'yellow',1);global_head(p,-3,1,-3.3,6,1.6,.4,'mouth')
for x in [-1.9,.2]:global_head(p,x,1.2,-3.8,1.7,1.9,.5,'white')
box(p,'body',-7,5,-3,14,2,6,'white');box(p,'body',-7,7,-3,14,5,6,'brown');box(p,'body',-.65,5.4,-3.4,1.3,3.4,.45,'red')
for x in [-5,-1.5,2]:box(p,'body',x,8,-3.2,2.5,.5,.3,'black')
limb_pair(p,'arm',0,9,1.6,1.6,'yellow')
for side in ['right','left']:
 a=side+'_arm';box(p,a,-1.7,8,-1.3,3.4,2.3,2.6,'yellow',.8)
 for x in [-1.8,-.5,.8]:box(p,a,x,10,-1,1,1.8,1.2,'yellow',1)
 l=side+'_leg';box(p,l,-.9,0,-.9,1.8,7,1.8,'yellow',.9);box(p,l,-1.1,6,-1.1,2.2,4.5,2.2,'white');box(p,l,-1.15,7,-1.15,2.3,.45,2.3,'red');box(p,l,-1.15,8,-1.15,2.3,.45,2.3,'sock_blue');box(p,l,-1.9,10,-3.1,3.8,2,5,'black',.75)
# DrDonutt: stylized real-life human with short brown hair, headphones and white T-shirt.
p=actor('drdonutt',5)
global_head(p,-3.8,-8,-3.8,7.6,8,7.6,'skin',.72)
# Overlapping rounded locks replace the flat, cube-shaped haircut.
global_head(p,-4,-8.8,-3.7,8,3.7,7.6,'hair',.75)
for x,y,z,w,h,d in [(-3.9,-8,-4,3.5,2.8,2.8),(-1.2,-8.5,-4.1,3.5,2.9,3),(1,-8,-3.9,3.1,2.5,2.7)]:global_head(p,x,y,z,w,h,d,'hair_light',1)
for x in [-4.05,3.05]:global_head(p,x,-6.2,.2,1,4,3.6,'hair',1)
for x in [-2.7,.8]:eye(p,x,-4.6,-4.35,1.9,1.2);global_head(p,x,-5.5,-4.35,2,.4,.3,'hair')
global_head(p,-.6,-3.7,-5,1.2,2,1.2,'skin_shadow');global_head(p,-1.5,-1.3,-4.2,3,.4,.25,'skin_shadow')
for x in [-5.25,4.05]:global_head(p,x,-5.8,-.8,1.2,4,3.1,'headset',.8);global_head(p,x,-4.9,-1.1,1.2,2.1,.6,'headset_trim')
global_head(p,-4.7,-9,-.5,9.4,.8,1.5,'headset',.7);box(p,'body',-4,0,-2,8,12,4.5,'white',.42);box(p,'body',-1.7,0,-2.15,3.4,1.4,.25,'skin')
for side in ['right','left']:
 a=side+'_arm';box(p,a,-2,-2,-2,4,4.5,4,'white');box(p,a,-1.7,2,-1.7,3.4,8,3.4,'skin',.8);box(p,a,-1.9,8.7,-2,3.8,2,3.8,'skin_shadow',1)
 l=side+'_leg';box(p,l,-2,0,-2,4,10,4,'denim');box(p,l,-2,9.3,-3,4,2.2,5.3,'shoe');box(p,l,-2.1,11.1,-3.1,4.2,.9,5.5,'sole')
# Patrick: tapered star head, rounded belly, lime shorts and purple flower patches.
p=actor('patrick',7)
global_head(p,-2.7,-8.5,-2.6,5.4,10,5.2,'pink',1,.62)
eye(p,-2.4,-3,-3.4,2,2.7);eye(p,.4,-3,-3.4,2,2.7);global_head(p,-1.5,.2,-3.2,3,.45,.4,'mouth')
box(p,'body',-6.9,-1.3,-4,13.8,13.3,8,'pink',1,.18)
box(p,'body',-6.9,7.6,-4.15,13.8,4.5,8.3,'green',.55,-.12)
for x,y in [(-5,9),(-1,8.8),(3.3,9.6)]:
 box(p,'body',x,y,-4.25,2,1.3,.25,'purple',.8);box(p,'body',x+.6,y-.5,-4.3,.7,2.3,.3,'purple',.8)
for side in ['right','left']:
 a=side+'_arm';box(p,a,-2,-.4,-2,4,11.4,4,'pink',1,-.5)
 l=side+'_leg';box(p,l,-2.7,0,-2.5,5.4,3,5,'green',.7);box(p,l,-2.2,2,-2.1,4.4,8,4.2,'pink',1,-.18);box(p,l,-2.5,9,-3.2,5,3,5.3,'pink',1)
# Squidward: smooth bulbous head, drooping dimensional nose, brown polo and tentacles.
p=actor('squidward',5)
global_head(p,-5.5,-8.5,-4,11,7,8,'aqua',1);global_head(p,-4.5,-3.5,-3.4,8.5,4.5,6.8,'aqua',.85)
for x in [-4,-.1]:
 eye(p,x,-3.6,-3.85,3.6,2.8,'eye_red');global_head(p,x,-4,-4.1,3.6,1.4,.45,'aqua_dark')
global_head(p,-1.4,-2.2,-6.8,2.8,6,3.7,'aqua',1);global_head(p,-2.5,.9,-3.5,5,.4,.4,'aqua_dark')
box(p,'body',-1.6,0,-1.6,3.2,3.5,3.2,'aqua');box(p,'body',-4,3,-2.6,8,8,5.2,'shirt_brown',.6)
for side in ['right','left']:
 a=side+'_arm';box(p,a,-1.7,-.5,-1.8,3.4,3.5,3.6,'shirt_brown');box(p,a,-1,2,-1,2,8,2,'aqua',1);box(p,a,-1.7,9,-1.3,3.4,2.5,2.6,'aqua')
 l=side+'_leg';box(p,l,-1.1,-1,-1.1,2.2,11,2.2,'aqua',.9);box(p,l,-1.8,9,-4,3.6,3,5.5,'aqua',1)
# Mr. Krabs: eye stalks, round crab body, belt/trousers and separated solid pincers.
p=actor('mr_krabs',8)
global_head(p,-5,-1,-3.5,10,4,7,'krab_red',.85)
for x in [-3.3,1.8]:global_head(p,x,-7.5,-1.2,1.5,7,1.5,'krab_red',1);eye(p,x-.35,-8.5,-1.7,2.2,3.2)
global_head(p,-1.5,0,-4.2,3,1.5,1.4,'krab_red');global_head(p,-3.4,1.5,-3.8,6.8,.6,.45,'mouth')
box(p,'body',-7,2,-4.2,14,8.5,8.4,'light_blue',.8);box(p,'body',-6.6,10,-4,13.2,2.3,8,'pants_blue');box(p,'body',-7,9.4,-4.3,14,1.2,8.6,'belt');box(p,'body',-1.1,9.2,-4.6,2.2,1.6,.45,'gold')
for side in ['right','left']:
 a=side+'_arm';box(p,a,-1.8,-.5,-1.8,3.6,3.5,3.6,'light_blue');box(p,a,-1.4,2,-1.4,2.8,5.5,2.8,'krab_red');box(p,a,-3.1,7,-2.1,6.2,4,4.2,'krab_red',1);box(p,a,-3.1,9,-2.1,2.3,3.2,4.2,'krab_red',.85);box(p,a,.8,9,-2.1,2.3,3.2,4.2,'krab_red',.85)
 l=side+'_leg';box(p,l,-1,0,-1,2,9.5,2,'krab_red',.85);box(p,l,-1.9,9,-3.4,3.8,3,5.4,'krab_red',1)
# Sandy: rounded squirrel, translucent bubble helmet, flower and fluffy tail.
p=actor('sandy',5.4)
global_head(p,-3.8,-6.6,-3.4,7.6,6.9,6.8,'sandy_brown',1)
for x in [-3.7,1.5]:global_head(p,x,-8.1,-1.3,2.2,2.4,1.9,'sandy_brown',1)
eye(p,-2.9,-4.9,-3.9,2.4,2.8);eye(p,.5,-4.9,-3.9,2.4,2.8);global_head(p,-2,-1.8,-4.5,4,2.1,1.4,'cream');global_head(p,-.7,-2.2,-5,1.4,1,.7,'black')
# A thin curved rim and transparent dome keep her face visible from every angle.
global_head(p,-5.7,-9,-5.2,11.4,11.4,.5,'glass_edge',1,ring=True,band=.2)
for x,y,w,h in [(4,-9.4,2.6,1.6),(3.2,-10.5,1.6,2.8),(5.3,-10.2,1.6,2.8)]:global_head(p,x,y,-3,w,h,.9,'flower')
global_head(p,4.5,-9.9,-3.5,1.1,1.1,1,'gold');box(p,'body',-4.4,0,-2.7,8.8,12,5.4,'suit',.65);box(p,'body',-4.9,0,-3.1,9.8,1.5,6.2,'suit_shadow');box(p,'body',-2,3,-3.2,4,4,.6,'gold');box(p,'body',-.7,3.7,-3.6,1.4,2.5,.6,'sandy_brown');box(p,'body',-4.5,10,-2.8,9,1,5.6,'red')
for x,y,z,w,h,d in [(-2.9,5,2.4,5.8,8,5.5),(-3.3,-1,5.2,6.6,10,5),(-2.4,-3,6.2,4.8,5,3.8)]:box(p,'body',x,y,z,w,h,d,'sandy_brown',1)
for side in ['right','left']:
 a=side+'_arm';box(p,a,-1.8,-2,-1.8,3.6,10,3.6,'suit',.8);box(p,a,-2,7,-2,4,1,4,'red');box(p,a,-2,8,-2,4,2.6,4,'suit_shadow')
 l=side+'_leg';box(p,l,-1.8,0,-1.8,3.6,9,3.6,'suit',.7);box(p,l,-2.1,8,-3,4.2,3.2,5.3,'suit',.8);box(p,l,-2.15,11,-3.05,4.3,1,5.4,'red')
global_head(p,-5.6,-9,-5.1,11.2,11.3,10.5,'glass',1)
# Shared solid-color texture atlas: a 64px tile per color accommodates cube UV unfolding.
size=512;scan=bytearray()
for y in range(size):
 scan.append(0)
 for x in range(size):
  i=(y//64)*8+x//64;c=palette[i] if i<len(palette) else 'FFFFFF';scan.extend(bytes.fromhex(c)+(b'\xff' if len(c)==6 else b''))
def chunk(tag,data):return struct.pack('>I',len(data))+tag+data+struct.pack('>I',zlib.crc32(tag+data)&0xffffffff)
png=b'\x89PNG\r\n\x1a\n'+chunk(b'IHDR',struct.pack('>IIBBBBB',size,size,8,6,0,0,0))+chunk(b'IDAT',zlib.compress(scan,9))+chunk(b'IEND',b'')
texture=ROOT/'textures/entity/characters.png';texture.parent.mkdir(parents=True,exist_ok=True);texture.write_bytes(png)
(ROOT/'textures/item/character_palette.png').write_bytes(png)
(ROOT/'characters/models.json').write_text(json.dumps({'palette':palette,'models':models},indent=2)+'\n')
# Matching 3D GUI previews, scaled to fit the native item-model element limits.
def preview(name,parts,icon=False):
 elements=[];bones=['head'] if icon else list(parts)
 for bone in bones:
  part=parts[bone]
  for b in part['boxes']:
   x,y,z=b['from'];w,h,d=b['size'];px,py,pz=part['pivot'];k=.64
   lo=[8+(x+px)*k,(24-y-py-h)*k,8+(z+pz)*k];hi=[lo[0]+w*k,lo[1]+h*k,lo[2]+d*k]
   tile=b['color'];u=(tile%8)*2+.2;v=(tile//8)*2+.2
   faces={face:{'uv':[u,v,u+.3,v+.3],'texture':'#body'} for face in ['north','south','west','east','up','down']}
   elements.append({'from':lo,'to':hi,'faces':faces})
 ident=name+('_icon' if icon else '')
 model={'textures':{'body':'astra-client:item/character_palette','particle':'astra-client:item/character_palette'},'elements':elements,'gui_light':'front','display':{'gui':{'rotation':[8,205,0],'translation':[0,-1 if not icon else -13,0],'scale':[.78 if not icon else 1.6]*3}}}
 # GUI rotation looks at the face (negative Z) with one side visible.
 (ROOT/'models/character').mkdir(parents=True,exist_ok=True);(ROOT/'items/character').mkdir(parents=True,exist_ok=True)
 (ROOT/'models/character'/f'{ident}.json').write_text(json.dumps(model,separators=(',',':'))+'\n')
 (ROOT/'items/character'/f'{ident}.json').write_text(json.dumps({'model':{'type':'minecraft:model','model':'astra-client:character/'+ident}})+'\n')
for name,spec in models.items():preview(name,spec['parts'])
preview('spongebob',models['spongebob']['parts'],True)
print('Authored',len(models),'curved characters,',sum(len(p['boxes']) for m in models.values() for p in m['parts'].values()),'rounded primitives and',len(palette),'atlas colors.')
