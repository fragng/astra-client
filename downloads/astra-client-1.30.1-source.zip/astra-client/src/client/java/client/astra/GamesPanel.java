package client.astra;

import net.minecraft.client.Minecraft;
import net.minecraft.client.gui.GuiGraphics;
import net.minecraft.client.gui.screens.ConfirmLinkScreen;
import net.minecraft.client.resources.sounds.SimpleSoundInstance;
import net.minecraft.sounds.SoundEvent;
import net.minecraft.resources.Identifier;
import java.time.*;
import java.time.format.DateTimeFormatter;
import java.util.*;

/** The game is a menu activity; leaving it stops auto-opening without rerolling a draw. */
public final class GamesPanel {
    public enum Page {HOME,OPENING,CONTENTS,CLAIMS,WORDLE,KRILLION}
    private static final DateTimeFormatter DATE=DateTimeFormatter.ofPattern("dd MMM HH:mm").withZone(ZoneId.systemDefault());
    private final FreeGamesPanel free=new FreeGamesPanel();
    public boolean key(ClientMenuScreen s,int key){return free.key(s,page,key);}
    public boolean character(int codepoint){return free.character(page,codepoint);}
    public void closed(){stopAuto();free.closed();}
    private Page page=Page.HOME;private CaseSpin spin;private String accountHash="";private boolean auto,announced;private long nextAuto,lastTickSound,celebrationStarted;private int claimPage,lastCard=-1;
    public Page page(){return page;}
    public String title(){return switch(page){case HOME->"GAMES";case OPENING->"Case Opening";case CONTENTS->"Case Contents";case CLAIMS->"My Claims";case WORDLE->"Wordle";case KRILLION->"Krillion";};}
    public void change(Page next){if(next!=Page.OPENING)stopAuto();page=next;}
    public void stopAuto(){auto=false;}
    public boolean auto(){return auto;}
    public boolean opening(){return spin!=null&&!spin.finished(System.nanoTime());}
    private CaseLedger.Draw result(){return spin!=null?spin.draw:CaseGames.data()==null?null:CaseGames.data().lastDraw;}
    public boolean celebrating(){var data=CaseGames.data();return page==Page.OPENING&&!opening()&&result()!=null&&result().reward()!=CaseReward.NOTHING&&!result().duplicate()&&data!=null&&!result().id().equals(data.seenWin);}
    private boolean major(){return !opening()&&result()!=null&&result().reward().ticketClaim;}
    private void sound(String event,float pitch,float volume){if(AstraConfig.sounds)Minecraft.getInstance().getSoundManager().play(SimpleSoundInstance.forUI(SoundEvent.createVariableRangeEvent(Identifier.parse(event)),pitch,volume));}
    private void landingSound(boolean win){
        sound("minecraft:block.amethyst_block.chime",1.25f,.38f);
        if(win)sound("minecraft:entity.player.levelup",1.1f,.3f);
    }
    private void open(ClientMenuScreen screen){
        if(opening()||celebrating())return;var draw=CaseGames.open();if(draw==null){auto=false;screen.refresh();return;}
        long now=System.nanoTime();spin=new CaseSpin(draw,now);announced=false;celebrationStarted=0;lastCard=spin.cardAt(now,AstraConfig.animations);lastTickSound=now;nextAuto=now+(long)(CaseSpin.AUTO_SECONDS*1e9);screen.refresh();
    }
    public void tick(ClientMenuScreen screen,boolean visible){
        free.tick(screen,page,visible);
        var data=CaseGames.data();String identity=data==null?"":data.accountHash;
        if(!identity.equals(accountHash)){accountHash=identity;spin=data!=null&&data.lastDraw!=null?CaseSpin.restore(data.lastDraw,System.nanoTime(),CaseGames.now()):null;auto=false;announced=spin!=null&&spin.finished(System.nanoTime());celebrationStarted=0;screen.refresh();}
        if(!visible||page!=Page.OPENING){stopAuto();return;}
        long now=System.nanoTime();
        if(page==Page.OPENING&&spin!=null){
            if(!spin.finished(now)&&AstraConfig.animations){
                int current=spin.cardAt(now,true);
                if(current!=lastCard&&now-lastTickSound>75_000_000L){lastCard=current;lastTickSound=now;sound("minecraft:block.note_block.hat",1.6f,.12f);}
            }
            if(spin.finished(now)&&!announced){announced=true;landingSound(spin.draw.reward()!=CaseReward.NOTHING&&!spin.draw.duplicate());screen.refresh();}
        }
        if(auto && (CaseGames.remaining()==0||!CaseGames.status().isEmpty())){stopAuto();screen.refresh();}
        if(celebrating()){
            if(celebrationStarted==0){celebrationStarted=now;screen.refresh();}
            if(auto&&now-celebrationStarted>6_000_000_000L){CaseGames.acknowledgeWin(result().id());celebrationStarted=0;screen.refresh();}
        }
        if(auto&&page==Page.OPENING&&!opening()&&!celebrating()&&now>=nextAuto)open(screen);
    }
    private void discord(ClientMenuScreen screen){ConfirmLinkScreen.confirmLinkNow(screen,ClientMenuScreen.PREMIUM_URL);}
    public void init(ClientMenuScreen s){
        if(page!=Page.HOME)s.control(new MenuButton(455,72,160,25,"Back to Games","Games",()->false,false,()->s.showGamePage(Page.HOME)));
        switch(page){
            case HOME->{
                s.control(new MenuButton(153,127,224,45,"Wordle","Wordle",()->false,false,()->s.showGamePage(Page.WORDLE)));
                s.control(new MenuButton(389,127,226,45,"Krillion","Krillion",()->false,false,()->s.showGamePage(Page.KRILLION)));
                s.control(new MenuButton(153,230,462,39,"Case Opening","Case Opening",()->false,false,()->s.showGamePage(Page.OPENING)));
                s.control(new MenuButton(153,304,144,28,"My Claims","",()->false,false,()->s.showGamePage(Page.CLAIMS)));
                s.control(new MenuButton(311,304,144,28,"Case Contents","Case Opening",()->false,false,()->s.showGamePage(Page.CONTENTS)));
                s.control(new MenuButton(469,304,146,28,"Rare Cosmetics","Settings",()->false,false,()->s.openCaseCosmetics()));
            }
            case WORDLE,KRILLION->free.init(s,page);
            case OPENING->{
                if(celebrating()){
                    s.control(new MenuButton(183,315,125,30,"Continue","",()->false,false,()->{CaseGames.acknowledgeWin(result().id());celebrationStarted=0;s.refresh();}));
                    s.control(new MenuButton(318,315,143,30,result().reward().ticketClaim?"Claim in Discord":result().reward()==CaseReward.INFINITE_CASES?"Keep Opening":"Equip Cosmetic",result().reward().ticketClaim?"Buy Premium":"Settings",()->false,false,()->{CaseGames.acknowledgeWin(result().id());if(result().reward()==CaseReward.INFINITE_CASES){celebrationStarted=0;s.refresh();}else if(result().reward().ticketClaim)discord(s);else if(result().reward()==CaseReward.SKIN_TOTEM)s.openPersonalTotem();else s.openCaseCosmetics();}));
                    if(result().reward().ticketClaim)s.control(new MenuButton(471,315,115,30,"Copy Claim ID","",()->false,false,()->Minecraft.getInstance().keyboardHandler.setClipboard(result().id().toString())));
                    break;
                }
                s.control(new MenuButton(153,281,148,30,opening()?"OPENING...":"OPEN","Case Opening",()->false,false,()->{if(!auto)open(s);}).available(()->!opening()&&!auto&&CaseGames.remaining()>0&&CaseGames.status().isEmpty()));
                s.control(new MenuButton(313,281,144,30,"AUTO OPEN","",()->auto,true,()->{auto=!auto;if(auto&&!opening())nextAuto=System.nanoTime();s.refresh();}).available(()->CaseGames.remaining()>0&&CaseGames.status().isEmpty()));
                s.control(new MenuButton(469,281,146,30,major()?"Claim in Discord":"Join Discord","Buy Premium",()->false,false,()->discord(s)));
                if(major())s.control(new MenuButton(507,250,108,21,"Copy Claim ID","",()->false,false,()->Minecraft.getInstance().keyboardHandler.setClipboard(result().id().toString())));
                s.control(new MenuButton(500,330,115,20,"View Contents","",()->false,false,()->s.showGamePage(Page.CONTENTS)));
            }
            case CONTENTS->s.control(new MenuButton(153,365,462,27,"Discord rewards: join and create a ticket","Buy Premium",()->false,false,()->discord(s)));
            case CLAIMS->{
                var claims=CaseGames.data()==null?List.<CaseLedger.Draw>of():CaseGames.data().claims;claimPage=Math.clamp(claimPage,0,Math.max(0,(claims.size()-1)/3));
                for(int i=0;i<3;i++){int index=claimPage*3+i;if(index>=claims.size())break;var claim=claims.get(index);s.control(new MenuButton(515,140+i*65,100,25,"Copy ID","",()->false,false,()->Minecraft.getInstance().keyboardHandler.setClipboard(claim.id().toString())));}
                s.control(new MenuButton(153,338,86,26,"< Previous","",()->false,false,()->{claimPage--;s.refresh();}).available(()->claimPage>0));
                s.control(new MenuButton(529,338,86,26,"Next >","",()->false,false,()->{claimPage++;s.refresh();}).available(()->(claimPage+1)*3<claims.size()));
                s.control(new MenuButton(251,338,266,26,"Join Discord / Open a Ticket","Buy Premium",()->false,false,()->discord(s)));
            }
        }
    }
    public void render(ClientMenuScreen s,GuiGraphics g){
        var font=Minecraft.getInstance().font;
        switch(page){
            case HOME->{
                small(g,"Pick a game and take a break.",153,103,.88f,0xFFC9B7E6);
                small(g,"Five letters / six guesses",153,183,.80f,0xFFC0B6D5);
                small(g,"Seven prompts / timed trivia",389,183,.80f,0xFFC0B6D5);
                small(g,"Wordle and Krillion: unlimited play / no prizes.",153,206,.80f,0xFFB5DAD5);
                small(g,CaseGames.balance(),153,278,.82f,0xFFFFDD87);small(g,CaseGames.refill(),389,278,.76f,0xFFB7AACA);
                small(g,"Bored? Have a Chance to win cool rewards for FREE!",153,346,.80f,0xFFC9B7E6);
                small(g,"Case prizes only. Your word-game scores award nothing.",153,369,.78f,0xFFB7A5CD);
                if(!CaseGames.status().isEmpty())small(g,CaseGames.status(),153,386,.65f,0xFFFFB39F);
            }
            case WORDLE,KRILLION->free.render(s,g,page);
            case OPENING->{
                s.text(g,CaseGames.balance(),153,111,0xFFFFD98B);s.text(g,CaseGames.refill(),389,111,0xFFB9A8CE);
                reel(g);var result=result();
                String title=opening()?"Opening your case...":result==null?"Ready when you are.":result.reward()==CaseReward.NOTHING?CaseReward.MISS_LINES[result.line()]:"You won: "+result.reward().title;
                if(!opening()&&result!=null&&result.reward()==CaseReward.NOTHING)CaseArt.nothing(g,153,237,145,30);
                else s.text(g,s.fitText(title,462),153,239,!opening()&&result!=null?result.reward().color:0xFFE0D1EF);
                String detail=opening()?"Reward previews / landing shows your result.":result==null?"Open a free case to begin.":result.reward().ticketClaim?"Join Discord and make a ticket to claim.":result.reward()==CaseReward.INFINITE_CASES?"Unlimited opens unlocked for this account.":result.reward().cosmetic()?result.duplicate()?"Already in your collection.":result.reward()==CaseReward.SKIN_TOTEM?"Unlocked in Customize Totem.":"Unlocked in Settings / Rare Cosmetics.":"Your next case is waiting.";
                if(!opening()&&result!=null&&result.reward()==CaseReward.NOTHING)small(g,CaseReward.MISS_LINES[result.line()],310,247,.80f,0xFFBFAED3);
                else small(g,detail,153,259,.86f,0xFFBFAED3);
                String status=!CaseGames.status().isEmpty()?CaseGames.status():auto?opening()?"Auto Open enabled":"Auto Open / next case in "+Math.max(0,(nextAuto-System.nanoTime()+999_999_999)/1_000_000_000)+"s":CaseGames.remaining()==0?"Your cases will refill automatically.":"";
                small(g,status,153,317,.78f,0xFFC3AECF);
                s.text(g,"Inside the case",153,337,0xFFE1C9F6);
                for(int i=0;i<CaseReward.CONTENTS.length;i++){var reward=CaseReward.CONTENTS[i];int x=153+i*66;Ui.round(g,x,355,60,36,7,0xB32C2542);CaseArt.icon(g,reward,x+3,358,16);small(g,reward.shortTitle,x+3,379,.56f,reward.color);}
                if(celebrating())celebration(s,g);
            }
            case CONTENTS->{
                s.text(g,"Rare finds / previews do not show probabilities.",153,104,0xFFC6B0DE);
                for(int i=0;i<CaseReward.CONTENTS.length;i++){
                    var reward=CaseReward.CONTENTS[i];int x=153+i%2*234,y=126+i/2*56;
                    Ui.round(g,x,y,226,50,9,0xFF77618F);Ui.gradient(g,x+1,y+1,224,48,8,0xFF39304F,0xFF201D35);CaseArt.icon(g,reward,x+9,y+9,29);
                    small(g,reward.title,x+47,y+9,.78f,reward.color);small(g,reward.ticketClaim?"Discord ticket claim":reward==CaseReward.INFINITE_CASES?"Unlimited opens / automatic":reward==CaseReward.SKIN_TOTEM?"Your own Minecraft skin":"Equip in Settings",x+47,y+29,.68f,0xFFBEADCE);
                }
            }
            case CLAIMS->{
                s.text(g,"Join our Discord and make a ticket with your Claim ID.",153,104,0xFFC6B0DD);
                var claims=CaseGames.data()==null?List.<CaseLedger.Draw>of():CaseGames.data().claims;
                if(claims.isEmpty()){s.card(g,142,129,484,178,"No claims yet","Case Opening");s.text(g,"Special prize wins will appear here.",163,178,0xFFC8B1DF);}
                for(int i=0;i<3;i++){int index=claimPage*3+i;if(index>=claims.size())break;var claim=claims.get(index);int y=129+i*65;Ui.round(g,153,y,462,55,9,0xD6322949);CaseArt.icon(g,claim.reward(),163,y+12,27);small(g,claim.reward().title,201,y+10,.85f,claim.reward().color);small(g,DATE.format(Instant.ofEpochMilli(claim.at()))+" / "+claim.id().toString().substring(0,8),201,y+31,.76f,0xFFBCA9CE);}
                small(g,"Keep your case history. Ticket rewards are reviewed in Discord.",153,379,.78f,0xFFBBA5CD);
            }
        }
    }
    private void celebration(ClientMenuScreen s,GuiGraphics g){
        var draw=result();var reward=draw.reward();var font=Minecraft.getInstance().font;
        Ui.round(g,146,110,476,281,15,0xE5101023);
        Ui.round(g,169,115,430,248,19,0x887E3D99);
        Ui.round(g,172,118,424,242,17,reward.color);
        Ui.gradient(g,174,120,420,238,15,0xFF30213E,0xFF13132B);
        if(AstraConfig.animations&&!PerformanceMode.enabled()){
            double time=Math.min(3,(System.nanoTime()-celebrationStarted)/1e9);
            for(int i=0;i<22;i++){double angle=i*2.399963+draw.id().hashCode()*.001,radius=24+time*(18+i%5*6);int x=384+(int)(Math.cos(angle)*radius),y=215+(int)(Math.sin(angle)*radius*.64);if(x>181&&x<586&&y>127&&y<304){int color=i%3==0?0xFFFFDF80:i%3==1?reward.color:0xFFD7B6FF;Ui.round(g,x,y,2+i%2,2+i%2,1,Ui.alpha(color,(float)Math.max(0,1-time/3)));}}
        }
        Ui.centered(g,font,"BIG WIN!",384,132,2.2f,0xFFFFDE87);
        CaseArt.icon(g,reward,340,164,88);
        Ui.centered(g,font,reward.title,384,253,1.15f,reward.color);
        Ui.centered(g,font,reward.ticketClaim?"Join Discord and make a ticket to claim.":reward==CaseReward.INFINITE_CASES?"Unlimited case openings are now yours.":"A rare cosmetic has joined your collection.",384,277,.85f,0xFFD8C4E7);
        if(draw.reward().ticketClaim)Ui.centered(g,font,"Claim ID: "+draw.id().toString().substring(0,8),384,294,.76f,0xFFAA98BF);
        if(auto)Ui.centered(g,font,"Auto Open enabled",384,349,.72f,0xFFBDA5CE);
    }

    private void reel(GuiGraphics g){
        Ui.round(g,151,137,466,94,12,0xFFB293D8);Ui.gradient(g,153,139,462,90,10,0xFF17162D,0xFF30213E);
        long now=System.nanoTime();double position=spin==null?CaseSpin.LAND-28:spin.position(now,AstraConfig.animations);
        int first=Math.max(0,(int)position-4),last=Math.min(CaseSpin.SIZE-1,(int)position+4);
        g.enableScissor(154,141,614,227);
        try{for(int i=first;i<=last;i++){
            var reward=spin==null?CaseReward.CONTENTS[i%CaseReward.CONTENTS.length]:spin.cards.get(i);int x=(int)Math.round(384+(i-position)*82-37);
            Ui.round(g,x,146,74,76,8,Ui.blend(0xFF363044,reward.color,.24f));Ui.round(g,x+1,147,72,73,7,0xFF211E33);Ui.round(g,x+3,215,68,3,1,reward.color);if(reward==CaseReward.NOTHING)CaseArt.nothing(g,x+4,157,66,40);else{CaseArt.icon(g,reward,x+19,151,36);small(g,reward.shortTitle,x+6,194,.78f,reward.color);}
        }}finally{g.disableScissor();}
        g.fill(383,136,385,231,Ui.tint(0xFFFF566E));for(int r=0;r<5;r++){g.fill(379+r,132+r,389-r,133+r,Ui.tint(0xFFFF6B80));g.fill(379+r,235-r,389-r,236-r,Ui.tint(0xFFFF6B80));}
    }
    static void small(GuiGraphics g,String text,int x,int y,float scale,int color){var font=Minecraft.getInstance().font;g.pose().pushMatrix();g.pose().translate(x,y);g.pose().scale(scale,scale);Ui.animated(g,font,text,0,0,color);g.pose().popMatrix();}
}
