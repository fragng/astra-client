package client.astra;

import net.minecraft.client.Minecraft;
import net.minecraft.client.gui.GuiGraphics;
import net.minecraft.client.gui.components.Button;

/** Colour-aware native keyboard key; narration and focus use Minecraft's widgets. */
public final class WordKey extends Button {
    private final String label;
    public WordKey(int x,int y,int width,String label,Runnable action){super(x,y,width,24,Ui.text(label),b->action.run(),DEFAULT_NARRATION);this.label=label;}
    public static int color(int mark){return switch(mark){case WordleGame.CORRECT->0xFF427E65;case WordleGame.PRESENT->0xFFB38B37;case WordleGame.ABSENT->0xFF514C60;default->0xFF665280;};}
    @Override protected void renderContents(GuiGraphics g,int mx,int my,float delta){
        int mark=label.length()==1?PuzzleSessions.wordle().letter(label.charAt(0)):0,color=color(mark);
        Ui.round(g,getX(),getY()+1,getWidth(),getHeight(),6,0xFF0E0B1A);
        Ui.round(g,getX(),getY(),getWidth(),getHeight()-1,6,Ui.blend(color,0xFFE4CBFF,isHoveredOrFocused()?.22f:0));
        Ui.centered(g,Minecraft.getInstance().font,label,getX()+getWidth()/2,getY()+7,label.length()==1?1:.70f,0xFFF7F0FF);
    }
}
