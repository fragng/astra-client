package client.astra;

import net.minecraft.client.Minecraft;
import net.minecraft.client.gui.GuiGraphics;
import net.minecraft.client.gui.components.EditBox;
import net.minecraft.network.chat.Component;
import org.lwjgl.glfw.GLFW;

/** Native casual-game pages. No call path awards rewards or spends cases. */
public final class FreeGamesPanel {
    private EditBox answer;
    private boolean visible;
    private final KrillionDive dive=new KrillionDive();
    public void init(ClientMenuScreen s,GamesPanel.Page page){
        PuzzleSessions.load();answer=null;
        if(page==GamesPanel.Page.WORDLE){
            s.control(new MenuButton(153,357,224,28,"New Word","Wordle",()->false,false,()->{PuzzleSessions.wordle().newWord(PuzzleSessions.RANDOM);PuzzleSessions.save();s.refresh();}));
            s.control(new MenuButton(389,357,226,28,"Submit Guess","",()->false,false,()->submitWord(s)).available(()->!PuzzleSessions.wordle().finished()));
            String[] keys={"QWERTYUIOP","ASDFGHJKL","ZXCVBNM"};
            for(int row=0;row<keys.length;row++){int base=384-keys[row].length()*31/2;for(int n=0;n<keys[row].length();n++){char c=keys[row].charAt(n);s.control(new WordKey(base+n*31,274+row*26,28,String.valueOf(c),()->PuzzleSessions.wordle().type(c)));}}
            s.control(new WordKey(173,326,69,"ENTER",()->submitWord(s)));
            s.control(new WordKey(526,326,69,"DEL",()->PuzzleSessions.wordle().backspace()));
        }else{
            var game=PuzzleSessions.krillion();
            switch(game.phase()){
                case READY,COMPLETE->s.control(new MenuButton(210,343,348,32,game.phase()==KrillionGame.Phase.READY?"Start Dive":"Play Again","Krillion",()->false,false,()->{game.start(PuzzleSessions.RANDOM);dive.update(0,System.nanoTime(),false);PuzzleSessions.save();s.refresh();}));
                case QUESTION->{
                    answer=new EditBox(Minecraft.getInstance().font,358,244,240,20,Component.literal("Your trivia answer"));answer.setBordered(false);answer.setMaxLength(64);answer.setTextColor(0xFFF3EBFF);answer.setHint(Ui.text("Type an answer..."));answer.setValue(game.draft());answer.setResponder(game::draft);s.control(answer);s.focusGameInput(answer);
                    s.control(new MenuButton(349,279,168,29,"Submit Answer","",()->false,false,()->submitTrivia(s)));
                    s.control(new MenuButton(527,279,80,29,"Skip","",()->false,false,()->{game.skip();PuzzleSessions.save();s.refresh();}));
                }
                case RESULT->s.control(new MenuButton(210,343,348,32,game.index()==6?"See Results":"Next Prompt","Krillion",()->false,false,()->{game.next();PuzzleSessions.save();s.refresh();}).available(()->dive.ready(game.depth(),System.nanoTime())));
            }
        }
    }
    private void submitWord(ClientMenuScreen s){if(PuzzleSessions.wordle().submit()){PuzzleSessions.save();s.refresh();}}
    private void submitTrivia(ClientMenuScreen s){if(answer==null)return;if(PuzzleSessions.krillion().submit(answer.getValue())){PuzzleSessions.save();s.refresh();}else s.focusGameInput(answer);}
    public boolean key(ClientMenuScreen s,GamesPanel.Page page,int key){
        if(key==GLFW.GLFW_KEY_ENTER||key==GLFW.GLFW_KEY_KP_ENTER){if(page==GamesPanel.Page.WORDLE)submitWord(s);else if(page==GamesPanel.Page.KRILLION){var game=PuzzleSessions.krillion();if(game.phase()==KrillionGame.Phase.QUESTION)submitTrivia(s);else{if(game.phase()==KrillionGame.Phase.RESULT){if(!dive.ready(game.depth(),System.nanoTime()))return true;game.next();}else game.start(PuzzleSessions.RANDOM);PuzzleSessions.save();s.refresh();}}else return false;return true;}
        if(page==GamesPanel.Page.WORDLE&&key==GLFW.GLFW_KEY_BACKSPACE){PuzzleSessions.wordle().backspace();return true;}return false;
    }
    public boolean character(GamesPanel.Page page,int codepoint){if(page!=GamesPanel.Page.WORDLE)return false;PuzzleSessions.wordle().type(codepoint);return true;}
    public void tick(ClientMenuScreen s,GamesPanel.Page page,boolean active){
        boolean free=page==GamesPanel.Page.WORDLE||page==GamesPanel.Page.KRILLION;
        if(free&&active)PuzzleSessions.load();
        if(visible&&(!free||!active))PuzzleSessions.pause();visible=free&&active;
        if(active&&page==GamesPanel.Page.KRILLION)dive.update(PuzzleSessions.krillion().depth(),System.nanoTime(),AstraConfig.animations);
        if(PuzzleSessions.krillion()!=null&&PuzzleSessions.krillion().tick(System.nanoTime(),active&&page==GamesPanel.Page.KRILLION)){PuzzleSessions.save();s.refresh();}
    }
    public void closed(){visible=false;PuzzleSessions.pause();}
    public void render(ClientMenuScreen s,GuiGraphics g,GamesPanel.Page page){
        if(page==GamesPanel.Page.WORDLE)wordle(s,g);else trivia(s,g);
        if(!PuzzleSessions.warning().isEmpty())GamesPanel.small(g,PuzzleSessions.warning(),153,390,.60f,0xFFFFC6A1);
    }
    private void wordle(ClientMenuScreen s,GuiGraphics g){
        var game=PuzzleSessions.wordle();GamesPanel.small(g,"Unlimited puzzles / No rewards",153,103,.82f,0xFFBFB0DB);
        String[] legend={"Correct spot","Wrong spot","Not in word"};int[] legendMarks={3,2,1};for(int n=0;n<3;n++){Ui.round(g,160,151+n*29,9,9,2,WordKey.color(legendMarks[n]));GamesPanel.small(g,legend[n],176,152+n*29,.68f,0xFFC7B8DD);}
        GamesPanel.small(g,"Guess "+Math.min(6,game.guesses().size()+1)+" / 6",507,151,.75f,0xFFCFBFE6);
        for(int row=0;row<6;row++){
            String letters=row<game.guesses().size()?game.guesses().get(row):row==game.guesses().size()?game.input():"";int[] marks=row<game.guesses().size()?game.row(row):null;
            for(int col=0;col<5;col++){int x=288+col*39,y=123+row*22,mark=marks==null?0:marks[col];Ui.round(g,x,y,35,20,4,mark==0?0xFF9B80B9:WordKey.color(mark));Ui.round(g,x+1,y+1,33,18,3,mark==0?0xFF28223C:WordKey.color(mark));if(col<letters.length())Ui.centered(g,Minecraft.getInstance().font,String.valueOf(letters.charAt(col)),x+17,y+5,1,0xFFF7F2FF);}
        }
        GamesPanel.small(g,s.fitText(game.message(),550),153,259,.78f,game.solved()?0xFF9DE7BC:0xFFE3D4EE);
    }
    private static void wrap(GuiGraphics g,String value,int x,int y,int width,float scale,int color){
        var font=Minecraft.getInstance().font;String line="";int row=0;
        for(String word:value.split(" ")){String next=line.isEmpty()?word:line+" "+word;if(!line.isEmpty()&&font.width(Ui.text(next))*scale>width){GamesPanel.small(g,line,x,y+row++*13,scale,color);line=word;}else line=next;}
        if(!line.isEmpty())GamesPanel.small(g,line,x,y+row*13,scale,color);
    }
    private void trivia(ClientMenuScreen s,GuiGraphics g){
        var game=PuzzleSessions.krillion();var font=Minecraft.getInstance().font;long now=System.nanoTime();
        dive.update(game.depth(),now,AstraConfig.animations);
        GamesPanel.small(g,"Astra practice / Unlimited dives / No rewards",153,103,.79f,0xFFB8B8E7);
        KrillionOcean.draw(g,dive,now,AstraConfig.animations&&!PerformanceMode.enabled());
        Ui.gradient(g,341,120,274,212,14,0xFF253653,0xFF15172F);
        if(game.phase()==KrillionGame.Phase.READY){
            Ui.centered(g,font,"Deep dive",478,143,1.3f,0xFFBCE6F4);
            wrap(g,"Seven categories. 25 seconds for each answer.",354,184,246,.86f,0xFFE3DBF2);
            wrap(g,"Unusual valid answers send your fish deeper.",354,226,246,.82f,0xFFC1BDDC);
            wrap(g,"Astra's own offline questions and answer tiers.",354,270,246,.75f,0xFFADBBD9);
            GamesPanel.small(g,"The timer pauses when you leave.",354,312,.69f,0xFFB7C4DC);return;
        }
        GamesPanel.small(g,"Round "+(game.index()+1)+" / 7",354,135,.82f,0xFFC9D2F1);
        GamesPanel.small(g,game.score()+" points",522,135,.82f,0xFFC3E1F5);
        if(game.phase()==KrillionGame.Phase.COMPLETE){
            Ui.centered(g,font,"Dive complete",478,169,1.2f,0xFFC5DBFF);
            Ui.centered(g,font,game.score()+" / 700 points",478,208,1.05f,0xFFE6CBFF);
            Ui.centered(g,font,game.depth()+" m explored",478,244,1,0xFFA4E0E1);
            wrap(g,"Play again for a new set. No prizes are awarded.",354,287,246,.78f,0xFFC4BCDD);return;
        }
        wrap(g,game.prompt().question(),354,165,246,.84f,0xFFF2EAFE);
        if(game.phase()==KrillionGame.Phase.QUESTION){
            int remaining=(int)Math.ceil(game.seconds());GamesPanel.small(g,remaining+"s",574,205,.8f,remaining<=5?0xFFFFADBA:0xFFAAE4EB);
            Ui.round(g,354,220,248,6,3,0xFF41405C);int fill=(int)Math.round(248*game.seconds()/25);if(fill>0)Ui.round(g,354,220,fill,6,3,0xFF9E85DE);
            Ui.round(g,349,235,258,35,9,0xFF9B85BD);Ui.round(g,351,237,254,31,8,0xFF17182E);
            wrap(g,game.message(),354,316,248,.63f,0xFFD8C8E5);
            GamesPanel.small(g,"Answers use Astra's offline list. Retry before the timer ends.",153,352,.76f,0xFFB5AECF);
            GamesPanel.small(g,"Enter submits / Unusual accepted answers dive further.",153,375,.76f,0xFFB5AECF);
        }else{
            var result=game.results().getLast();
            Ui.centered(g,font,s.fitText(result.answer(),220),478,216,1.05f,0xFFEEDBFF);
            Ui.centered(g,font,game.message(),478,254,.85f,result.points()>0?0xFFA6E9DA:0xFFD3B4D2);
            Ui.centered(g,font,dive.moving(now)?"Fish descending...":"Ready for the next prompt.",478,296,.76f,0xFFB8C4DE);
        }
    }
}
