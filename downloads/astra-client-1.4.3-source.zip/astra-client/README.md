# Astra Client 1.4.3

A cosmetic Minecraft Java 1.21.11 client mod for Fabric Loader 0.19.3 or newer and Java 21. Requires Fabric API 0.141.6+1.21.11 for Minecraft 1.21.11.

## Install

Remove previous Astra Client jars from your instance's `mods` folder, then add `astra-client-1.4.3.jar` alongside Fabric API. Launch Minecraft's Fabric profile.

## Right Shift menu

Press **Right Shift** in a world to open Astra Client. Right Shift, Escape or X closes it. Mouse hitboxes and dragging scale together with the centred menu. Tab/Shift+Tab and arrow keys operate the native Minecraft widgets.

- **Visuals:** Bubble Font toggle, menu-only brightness, Minecraft FOV, and four exclusive menu backgrounds.
- **Settings:** toggle subtle animations and UI button sounds.
- **Jamble:** a clearly labelled page for future Jamble features; none are implemented yet.
- **Best Buds:** a clearly labelled page for future friend features; none are implemented yet.
- **Music:** actual Minecraft Music volume and a mute toggle that restores the previous volume.
- **HUD:** show/hide the Astra watermark and its moon logo. F1/F3 visibility still applies.
- **General:** client, Minecraft and loader information; reset Astra preferences to defaults.

**Menu brightness does not change world gamma.** 100% is normal menu brightness; 0% is the darkest readable menu. It dims the whole Astra panel, including its controls, without dimming the world outside it.

FOV uses Minecraft's normal 30–110 range. Its slider reads Minecraft's actual option rather than a separate copy. Music likewise reads and changes Minecraft's actual Music option. Native options save through Minecraft; custom preferences save to `config/astra-client.json`. Writes are debounced while dragging and flushed when closing the menu or stopping the client.

Reset restores only Astra preferences: Galaxy background, 100% menu brightness, enabled animations and sounds, visible watermark and logo, and Bubble Font enabled. It keeps Minecraft FOV, world gamma and music volume unchanged.

## Backgrounds

Inside the Right Shift menu:

- **Normal:** plain navy, minimal effects.
- **Galaxy:** blue/purple galaxy texture, subtle drifting stars and cosmic lines.
- **Nebula:** tinted nebula clouds and gentle motion.
- **Astra:** deep purple gradients, tiny stars and slow cosmic waves.

Disabling animations stops the background movement, hover interpolation, slider interpolation and tab fade. Theme selection changes immediately and survives restarts. All artwork is bundled; no online download is needed.

The title-screen appearance selector retains its earlier behaviour: Normal shows Minecraft's original panorama, while the three space modes show their wallpapers. The title buttons align to Mod Menu without moving the Mods button. Shared vanilla widgets have rounded styling and soft button sounds.

## Build

Use a Java 21 JDK:

```sh
./gradlew build
./gradlew runClient
```

On Windows, use `gradlew.bat`. The installable file is `build/libs/astra-client-1.4.3.jar`; do not install the sources jar.

Typography uses the chunky Coiny bubble font. Its OFL license is included in `src/main/resources/COINY-OFL.txt` and in the built jar. The moon icon was adapted from the supplied reference, backgrounds were generated for Astra, and the soft click sound was synthesized for this client.

## Spotify desktop link (Windows)

Open the **Spotify desktop app** on Windows 10/11 and play a song. In Minecraft, open **Right Shift → Music**. Keep **Desktop link** enabled. The card shows the title, artist, and actual playback state. Previous, Play/pause, and Next operate Spotify's Windows media session; unavailable controls are disabled according to Windows' reported capabilities. Reconnect restarts the bridge if Windows media access stops responding.

This uses the Windows Global System Media Transport Controls API through one background Windows PowerShell helper. It does not request a Spotify password, use Spotify's web API, stream Spotify audio through Minecraft, or inspect other apps' media. Audio continues playing from Spotify. The helper exits when Minecraft closes or Desktop link is disabled. Windows PowerShell and desktop media access must be available. Browser-only Spotify and non-Windows platforms are not supported by this desktop bridge.

The Music volume slider and Mute button still control **Minecraft Music**, separately from Spotify transport controls.

## HUD and text animation

The Astra watermark is now a compact rounded pill with eased entrance/exit, smooth resizing, a gently breathing moon and border, and softer text. Enable **HUD → Spotify now playing** to add a song/artist line when a Spotify media session is connected. Long song text gently scrolls; the small playback bars animate while Spotify reports Playing.

With Bubble Font enabled, all Astra menu labels use Coiny bubble lettering with a soft shadow. Text positions and colours stay steady for crisp readability. **Settings → Smooth animations** controls hover transitions, background movement and HUD transitions; it does not wobble the text. Existing brightness, FOV, volume, themes and HUD settings still save normally.

### Validation limit

The Minecraft UI/HUD was exercised on Linux, including an unavailable-Spotify state. The PowerShell script passed syntax checks, and its production polling/JSON/command loop was tested with mocked Windows media objects. Java metadata and command handling were tested independently. A live Windows Spotify session could not be tested in this environment; that native path remains unverified on Windows.

## Bubble Font toggle (1.4.3)

**Visuals → Bubble Font** switches between chunky Coiny bubble lettering (On) and the normal Minecraft font (Off). It updates immediately without a resource reload or restart, including Astra headings, labels, controls, HUD and standard Minecraft menus. It defaults to On and saves in `config/astra-client.json`. Text measurement switches together with drawing to keep spacing consistent. Minecraft's original font resources remain intact when the toggle is Off. Other resource packs can still customize Minecraft's normal font.
Panels have softer illustrated borders; buttons have puffy edges and glossy highlights; slider knobs and switches have rounded cartoon details. The cosmic purple background and all existing controls remain. Text stays steady for readability; hover and short transition effects still respect Smooth animations.

The optimized GPU panel gradients from 1.4.1 remain. No hardware FPS improvement percentage is claimed.
