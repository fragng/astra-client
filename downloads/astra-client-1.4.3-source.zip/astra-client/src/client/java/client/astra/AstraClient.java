package client.astra;

import net.fabricmc.api.ClientModInitializer;
import net.fabricmc.fabric.api.client.rendering.v1.hud.HudElementRegistry;
import net.fabricmc.fabric.api.client.rendering.v1.hud.VanillaHudElements;
import net.minecraft.client.Minecraft;
import net.minecraft.resources.Identifier;
import net.fabricmc.fabric.api.client.screen.v1.ScreenEvents;
import net.minecraft.client.gui.screens.TitleScreen;

public final class AstraClient implements ClientModInitializer {
    public static final String MOD_ID = "astra-client";
    public static final String NAME = "Astra Client";

    @Override
    public void onInitializeClient() {
        AstraConfig.load();
        net.fabricmc.fabric.api.client.event.lifecycle.v1.ClientLifecycleEvents.CLIENT_STOPPING.register(client -> {AstraConfig.flush();SpotifyBridge.stop();});
        var menuKey = net.fabricmc.fabric.api.client.keybinding.v1.KeyBindingHelper.registerKeyBinding(
            new net.minecraft.client.KeyMapping("Open Astra Client", org.lwjgl.glfw.GLFW.GLFW_KEY_RIGHT_SHIFT,
                net.minecraft.client.KeyMapping.Category.MISC));
        net.fabricmc.fabric.api.client.event.lifecycle.v1.ClientTickEvents.END_CLIENT_TICK.register(client -> {
            AstraConfig.tick(client);SpotifyBridge.tick();
            while (menuKey.consumeClick()) {
                if (client.player != null && client.screen == null) client.setScreen(new ClientMenuScreen());
            }
        });
        ScreenEvents.AFTER_INIT.register((client, screen, width, height) -> {
            if (screen instanceof TitleScreen title) AstraMenu.initialize(title);
        });
        // Inherit vanilla's HUD visibility condition, so F1 hides the watermark too.
        HudElementRegistry.attachElementBefore(VanillaHudElements.CHAT,
            Identifier.fromNamespaceAndPath(MOD_ID, "watermark"), (graphics, delta) -> {
                Minecraft client = Minecraft.getInstance();
                if (client.player != null && !client.getDebugOverlay().showDebugScreen()) {
                    AstraBranding.drawHud(graphics, client.font, 8, 8);
                }
            });
    }
}
