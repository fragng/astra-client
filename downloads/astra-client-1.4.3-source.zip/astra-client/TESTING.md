# Astra Client 1.4.3 validation

- Built with Java 21 for Minecraft 1.21.11 / Fabric Loader 0.19.3.
- Opened Right Shift in a singleplayer world with Mod Menu installed.
- Toggled Visuals → Bubble Font off and on; checked Astra typography changes immediately between Minecraft pixel lettering and Coiny bubble lettering.
- Checked the standard Minecraft pause menu uses the normal pixel font with Bubble Font off.
- Verified both toggle states are written to config/astra-client.json.
- Exercised the FOV slider after changing the font; Minecraft's native option updated correctly.
- Existing themes, animations, layout and Spotify implementation are unchanged by this patch.

Coiny is bundled under the included OFL license. No FPS improvement is claimed. A live Windows Spotify session remains unverified from this Linux host.
