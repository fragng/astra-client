package client.astra;

import net.minecraft.client.gui.GuiGraphics;
import net.minecraft.client.gui.screens.Screen;
import net.minecraft.client.gui.components.EditBox;
import net.minecraft.client.input.KeyEvent;
import net.minecraft.client.input.MouseButtonEvent;
import net.minecraft.network.chat.Component;
import org.lwjgl.glfw.GLFW;
import java.util.function.*;

public final class ClientMenuScreen extends Screen {
    private static final int W=640,H=400,X=142,CW=484;
    private static final String[] TABS={"Visuals","HUD","Spotify HUD","Essentials","Customize Totem","Jamble","Settings","Buy Premium"};
    private static final int[] TAB_Y={84,118,152,214,248,282,318,354};
    private String tab="Visuals";
    private boolean customiseSpotify,donutPack,bindingFreelook,customSky,jambleLimits;
    private EditBox minimumPay,maximumPay;
    private String minimumDraft,maximumDraft,limitMessage="";
    private boolean limitError;
    private boolean lastPremium=PremiumEdition.premium();
    public static final String PREMIUM_URL="https://discord.gg/gazebo";
    private boolean locked(){return !PremiumEdition.premium() && (tab.equals("Jamble") || tab.equals("Customize Totem"));}
    private final MenuTween openMotion=new MenuTween(0),pageMotion=new MenuTween(1);
    private boolean closing,pendingCustomise;
    private String pendingTab;
    private float scale,originX,originY,pageOffset,brightness=(float)AstraConfig.menuBrightness;
    private long lastFrame=System.nanoTime();
    public ClientMenuScreen() { super(Component.literal("Astra Client")); }
    private void fit() {
        scale=Math.min(1.3f,Math.min((width-18f)/W,(height-18f)/H))*(.975f+.025f*openMotion.eased());
        originX=(width-W*scale)/2;originY=(height-H*scale)/2+(1-openMotion.eased())*6;
    }
    @Override protected void init() {
        fit();
        addRenderableWidget(new MenuButton(566,15,25,26,"","Settings",()->tab.equals("Profile"),false,()->navigate("Profile",false)));
        addRenderableWidget(new MenuButton(601,15,25,26,"X","",()->false,false,this::onClose));
        for(int i=0;i<TABS.length;i++) {
            String next=TABS[i];
            addRenderableWidget(new MenuButton(14,TAB_Y[i],112,29,next,next,()->(pendingTab==null?tab:pendingTab).equals(next),false,()->{
                if(!tab.equals(next) || customiseSpotify || donutPack || customSky || jambleLimits || pendingTab!=null)navigate(next,false);
            }));
        }
        if(locked()) {
            addRenderableWidget(new MenuButton(163,286,280,34,"Explore Premium","Buy Premium",()->false,false,()->navigate("Buy Premium",false)));
            return;
        }
        switch(tab) {
            case "Visuals" -> {
                if(customSky) {
                    addRenderableWidget(new MenuButton(455,72,160,25,"Minecraft sky","",()->AstraConfig.skyTheme()==SkyTheme.VANILLA,false,()->AstraConfig.selectSky(SkyTheme.VANILLA)));
                    for(int i=0;i<SkyTheme.CUSTOM.length;i++){
                        SkyTheme sky=SkyTheme.CUSTOM[i];
                        addRenderableWidget(new SkyPreviewButton(153+i%3*158,132+i/3*96,sky,()->{if(PremiumEdition.premium())AstraConfig.selectSky(sky);else navigate("Buy Premium",false);}));
                    }
                    addRenderableWidget(new MenuButton(153,338,296,29,"Lyrics In Sky: "+(PremiumEdition.premium() && AstraConfig.lyricsInSky?"ON":"OFF"),"",()->PremiumEdition.premium() && AstraConfig.lyricsInSky,true,()->{
                        if(!PremiumEdition.premium()){navigate("Buy Premium",false);return;}
                        AstraConfig.lyricsInSky=!AstraConfig.lyricsInSky;
                        if(AstraConfig.lyricsInSky){AstraConfig.spotifyEnabled=true;if(!SpotifyBridge.state().connected())SpotifyBridge.reconnect();}
                        SkyLyrics.close();AstraConfig.changed();rebuildWidgets();
                    }));
                    addRenderableWidget(new MenuButton(459,338,156,29,"Set Sky Position","",()->false,false,()->{
                        var camera=minecraft.gameRenderer.getMainCamera();AstraConfig.placeSkyLyrics(camera.yRot(),-camera.xRot());SkyLyrics.close();
                    }).available(()->PremiumEdition.premium() && minecraft.player!=null));
                    break;
                }
                addRenderableWidget(new MenuButton(455,72,160,25,"Custom Sky / Premium","",()->false,false,()->navigate("Visuals",true)));
                slider(153,129,462,()->AstraConfig.menuBrightness,v->{AstraConfig.menuBrightness=v;AstraConfig.changed();},v->"Brightness: "+Math.round(v*100)+"%");
                addRenderableWidget(new MenuSlider(153,190,462,()->(minecraft.options.fov().get()-30)/80.0,v->{minecraft.options.fov().set((int)Math.round(30+v*80));AstraConfig.nativeChanged();},v->"Field of view: "+minecraft.options.fov().get(),1.0/80));
                for(int i=0;i<Theme.values().length;i++) {
                    Theme theme=Theme.values()[i];
                    addRenderableWidget(new MenuButton(153+i*117,296,111,25,theme.label,"",()->AstraConfig.theme()==theme,true,()->AstraConfig.select(theme)));
                }
                addRenderableWidget(new MenuButton(153,324,462,23,"Reactive Background","",()->AstraConfig.reactiveBackground,true,()->{
                    AstraConfig.reactiveBackground=!AstraConfig.reactiveBackground;AstraConfig.changed();
                }));
                addRenderableWidget(new MenuButton(153,366,462,23,"Bubble Font","",()->AstraConfig.bubbleFont,true,()->{
                    AstraConfig.bubbleFont=!AstraConfig.bubbleFont;AstraConfig.changed();
                }));
            }
            case "Settings" -> {
                toggle(153,137,462,"Smooth animations",()->AstraConfig.animations,()->{AstraConfig.animations=!AstraConfig.animations;AstraConfig.changed();});
                toggle(153,191,462,"Button sounds",()->AstraConfig.sounds,()->{AstraConfig.sounds=!AstraConfig.sounds;AstraConfig.changed();});
                toggle(153,303,462,"Discord Capture Mode",DiscordCapture::enabled,DiscordCapture::toggle);
                addRenderableWidget(new MenuButton(153,258,240,29,"Reset Astra preferences","",()->false,false,()->{
                    AstraConfig.reset();FreelookBridge.initialize();AstraConfig.nativeChanged();brightness=1;pageMotion.reset(0);rebuildWidgets();
                }));

            }
            case "Jamble" -> {
                if(jambleLimits){
                    addRenderableWidget(new MenuButton(455,72,160,25,"Back to Jamble","",()->false,false,()->navigate("Jamble",false)));
                    if(minimumDraft==null)minimumDraft=JambleMoney.editable(AstraConfig.jambleMinPay);
                    if(maximumDraft==null)maximumDraft=JambleMoney.editable(AstraConfig.jambleMaxPay);
                    minimumPay=amountField(171,177,"Minimum pay",minimumDraft,value->minimumDraft=value);
                    maximumPay=amountField(403,177,"Maximum pay",maximumDraft,value->maximumDraft=value);
                    addRenderableWidget(new MenuButton(153,209,222,29,"Apply Payment Limits","",()->false,false,()->{
                        try{
                            long min=JambleMoney.parse(minimumPay.getValue()),max=JambleMoney.parse(maximumPay.getValue());
                            if(!JambleMoney.validRange(min,max))throw new IllegalArgumentException("Maximum must be positive and at least the minimum.");
                            AstraConfig.jambleMinPay=min;AstraConfig.jambleMaxPay=max;AstraConfig.changed();
                            limitMessage="Saved: "+JambleMoney.compact(min)+" - "+JambleMoney.compact(max);limitError=false;
                        }catch(IllegalArgumentException e){limitMessage=e.getMessage();limitError=true;}
                    }));break;
                }
                addRenderableWidget(new MenuButton(455,72,160,25,"Payment Limits","",()->false,false,()->navigate("Jamble",true)));
                toggle(153,137,224,"Enable Jamble",()->AstraConfig.jambleEnabled,()->{if(!PremiumEdition.premium())return;AstraConfig.jambleEnabled=!AstraConfig.jambleEnabled;JambleHud.reset();JamblePayments.clear();AstraConfig.changed();});
                addRenderableWidget(new MenuButton(389,137,226,35,"Payments / "+JamblePayments.reviewKeyName(),"",()->false,false,()->JamblePayments.openReview(null,this)).available(()->JamblePayments.ledger().size()>0));
            }
            case "HUD" -> {
                toggle(153,137,462,"Show Astra watermark",()->AstraConfig.hudVisible,()->{AstraConfig.hudVisible=!AstraConfig.hudVisible;AstraConfig.changed();});
                toggle(153,191,462,"Show moon logo",()->AstraConfig.hudLogo,()->{AstraConfig.hudLogo=!AstraConfig.hudLogo;AstraConfig.changed();});
                toggle(153,245,462,"Fake Media (local)",()->AstraConfig.fakeMedia,()->{AstraConfig.fakeMedia=!AstraConfig.fakeMedia;AstraConfig.changed();});
            }
            case "Spotify HUD" -> {
                if(customiseSpotify) {
                    for(int i=0;i<SpotifyHudTheme.values().length;i++) {
                        SpotifyHudTheme theme=SpotifyHudTheme.values()[i];
                        addRenderableWidget(new MenuButton(153+i*117,177,111,33,theme.label,"",()->AstraConfig.spotifyTheme()==theme,true,()->AstraConfig.selectSpotifyTheme(theme)));
                    }
                    addRenderableWidget(new MenuButton(153,226,160,27,"Back to Spotify HUD","",()->false,false,()->spotifyPage(false)));
                } else {
                    addRenderableWidget(new MenuButton(153,137,224,29,"Enable Spotify HUD","",()->AstraConfig.hudSpotify,true,this::toggleSpotifyHud));
                    addRenderableWidget(new MenuButton(389,137,226,29,"Enable Lyrics","",()->AstraConfig.lyricsEnabled,true,()->{AstraConfig.lyricsEnabled=!AstraConfig.lyricsEnabled;AstraConfig.changed();}));
                    addRenderableWidget(new MenuButton(153,174,224,29,"Desktop link","",()->AstraConfig.spotifyEnabled,true,()->{AstraConfig.spotifyEnabled=!AstraConfig.spotifyEnabled;AstraConfig.changed();SpotifyBridge.tick();}));
                    addRenderableWidget(new MenuButton(389,174,226,29,"Reconnect","",()->false,false,SpotifyBridge::reconnect)
                        .available(()->SpotifyBridge.windows() && AstraConfig.spotifyEnabled));
                    addRenderableWidget(new MenuSlider(153,211,462,()->(AstraConfig.spotifyHudScale-.5)/.5,v->{
                        AstraConfig.spotifyHudScale=Math.round((.5+v*.5)*100)/100.0;AstraConfig.changed();
                    },v->"Spotify HUD size: "+Math.round(AstraConfig.spotifyHudScale*100)+"%",.02));
                    addRenderableWidget(new MenuButton(153,321,143,28,"Previous","",()->false,false,()->SpotifyBridge.send("previous"))
                        .available(()->SpotifyBridge.state().connected() && SpotifyBridge.state().previous()));
                    addRenderableWidget(new MenuButton(307,321,153,28,"Play / pause","",()->SpotifyBridge.state().playing(),false,()->SpotifyBridge.send("toggle"))
                        .available(()->SpotifyBridge.state().connected() && SpotifyBridge.state().toggle()));
                    addRenderableWidget(new MenuButton(471,321,144,28,"Next","",()->false,false,()->SpotifyBridge.send("next"))
                        .available(()->SpotifyBridge.state().connected() && SpotifyBridge.state().next()));
                    addRenderableWidget(new MenuButton(153,357,462,26,"Customise Spotify HUD","General",()->false,false,()->spotifyPage(true)));
                }
            }
            case "Customize Totem" -> {
                if(donutPack) {
                    addRenderableWidget(new MenuButton(515,72,100,25,"Back to packs","",()->false,false,()->totemPage(false)));
                    for(int i=0;i<TotemStyle.PACK.length;i++) {
                        TotemStyle style=TotemStyle.PACK[i];int tx=153+i%3*158,ty=109+i/3*130;
                        addRenderableWidget(new MenuButton(tx+9,ty+90,128,24,AstraConfig.totemStyle()==style?"Unequip":"Equip","",()->AstraConfig.totemStyle()==style,false,()->{
                            AstraConfig.selectTotem(AstraConfig.totemStyle()==style?TotemStyle.NONE:style);rebuildWidgets();
                        }));
                    }
                } else {
                    addRenderableWidget(new MenuButton(457,295,158,31,"Open Pack","",()->false,false,()->totemPage(true)));
                    addRenderableWidget(new MenuButton(153,350,192,27,"Unequip Totem","",()->false,false,()->{AstraConfig.selectTotem(TotemStyle.NONE);rebuildWidgets();}).available(()->AstraConfig.totemStyle()!=TotemStyle.NONE));
                }
            }
            case "Profile" -> {
                toggle(153,308,462,"Performance Mode",PerformanceMode::enabled,PerformanceMode::toggle);
            }
            case "Buy Premium" -> addRenderableWidget(new MenuButton(163,290,280,38,"Join Discord / Buy Premium","Buy Premium",()->false,false,()->net.minecraft.client.gui.screens.ConfirmLinkScreen.confirmLinkNow(this,PREMIUM_URL)));
            case "Essentials" -> {
                toggle(153,137,462,"Freelook",()->AstraConfig.freelookEnabled,()->{AstraConfig.freelookEnabled=!AstraConfig.freelookEnabled;AstraConfig.changed();});
                addRenderableWidget(new MenuButton(153,207,462,35,bindingFreelook?"Press a key or mouse button...":"Set a key: "+FreelookBridge.keyName(),"",()->bindingFreelook,false,()->{bindingFreelook=true;rebuildWidgets();}));
                toggle(153,338,462,"Fullbright",()->AstraConfig.fullbright,Fullbright::toggle);
            }
        }
    }
    private void totemPage(boolean open){navigate("Customize Totem",open);}
    private void spotifyPage(boolean customise) {navigate("Spotify HUD",customise);}
    private void navigate(String next,boolean customise) {
        pendingTab=next;pendingCustomise=customise;
        if(!AstraConfig.animations)applyPendingPage();
    }
    private void applyPendingPage() {
        tab=pendingTab;customiseSpotify=pendingCustomise && tab.equals("Spotify HUD");donutPack=pendingCustomise && tab.equals("Customize Totem");customSky=pendingCustomise && tab.equals("Visuals");jambleLimits=pendingCustomise && tab.equals("Jamble");pendingTab=null;bindingFreelook=false;
        if(!jambleLimits){minimumDraft=null;maximumDraft=null;limitMessage="";limitError=false;}
        pageMotion.reset(AstraConfig.animations?0:1);setDragging(false);rebuildWidgets();
    }
    private boolean content(net.minecraft.client.gui.components.Renderable r) {
        return r instanceof net.minecraft.client.gui.components.AbstractWidget w && w.getX()>=X && w.getY()>=70;
    }
    private void slider(int x,int y,int w,DoubleSupplier read,DoubleConsumer write,Function<Double,String> format) {
        addRenderableWidget(new MenuSlider(x,y,w,read,write,format));
    }
    private void toggle(int x,int y,int w,String label,BooleanSupplier read,Runnable write) {
        addRenderableWidget(new MenuButton(x,y,w,35,label,"",read,true,write));
    }
    private EditBox amountField(int x,int y,String label,String value,Consumer<String> changed){
        var field=new EditBox(font,x,y,194,14,Ui.text(label));field.setBordered(false);field.setMaxLength(32);field.setTextColor(0xFFECE2F8);field.setValue(value);field.setResponder(changed);return addRenderableWidget(field);
    }
    private void toggleSpotifyHud() {
        AstraConfig.hudSpotify=!AstraConfig.hudSpotify;
        if(AstraConfig.hudSpotify) {
            AstraConfig.spotifyEnabled=true;
            if(!SpotifyBridge.state().connected())SpotifyBridge.reconnect();
        }
        AstraConfig.changed();
    }
    private String fitText(String value,int maxWidth) {
        if(font.width(Ui.text(value))<=maxWidth) return value;
        String trim=value;
        while(!trim.isEmpty() && font.width(Ui.text(trim+"..."))>maxWidth) trim=trim.substring(0,trim.offsetByCodePoints(trim.length(),-1));
        return trim+"...";
    }
    private void text(GuiGraphics g,String label,int x,int y,int color) {Ui.animated(g,font,label,x,y,color);}
    private void card(GuiGraphics g,int x,int y,int w,int h,String title,String icon) {
        Ui.round(g,x-2,y-2,w+4,h+4,19,0x299A55EA);
        Ui.round(g,x,y,w,h,17,0xFFE4C2FA);
        Ui.gradient(g,x+2,y+2,w-4,h-4,15,0xF13D305B,0xF01C1935);
        if(!title.isEmpty()) {MenuArt.icon(g,icon,x+12,y+12,14,0xFFC5A6F4);
        Ui.animated(g,font,Ui.heading(title),x+35,y+12,0xFFF2E6FF);}
    }
    @Override public void render(GuiGraphics g,int mouseX,int mouseY,float delta) {
        if(lastPremium!=PremiumEdition.premium()){lastPremium=PremiumEdition.premium();rebuildWidgets();}
        long now=System.nanoTime();float elapsed=Math.clamp((now-lastFrame)/1e9f,0,1),dt=Math.min(.1f,elapsed);lastFrame=now;
        openMotion.advance(closing?0:1,elapsed,closing?.24f:.30f,AstraConfig.animations);
        if(closing && openMotion.at(0)) {minecraft.setScreen(null);return;}
        if(pendingTab!=null) {
            float outgoing=pageMotion.secondsTo(0,.11f);
            pageMotion.advance(0,elapsed,.11f,AstraConfig.animations);
            if(pageMotion.at(0)) {
                applyPendingPage();
                pageMotion.advance(1,Math.max(0,elapsed-outgoing),.18f,AstraConfig.animations);
            }
        } else pageMotion.advance(1,elapsed,.18f,AstraConfig.animations);
        pageOffset=(pendingTab==null?1:-1)*14*(1-pageMotion.eased());
        fit();
        float target=(float)AstraConfig.menuBrightness;
        brightness=AstraConfig.animations?brightness+(target-brightness)*(1-(float)Math.exp(-dt*24)):target;
        g.pose().pushMatrix();g.pose().translate(originX,originY);g.pose().scale(scale,scale);
        float oldRoot=Ui.pushOpacity(openMotion.eased());
        try {
        Ui.round(g,-2,-2,W+4,H+4,20,0x457F55D7);
        Ui.round(g,-1,-1,W+2,H+2,19,0xFFD3A5FF);
        MenuArt.background(g,W,H);
        MenuArt.icon(g,"star",24,19,23,0xFFC6A2FF);
        Ui.centered(g,font,"Astra Client",64+(int)(font.width(Ui.heading("Astra Client"))*.85f),14,1.7f,0xFFF0E9FF);
        text(g,"Minecraft Client",64,40,0xFFA2A2C1);
        ProfileHeader.draw(g,font,523,10);
        g.fill(12,61,W-12,62,Ui.tint(0x7F766498));
        g.fill(133,71,134,H-20,Ui.tint(0x554D4B70));
        text(g,"APPEARANCE",20,71,0xFFADA0C6);
        text(g,"TOOLS",20,199,0xFFADA0C6);
        for(var child:children())if(child instanceof net.minecraft.client.gui.components.Renderable r && !content(r))r.render(g,(int)((mouseX-originX)/scale),(int)((mouseY-originY)/scale),delta);
        g.enableScissor(X-3,69,W-5,H-5);
        g.pose().pushMatrix();g.pose().translate(pageOffset,0);
        float oldPage=Ui.pushOpacity(pageMotion.eased());
        try {
            renderPage(g);
            for(var child:children())if(child instanceof net.minecraft.client.gui.components.Renderable r && content(r))r.render(g,(int)((mouseX-originX)/scale-pageOffset),(int)((mouseY-originY)/scale),delta);
        } finally {Ui.restoreOpacity(oldPage);g.pose().popMatrix();g.disableScissor();}

        Ui.round(g,0,0,W,H,18,Ui.alpha(0xFF000000,(1-brightness)*.90f));
        } finally {Ui.restoreOpacity(oldRoot);g.pose().popMatrix();}
    }
    private void renderPage(GuiGraphics g) {
        String title=customSky?"Custom Sky":donutPack?"DonutSMP Pack":jambleLimits?"Payment Limits":tab;
        Ui.centered(g,font,title,X+font.width(Ui.heading(title))*3/4,76,1.5f,0xFFF1EAFF);
        if(locked()) {
            card(g,X,105,CW,268,"Premium feature",tab);
            text(g,tab.equals("Jamble")?"Named hotbar rolls, item icons and winner announcements.":"Equip a 3D creator totem from the DonutSMP Pack.",163,150,0xFFE2DAED);
            if(tab.equals("Customize Totem"))for(int i=0;i<TotemStyle.PACK.length;i++)TotemStyle.PACK[i].preview(g,170+i*88,180,56);
            else {
                text(g,"Host names: 1.1 - 9.1. Viewer names: 1 - 9.",163,190,0xFFB5AACB);
                text(g,"Receive one of each together in your hotbar.",163,214,0xFFB5AACB);
            }
            text(g,"Included with an active 30-day Premium edition.",163,258,0xFFFFD982);
            text(g,"Your saved selections are kept while Premium is inactive.",163,343,0xFFA9A9C2);
            return;
        }
        switch(tab) {
            case "Visuals" -> {
                if(customSky) {
                    text(g,PremiumEdition.premium()?"Choose a sky preview to apply it immediately.":"Premium skies / choose a preview to explore Premium.",153,111,0xFFB5AACB);
                    text(g,"Six skies / "+(PremiumEdition.premium()?AstraConfig.skyTheme().label:"Premium required"),153,321,0xFFE8D5FF);
                    text(g,"Fixed sky position: "+SkyLyrics.positionLabel()+". Synced Spotify lyrics.",153,374,0xFFB5AACB);
                    text(g,"Look up, reopen this menu, then Set Sky Position.",153,386,0xFFA9A9C2);
                    break;
                }
                card(g,X,105,CW,147,"Appearance","Visuals");
                text(g,"Adjusts menu brightness only; the world is unchanged.",163,177,0xFFA4A3BE);
                card(g,X,265,CW,130,"Menu Background","General");
                text(g,PerformanceMode.enabled()?"Reactive effects paused by Performance Mode.":"Makes the Menu Look 100X Better.",163,351,0xFFB1ABC8);
            }
            case "Settings" -> {
                card(g,X,105,CW,290,"Client preferences","Settings");
                text(g,"Gentle motion, hover transitions and animated sliders.",163,177,0xFFA4A3BE);
                text(g,"Soft UI clicks. Respects Minecraft's sound volume.",163,231,0xFFA4A3BE);
                text(g,"Windowed capture; keeps rendering when you switch apps.",163,345,0xFFB8A6D9);
                text(g,"Share Astra Client | Minecraft in Discord's Applications.",163,361,0xFFA4A3BE);
                text(g,"Keep the game open. Off restores the previous options.",163,377,0xFFA4A3BE);
            }
            case "HUD" -> {
                card(g,X,105,CW,238,"Astra HUD elements","HUD");
                text(g,"A compact pill with smooth entry and resizing.",163,177,0xFFA4A3BE);
                text(g,"The moon gently breathes while animations are on.",163,231,0xFFA4A3BE);
                text(g,"Local F5 badge. Your server rank stays the same.",163,285,0xFFA4A3BE);
                text(g,"Spotify controls have their own sidebar category.",156,316,0xFFB8A6D9);
            }
            case "Spotify HUD" -> {
                if(customiseSpotify) {
                    card(g,X,105,CW,160,"Customise Spotify HUD","General");
                    text(g,"Choose a theme for your Spotify HUD.",156,148,0xFFB8A6D9);
                    text(g,"Saves automatically.",331,236,0xFFB8A6D9);
                    card(g,X,278,CW,105,"Live preview","Visuals");
                    SpotifyHud.drawPreview(g,font,X+CW/2,310);
                } else {
                    card(g,X,105,CW,282,"Playback and HUD","Music");
                    var media=SpotifyBridge.state();
                    text(g,media.connected()?media.playing()?"Connected / Playing":"Connected / Paused":fitText(media.status(),445),156,267,media.connected()?0xFFC8B0F3:0xFFA4A3BE);
                    text(g,fitText(media.connected()?media.title():"Open Spotify on Windows and play a song.",445),156,285,0xFFF0E8FF);
                    text(g,fitText(media.connected()?media.artist():"Close this menu to view the HUD. Lyrics use LRCLIB online.",445),156,303,0xFFB6B2CD);
                }
            }
            case "Jamble" -> {
                if(jambleLimits){
                    card(g,X,105,CW,155,"Bet amount range","Jamble");
                    text(g,"Minimum Pay",163,147,0xFFE5D6F8);text(g,"Maximum Pay",395,147,0xFFE5D6F8);
                    for(int x:new int[]{163,395}){Ui.round(g,x,166,210,32,9,0xFF9574BC);Ui.round(g,x+1,167,208,30,8,0xFF19172D);}
                    text(g,fitText(limitMessage.isEmpty()?"K = thousands / M = millions / B = billions":limitMessage,440),163,245,limitError?0xFFF0A09D:0xFFB9ACCF);
                    card(g,X,272,CW,121,"Payments and payouts","Jamble");
                    text(g,"New DonutSMP payments in this range join the queue.",163,307,0xFFE2DAED);
                    text(g,"Use arrival order. A confirmed viewer win records 2x.",163,327,0xFFE2DAED);
                    text(g,"Press "+JamblePayments.reviewKeyName()+" to review payments, then click Mark won.",163,347,0xFFBFAAD9);
                    text(g,"Local record only. Off or leaving clears the session.",163,374,0xFFA9A9C2);break;
                }
                card(g,X,105,CW,94,"Hotbar roll tracker","Jamble");
                text(g,AstraConfig.jambleEnabled?"Listening for DonutSMP payments / "+JamblePayments.ledger().pending()+" pending":"Enable before receiving a payment and its roll.",163,181,0xFFB5AACB);
                card(g,X,211,CW,176,"Instructions","Settings");
                text(g,"1. Name the items in an anvil before dispensing.",163,246,0xFFE2DAED);
                text(g,"2. Host: 1.1 - 9.1 (.1); Viewer: 1 - 9.",163,266,0xFFE2DAED);
                text(g,"3. Receive one of each together into your HOTBAR.",163,286,0xFFE2DAED);
                text(g,"4. Main inventory and offhand items do not count.",163,306,0xFFE2DAED);
                text(g,"Higher wins: 5.1 beats 5, so Host wins.",163,326,0xFFFFD982);
                text(g,"Payments use arrival order. Set Payment Limits above.",163,346,0xFFBFAAD9);
                text(g,"Press "+JamblePayments.reviewKeyName()+" for payment buttons after a viewer win.",163,366,0xFFA9A9C2);
            }
            case "Customize Totem" -> {
                if(donutPack) {
                    for(int i=0;i<TotemStyle.PACK.length;i++) {
                        TotemStyle style=TotemStyle.PACK[i];int tx=153+i%3*158,ty=109+i/3*130;
                        boolean equipped=AstraConfig.totemStyle()==style;
                        if(equipped)Ui.round(g,tx-2,ty-2,150,126,13,0x557D43DA);
                        Ui.round(g,tx,ty,146,122,11,equipped?0xFFD8B5FF:0xFF6C5A88);
                        Ui.gradient(g,tx+1,ty+1,144,120,10,equipped?0xFF40305B:0xFF302A43,0xFF19182F);
                        var label=Ui.text(style.label());float small=Math.min(1,130f/font.width(label));
                        g.pose().pushMatrix();g.pose().translate(tx+73,ty+8);g.pose().scale(small,small);Ui.animated(g,font,label,-font.width(label)/2f,0,equipped?0xFFF0D9FF:0xFFE2DAED);g.pose().popMatrix();
                        style.preview(g,tx+43,ty+24,60);
                    }
                    text(g,"One totem equipped at a time. Unequip restores Minecraft's.",156,381,0xFFB5AACB);
                } else {
                    card(g,X,105,CW,232,"DonutSMP Pack","Customize Totem");
                    text(g,"Five creator totems. Choose your favourite inside the pack.",163,145,0xFFB5AACB);
                    for(int i=0;i<TotemStyle.PACK.length;i++) {
                        TotemStyle style=TotemStyle.PACK[i];int tx=163+i*90;style.preview(g,tx,171,64);
                        var label=Ui.text(style.creator);Ui.animated(g,font,label,tx+32-font.width(label)/2f,245,0xFFE2DAED);
                    }
                    text(g,"Equipped: "+AstraConfig.totemStyle().creator,163,307,0xFFE0CCF2);
                    text(g,"Restores the original totem.",362,359,0xFFA9A9C2);
                }
            }
            case "Profile" -> {
                card(g,X,105,CW,187,"Minecraft profile","Settings");
                var skin=minecraft.player==null?net.minecraft.client.resources.DefaultPlayerSkin.get(minecraft.getUser().getProfileId()):minecraft.player.getSkin();
                net.minecraft.client.gui.components.PlayerFaceRenderer.draw(g,skin,163,151,42,Ui.tint(0xFFFFFFFF));
                text(g,minecraft.getUser().getName(),220,154,0xFFF0E8FF);
                text(g,PremiumEdition.premium()?"Premium":"Member",220,179,PremiumEdition.premium()?0xFFFFD26F:0xFFAAAAAA);
                text(g,PremiumEdition.description(),163,207,0xFFB5AACB);
                if(PremiumEdition.premium()) {
                    text(g,"Time remaining: "+PremiumEdition.timeLeft(),163,232,0xFFFFD26F);
                    text(g,"Expires: "+PremiumEdition.expiry(),163,257,0xFFB5AACB);
                } else text(g,PremiumEdition.edition()?"Your Premium period has ended. Member mode remains available.":"Premium includes skies, sky lyrics, custom totems and Jamble.",163,232,0xFFA9A9C2);
                text(g,"Astra cosmetic rank. DonutSMP server ranks are separate.",163,277,0xFFA9A9C2);
                card(g,X,300,CW,93,"","Settings");
                text(g,"8-chunk preset, fewer particles, clouds and shadows off.",163,352,0xFFB5AACB);
                text(g,"Keeps HUDs, music and totems. Off restores prior settings.",163,375,0xFFA9A9C2);
            }
            case "Essentials" -> {
                card(g,X,105,CW,215,"Freelook","Essentials");
                text(g,"Use your bind to look around. F5 is not required.",163,181,0xFFA4A3BE);
                text(g,bindingFreelook?"Escape or Delete: clear binding.":FreelookBridge.instruction(),163,255,0xFFB8A6D9);
                String conflict=FreelookBridge.conflict();
                text(g,fitText(conflict.isBlank()?FreelookBridge.status():"Also bound to: "+conflict,440),163,285,conflict.isBlank()?0xFFA4A3BE:0xFFE4C48F);
                card(g,X,332,CW,63,"","Essentials");
                text(g,"Brightens dark areas. Off restores normal lighting.",163,379,0xFFA4A3BE);
            }
            case "Buy Premium" -> {
                card(g,X,105,CW,275,"Astra Premium","Buy Premium");
                MenuArt.icon(g,"Buy Premium",163,149,42,0xFFFFFFFF);
                text(g,PremiumEdition.premium()?"Premium is active / "+PremiumEdition.timeLeft():"Make Astra yours.",218,157,0xFFFFD982);
                text(g,"Six custom skies and lyrics in the sky.",163,211,0xFFE5D9F7);
                text(g,"3D creator totems and the Jamble tracker.",163,233,0xFFE5D9F7);
                text(g,"Get the separate 30-day edition in our Discord.",163,260,0xFFB5AACB);
                text(g,PREMIUM_URL,163,346,0xFFAEB9FF);
            }
        }
    }
    @Override public void onClose() {
        if(closing)return;
        closing=true;
        if(!AstraConfig.animations)minecraft.setScreen(null);
    }
    private MouseButtonEvent local(MouseButtonEvent e) {return new MouseButtonEvent((e.x()-originX)/scale,(e.y()-originY)/scale,e.buttonInfo());}
    @Override public boolean mouseClicked(MouseButtonEvent e,boolean twice) {
        if(bindingFreelook) {
            FreelookBridge.bind(com.mojang.blaze3d.platform.InputConstants.Type.MOUSE.getOrCreate(e.button()));bindingFreelook=false;rebuildWidgets();return true;
        }
        if(closing)return true;
        var hit=local(e);
        if((pendingTab!=null || !pageMotion.at(1)) && hit.x()>=X && hit.y()>=70)return true;
        return super.mouseClicked(hit,twice);
    }
    @Override public boolean mouseReleased(MouseButtonEvent e) {return !closing && pendingTab==null && pageMotion.at(1) && super.mouseReleased(local(e));}
    @Override public boolean mouseDragged(MouseButtonEvent e,double dx,double dy) {return !closing && pendingTab==null && pageMotion.at(1) && super.mouseDragged(local(e),dx/scale,dy/scale);}
    @Override public boolean keyPressed(KeyEvent key) {
        if(bindingFreelook) {
            FreelookBridge.bind(key.key()==GLFW.GLFW_KEY_DELETE || key.key()==GLFW.GLFW_KEY_ESCAPE?com.mojang.blaze3d.platform.InputConstants.UNKNOWN:com.mojang.blaze3d.platform.InputConstants.getKey(key));
            bindingFreelook=false;rebuildWidgets();return true;
        }
        if(key.key()==GLFW.GLFW_KEY_RIGHT_SHIFT) {onClose();return true;}
        if(key.key()==GLFW.GLFW_KEY_ESCAPE) {onClose();return true;}
        if(closing || pendingTab!=null || !pageMotion.at(1))return true;
        return super.keyPressed(key);
    }
    @Override public void removed() {AstraConfig.flush();super.removed();}
    @Override public boolean isPauseScreen() {return false;}
}
