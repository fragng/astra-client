package client.astra.mixin;

import client.astra.FreelookBridge;
import net.ninjadev.freelook.fabric.event.CameraEvents;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.Shadow;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfoReturnable;

/** Keep the upstream camera-only implementation; gate it through Astra's setting. */
@Mixin(value=CameraEvents.class,remap=false)
public abstract class FreelookGateMixin {
    @Shadow private static boolean isToggled;
    @Shadow private static void reset() {throw new AssertionError();}
    @Inject(method="onClientTick",at=@At("HEAD"),cancellable=true,remap=false)
    private static void astra$holdMode(CallbackInfo ci) {
        isToggled=false;
        if(!FreelookBridge.allowed())reset();
        ci.cancel();
    }
    @Inject(method="onCameraUpdate",at=@At("HEAD"),cancellable=true,remap=false)
    private static void astra$cameraGate(CallbackInfo ci) {
        isToggled=false;
        if(!FreelookBridge.allowed()) {reset();ci.cancel();}
    }
    @Inject(method="shouldUpdate",at=@At("HEAD"),cancellable=true,remap=false)
    private static void astra$inactiveGate(CallbackInfoReturnable<Boolean> cir) {
        if(!FreelookBridge.allowed()) {reset();cir.setReturnValue(false);}
    }
}
