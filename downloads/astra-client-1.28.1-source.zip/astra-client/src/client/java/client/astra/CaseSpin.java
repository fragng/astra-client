package client.astra;

import java.util.*;

/** Fixed committed outcome and a frame-rate-independent, bounded reveal animation. */
public final class CaseSpin {
    public static final double SECONDS=2.0,ROLL_SECONDS=1.8,AUTO_SECONDS=SECONDS*10;
    public static final int LAND=44,SIZE=54;
    public final CaseLedger.Draw draw;public final List<CaseReward> cards;
    public final long started;private final double destination;
    public CaseSpin(CaseLedger.Draw draw,long now){
        this.draw=Objects.requireNonNull(draw);started=now;var rng=new Random(draw.id().getMostSignificantBits()^draw.id().getLeastSignificantBits());var list=new ArrayList<CaseReward>();for(int i=0;i<SIZE;i++)list.add(CaseReward.pick(rng));list.set(LAND,draw.reward());cards=List.copyOf(list);destination=LAND+(rng.nextDouble()-.5)*.42;
    }
    public static CaseSpin restore(CaseLedger.Draw draw,long nowNanos,long nowMillis){long elapsed=Math.clamp(nowMillis-draw.at(),0,(long)(SECONDS*1000));return new CaseSpin(draw,nowNanos-elapsed*1_000_000);}
    public double progress(long now){return Math.clamp((now-started)/(SECONDS*1e9),0,1);}
    public double position(long now,boolean animate){
        double t=Math.clamp((now-started)/(ROLL_SECONDS*1e9),0,1),from=LAND-20;
        return animate?from+(destination-from)*(1-Math.pow(1-t,3)):destination;
    }
    public int cardAt(long now,boolean animate){return (int)Math.floor(position(now,animate)+.5);}
    public boolean finished(long now){return progress(now)>=1;}
    public int landing(){return (int)Math.floor(destination+.5);}
}
