package client.astra;

import com.mojang.blaze3d.vertex.PoseStack;
import net.fabricmc.fabric.api.client.rendering.v1.LivingEntityFeatureRendererRegistrationCallback;
import net.minecraft.client.Minecraft;
import net.minecraft.client.model.geom.*;
import net.minecraft.client.model.geom.builders.*;
import net.minecraft.client.model.player.PlayerModel;
import net.minecraft.client.renderer.*;
import net.minecraft.client.renderer.entity.RenderLayerParent;
import net.minecraft.client.renderer.entity.layers.RenderLayer;
import net.minecraft.client.renderer.entity.player.AvatarRenderer;
import net.minecraft.client.renderer.entity.state.AvatarRenderState;
import net.minecraft.client.renderer.rendertype.RenderTypes;
import net.minecraft.client.renderer.texture.OverlayTexture;
import net.minecraft.resources.Identifier;

/** Local cosmetic equipment only; does not change movement, flight or server/player data. */
public final class CaseCosmeticLayer extends RenderLayer<AvatarRenderState,PlayerModel> {
    private static final Identifier WHITE=Identifier.fromNamespaceAndPath(AstraClient.MOD_ID,"textures/misc/case-white.png");
    private final ModelPart crown,wings;
    private CaseCosmeticLayer(RenderLayerParent<AvatarRenderState,PlayerModel> parent){super(parent);crown=CaseCosmeticMeshes.crown();wings=CaseCosmeticMeshes.wings();}
    @SuppressWarnings({"rawtypes","unchecked"})
    public static void initialize(){LivingEntityFeatureRendererRegistrationCallback.EVENT.register((type,renderer,helper,context)->{if(renderer instanceof AvatarRenderer avatar)helper.register(new CaseCosmeticLayer(avatar));});}
    private static void part(ModelPart part,PoseStack pose,SubmitNodeCollector collector,int light,int color,boolean glow){collector.submitModelPart(part,pose,glow?RenderTypes.entityTranslucentEmissive(WHITE):RenderTypes.entityCutoutNoCull(WHITE),light,OverlayTexture.NO_OVERLAY,null,false,false,color,null,0);}
    public void submit(PoseStack pose,SubmitNodeCollector collector,int light,AvatarRenderState state,float yaw,float pitch){
        var mc=Minecraft.getInstance();if(mc.player==null||state.id!=mc.player.getId()||state.isInvisible)return;
        if(CaseGames.crown()){
            pose.pushPose();try{getParentModel().head.translateAndRotate(pose);var style=AstraConfig.characterStyle();float scale=switch(style){case SPONGEBOB->1.6f;case DRDONUTT->.82f;case SQUIDWARD,SANDY->1.2f;default->1;};float y=switch(style){case SPONGEBOB->.10f;case DRDONUTT->0;case SQUIDWARD->.10f;case SANDY->.075f;default->.035f;};pose.translate(0,y,0);pose.scale(scale,scale,scale);part(crown.getChild("gold"),pose,collector,15728880,0xFFFFCC59,false);part(crown.getChild("gems"),pose,collector,15728880,0xFF5FF5DF,false);part(crown.getChild("glints"),pose,collector,15728880,0xFFE2FFF8,false);if(!PerformanceMode.enabled())part(crown.getChild("gems"),pose,collector,15728880,0x4D7EFFE8,true);}finally{pose.popPose();}
        }
        if(CaseGames.wings()){
            float flap=AstraConfig.animations&&!PerformanceMode.enabled()?(float)Math.sin(state.ageInTicks*.055)*.12f:0;
            var left=wings.getChild("left");var right=wings.getChild("right");left.yRot=.25f+flap;right.yRot=-.25f-flap;
            pose.pushPose();try{getParentModel().body.translateAndRotate(pose);if(AstraConfig.characterStyle()!=CharacterStyle.NONE)pose.translate(0,0,.09);for(var side:new ModelPart[]{left,right}){pose.pushPose();try{side.translateAndRotate(pose);part(side.getChild("dark"),pose,collector,light,0xFF71218E,false);part(side.getChild("pink"),pose,collector,15728880,0xFFE837BC,false);part(side.getChild("gold"),pose,collector,15728880,0xFFF5C556,false);part(side.getChild("cream"),pose,collector,light,0xFFFFE4AF,false);if(!PerformanceMode.enabled())part(side.getChild("pink"),pose,collector,15728880,0x25FF65DC,true);}finally{pose.popPose();}}}finally{pose.popPose();}
        }
    }
}
