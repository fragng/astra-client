package client.astra;

import net.minecraft.client.gui.GuiGraphics;
import net.minecraft.world.item.*;
import java.util.EnumMap;

public final class CaseArt {
    private static final net.minecraft.resources.Identifier ART=net.minecraft.resources.Identifier.fromNamespaceAndPath(AstraClient.MOD_ID,"textures/cases/rewards.png");
    private static final EnumMap<CaseReward,ItemStack> ICONS=new EnumMap<>(CaseReward.class);
    private CaseArt(){}
    public static void nothing(GuiGraphics g,int x,int y,int w,int h){art(g,2,x,y,w,h);}
    private static void art(GuiGraphics g,int cell,int x,int y,int w,int h){
        int[] region=switch(cell){case 0->new int[]{48,116,674,605};case 1->new int[]{748,112,1425,609};default->new int[]{1481,287,2138,425};};
        float factor=Math.min(w/(float)(region[2]-region[0]),h/(float)(region[3]-region[1]));int rw=Math.max(1,Math.round((region[2]-region[0])*factor)),rh=Math.max(1,Math.round((region[3]-region[1])*factor));
        Ui.texture(g,ART,x+(w-rw)/2,y+(h-rh)/2,rw,rh,region[0]/2172f,region[2]/2172f,region[1]/724f,region[3]/724f,2172,724);
    }
    public static void icon(GuiGraphics g,CaseReward reward,int x,int y,int size){
        if(reward==CaseReward.NOTHING){art(g,2,x,y,size,size);return;}
        if(reward==CaseReward.CROWN){art(g,0,x,y,size,size);return;}
        if(reward==CaseReward.WINGS){art(g,1,x,y,size,size);return;}
        if(reward==CaseReward.SKIN_TOTEM){PersonalTotemRenderer.preview(g,x,y,size);return;}
        var stack=ICONS.computeIfAbsent(reward,key->new ItemStack(switch(key){case CROWN->Items.GOLDEN_HELMET;case WINGS->Items.ELYTRA;case DISCORD_RANK->Items.NAME_TAG;case MONTH_PREMIUM->Items.NETHER_STAR;default->Items.ENCHANTED_GOLDEN_APPLE;}));
        g.pose().pushMatrix();g.pose().translate(x,y);g.pose().scale(size/16f,size/16f);g.renderFakeItem(stack,0,0);g.pose().popMatrix();
    }
}
