package client.astra;

import java.util.random.RandomGenerator;

/** One mutually exclusive draw. Presentation never chooses or changes its outcome. */
public enum CaseReward {
    DISCORD_RANK("Special Discord Rank","Discord Rank",150,0xFFE4A3FF,true),
    MONTH_PREMIUM("1 Month Premium","1 Month",50,0xFFFFD77B,true),
    LIFETIME_PREMIUM("Lifetime Premium","Lifetime",20,0xFFFF8FAD,true),
    CROWN("Yellow Glowing Crown","Crown",240,0xFFFFDF53,false),
    WINGS("Astral Wings","Wings",120,0xFFF25AD3,false),
    SKIN_TOTEM("Your Skin Totem","Skin Totem",30,0xFF8CE4C8,false),
    NOTHING("No drop this time","No Drop",59390,0xFF9291AE,false);
    public static final int TICKETS=60000;
    public static final CaseReward[] CONTENTS={DISCORD_RANK,MONTH_PREMIUM,LIFETIME_PREMIUM,CROWN,SKIN_TOTEM,WINGS};
    public static final String[] MISS_LINES={"Better luck next time!","The stars missed this one.","A quiet case. Your next one awaits.","Not this time. Keep shining!","Empty orbit. Fresh chances ahead.","The next case could be the one."};
    public final String title,shortTitle;public final int weight,color;public final boolean ticketClaim;
    CaseReward(String title,String shortTitle,int weight,int color,boolean ticketClaim){this.title=title;this.shortTitle=shortTitle;this.weight=weight;this.color=color;this.ticketClaim=ticketClaim;}
    public boolean cosmetic(){return this==CROWN || this==WINGS || this==SKIN_TOTEM;}
    public static CaseReward pick(int ticket){
        if(ticket<0||ticket>=TICKETS)throw new IllegalArgumentException("Draw ticket");
        for(var reward:values()){if(ticket<reward.weight)return reward;ticket-=reward.weight;}throw new IllegalStateException("Case table");
    }
    public static CaseReward pick(RandomGenerator random){return pick(random.nextInt(TICKETS));}
}
