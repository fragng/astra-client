#!/usr/bin/env python3
"""Author closed cuboid character models, reusing the supplied front-art UVs.

Side/back surfaces are estimates using the same hair, clothing and shoe patches.
This edits geometry/UV JSON only; it does not modify the texture artwork.
"""
from pathlib import Path
import json
ROOT=Path(__file__).resolve().parents[1]/'src/main/resources/assets/astra-client/models/item/totem'

def uv(rect):return [round(n/4,4) for n in rect] # texture is 64px; block UV units are 0..16

def cube(name,lo,hi,front,side=None,back=None,top=None,bottom=None):
    side=side or front;back=back or side;top=top or back;bottom=bottom or top
    faces={k:{'uv':uv(r),'texture':'#skin'} for k,r in {
        'south':front,'north':back,'east':side,'west':side,'up':top,'down':bottom}.items()}
    return {'name':name,'from':lo,'to':hi,'faces':faces}

DATA={
 'drdonut':dict(head=(21,4,42,22),hair=(25,4,38,8),skin=(24,11,27,15),body=(21,22,42,42),back=(24,28,39,41),arms=[(13,22,21,35),(42,22,50,35)],legs=[(23,42,31,61),(32,42,40,61)],shoes=(24,58,38,61)),
 'jettism':dict(head=(22,8,41,22),hair=(27,22,36,29),skin=(27,22,36,29),body=(22,22,41,42),back=(26,26,38,38),arms=[(14,22,22,35),(41,22,49,35)],legs=[(24,42,31,61),(32,42,39,61)],shoes=(27,52,37,60)),
 'farex':dict(head=(24,15,40,24),hair=(25,21,29,23),skin=(27,20,30,22),body=(23,24,41,44),back=(25,31,39,42),arms=[(15,24,23,37),(41,24,49,37)],legs=[(25,44,32,61),(33,44,40,61)],shoes=(27,54,37,60)),
 'hoozar0':dict(head=(21,6,43,23),hair=(25,8,36,15),skin=(26,19,30,22),body=(21,23,43,42),back=(25,36,40,41),arms=[(14,23,21,35),(43,23,50,35)],legs=[(23,42,32,61),(33,42,41,61)],shoes=(25,58,39,61)),
 'jack':dict(head=(20,10,43,23),hair=(31,14,34,17),skin=(23,20,27,22),body=(21,23,42,44),back=(28,33,38,42),arms=[(13,23,21,35),(42,23,50,35)],legs=[(23,44,31,61),(32,44,40,61)],shoes=(24,56,39,61))
}
DISPLAY={
 'gui':{'rotation':[20,-25,0],'translation':[0,-.2,0],'scale':[.86,.86,.86]},
 'ground':{'rotation':[0,0,0],'translation':[0,3,0],'scale':[.5,.5,.5]},
 'fixed':{'rotation':[0,180,0],'scale':[.8,.8,.8]},
 'on_shelf':{'rotation':[0,180,0],'scale':[.85,.85,.85]},
 'head':{'rotation':[0,180,0],'translation':[0,13,7],'scale':[.8,.8,.8]},
 'thirdperson_righthand':{'rotation':[0,0,0],'translation':[0,3,1],'scale':[.55,.55,.55]},
 'thirdperson_lefthand':{'rotation':[0,0,0],'translation':[0,3,1],'scale':[.55,.55,.55]},
 'firstperson_righthand':{'rotation':[0,-25,0],'translation':[1.13,2.2,1.13],'scale':[.68,.68,.68]},
 'firstperson_lefthand':{'rotation':[0,25,0],'translation':[1.13,2.2,1.13],'scale':[.68,.68,.68]},
}
for name,d in DATA.items():
    head_top=14 if name=='farex' else 15.4 if name=='jack' else 15.5 if name=='jettism' else 16
    elements=[cube('Head',[6,12,6],[10,head_top,10],d['head'],d['hair'],d['hair'],d['hair'],d['skin']),
              cube('Torso',[6,6,7],[10,12,9],d['body'],d['back'],d['back'],d['back'])]
    for i,(x,arm) in enumerate(zip([4,10],d['arms'])):
        elements.append(cube('Arm '+str(i+1),[x,6,7],[x+2,12,9],arm,arm,arm,tuple([arm[0],arm[1],arm[2],arm[1]+3]),d['skin']))
    for i,(x,leg) in enumerate(zip([6,8.06],d['legs'])):
        elements.append(cube('Leg '+str(i+1),[x,0,7],[x+1.94,6,9],leg,leg,leg,d['back'],d['shoes']))
    if name=='jettism':
        gold=(24,6,27,7);blue=(30,10,34,14)
        elements.append(cube('Gold crown band',[5.9,15.2,5.9],[10.1,15.6,10.1],gold))
        for i,(x,z) in enumerate([(6,6),(7.6,6),(9.2,6),(6,9.2),(7.6,9.2),(9.2,9.2),(6,7.6),(9.2,7.6)]):
            elements.append(cube('Crown point '+str(i),[x,15.6,z],[x+.8,16.4,z+.8],gold))
        for i,(lo,hi) in enumerate([([7.7,15.25,10.1],[8.3,15.55,10.16]),([7.7,15.25,5.84],[8.3,15.55,5.9]),([5.84,15.25,7.7],[5.9,15.55,8.3]),([10.1,15.25,7.7],[10.16,15.55,8.3])]):
            elements.append(cube('Crown blue jewel '+str(i),lo,hi,blue))
    elif name=='farex':
        black=(28,9,36,11);hat=(24,4,40,15);band=(27,9,37,11)
        elements += [cube('Top hat brim',[5.6,14,5.6],[10.4,14.3,10.4],black),cube('Top hat',[6.05,14.3,6.05],[9.95,16.4,9.95],hat,hat,hat,(26,4,38,8)),cube('Hat ribbon',[6,14.4,6],[10,14.75,10],band)]
    elif name=='hoozar0':
        red=(26,44,30,48);white=(29,4,34,5)
        elements += [cube('Hood back',[5.85,12.5,5.8],[10.15,16.1,6.05],red),cube('Hood top',[5.85,15.8,5.8],[10.15,16.12,10.12],red),cube('Hood left edge',[5.85,13.2,6],[6.04,15.9,8.5],red),cube('Hood right edge',[9.96,13.2,6],[10.15,15.9,8.5],red),cube('White hood trim',[5.8,15.75,9.95],[10.2,16.08,10.2],white)]
    elif name=='jack':
        red=(25,3,36,5);white=(22,9,26,11);cyan=(14,26,16,33)
        elements += [cube('Santa hat',[6.05,15.25,6.05],[9.95,16.1,9.95],red),cube('White hat brim',[5.85,15.1,5.85],[10.15,15.5,10.15],white),cube('Hat pompom',[9.7,15,8.6],[10.6,15.9,9.5],white),cube('Hoodie left seam',[6,6.1,6.92],[6.18,11.7,7.03],cyan),cube('Hoodie right seam',[9.82,6.1,6.92],[10,11.7,7.03],cyan)]
    if name in ('drdonut','hoozar0','jack'):
        for i,x in enumerate([6,8.06]):elements.append(cube('Shoe toe '+str(i),[x,0,9],[x+1.94,1.0,9.4],d['shoes']))
    model={'gui_light':'front','ambientocclusion':False,'textures':{'skin':f'astra-client:item/totem/{name}','particle':'#skin'},'display':DISPLAY,'elements':elements}
    ROOT.mkdir(parents=True,exist_ok=True);(ROOT/f'{name}.json').write_text(json.dumps(model,indent=2)+'\n')
    print(name,len(elements),'closed cuboids',len(elements)*6,'faces')
