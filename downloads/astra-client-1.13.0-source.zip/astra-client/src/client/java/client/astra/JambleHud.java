package client.astra;

import net.minecraft.client.Minecraft;
import net.minecraft.client.gui.Font;
import net.minecraft.client.gui.GuiGraphics;
import net.minecraft.client.gui.screens.inventory.AnvilScreen;
import net.minecraft.core.component.DataComponents;
import net.minecraft.world.item.Item;
import net.minecraft.world.item.ItemStack;
import java.util.*;

/** Read-only hotbar acquisition tracker. It never moves or changes inventory items. */
public final class JambleHud {
    private static final long PAIR_TIME=2_000_000_000L,DISPLAY_TIME=8_000_000_000L,TITLE_TIME=3_500_000_000L;
    private static final int CARD_W=104,CARD_H=78,TOP=10;
    private record Key(Item item,JambleRules.Number number){}
    private record Entry(long count,ItemStack icon){}
    private record Snapshot(Map<Item,Long> physical,Map<Key,Long> named,Map<Key,Entry> hotbar){}
    private record Pending(Key key,ItemStack icon,long time){}
    public record Round(JambleRules.Number host,JambleRules.Number viewer,ItemStack hostIcon,ItemStack viewerIcon,JambleRules.Side winner,long started,long sequence){}
    private static Object player,level;
    private static Snapshot previous;
    private static Pending host,viewer;
    private static Round round;
    private static long readyAt,sequence;
    private static String status="Off";
    private JambleHud(){}
    public static Round round(){return round;}
    public static String status(){return status;}
    public static void reset(){player=null;level=null;previous=null;host=null;viewer=null;round=null;readyAt=0;status=AstraConfig.jambleEnabled?"Waiting for the hotbar to synchronise...":"Off";}
    private static void add(Snapshot s,ItemStack stack,boolean hotbar){
        if(stack.isEmpty())return;
        s.physical.merge(stack.getItem(),(long)stack.getCount(),Long::sum);
        var name=stack.get(DataComponents.CUSTOM_NAME);if(name==null)return;
        var number=JambleRules.parse(name.getString());if(number==null)return;
        var key=new Key(stack.getItem(),number);s.named.merge(key,(long)stack.getCount(),Long::sum);
        if(hotbar){var old=s.hotbar.get(key);s.hotbar.put(key,new Entry((old==null?0:old.count)+stack.getCount(),stack));}
    }
    private static Snapshot snapshot(Minecraft mc){
        var s=new Snapshot(new HashMap<>(),new HashMap<>(),new LinkedHashMap<>());
        var inventory=mc.player.getInventory();for(int i=0;i<inventory.getContainerSize();i++)add(s,inventory.getItem(i),i<9);
        // Cursor-held items are still owned; moving them back into the hotbar is not a pickup.
        add(s,mc.player.containerMenu.getCarried(),false);return s;
    }
    public static void tick(Minecraft mc){
        if(!AstraConfig.jambleEnabled||mc.player==null||mc.level==null){if(previous!=null||round!=null||player!=null)reset();return;}
        long now=System.nanoTime();Snapshot current=snapshot(mc);
        if(player!=mc.player||level!=mc.level||previous==null){player=mc.player;level=mc.level;previous=current;host=null;viewer=null;round=null;readyAt=now+1_000_000_000L;status="Waiting for the hotbar to synchronise...";return;}
        if(now<readyAt || mc.screen instanceof AnvilScreen){previous=current;host=null;viewer=null;return;}
        if(host!=null&&(now-host.time>PAIR_TIME||!current.hotbar.containsKey(host.key)))host=null;
        if(viewer!=null&&(now-viewer.time>PAIR_TIME||!current.hotbar.containsKey(viewer.key)))viewer=null;
        Pending newHost=null,newViewer=null;boolean ambiguous=false;
        var gains=new HashMap<Item,Long>();current.physical.forEach((item,count)->gains.put(item,count-previous.physical.getOrDefault(item,0L)));
        for(var pair:current.hotbar.entrySet()) {
            Key key=pair.getKey();Entry entry=pair.getValue();Entry old=previous.hotbar.get(key);
            long hotGain=entry.count-(old==null?0:old.count),namedGain=current.named.getOrDefault(key,0L)-previous.named.getOrDefault(key,0L);
            long added=Math.min(Math.min(hotGain,namedGain),gains.getOrDefault(key.item,0L));
            if(added<=0)continue;
            gains.merge(key.item,-added,Long::sum);
            if(added!=1){ambiguous=true;continue;}
            var next=new Pending(key,entry.icon.copyWithCount(1),now);
            if(key.number.side()==JambleRules.Side.HOST){if(newHost!=null||host!=null)ambiguous=true;newHost=next;}
            else {if(newViewer!=null||viewer!=null)ambiguous=true;newViewer=next;}
        }
        previous=current;
        if(ambiguous){host=null;viewer=null;round=null;status="Receive exactly one Host and one Viewer item together.";return;}
        if(newHost!=null)host=newHost;if(newViewer!=null)viewer=newViewer;
        if(host!=null&&viewer!=null){
            var h=host;var v=viewer;host=null;viewer=null;
            round=new Round(h.key.number,v.key.number,h.icon,v.icon,JambleRules.winner(h.key.number,v.key.number),now,++sequence);
            status=round.winner==JambleRules.Side.HOST?"Host Wins!":"Viewer Wins!";
        }else status=host!=null?"Host received. Waiting for Viewer...":viewer!=null?"Viewer received. Waiting for Host...":"Watching hotbar for a new pair.";
    }
    public static boolean visible(){return AstraConfig.jambleEnabled && round!=null && Minecraft.getInstance().screen==null && System.nanoTime()-round.started<DISPLAY_TIME;}
    private static float musicWidth(int width){return Math.min((float)AstraConfig.spotifyHudScale,(width-16f)/320)*320;}
    private static boolean flanked(int width){return AstraConfig.hudSpotify && width>=musicWidth(width)+CARD_W*2+48;}
    public static int spotifyTop(int width){return visible()&&!flanked(width)?TOP+CARD_H+8:12;}
    private static int hostX(int width){return flanked(width)?Math.round((width-musicWidth(width))/2)-CARD_W-12:width/2-CARD_W-6;}
    private static int viewerX(int width){return flanked(width)?Math.round((width+musicWidth(width))/2)+12:width/2+6;}
    public static int watermarkY(int width,int watermarkWidth,int initial){
        if(!visible())return initial;int right=8+watermarkWidth;
        boolean overlap=8<hostX(width)+CARD_W&&right>hostX(width)||8<viewerX(width)+CARD_W&&right>viewerX(width);
        return overlap?Math.max(initial,TOP+CARD_H+8):initial;
    }
    public static void draw(GuiGraphics g,Font font){
        if(!visible())return;
        long elapsed=System.nanoTime()-round.started;
        float fade=AstraConfig.animations?Math.min(1,Math.min(elapsed/220_000_000f,(DISPLAY_TIME-elapsed)/350_000_000f)):1;
        float old=Ui.pushOpacity(fade);
        try{
            card(g,font,hostX(g.guiWidth()),"Host",round.host.label(),round.hostIcon,round.winner==JambleRules.Side.HOST,fade);
            card(g,font,viewerX(g.guiWidth()),"Viewer",round.viewer.label(),round.viewerIcon,round.winner==JambleRules.Side.VIEWER,fade);
        }finally{Ui.restoreOpacity(old);}
        if(elapsed<TITLE_TIME){
            float alpha=AstraConfig.animations?Math.min(1,Math.min(elapsed/180_000_000f,(TITLE_TIME-elapsed)/300_000_000f)):1;
            old=Ui.pushOpacity(alpha);
            try{
                String text=round.winner==JambleRules.Side.HOST?"Host Wins!":"Viewer Wins!";
                float size=Math.min(2.1f,(g.guiWidth()-40f)/font.width(Ui.heading(text)));
                int w=Math.round(font.width(Ui.heading(text))*size)+30,h=38,x=(g.guiWidth()-w)/2,y=g.guiHeight()/2-h/2;
                Ui.round(g,x-2,y-2,w+4,h+4,12,0x55B38BF0);Ui.round(g,x,y,w,h,10,0xE81B1630);
                Ui.centered(g,font,text,g.guiWidth()/2,y+10,size,round.winner==JambleRules.Side.HOST?0xFFFFD982:0xFF91E9FF);
            }finally{Ui.restoreOpacity(old);}
        }
    }
    private static void card(GuiGraphics g,Font font,int x,String side,String number,ItemStack icon,boolean winner,float fade){
        int y=TOP+Math.round((1-fade)*-5);int accent=winner?0xFFECCB81:0xFFA68BC9;
        Ui.round(g,x-1,y-1,CARD_W+2,CARD_H+2,11,Ui.alpha(accent,.45f));Ui.round(g,x,y,CARD_W,CARD_H,10,accent);
        Ui.gradient(g,x+1,y+1,CARD_W-2,CARD_H-2,9,0xF13A2D50,0xF014172B);
        var role=Ui.heading(side);Ui.animated(g,font,role,x+(CARD_W-font.width(role))/2f,y+8,0xFFD9C7F1);
        Ui.centered(g,font,number,x+CARD_W/2,y+25,1.8f,winner?0xFFFFE2A4:0xFFF1EAFF);
        g.pose().pushMatrix();g.pose().translate(x+CARD_W/2f-11,y+51);g.pose().scale(22/16f,22/16f);g.renderFakeItem(icon,0,0);g.pose().popMatrix();
    }
}
