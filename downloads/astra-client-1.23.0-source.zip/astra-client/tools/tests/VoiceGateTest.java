package client.astra;
public final class VoiceGateTest {
    private static void check(boolean ok,String why){if(!ok)throw new AssertionError(why);}
    public static void main(String[] args){
        VoiceGate gate=new VoiceGate();long t=1_000_000_000L;
        check(gate.accept(VoiceEvent.RAIN,t,3,1),"initial event");
        check(!gate.accept(VoiceEvent.MINING,t+1,2,1),"no overlapping chatter");
        check(gate.accept(VoiceEvent.TOTEM,t+2,3,1),"urgent pop interrupts weather");
        check(!gate.accept(VoiceEvent.HURT,t+3,2,1),"injury cannot mask totem");
        check(!gate.accept(VoiceEvent.TOTEM,t+4,2,1),"duplicate packet debounce");
        check(!gate.accept(VoiceEvent.CHEST,t+5_000_000_000L,2,1),"global quiet gap");
        check(gate.accept(VoiceEvent.DIAMOND,t+5_000_000_001L,2,1),"milestone bypasses quiet gap");
        check(!gate.accept(VoiceEvent.RAIN,t+30_000_000_000L,2,1),"per-event cooldown");
        check(gate.accept(VoiceEvent.RAIN,t+50_000_000_000L,2,1),"event recovers");
        gate.clear();check(gate.accept(VoiceEvent.RAIN,t,2,0),"clear releases previous world");check(!gate.accept(VoiceEvent.MINING,t+20_000_000_000L,2,0),"calm cadence");
        gate.clear();check(gate.accept(VoiceEvent.RAIN,t,2,2),"chatty initial");check(gate.accept(VoiceEvent.MINING,t+9_000_000_000L,2,2),"chatty cadence");
        for(var event:VoiceEvent.values()){check(event.enabled(31),"default all groups");check(!event.enabled(0),"all groups off");check(event.enabled(1<<event.group),"correct group");check(!event.enabled(31^(1<<event.group)),"group can be disabled");}
        System.out.println("PASS voice priority, overlap prevention, totem debounce, cooldowns, cadence, clearing and 27 grouped events");
    }
}
