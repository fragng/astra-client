package client.astra;
import java.util.List;
public final class CharacterSurfaceTest {
    private static void check(boolean ok,String why){if(!ok)throw new AssertionError(why);}
    public static void main(String[] args){
        var mesh=CharacterMesh.build(-5,-5,-3,10,10,6,.2,0,false,.2,48);
        var pore=new CharacterSurface.Pore(0,0,2,.4f);var refined=CharacterSurface.recess(mesh,List.of(pore));float[] a=mesh.vertices(),b=refined.vertices();int recessed=0,center=0,back=0;
        for(int i=0;i<a.length;i+=6){
            if(a[i+2]>0){check(a[i+2]==b[i+2],"back must remain solid");back++;}
            check(b[i+2]<=mesh.maxZ() && b[i+2]>=mesh.minZ(),"closed depth bounds");
            check(mesh.maxZ()-b[i+2]>=2.99 || a[i+2]>=0,"no through-hole");
            double n=b[i+3]*b[i+3]+b[i+4]*b[i+4]+b[i+5]*b[i+5];check(Math.abs(n-1)<.00001,"recess unit normal");
            if(b[i+2]>a[i+2])recessed++;
            if(Math.abs(a[i])<.00001 && Math.abs(a[i+1])<.00001 && a[i+2]<0){check(Math.abs(b[i+2]-a[i+2]-.4)<.00001,"blind pore floor depth");center++;}
            if(a[i]*a[i]+a[i+1]*a[i+1]>=4)check(a[i+2]==b[i+2],"smoothly joins untouched surface");
        }
        check(recessed>40 && center>0 && back>100,"real recessed surface, not painted spot");
        check(CharacterSurface.shade(0,0,-2.6f,"sponge",List.of(pore))<CharacterSurface.shade(3,3,-3,"sponge",List.of(pore)),"pore interior material shade");
        check(CharacterSurface.recess(mesh,List.of())==mesh,"reuse untouched geometry");
        System.out.println("PASS real blind pore floor, solid back, unchanged boundary, smooth unit normals and material shading");
    }
}
