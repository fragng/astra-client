package client.astra;

/** Closed, genuinely curved geometry with consistent winding and lighting normals. */
public final class CharacterMeshTest {
    private static void require(boolean ok,String message){if(!ok)throw new AssertionError(message);}
    private static void validate(CharacterMesh.Mesh shape){
        float[] v=shape.vertices();require(v.length%24==0 && v.length>100,"quad geometry");double volume=0;
        for(int i=0;i<v.length;i+=6){
            for(int j=0;j<6;j++)require(Float.isFinite(v[i+j]),"finite vertex");
            double n=v[i+3]*v[i+3]+v[i+4]*v[i+4]+v[i+5]*v[i+5];require(Math.abs(n-1)<.00001,"unit normal");
        }
        for(int i=0;i<v.length;i+=24)for(int tri=0;tri<2;tri++){
            int a=i,b=i+(tri==0?6:12),c=i+(tri==0?12:18);
            double ux=v[b]-v[a],uy=v[b+1]-v[a+1],uz=v[b+2]-v[a+2],vx=v[c]-v[a],vy=v[c+1]-v[a+1],vz=v[c+2]-v[a+2];
            double nx=uy*vz-uz*vy,ny=uz*vx-ux*vz,nz=ux*vy-uy*vx;
            require(nx*nx+ny*ny+nz*nz>1e-12,"nondegenerate triangle");
            double alignment=nx*(v[a+3]+v[b+3]+v[c+3])+ny*(v[a+4]+v[b+4]+v[c+4])+nz*(v[a+5]+v[b+5]+v[c+5]);require(alignment>0,"outward winding");
            volume+=(v[a]*(v[b+1]*v[c+2]-v[b+2]*v[c+1])+v[a+1]*(v[b+2]*v[c]-v[b]*v[c+2])+v[a+2]*(v[b]*v[c+1]-v[b+1]*v[c]))/6.;
        }
        require(volume>0,"positive enclosed volume");
        require(shape.maxX()>shape.minX() && shape.maxY()>shape.minY() && shape.maxZ()>shape.minZ(),"three dimensions");
    }
    public static void main(String[] args){
        for(double p:new double[]{.19,.35,.72,1})for(double taper:new double[]{-.5,0,.62})validate(CharacterMesh.build(-5,-8,-3,10,16,6,p,taper,false,.2));
        validate(CharacterMesh.build(-5,-5,-.25f,10,10,.5f,1,0,true,.2));
        var sphere=CharacterMesh.build(-4,-4,-4,8,8,8,1,0,false,.2);
        for(int i=0;i<sphere.vertices().length;i+=6){float[] v=sphere.vertices();double r=Math.sqrt(v[i]*v[i]+v[i+1]*v[i+1]+v[i+2]*v[i+2]);require(Math.abs(r-4)<.00001,"round silhouette");require(v[i]*v[i+3]+v[i+1]*v[i+4]+v[i+2]*v[i+5]>3.9999,"smooth radial normals");}
        System.out.println("PASS rounded/tapered surfaces, helmet ring, winding, enclosed volume, smooth lighting normals");
    }
}
