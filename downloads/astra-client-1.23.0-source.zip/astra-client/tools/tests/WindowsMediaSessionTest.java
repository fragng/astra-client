package client.astra;
import com.sun.jna.*;
import com.sun.jna.platform.win32.Guid;
import com.sun.jna.ptr.*;
import java.nio.charset.StandardCharsets;
import java.util.*;

/** Native JNA callback/vtable tests of the actual client implementation. */
public class WindowsMediaSessionTest {
 interface NoArg extends Callback {int call(Pointer self);}
 interface Out extends Callback {int call(Pointer self,Pointer out);}
 interface Indexed extends Callback {int call(Pointer self,int index,Pointer out);}
 interface Query extends Callback {int call(Pointer self,Pointer iid,Pointer out);}
 static final class Mock implements WindowsMediaSession.RuntimeApi,AutoCloseable {
  final List<Stub> objects=new ArrayList<>();final List<Memory> allocations=new ArrayList<>();final Map<Long,Memory> strings=new HashMap<>();
  int initialized,uninitialized,live,createdStrings,deletedStrings,status=1,cancelled,closed,metadataReads,next,previous,toggle;
  boolean sessions=true,failedTimeline=false;int count=2;
  final Stub manager,factory,vector,spotify,browser,properties,playback,controls,timeline;
  final long now=(System.currentTimeMillis()+11_644_473_600_000L)*10000;
  final class Stub {
   final Memory table=new Memory(40L*Native.POINTER_SIZE),self=new Memory(Native.POINTER_SIZE);final List<Callback> callbacks=new ArrayList<>();int refs;
   Stub(){allocations.add(table);allocations.add(self);table.clear();self.setPointer(0,table);objects.add(this);slot(2,(NoArg)p->{refs--;live--;return refs;});}
   Stub slot(int i,Callback cb){callbacks.add(cb);table.setPointer((long)i*Native.POINTER_SIZE,CallbackReference.getFunctionPointer(cb));return this;}
   Pointer ref(){refs++;live++;return self;}
   Stub result(int slot,java.util.function.Supplier<Pointer> value){return slot(slot,(Out)(p,out)->{out.setPointer(0,value.get());return 0;});}
   Stub number(int slot,java.util.function.IntSupplier value){return slot(slot,(Out)(p,out)->{out.setInt(0,value.getAsInt());return 0;});}
   Stub flag(int slot,boolean value){return slot(slot,(Out)(p,out)->{out.setByte(0,(byte)(value?1:0));return 0;});}
   Stub ticks(int slot,long value){return slot(slot,(Out)(p,out)->{out.setLong(0,value);return 0;});}
  }
  Pointer hstring(String text){byte[] bytes=text.getBytes(StandardCharsets.UTF_16LE);Memory data=new Memory(bytes.length+2L);allocations.add(data);data.clear();data.write(0,bytes,0,bytes.length);Memory handle=new Memory(Native.POINTER_SIZE+4);allocations.add(handle);handle.setPointer(0,data);handle.setInt(Native.POINTER_SIZE,text.length());strings.put(Pointer.nativeValue(handle),handle);createdStrings++;return handle;}
  Mock(){
   properties=new Stub();properties.result(6,()->{metadataReads++;return hstring("Song \uD83C\uDF19");}).result(9,()->hstring("Artist")).result(10,()->hstring("Album"));
   controls=new Stub().flag(16,true).flag(12,true).flag(13,false);
   playback=new Stub().result(6,controls::ref).number(7,()->4);
   timeline=new Stub().ticks(6,0).ticks(7,2000000000L).ticks(9,2000000000L).ticks(10,50000000L).ticks(11,now-30000000L);
   spotify=new Stub().result(6,()->hstring("SpotifyAB.SpotifyMusic"));
   spotify.result(7,()->operation(properties,false).ref());
   spotify.slot(8,(Out)(p,out)->{if(failedTimeline)return 0x80004001;out.setPointer(0,timeline.ref());return 0;});
   spotify.result(9,playback::ref);
   spotify.result(16,()->{next++;return operation(null,true).ref();}).result(17,()->{previous++;return operation(null,false).ref();}).result(20,()->{toggle++;return operation(null,true).ref();});
   browser=new Stub().result(6,()->hstring("Browser"));
   vector=new Stub().number(7,()->sessions?count:0);
   vector.slot(6,(Indexed)(p,index,out)->{out.setPointer(0,(index==0?browser:spotify).ref());return 0;});
   manager=new Stub().result(7,vector::ref);
   factory=new Stub().result(6,()->operation(manager,false).ref());
  }
  Stub operation(Stub result,boolean value){
   Stub info=new Stub().number(7,()->status).number(8,()->0x80070005);
   info.slot(9,(NoArg)p->{cancelled++;return 0;}).slot(10,(NoArg)p->{closed++;return 0;});
   Stub op=new Stub();op.slot(0,(Query)(p,iid,out)->{var guid=new Guid.GUID(iid);guid.read();if(!guid.toGuidString().equalsIgnoreCase("{00000036-0000-0000-C000-000000000046}"))return 0x80004002;out.setPointer(0,info.ref());return 0;});
   op.slot(8,(Out)(p,out)->{if(result!=null)out.setPointer(0,result.ref());else out.setByte(0,(byte)(value?1:0));return 0;});return op;
  }
  public int RoInitialize(int type){if(type!=1)throw new AssertionError("Not MTA");initialized++;return 0;}
  public void RoUninitialize(){uninitialized++;}
  public int WindowsCreateString(WString text,int length,PointerByReference result){if(length!=text.toString().length())throw new AssertionError("Wrong UTF16 length");result.setValue(hstring(text.toString()));return 0;}
  public int WindowsDeleteString(Pointer value){if(value!=null){if(strings.remove(Pointer.nativeValue(value))==null)throw new AssertionError("String released twice");deletedStrings++;}return 0;}
  public Pointer WindowsGetStringRawBuffer(Pointer value,IntByReference size){Memory handle=strings.get(Pointer.nativeValue(value));size.setValue(handle.getInt(Native.POINTER_SIZE));return handle.getPointer(0);}
  public int RoGetActivationFactory(Pointer name,Guid.GUID iid,PointerByReference out){if(!iid.toGuidString().equalsIgnoreCase("{2050C4EE-11A0-57DE-AED7-C97C70338245}"))return 0x80004002;out.setValue(factory.ref());return 0;}
  void balanced(){if(live!=0 || createdStrings!=deletedStrings || initialized!=uninitialized)throw new AssertionError("Resource leak: COM="+live+" strings="+(createdStrings-deletedStrings)+" apartments="+(initialized-uninitialized));for(Stub s:objects)if(s.refs!=0)throw new AssertionError("Live COM reference");}
  public void close(){for(Memory m:allocations)m.close();}
 }
 static void require(boolean ok,String message){if(!ok)throw new AssertionError(message);}
 public static void main(String[] args)throws Exception {
  try(var mock=new Mock()){
   try(var media=new WindowsMediaSession(mock)){
    var s=media.poll();require(s.connected() && s.title().equals("Song \uD83C\uDF19") && s.artist().equals("Artist") && s.album().equals("Album"),s.toString());
    require(s.playing() && s.toggle() && s.next() && !s.previous(),s.toString());require(s.duration()==200 && s.position()>=8 && s.position()<12,s.toString());
    require(media.command("next") && media.command("toggle") && !media.command("previous"),"Wrong command result");require(mock.next==1 && mock.toggle==1 && mock.previous==1,"Wrong vtable command slots");
    boolean rejected=false;try{media.command("unsupported");}catch(IllegalArgumentException expected){rejected=true;}require(rejected,"Unknown command accepted");
    mock.failedTimeline=true;var noTime=media.poll();require(noTime.connected() && noTime.title().equals(s.title()) && noTime.duration()==0,"Timeline failure hid metadata");
    mock.sessions=false;require(!media.poll().connected(),"No-session state connected");
   }
   mock.balanced();System.out.println("PASS actual native COM-vtable calls: Spotify-only selection, Unicode strings, time/timeline, controls, correct command slots, unsupported actions, missing timeline, empty sessions and balanced references/HSTRING/apartment");
  }
  for(int status:new int[]{2,3,0})try(var mock=new Mock()){
   mock.status=status;boolean failed=false;
   try(var ignored=new WindowsMediaSession(mock)){}catch(IllegalStateException expected){failed=true;}
   require(failed,"Async error/timeout was accepted");if(status==0)require(mock.cancelled==1,"Timeout did not cancel WinRT operation");mock.balanced();System.out.println("PASS async cancellation/error/timeout cleanup: "+status);
  }
  try(var mock=new Mock()){
   try(var media=new WindowsMediaSession(mock)){
    mock.count=257;boolean rejected=false;try{media.poll();}catch(IllegalStateException expected){rejected=true;}require(rejected,"Unbounded session count accepted");
    final boolean[] threadRejected={false};Thread t=new Thread(()->{try{media.poll();}catch(IllegalStateException expected){threadRejected[0]=true;}});t.start();t.join();require(threadRejected[0],"Cross-apartment call allowed");
   }
   mock.balanced();System.out.println("PASS bounded session vector and COM thread affinity");
  }
 }
}
