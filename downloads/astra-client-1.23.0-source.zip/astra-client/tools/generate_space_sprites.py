"""Author cached space-effect sprites; Pillow is a development dependency only."""
from pathlib import Path
from PIL import Image, ImageDraw, ImageFilter
import math
ROOT=Path(__file__).resolve().parents[1]/'src/main/resources/assets/astra-client/textures/gui/sprites/space'
ROOT.mkdir(parents=True,exist_ok=True)

def save(name,im):im.save(ROOT/(name+'.png'),optimize=True)
def planet(name,base,ring):
 im=Image.new('RGBA',(128,100));d=ImageDraw.Draw(im)
 d.ellipse((9,28,119,79),outline=(*ring,105),width=4)
 for radius in range(34,0,-1):
  light=1-(34-radius)*.006
  color=tuple(int(c*light) for c in base)
  d.ellipse((64-radius,47-radius,64+radius,47+radius),fill=(*color,245))
 d.ellipse((39,22,69,43),fill=(*ring,75))
 d.arc((9,28,119,79),0,180,fill=(*ring,230),width=4)
 d.arc((14,31,114,75),8,171,fill=(237,226,255,120),width=1)
 glow=im.filter(ImageFilter.GaussianBlur(5));glow.alpha_composite(im);save(name,glow)
planet('planet_violet',(123,80,179),(195,168,251))
planet('planet_ice',(47,125,159),(151,222,246))
im=Image.new('RGBA',(64,100));d=ImageDraw.Draw(im)
d.polygon([(24,69),(32,99),(41,69)],fill=(218,139,255,100));d.polygon([(27,64),(32,89),(37,64)],fill=(255,183,102,230));d.polygon([(29,63),(32,79),(35,63)],fill=(255,247,203,255))
d.polygon([(17,47),(7,72),(24,65)],fill=(129,91,191,255));d.polygon([(46,47),(56,72),(39,65)],fill=(103,85,167,255))
d.rounded_rectangle((20,21,44,69),radius=10,fill=(215,218,241,255));d.polygon([(20,30),(32,5),(44,30)],fill=(214,188,250,255))
d.rectangle((35,30,43,58),fill=(158,162,202,255));d.ellipse((25,33,39,47),fill=(63,52,105,255));d.ellipse((28,35,37,44),fill=(149,215,250,255));d.line((29,36,33,36),fill=(245,248,255,255),width=2)
save('rocket',im)
for name,w,h,palette in [('meteor',112,40,(255,180,117)),('shooting_star',144,28,(201,174,255))]:
 im=Image.new('RGBA',(w,h));d=ImageDraw.Draw(im)
 for x in range(w-12):
  t=x/(w-13);r=max(1,int((1-t)*h*.13+1));a=int(t*t*210)
  d.line((x,h//2-r,x,h//2+r),fill=(*palette,a),width=1)
 cx=w-13;cy=h//2
 if name=='meteor':
  d.ellipse((cx-10,cy-10,cx+10,cy+10),fill=(222,150,107,255));d.ellipse((cx-5,cy-5,cx+6,cy+6),fill=(110,83,102,255));d.ellipse((cx-6,cy-7,cx,cy-2),fill=(251,218,171,255))
 else:
  d.line((cx-9,cy,cx+9,cy),fill=(243,231,255,230),width=2);d.line((cx,cy-8,cx,cy+8),fill=(243,231,255,230),width=2);d.ellipse((cx-3,cy-3,cx+3,cy+3),fill=(255,255,255,255))
 glow=im.filter(ImageFilter.GaussianBlur(3));glow.alpha_composite(im);save(name,glow)
im=Image.new('RGBA',(16,16));d=ImageDraw.Draw(im);d.line((3,8,13,8),fill=(233,223,255,190));d.line((8,3,8,13),fill=(233,223,255,190));d.ellipse((6,6,10,10),fill=(255,251,255,255));save('star',im)
