#!/usr/bin/env python3
"""Create original seamless procedural sky panoramas. Pillow is an authoring tool only.
The preview and the world dome share each texture; nothing is generated during play.
"""
import math,random
from pathlib import Path
from PIL import Image,ImageDraw
ROOT=Path(__file__).resolve().parents[1]/'src/main/resources/assets/astra-client/textures/sky'
W,H=1024,512
PALETTES={
'northern_echos':((5,12,28),(19,31,67),(66,238,175),(141,86,226)),
'galaxy':((5,8,26),(25,20,62),(80,71,177),(211,135,224)),
'nebula':((12,8,35),(30,24,68),(127,75,181),(74,146,203)),
'astra':((10,5,32),(35,15,72),(145,66,220),(225,128,230)),
'solar_dusk':((23,17,58),(221,120,111),(255,180,117),(172,99,167)),
'midnight':((3,9,24),(16,32,59),(53,101,145),(111,161,199))}
def mix(a,b,t):return tuple(a[i]*(1-t)+b[i]*t for i in range(3))
for number,(name,(top,bottom,light,accent)) in enumerate(PALETTES.items()):
 im=Image.new('RGB',(W,H));pix=im.load()
 for y in range(H):
  v=y/(H-1)
  for x in range(W):
   u=x/W;angle=u*math.tau
   base=mix(top,bottom,v**2.2)
   cloud=(math.sin(angle*3+v*11)+math.sin(angle*7-v*17)*.5+math.sin(angle*13+v*29)*.22)/1.72
   band=.49+.14*math.sin(angle*2)+.06*math.sin(angle*5)
   if name=='northern_echos':
    curtain=math.exp(-((v-band)/.085)**2)*(.63+.37*math.sin(angle*47+v*9)**2)
    strength=curtain*.8;colour=mix(light,accent,.5+.5*math.sin(angle*2))
   elif name=='galaxy':
    strength=math.exp(-((v-(.46+.19*math.sin(angle)))/.12)**2)*(.46+.2*cloud);colour=mix(light,accent,(cloud+1)/2)
   elif name=='nebula':
    strength=max(0,cloud+.26)*.5*(.6+.4*math.sin(v*math.pi));colour=mix(light,accent,.5+.5*math.sin(angle*2+v*9))
   elif name=='astra':
    wave=math.exp(-((v-band)/.055)**2)+.45*math.exp(-((v-band-.14)/.025)**2)
    strength=wave*.55;colour=mix(light,accent,v)
   elif name=='solar_dusk':
    strength=max(0,cloud)*.19*v;colour=light
   else:
    strength=math.exp(-((v-band)/.15)**2)*.12;colour=light
   pix[x,y]=tuple(max(0,min(255,round(c))) for c in mix(base,colour,min(.85,strength)))
 draw=ImageDraw.Draw(im);rng=random.Random(1400+number)
 for i in range(235 if name!='solar_dusk' else 35):
  x=rng.randrange(W);y=rng.randrange(9,H-35)
  brightness=rng.uniform(.35,.85)*(1-y/H*.5);old=im.getpixel((x,y));c=tuple(round(k*(1-brightness)+245*brightness) for k in old)
  draw.point((x,y),fill=c)
  if i%39==0:
   draw.line((x-1,y,x+1,y),fill=tuple(round(k*.65) for k in c));draw.line((x,y-1,x,y+1),fill=tuple(round(k*.65) for k in c));draw.point((x,y),fill=c)
 # Pole rows converge to one colour, avoiding a pinwheel seam at the zenith.
 for y in range(7):
  for x in range(W):pix[x,y]=tuple(round(c) for c in mix(top,pix[x,y],y/7))
 ROOT.mkdir(parents=True,exist_ok=True);im.save(ROOT/(name+'.png'),optimize=True)
 ROOT.joinpath(name+'.png.mcmeta').write_text('{"texture":{"blur":true,"clamp":true}}\n')
 print(name,ROOT.joinpath(name+'.png').stat().st_size,'bytes')
