Astra Client includes the exact user-supplied Freelook 1.2.8 JAR by Celibistrial, unmodified.
Original filename: freelook-1.2.8 (1).jar
SHA-256: fe1a32d9e4b8894122f52985c9d81b5cefa7bb7b67e67d17e8d03c495f8ba1e4
Source: https://github.com/Celibistrial/freelook/tree/e9415883af0fb031a0f3bb49c4e701e9b575bb8f
The matching 1.2.8 upstream source and build scripts are in third-party/freelook/upstream in the Astra source archive.
Complete source archive: https://raw.githubusercontent.com/fragng/astra-client/main/downloads/astra-client-1.8.2-source.zip
The original JAR's metadata says GNU GPLv3; its bundled license document is AGPLv3. Both are preserved verbatim.
The following is the bundled LICENSE_freelook text:

