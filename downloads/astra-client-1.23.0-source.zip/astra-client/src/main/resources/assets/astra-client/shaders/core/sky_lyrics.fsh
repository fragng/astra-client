#version 330
#moj_import <minecraft:dynamictransforms.glsl>
uniform sampler2D Sampler0;
in vec4 vertexColor;
in vec2 texCoord0;
out vec4 fragColor;
vec4 glyph(vec2 uv) {
    vec4 sampleColor = texture(Sampler0, uv);
#ifdef GLYPH_INTENSITY
    return sampleColor.rrrr;
#else
    return sampleColor;
#endif
}
void main() {
    vec4 ink = glyph(texCoord0);
    vec2 pixel = 1.0 / vec2(textureSize(Sampler0, 0));
    float halo = (glyph(texCoord0 + vec2(pixel.x, 0.0)).a
        + glyph(texCoord0 - vec2(pixel.x, 0.0)).a
        + glyph(texCoord0 + vec2(0.0, pixel.y)).a
        + glyph(texCoord0 - vec2(0.0, pixel.y)).a) * 0.25;
    float opacity = clamp(ink.a + halo * (1.0 - ink.a) * 0.35, 0.0, 1.0);
    if (opacity < 0.01) discard;
    vec3 glow = vec3(0.63, 0.48, 0.95) * ColorModulator.rgb;
    vec3 color = mix(glow, ink.rgb * vertexColor.rgb * ColorModulator.rgb, smoothstep(0.0, 0.3, ink.a));
    fragColor = vec4(color, opacity * vertexColor.a * ColorModulator.a);
}
