package client.astra;

import com.google.gson.*;
import org.slf4j.LoggerFactory;
import java.util.*;
import java.util.concurrent.*;
import java.util.concurrent.atomic.AtomicBoolean;

/** In-process Windows media integration. All COM work stays off Minecraft's thread. */
public final class SpotifyBridge {
    public record State(boolean connected,String title,String artist,String status,boolean playing,boolean toggle,boolean next,boolean previous,String album,double position,double duration,long receivedAt,String artwork){
        public double elapsed(){double delta=playing?Math.min(5,Math.max(0,(System.nanoTime()-receivedAt)/1e9)):0;return duration>0?Math.clamp(position+delta,0,duration):Math.max(0,position+delta);}
        public String trackKey(){return title+"\u0000"+artist+"\u0000"+album;}
    }
    private static volatile State state=empty("Spotify link is starting...");
    private static final ScheduledThreadPoolExecutor WORK=new ScheduledThreadPoolExecutor(1,r->{Thread t=new Thread(r,"Astra Windows media");t.setDaemon(true);return t;});
    static {WORK.setRemoveOnCancelPolicy(true);WORK.setExecuteExistingDelayedTasksAfterShutdownPolicy(false);}
    private static ScheduledFuture<?> poller;
    private static WindowsMediaSession session; // Accessed and released only on WORK's thread.
    private static volatile int generation;
    private static volatile long lastUpdate;
    private static long retryAt;
    private static final AtomicBoolean pending=new AtomicBoolean();
    private SpotifyBridge(){}
    static State empty(String status){return new State(false,"","",status,false,false,false,false,"",0,0,System.nanoTime(),"");}
    public static State state(){return state;}
    public static boolean windows(){return System.getProperty("os.name","").toLowerCase(Locale.ROOT).startsWith("windows");}
    public static synchronized void tick(){
        if(!AstraConfig.spotifyEnabled){if(poller!=null)stop();state=empty("Spotify desktop link is disabled.");return;}
        if(!windows()){state=empty("Spotify desktop link requires Windows 10/11.");return;}
        if(poller==null){
            int token=++generation;lastUpdate=System.nanoTime();state=empty("Connecting to Windows desktop media...");
            poller=WORK.scheduleWithFixedDelay(()->poll(token),0,1,TimeUnit.SECONDS);
        }else if(System.nanoTime()-lastUpdate>15_000_000_000L)state=empty("Windows media service is not responding. Try Reconnect.");
    }
    private static void poll(int token){
        if(token!=generation || System.nanoTime()<retryAt)return;
        try{
            if(session==null)session=new WindowsMediaSession();
            State next=session.poll();if(token==generation){state=next;lastUpdate=System.nanoTime();}
        }catch(RuntimeException | LinkageError e){
            closeSession();retryAt=System.nanoTime()+10_000_000_000L;
            if(token==generation){state=empty("Windows media is unavailable. Retrying automatically...");lastUpdate=System.nanoTime();LoggerFactory.getLogger("Astra Spotify").warn("Cannot read Windows desktop media",e);}
        }
    }
    private static void closeSession(){
        if(session!=null){try{session.close();}catch(RuntimeException e){LoggerFactory.getLogger("Astra Spotify").warn("Could not release Windows media session",e);}finally{session=null;}}
    }
    public static synchronized void reconnect(){stop();tick();}
    public static synchronized void stop(){
        generation++;if(poller!=null){poller.cancel(false);poller=null;}
        WORK.execute(()->{closeSession();retryAt=0;});
    }
    public static void send(String command){
        if(!Set.of("toggle","next","previous").contains(command) || !state.connected() || !pending.compareAndSet(false,true))return;
        int token=generation;
        WORK.execute(()->{
            try{if(token==generation && session!=null && !session.command(command))state=empty("Spotify did not accept the playback command. Try again.");}
            catch(RuntimeException e){if(token==generation)state=empty("Playback command failed. Try Reconnect.");}
            finally{pending.set(false);}
        });
    }
    // Retain the bounded protocol parser for diagnostics and compatibility tests.
    public static State parse(String line){
        JsonObject j=JsonParser.parseString(line).getAsJsonObject();boolean connected=j.has("connected")&&j.get("connected").getAsBoolean();
        return new State(connected,text(j,"title"),text(j,"artist"),text(j,"status"),bool(j,"playing"),bool(j,"toggle"),bool(j,"next"),bool(j,"previous"),text(j,"album"),seconds(j,"position"),seconds(j,"duration"),System.nanoTime(),"");
    }
    private static double seconds(JsonObject j,String key){try{double n=j.get(key).getAsDouble();return Double.isFinite(n)?Math.clamp(n,0,604800):0;}catch(RuntimeException e){return 0;}}
    private static String text(JsonObject j,String key){String s=j.has(key)&&!j.get(key).isJsonNull()?j.get(key).getAsString().replaceAll("[\\p{Cntrl}]"," "):"";return s.length()>512?s.substring(0,512):s;}
    private static boolean bool(JsonObject j,String key){return j.has(key)&&j.get(key).getAsBoolean();}
}
