package client.astra.mixin;

import net.minecraft.client.gui.components.AbstractWidget;
import net.minecraft.client.sounds.SoundManager;
import net.minecraft.client.resources.sounds.SimpleSoundInstance;
import net.minecraft.resources.Identifier;
import net.minecraft.sounds.SoundEvent;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;

@Mixin(AbstractWidget.class)
public abstract class ClickSoundMixin {
    @Inject(method = "playButtonClickSound", at = @At("HEAD"), cancellable = true)
    private static void astra$softClick(SoundManager soundManager, CallbackInfo ci) {
        if (!client.astra.AstraConfig.sounds) { ci.cancel(); return; }
        soundManager.play(SimpleSoundInstance.forUI(SoundEvent.createVariableRangeEvent(
            Identifier.fromNamespaceAndPath("astra-client", "ui.click")), 1f, .7f));
        ci.cancel();
    }
}
