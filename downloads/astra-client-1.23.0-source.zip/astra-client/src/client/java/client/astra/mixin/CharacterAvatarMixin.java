package client.astra.mixin;

import client.astra.*;
import com.mojang.blaze3d.vertex.PoseStack;
import net.minecraft.client.Minecraft;
import net.minecraft.client.model.EntityModel;
import net.minecraft.client.renderer.SubmitNodeCollector;
import net.minecraft.client.renderer.entity.player.AvatarRenderer;
import net.minecraft.client.renderer.entity.state.AvatarRenderState;
import net.minecraft.resources.Identifier;
import org.spongepowered.asm.mixin.*;
import org.spongepowered.asm.mixin.injection.*;
import org.spongepowered.asm.mixin.injection.callback.*;

@Mixin(AvatarRenderer.class)
public abstract class CharacterAvatarMixin {
    @Unique private EntityModel<?> astra$handModel;
    @Inject(method="getTextureLocation(Lnet/minecraft/client/renderer/entity/state/AvatarRenderState;)Lnet/minecraft/resources/Identifier;",at=@At("HEAD"),cancellable=true)
    private void astra$texture(AvatarRenderState state,CallbackInfoReturnable<Identifier> ci){if(CharacterStyle.applies(state))ci.setReturnValue(CharacterStyle.TEXTURE);}
    @Inject(method={"renderRightHand","renderLeftHand"},at=@At("HEAD"))
    private void astra$hand(PoseStack pose,SubmitNodeCollector collector,int light,Identifier skin,boolean sleeve,CallbackInfo ci){
        if(Minecraft.getInstance().player==null || AstraConfig.characterStyle()==CharacterStyle.NONE)return;
        var access=(CharacterModelAccess)(Object)this;astra$handModel=access.astra$getModel();access.astra$setModel(CharacterModels.model(AstraConfig.characterStyle()));
    }
    @ModifyVariable(method={"renderRightHand","renderLeftHand"},at=@At("HEAD"),argsOnly=true)
    private Identifier astra$handTexture(Identifier original){return Minecraft.getInstance().player!=null && AstraConfig.characterStyle()!=CharacterStyle.NONE?CharacterStyle.TEXTURE:original;}
    @Inject(method={"renderRightHand","renderLeftHand"},at=@At("RETURN"))
    private void astra$restoreHand(PoseStack pose,SubmitNodeCollector collector,int light,Identifier skin,boolean sleeve,CallbackInfo ci){
        if(astra$handModel!=null){((CharacterModelAccess)(Object)this).astra$setModel(astra$handModel);astra$handModel=null;}
    }
}
