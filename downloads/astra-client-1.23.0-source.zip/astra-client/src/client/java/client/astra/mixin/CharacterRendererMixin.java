package client.astra.mixin;

import client.astra.*;
import com.mojang.blaze3d.vertex.PoseStack;
import net.minecraft.client.model.EntityModel;
import net.minecraft.client.renderer.*;
import net.minecraft.client.renderer.entity.LivingEntityRenderer;
import net.minecraft.client.renderer.entity.player.AvatarRenderer;
import net.minecraft.client.renderer.entity.layers.*;
import net.minecraft.client.renderer.entity.state.*;
import net.minecraft.client.renderer.state.CameraRenderState;
import org.spongepowered.asm.mixin.*;
import org.spongepowered.asm.mixin.injection.*;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;

@Mixin(LivingEntityRenderer.class)
public abstract class CharacterRendererMixin {
    @Shadow protected EntityModel model;
    @Unique private EntityModel astra$originalModel;
    @Inject(method="submit(Lnet/minecraft/client/renderer/entity/state/LivingEntityRenderState;Lcom/mojang/blaze3d/vertex/PoseStack;Lnet/minecraft/client/renderer/SubmitNodeCollector;Lnet/minecraft/client/renderer/state/CameraRenderState;)V",at=@At("HEAD"))
    private void astra$character(LivingEntityRenderState state,PoseStack pose,SubmitNodeCollector collector,CameraRenderState camera,CallbackInfo ci){
        if((Object)this instanceof AvatarRenderer && CharacterStyle.applies(state)){
            astra$originalModel=model;model=CharacterModels.model(AstraConfig.characterStyle());
        }
    }
    @Inject(method="submit(Lnet/minecraft/client/renderer/entity/state/LivingEntityRenderState;Lcom/mojang/blaze3d/vertex/PoseStack;Lnet/minecraft/client/renderer/SubmitNodeCollector;Lnet/minecraft/client/renderer/state/CameraRenderState;)V",at=@At("RETURN"))
    private void astra$restore(LivingEntityRenderState state,PoseStack pose,SubmitNodeCollector collector,CameraRenderState camera,CallbackInfo ci){
        if(astra$originalModel!=null){model=astra$originalModel;astra$originalModel=null;}
    }
    @Redirect(method="submit(Lnet/minecraft/client/renderer/entity/state/LivingEntityRenderState;Lcom/mojang/blaze3d/vertex/PoseStack;Lnet/minecraft/client/renderer/SubmitNodeCollector;Lnet/minecraft/client/renderer/state/CameraRenderState;)V",at=@At(value="INVOKE",target="Lnet/minecraft/client/renderer/entity/layers/RenderLayer;submit(Lcom/mojang/blaze3d/vertex/PoseStack;Lnet/minecraft/client/renderer/SubmitNodeCollector;ILnet/minecraft/client/renderer/entity/state/EntityRenderState;FF)V"))
    private void astra$equipmentLayer(RenderLayer layer,PoseStack pose,SubmitNodeCollector collector,int light,EntityRenderState state,float yaw,float pitch){
        if((Object)this instanceof AvatarRenderer && state instanceof LivingEntityRenderState living && CharacterStyle.applies(living) && !(layer instanceof PlayerItemInHandLayer))return;
        layer.submit(pose,collector,light,state,yaw,pitch);
    }
}
