package client.astra.mixin;

import client.astra.TotemStyle;
import net.minecraft.client.renderer.item.ItemModelResolver;
import net.minecraft.client.renderer.item.ItemStackRenderState;
import net.minecraft.resources.Identifier;
import net.minecraft.world.entity.ItemOwner;
import net.minecraft.world.item.ItemDisplayContext;
import net.minecraft.world.item.ItemStack;
import net.minecraft.world.level.Level;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.ModifyVariable;

@Mixin(ItemModelResolver.class)
public abstract class TotemModelMixin {
    @ModifyVariable(method="appendItemLayers",at=@At("STORE"),ordinal=0)
    private Identifier astra$totemModel(Identifier original,ItemStackRenderState state,ItemStack stack,
            ItemDisplayContext context,Level level,ItemOwner owner,int seed){
        return TotemStyle.resolve(original,stack);
    }
}
