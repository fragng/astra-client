package client.astra.mixin;

import client.astra.Ui;
import net.minecraft.client.gui.layouts.LayoutElement;
import org.spongepowered.asm.mixin.injection.Coerce;
import net.minecraft.client.gui.GuiGraphics;
import net.minecraft.client.gui.components.AbstractSelectionList;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;

@Mixin(AbstractSelectionList.class)
public abstract class SelectionListMixin {
    @Inject(method = "renderSelection", at = @At("HEAD"), cancellable = true)
    private void astra$roundSelection(GuiGraphics g, @Coerce Object rawEntry, int color, CallbackInfo ci) {
        LayoutElement entry = (LayoutElement) rawEntry;
        Ui.round(g, entry.getX(), entry.getY(), entry.getWidth(), entry.getHeight(), 6, color);
        Ui.round(g, entry.getX() + 1, entry.getY() + 1, entry.getWidth() - 2, entry.getHeight() - 2, 5, 0xDF12182B);
        ci.cancel();
    }
}
