package client.astra;

import net.fabricmc.fabric.api.client.screen.v1.Screens;
import net.minecraft.client.Minecraft;
import net.minecraft.client.gui.GuiGraphics;
import net.minecraft.client.gui.components.AbstractWidget;
import net.minecraft.client.gui.screens.TitleScreen;
import java.util.ArrayList;

public final class AstraMenu {
    private AstraMenu() {}
    public static int margin(int width) { return width < 480 ? 12 : 20; }
    public static int panelWidth(int width) { return width < 480 ? 116 : 144; }
    public static int panelX(int width) { return width - margin(width) - panelWidth(width); }
    public static int center(int width) { return (panelX(width) - 18) / 2; }
    public static int menuTop(int height) { return height / 4 + 32; }
    private static int headerHeight(int h){return h<220?22:26;}
    private static int rowHeight(int h){return h<220?16:h<290?19:23;}
    private static int rowGap(int h){return h<220?2:h<290?4:5;}
    private static int reactiveHeight(int h){return h<220?22:28;}
    private static int descriptionHeight(int h){return h<240?0:28;}
    private static int themeHeight(int h){return Theme.values().length*rowHeight(h)+(Theme.values().length-1)*rowGap(h);}
    private static int panelHeight(int h){return headerHeight(h)+themeHeight(h)+6+reactiveHeight(h)+descriptionHeight(h)+8;}
    private static int panelTop(int h){return Math.max(5,(h-panelHeight(h))/2);}
    private static int reactiveY(int h){return panelTop(h)+headerHeight(h)+themeHeight(h)+6;}

    private static String key(AbstractWidget widget) {
        return widget.getMessage().getContents() instanceof net.minecraft.network.chat.contents.TranslatableContents t ? t.getKey() : "";
    }
    private static boolean vanilla(AbstractWidget widget) {
        return java.util.Set.of("menu.singleplayer", "menu.multiplayer", "menu.online", "menu.options", "menu.quit",
            "options.language", "options.accessibility", "narrator.button.language", "narrator.button.accessibility").contains(key(widget));
    }
    private static AbstractWidget mods(TitleScreen screen) {
        for (AbstractWidget widget : Screens.getButtons(screen)) {
            if (key(widget).equals("modmenu.title") || key(widget).startsWith("modmenu.mods") || widget.getMessage().getString().equalsIgnoreCase("Mods")) return widget;
        }
        return null;
    }
    public static void alignToMods(TitleScreen screen) {
        int row = 0;
        for (AbstractWidget widget : Screens.getButtons(screen)) {
            if (widget instanceof ModeButton) {
                widget.setX(panelX(screen.width) + 9);
                widget.setY(panelTop(screen.height) + headerHeight(screen.height) + row++ * (rowHeight(screen.height) + rowGap(screen.height)));
                widget.setSize(panelWidth(screen.width) - 18, rowHeight(screen.height));
            } else if(widget instanceof ReactiveToggleButton) {
                widget.setX(panelX(screen.width)+9);widget.setY(reactiveY(screen.height));widget.setSize(panelWidth(screen.width)-18,reactiveHeight(screen.height));
            }
        }
        AbstractWidget anchor = mods(screen);
        if(anchor!=null && screen.width<480) {
            // Keep Mods' original x/y, but shrink its width on narrow windows.
            anchor.setWidth(Math.min(anchor.getWidth(),Math.max(90,panelX(screen.width)-8-anchor.getX())));
        }
        int c=anchor==null?center(screen.width):anchor.getX()+anchor.getWidth()/2;
        int available=Math.max(90,Math.min(c-12,panelX(screen.width)-8-c)*2);
        int buttonWidth=Math.min(anchor==null || anchor.getWidth()<90?200:anchor.getWidth(),available),half=(buttonWidth-6)/2;
        for(AbstractWidget widget:Screens.getButtons(screen)) {
            String id=key(widget);
            switch(id) {
                case "menu.singleplayer", "menu.multiplayer", "menu.online" -> {
                    widget.setX(c-buttonWidth/2);widget.setWidth(buttonWidth);
                    if(anchor!=null)widget.setY(anchor.getY()-(id.equals("menu.singleplayer")?78:id.equals("menu.multiplayer")?52:26));
                }
                case "menu.options", "menu.quit" -> {
                    widget.setWidth(half);widget.setX(id.equals("menu.options")?c-buttonWidth/2:c+3);
                    if(anchor!=null)widget.setY(anchor.getY()+anchor.getHeight()+10);
                }
                case "options.language", "options.accessibility", "narrator.button.language", "narrator.button.accessibility" -> {
                    boolean language=id.contains("language");
                    widget.setX(screen.width<480?(language?12:36):(language?c-24:c+4));
                    if(anchor!=null)widget.setY(anchor.getY()+anchor.getHeight()+(screen.width<480?11:38));
                }
            }
        }
    }
    public static void initialize(TitleScreen screen) {
        int center = center(screen.width), menuWidth = Math.min(200, center * 2 - 24);
        int oldTop = screen.height / 4 + 48, top = menuTop(screen.height);
        var buttons = Screens.getButtons(screen);
        for (AbstractWidget widget : new ArrayList<>(buttons)) {
            int oldX = widget.getX(), oldY = widget.getY(), oldWidth = widget.getWidth();
            if (oldY >= screen.height - 30 || !vanilla(widget)) continue;
            if (oldWidth >= 200) {
                widget.setX(center - menuWidth / 2);
                widget.setWidth(menuWidth);
                widget.setHeight(22);
                widget.setY(top + Math.round((oldY - oldTop) / 24f) * 26);
            } else if (oldWidth >= 90) {
                int half = (menuWidth - 6) / 2;
                widget.setX(oldX < screen.width / 2 ? center - menuWidth / 2 : center + 3);
                widget.setWidth(half);
                widget.setHeight(22);
                widget.setY(top + 82);
            } else if (oldWidth == 20) {
                widget.setX(oldX < screen.width / 2 ? center - 24 : center + 4);
                widget.setY(top + 110);
            }
            if (oldWidth >= 90) widget.setMessage(widget.getMessage().copy().withStyle(s -> s.withFont(Ui.FONT)));
        }
        int rowY = panelTop(screen.height) + headerHeight(screen.height);
        for (Theme theme : Theme.values()) {
            buttons.add(new ModeButton(panelX(screen.width) + 9, rowY, panelWidth(screen.width) - 18, rowHeight(screen.height), theme));
            rowY += rowHeight(screen.height) + rowGap(screen.height);
        }
        buttons.add(new ReactiveToggleButton(panelX(screen.width)+9,reactiveY(screen.height),panelWidth(screen.width)-18,reactiveHeight(screen.height)));
    }

    public static void drawPanel(GuiGraphics g, int width, int height) {
        int x = panelX(width), y = panelTop(height), w = panelWidth(width), h = panelHeight(height);
        int accent = AstraConfig.theme().accent;
        Ui.round(g, x - 4, y - 4, w + 8, h + 8, 19, Ui.alpha(accent, .07f));
        Ui.gradient(g, x, y, w, h, 16, 0xFFBFB1EC, 0xFF6C98DD);
        Ui.gradient(g, x + 1, y + 1, w - 2, h - 2, 15, 0xF2151A32, 0xF21A1834);
        var font = Minecraft.getInstance().font;
        var label=Ui.text("Menu Background");float labelScale=Math.min(1,(w-20f)/font.width(label));
        g.pose().pushMatrix();g.pose().translate(x+10,y+8);g.pose().scale(labelScale,labelScale);
        Ui.animated(g,font,label,0,0,0xFFEAE6FA);g.pose().popMatrix();
        if(descriptionHeight(height)==0)return;
        g.pose().pushMatrix();g.pose().translate(x+9,reactiveY(height)+reactiveHeight(height)+5);g.pose().scale(.8f,.8f);
        int line=0;
        for(var part:font.split(Ui.text("Makes the Menu Look 100X Better."),(int)((w-18)/.8f))) {
            g.drawString(font,part,0,line++*11,0xFFBDB4D4,false);
        }
        g.pose().popMatrix();
    }

    public static void drawHeading(GuiGraphics g, int width, int height, float alpha) {
        var font = Minecraft.getInstance().font;
        int center = center(width);
        if (Minecraft.getInstance().screen instanceof TitleScreen title) {
            AbstractWidget anchor = mods(title);
            if (anchor != null) center = anchor.getX() + anchor.getWidth() / 2;
        }
        int y = Math.max(12, menuTop(height) - 90);
        float titleScale=Math.min(width<400?1.9f:2.5f,Math.max(80,Math.min(center-12,panelX(width)-10-center)*2)/(float)font.width(Ui.heading(AstraClient.NAME)));
        Ui.centered(g, font, AstraClient.NAME, center, y, titleScale, Ui.alpha(0xFFF7F5FF, alpha));
        Ui.centered(g, font, "Get Client Free at", center, y + 33, 1f, Ui.alpha(0xFFC2C5D9, alpha));
        Ui.centered(g, font, ".gg/gazebo", center, y + 47, 1.15f, Ui.alpha(AstraConfig.theme().accent, alpha));
    }
}
