package client.astra;

import com.google.gson.*;
import java.util.*;

/** Local visual preferences. Shared controls have one value across all PvP categories. */
public final class PvpSettings {
    public enum Feature {
        LOW_FIRE("Low Fire","Lowers the first-person fire overlay."),
        EXPLOSIONS("Hide Explosion Particles","Hides crystal and other explosion particles. Sound stays on."),
        CRYSTALS("Crystal Count","Shows end crystals in your inventory and offhand."),
        TOTEMS("Totem Count","Shows totems in your inventory and offhand."),
        COOLDOWN("Attack Cooldown","Shows your real attack recovery percentage."),
        DURABILITY("Held Item Durability","Remaining durability of your held tool or weapon."),
        ARMOR("Armor Durability","Shows remaining durability for your equipped armor."),
        FALL("Fall Distance","Shows your current fall distance in blocks."),
        WIND("Wind Charge Count","Shows wind charges available in your inventory."),
        USE("Active Use Timer","Shows how long you have been using the held item."),
        APPLES("Golden Apple Count","Counts regular and enchanted golden apples separately."),
        EFFECTS("Own Effect Timers","Shows up to three of your active potion effects."),
        ABSORPTION("Absorption Hearts","Shows your current extra hearts."),
        SHIELD("Shield Status","Shield durability and whether it is raised."),
        PEARLS("Ender Pearl Count","Shows ender pearls available in your inventory."),
        POTIONS("Potion Count","Counts bottled, splash and lingering potions."),
        FOOD("Food and Saturation","Shows your own food level and saturation."),
        ARROWS("Arrow Count","Counts normal, tipped and spectral arrows."),
        DRAW("Bow Draw","Shows the real bow draw power while using a bow."),
        CROSSBOW("Crossbow Status","Shows whether your held crossbow is loaded.");
        public final String label,description;
        Feature(String label,String description){this.label=label;this.description=description;}
        public boolean enabled(){return enabled.contains(this);}
        public void toggle(){if(!enabled.remove(this))enabled.add(this);AstraConfig.changed();}
    }
    private static final EnumSet<Feature> enabled=EnumSet.noneOf(Feature.class);
    public static double x=.02,y=.86,scale=.8;
    public static boolean anyHud(){return enabled.stream().anyMatch(f->f!=Feature.LOW_FIRE && f!=Feature.EXPLOSIONS);}
    public static void reset(){enabled.clear();x=.02;y=.86;scale=.8;}
    public static void load(JsonElement element){
        reset();if(element==null || !element.isJsonObject())return;
        JsonObject j=element.getAsJsonObject();
        for(Feature f:Feature.values())try{if(j.get(f.name()).getAsBoolean())enabled.add(f);}catch(Exception ignored){}
        x=number(j,"x",.02,0,1);y=number(j,"y",.86,0,1);scale=number(j,"scale",.8,.6,1);
    }
    private static double number(JsonObject j,String key,double fallback,double min,double max){try{double v=j.get(key).getAsDouble();return Double.isFinite(v)?Math.clamp(v,min,max):fallback;}catch(Exception e){return fallback;}}
    public static JsonObject json(){
        var j=new JsonObject();for(Feature f:Feature.values())j.addProperty(f.name(),f.enabled());
        j.addProperty("x",x);j.addProperty("y",y);j.addProperty("scale",scale);return j;
    }
    private PvpSettings(){}
}
