package client.astra.mixin;

import client.astra.FreelookBridge;
import freelook.freelook.FreeLookMod;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;

/** Leave the attached mod's input and camera implementation intact. */
@Mixin(value=FreeLookMod.class,remap=false)
public abstract class FreelookGateMixin {
    @Inject(method="onInitializeClient",at=@At("TAIL"),remap=false)
    private void astra$attach(CallbackInfo ci) {FreelookBridge.attach((FreelookAccess)(Object)this);}
    @Inject(method="onTickEnd",at=@At("HEAD"),cancellable=true,remap=false)
    private void astra$gate(CallbackInfo ci) {
        if(FreelookBridge.stopIfUnavailable())ci.cancel();
    }
}
