package client.astra.mixin;

import client.astra.AstraConfig;
import com.mojang.blaze3d.systems.RenderSystem;
import com.mojang.blaze3d.textures.GpuTexture;
import net.minecraft.client.Minecraft;
import net.minecraft.client.renderer.LightTexture;
import org.spongepowered.asm.mixin.Final;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.Shadow;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;

@Mixin(LightTexture.class)
public abstract class FullbrightMixin {
    @Shadow @Final private GpuTexture texture;
    @Shadow @Final private Minecraft minecraft;
    @Shadow private boolean updateLightTexture;

    @Inject(method="updateLightTexture",at=@At("HEAD"),cancellable=true)
    private void astra$fullbright(float partialTick,CallbackInfo ci){
        if(!AstraConfig.fullbright || minecraft.level==null)return;
        if(updateLightTexture){
            RenderSystem.getDevice().createCommandEncoder().clearColorTexture(texture,0xFFFFFFFF);
            updateLightTexture=false;
        }
        ci.cancel();
    }
}
