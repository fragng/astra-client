package client.astra;

import net.minecraft.client.Minecraft;
import net.minecraft.client.gui.GuiGraphics;
import net.minecraft.client.gui.components.Button;

/** A real sky texture preview and exclusive selection, rather than an on/off switch. */
public final class SkyPreviewButton extends Button {
    private final SkyTheme theme;
    private float hover;
    private long last=System.nanoTime();
    public SkyPreviewButton(int x,int y,SkyTheme theme,Runnable action){
        super(x,y,146,84,Ui.text(theme.label),b->action.run(),DEFAULT_NARRATION);this.theme=theme;
    }
    @Override protected void renderContents(GuiGraphics g,int mx,int my,float delta){
        long now=System.nanoTime();float dt=Math.min(.1f,(now-last)/1e9f);last=now;
        float target=isHoveredOrFocused()?1:0;hover=AstraConfig.animations?hover+(target-hover)*(1-(float)Math.exp(-dt*14)):target;
        boolean selected=PremiumEdition.premium() && AstraConfig.skyTheme()==theme;
        int x=getX(),y=getY();
        if(selected)Ui.round(g,x-2,y-2,150,88,13,0x557E51CE);
        Ui.round(g,x,y,146,84,11,Ui.blend(selected?0xFFE4C0FF:0xFF73658F,0xFFC9ACF7,hover*.6f));
        Ui.round(g,x+1,y+1,144,82,10,0xFF19182D);
        Ui.texture(g,theme.texture,x+5,y+5,136,55,.05f,.95f,.04f,.9f,1024,512);
        var font=Minecraft.getInstance().font;
        Ui.animated(g,font,theme.label,x+8,y+66,selected?0xFFFFDA91:0xFFE9E1F7);
        if(selected)Ui.animated(g,font,"*",x+132,y+66,0xFFFFDA91);
    }
    @Override protected net.minecraft.network.chat.MutableComponent createNarrationMessage(){
        return net.minecraft.network.chat.Component.literal(theme.label+" sky preview, "+(!PremiumEdition.premium()?"Premium required":AstraConfig.skyTheme()==theme?"selected":"click to apply"));
    }
}
