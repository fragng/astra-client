package client.astra;

import client.astra.mixin.FreelookAccess;
import com.mojang.blaze3d.platform.InputConstants;
import freelook.freelook.FreeLookMod;
import net.minecraft.client.Minecraft;
import net.minecraft.client.KeyMapping;

/** Astra preferences and controls for the user's original Freelook 1.2.8 mod. */
public final class FreelookBridge {
    private static FreelookAccess mod;
    private static boolean initialized;
    private FreelookBridge() {}
    public static void attach(FreelookAccess instance) {
        mod=instance;
        if(initialized)initialize();
    }
    public static KeyMapping keyMapping() {return mod==null?null:mod.astra$key();}
    public static void initialize() {
        initialized=true;
        var mapping=keyMapping();if(mapping==null)return;
        if(AstraConfig.freelookKey==null)AstraConfig.freelookKey=mapping.saveString();
        InputConstants.Key key;
        try {key=InputConstants.getKey(AstraConfig.freelookKey);}
        catch(Exception e) {key=InputConstants.UNKNOWN;}
        bind(key);
    }
    public static boolean allowed() {
        var mc=Minecraft.getInstance();var key=keyMapping();
        return AstraConfig.freelookEnabled && key!=null && !key.isUnbound() && mc.player!=null
            && mc.screen==null && mc.isWindowActive();
    }
    public static void tick() {
        var mapping=keyMapping();if(mapping==null)return;
        String key=mapping.saveString();
        if(key.equals("key.keyboard.escape"))bind(InputConstants.UNKNOWN);
        else if(!key.equals(AstraConfig.freelookKey)) {AstraConfig.freelookKey=key;AstraConfig.changed();}
        stopIfUnavailable();
    }
    public static boolean stopIfUnavailable() {
        boolean stop=!allowed() || (mod!=null && FreeLookMod.config.isBlocked());
        if(stop && mod!=null && FreeLookMod.isFreeLooking)mod.astra$stop(Minecraft.getInstance());
        return stop;
    }
    public static String conflict() {
        var key=keyMapping();if(key==null || key.isUnbound())return "";
        for(var other:Minecraft.getInstance().options.keyMappings) {
            if(other!=key && !other.isUnbound() && key.same(other))return net.minecraft.network.chat.Component.translatable(other.getName()).getString();
        }
        return "";
    }
    public static String status() {
        if(mod!=null && FreeLookMod.config.isBlocked())return "Freelook is disabled by this mod's server block list.";
        return "Normal camera collision. No freecam or movement changes.";
    }
    public static String instruction() {
        return mod!=null && FreeLookMod.config.isToggle()?"Press your bind again to restore your view.":"Hold to look around; release to restore your view.";
    }
    public static String keyName() {
        var key=keyMapping();return key==null || key.isUnbound()?"Not bound":key.getTranslatedKeyMessage().getString();
    }
    public static void bind(InputConstants.Key key) {
        if(key.equals(InputConstants.getKey("key.keyboard.escape")))key=InputConstants.UNKNOWN;
        var mapping=keyMapping();if(mapping==null)return;
        mapping.setDown(false);mapping.setKey(key);KeyMapping.resetMapping();
        AstraConfig.freelookKey=key.getName();AstraConfig.changed();AstraConfig.nativeChanged();
        stopIfUnavailable();
    }
}
