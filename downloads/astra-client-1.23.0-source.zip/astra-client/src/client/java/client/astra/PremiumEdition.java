package client.astra;

import com.google.gson.*;
import net.fabricmc.loader.api.FabricLoader;
import java.nio.file.*;
import java.time.*;
import java.time.format.DateTimeFormatter;
import org.slf4j.LoggerFactory;

/** Local cosmetic Premium period. No account service, redemption or privileged access. */
public final class PremiumEdition {
    private static final Path FILE=FabricLoader.getInstance().getConfigDir().resolve("astra-premium.json");
    private static final long PERIOD=Duration.ofDays(30).toMillis();
    private static boolean edition,activeFile;
    private static long started,expires,lastSeen,baseTime,baseNanos,nextSave;
    private PremiumEdition(){}
    public static void initialize(){
        try(var in=PremiumEdition.class.getResourceAsStream("/astra-edition.json")) {
            edition=in!=null && JsonParser.parseReader(new java.io.InputStreamReader(in,java.nio.charset.StandardCharsets.UTF_8)).getAsJsonObject().get("premium").getAsBoolean();
        }catch(Exception e){edition=false;}
        if(!edition)return;
        long now=System.currentTimeMillis();
        if(Files.exists(FILE)) {
            try {
                var j=JsonParser.parseString(Files.readString(FILE)).getAsJsonObject();
                started=j.get("startedAt").getAsLong();lastSeen=j.get("lastSeenAt").getAsLong();
                if(started<=0 || started>Long.MAX_VALUE-PERIOD || lastSeen<started)throw new IllegalArgumentException("Invalid Premium dates");
                expires=started+PERIOD;activeFile=true;
            }catch(Exception e){LoggerFactory.getLogger("Astra Client").warn("Could not read local Premium period; using Member mode.");return;}
        }else {started=now;expires=now+PERIOD;lastSeen=now;activeFile=true;}
        baseTime=Math.max(now,lastSeen);baseNanos=System.nanoTime();flush();
    }
    private static long now(){return Math.max(System.currentTimeMillis(),baseTime+Math.max(0,(System.nanoTime()-baseNanos)/1_000_000));}
    public static boolean edition(){return edition;}
    public static boolean premium(){return edition && activeFile && now()<expires;}
    public static long remaining(){return activeFile?Math.max(0,(expires-now())/1000):0;}
    public static String timeLeft(){long n=remaining();return n/86400+"d "+n/3600%24+"h "+n/60%60+"m "+n%60+"s";}
    public static String expiry(){return activeFile?Instant.ofEpochMilli(expires).atZone(ZoneId.systemDefault()).format(DateTimeFormatter.ofPattern("dd MMM yyyy HH:mm z")):"Not active";}
    public static String description(){return !edition?"Astra Client / Member edition":!activeFile?"Premium dates are unavailable. Member mode is active.":premium()?"30-day Premium / skies, lyrics, totems and Jamble.":"The 30-day Premium period has expired.";}
    public static void tick(){if(activeFile && System.nanoTime()>nextSave)flush();}
    public static void flush(){
        if(!edition || !activeFile)return;
        try {
            lastSeen=now();var j=new JsonObject();j.addProperty("startedAt",started);j.addProperty("expiresAt",expires);j.addProperty("lastSeenAt",lastSeen);
            Files.createDirectories(FILE.getParent());var tmp=FILE.resolveSibling("astra-premium.json.tmp");
            Files.writeString(tmp,new GsonBuilder().setPrettyPrinting().create().toJson(j));
            try{Files.move(tmp,FILE,StandardCopyOption.REPLACE_EXISTING,StandardCopyOption.ATOMIC_MOVE);}catch(AtomicMoveNotSupportedException e){Files.move(tmp,FILE,StandardCopyOption.REPLACE_EXISTING);}
            nextSave=System.nanoTime()+60_000_000_000L;
        }catch(Exception e){LoggerFactory.getLogger("Astra Client").warn("Could not save local Premium dates.");}
    }
}
