package client.astra;

import net.minecraft.client.Minecraft;
import net.minecraft.client.gui.GuiGraphics;
import net.minecraft.client.gui.components.Button;
import net.minecraft.network.chat.MutableComponent;
import net.minecraft.network.chat.Component;

public final class ModeButton extends Button {
    private final Theme mode;
    public ModeButton(int x, int y, int width, int height, Theme mode) {
        super(x, y, width, height, Ui.text(mode.label), button -> AstraConfig.select(mode), DEFAULT_NARRATION);
        this.mode = mode;
    }

    @Override
    protected void renderContents(GuiGraphics g, int mouseX, int mouseY, float delta) {
        boolean selected = AstraConfig.theme() == mode;
        int x = getX(), y = getY(), w = getWidth(), h = getHeight();
        float a = getAlpha();
        if (selected) {
            Ui.round(g, x - 3, y - 3, w + 6, h + 6, 12, Ui.alpha(mode.accent, a * .12f));
            Ui.round(g, x - 1, y - 1, w + 2, h + 2, 10, Ui.alpha(mode.accent, a * .4f));
        }
        Ui.round(g, x, y, w, h, 9, Ui.alpha(selected || isHoveredOrFocused() ? mode.accent : 0xFF74799F, a));
        Ui.gradient(g, x + 1, y + 1, w - 2, h - 2, 8,
            Ui.alpha(selected ? 0xFF6951A2 : 0xEE353C5C, a), Ui.alpha(selected ? 0xFF302451 : 0xEE1E2540, a));
        if (selected) {
            for (int i = 0; i < 9; i++) {
                int sx = x + 5 + (i * 31 + 7) % Math.max(1, w - 10);
                int sy = y + 4 + (i * 13) % Math.max(1, h - 8);
                g.fill(sx, sy, sx + 1, sy + 1, Ui.alpha(0xFFDDD2FF, a * .65f));
            }
        }
        int toggleW = w < 110 ? 23 : 27, toggleH = 14;
        var font=Minecraft.getInstance().font;
        float labelScale=Math.min(1,(w-toggleW-24f)/Math.max(1,font.width(getMessage())));
        g.pose().pushMatrix();g.pose().translate(x+9,y+(h-9*labelScale)/2f);g.pose().scale(labelScale,labelScale);
        Ui.animated(g,font,getMessage(),0,0,Ui.alpha(0xFFF4F0FF,a));g.pose().popMatrix();
        int tx = x + w - toggleW - 8, ty = y + (h - toggleH) / 2;
        Ui.round(g, tx, ty, toggleW, toggleH, 7, Ui.alpha(selected ? 0xFFD6BEFF : 0xFF606988, a));
        Ui.round(g, tx + 1, ty + 1, toggleW - 2, toggleH - 2, 6, Ui.alpha(selected ? 0xFF9270E8 : 0xFF363D5C, a));
        Ui.round(g, selected ? tx + toggleW - 12 : tx + 2, ty + 2, 10, 10, 5, Ui.alpha(0xFFF4F3FF, a));
    }

    @Override
    protected MutableComponent createNarrationMessage() {
        return Component.literal(mode.label + " background, " + (AstraConfig.theme() == mode ? "selected" : "not selected"));
    }
}
