package client.astra;

import net.minecraft.client.gui.GuiGraphics;

public final class MenuArt {
    private MenuArt() {}
    private static void line(GuiGraphics g,float x,float y,float x2,float y2,int color) {
        int steps=Math.max(1,(int)Math.ceil(Math.hypot(x2-x,y2-y)*2));
        for(int i=0;i<=steps;i++) {
            float t=i/(float)steps;int px=Math.round(x+(x2-x)*t),py=Math.round(y+(y2-y)*t);
            g.fill(px,py,px+1,py+1,Ui.tint(color));
        }
    }
    private static final java.util.Map<String,net.minecraft.resources.Identifier> ICONS=java.util.Map.of(
        "Visuals",asset("visuals"),"Jamble",asset("jamble"),"HUD",asset("hud"),"Spotify HUD",asset("spotify"),"Music",asset("spotify"),"Essentials",asset("essentials"),"Buy Premium",asset("discord"));
    private static net.minecraft.resources.Identifier asset(String name){return net.minecraft.resources.Identifier.fromNamespaceAndPath(AstraClient.MOD_ID,"textures/icons/"+name+".png");}
    private static final net.minecraft.resources.Identifier TOTEM=net.minecraft.resources.Identifier.withDefaultNamespace("textures/item/totem_of_undying.png");
    public static void icon(GuiGraphics g,String name,int x,int y,int size,int color) {
        if(name.equals("3D Characters")){CharacterStyle.SPONGEBOB.icon(g,x,y,size);return;}
        var mode=PvpMode.find(name);
        if(mode!=null){g.pose().pushMatrix();g.pose().translate(x,y);g.pose().scale(size/16f,size/16f);g.renderItem(mode.icon,0,0);g.pose().popMatrix();return;}
        if(name.equals("Customize Totem")) {Ui.texture(g,TOTEM,x,y,size,size,0,1,0,1,16,16);return;}
        var texture=ICONS.get(name);
        if(texture!=null){if(name.equals("HUD"))Ui.round(g,x,y,size,size,3,0xFFE0D9ED);Ui.texture(g,texture,x,y,size,size,0,1,0,1,128,128);return;}
        g.pose().pushMatrix();g.pose().translate(x,y);g.pose().scale(size/16f,size/16f);
        switch(name) {
            case "Settings" -> {Ui.round(g,3,3,10,10,5,color);Ui.round(g,5,5,6,6,3,0xFF23213A);for(int i=0;i<8;i++){double a=i*Math.PI/4;line(g,8+(float)Math.cos(a)*5,8+(float)Math.sin(a)*5,8+(float)Math.cos(a)*8,8+(float)Math.sin(a)*8,color);}}
            case "General" -> {for(int i=0;i<3;i++){line(g,0,3+i*5,16,3+i*5,color);Ui.round(g,i==1?9:3,1+i*5,4,4,2,color);}}
            default -> {line(g,8,0,8,16,color);line(g,0,8,16,8,color);line(g,3,3,13,13,color);line(g,3,13,13,3,color);}
        }
        g.pose().popMatrix();
    }
    public static void background(GuiGraphics g,int w,int h) {Backgrounds.drawMenu(g,w,h);}
}
