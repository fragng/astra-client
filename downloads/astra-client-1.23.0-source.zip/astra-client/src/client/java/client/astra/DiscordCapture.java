package client.astra;

import com.google.gson.*;
import net.minecraft.client.Minecraft;

/** Opt-in, reversible windowed capture settings. Does not access Discord or inject hooks. */
public final class DiscordCapture {
    private record Saved(boolean pauseOnLostFocus,boolean fullscreen){}
    private static Saved saved;
    private DiscordCapture(){}
    public static boolean enabled(){return saved!=null;}
    public static void toggle(){if(enabled())disable();else enable();}
    public static void enable(){
        if(enabled())return;
        var client=Minecraft.getInstance();
        saved=new Saved(client.options.pauseOnLostFocus,client.getWindow().isFullscreen());
        // Retain the original settings before the native fullscreen callback runs.
        AstraConfig.changed();AstraConfig.flush();apply(client);
    }
    public static void initialize(Minecraft client){if(enabled())apply(client);}
    private static void apply(Minecraft client){
        client.options.pauseOnLostFocus=false;
        client.options.fullscreen().set(false);
        client.updateTitle();AstraConfig.nativeChanged();AstraConfig.flush();
    }
    public static void disable(){
        if(!enabled())return;
        var original=saved;var client=Minecraft.getInstance();
        // Keep deliberate native option edits rather than overwriting them.
        if(!client.options.pauseOnLostFocus)client.options.pauseOnLostFocus=original.pauseOnLostFocus;
        if(!client.options.fullscreen().get())client.options.fullscreen().set(original.fullscreen);
        AstraConfig.nativeChanged();AstraConfig.flush();
        saved=null;client.updateTitle();AstraConfig.changed();AstraConfig.flush();
    }
    public static JsonElement json(){
        if(saved==null)return JsonNull.INSTANCE;
        var result=new JsonObject();result.addProperty("pauseOnLostFocus",saved.pauseOnLostFocus);result.addProperty("fullscreen",saved.fullscreen);return result;
    }
    public static void load(JsonElement value){
        saved=null;if(value==null || value.isJsonNull())return;
        try{
            var object=value.getAsJsonObject();var pause=object.getAsJsonPrimitive("pauseOnLostFocus");var fullscreen=object.getAsJsonPrimitive("fullscreen");
            if(pause==null || fullscreen==null || !pause.isBoolean() || !fullscreen.isBoolean())throw new IllegalArgumentException();
            saved=new Saved(pause.getAsBoolean(),fullscreen.getAsBoolean());
        }catch(RuntimeException e){org.slf4j.LoggerFactory.getLogger(AstraClient.NAME).warn("Could not read Discord Capture Mode backup; leaving capture mode off.");}
    }
}
