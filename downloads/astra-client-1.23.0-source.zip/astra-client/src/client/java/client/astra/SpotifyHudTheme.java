package client.astra;

import net.minecraft.resources.Identifier;

/** Independent from the main-menu background preference. */
public enum SpotifyHudTheme {
    GALAXY("Galaxy",0xFFB7B7FF,0xFF17274C,0xFF10172F,"galaxy"),
    ASTRA("Astra",0xFFD5AEFF,0xFF39205B,0xFF19132F,"menu-astra"),
    NEBULA("Nebula",0xFFF2B9E1,0xFF3D2853,0xFF172846,"nebula"),
    BLACK("Black",0xFF90949E,0xFF191A20,0xFF08090D,null);

    public final String label;
    public final int accent,top,bottom;
    public final Identifier texture;
    SpotifyHudTheme(String label,int accent,int top,int bottom,String texture) {
        this.label=label;this.accent=accent;this.top=top;this.bottom=bottom;
        this.texture=texture==null?null:Identifier.fromNamespaceAndPath(AstraClient.MOD_ID,"textures/background/"+texture+".png");
    }
}
