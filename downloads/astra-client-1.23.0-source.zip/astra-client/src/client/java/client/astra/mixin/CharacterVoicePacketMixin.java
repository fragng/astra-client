package client.astra.mixin;
import client.astra.*;
import net.minecraft.client.Minecraft;
import net.minecraft.client.multiplayer.ClientPacketListener;
import net.minecraft.network.protocol.game.*;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.*;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;
@Mixin(ClientPacketListener.class)
public abstract class CharacterVoicePacketMixin {
    @Inject(method="handleEntityEvent",at=@At("RETURN"))
    private void astra$totem(ClientboundEntityEventPacket packet,CallbackInfo ci){
        var mc=Minecraft.getInstance();if(mc.level!=null && packet.getEventId()==35 && packet.getEntity(mc.level)==mc.player)CharacterVoices.request(VoiceEvent.TOTEM);
    }
    @Inject(method="handleUpdateAdvancementsPacket",at=@At("RETURN"))
    private void astra$advancement(ClientboundUpdateAdvancementsPacket packet,CallbackInfo ci){
        var mc=Minecraft.getInstance();if(packet.shouldReset() || mc.getConnection()==null)return;
        for(var entry:packet.getProgress().entrySet())if(entry.getValue().isDone()){
            var holder=mc.getConnection().getAdvancements().get(entry.getKey());
            if(holder!=null && holder.value().display().isPresent()){CharacterVoices.request(VoiceEvent.ADVANCEMENT);break;}
        }
    }
}
