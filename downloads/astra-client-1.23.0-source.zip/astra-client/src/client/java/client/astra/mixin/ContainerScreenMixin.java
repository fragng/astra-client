package client.astra.mixin;

import net.minecraft.client.renderer.RenderPipelines;
import net.minecraft.resources.Identifier;
import org.spongepowered.asm.mixin.Unique;
import net.minecraft.client.gui.GuiGraphics;
import net.minecraft.client.gui.screens.inventory.AbstractContainerScreen;
import net.minecraft.world.inventory.Slot;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;

@Mixin(AbstractContainerScreen.class)
public abstract class ContainerScreenMixin {
    @Unique private static final Identifier ASTRA_SLOT=Identifier.fromNamespaceAndPath("astra-client","widget/inventory_slot");
    @Inject(method = "renderSlot", at = @At("HEAD"))
    private void astra$roundSlot(GuiGraphics g, Slot slot, int mouseX, int mouseY, CallbackInfo ci) {
        if (!getClass().getName().startsWith("net.minecraft.")) return;
        int x = slot.x - 1, y = slot.y - 1;
        // One cached atlas sprite instead of rebuilding ~100 rectangles per slot.
        g.blitSprite(RenderPipelines.GUI_TEXTURED,ASTRA_SLOT,x,y,18,18);
    }
}
