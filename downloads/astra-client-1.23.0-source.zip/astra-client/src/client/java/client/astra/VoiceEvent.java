package client.astra;

/** Local cosmetic reactions, grouped so noisy activities can be disabled together. */
public enum VoiceEvent {
    JOIN(2,35),TOTEM(1,100),RAIN(0,20),CLEAR(0,20),THUNDER(0,40),DAWN(0,20),DUSK(0,20),
    HURT(1,55),LOW_HEALTH(1,95),RECOVERED(1,45),DEATH(1,99),RESPAWN(1,90),DIMENSION(2,70),
    DIAMOND(4,85),MINING(3,10),EATING(3,25),FISHING(3,30),SWIMMING(2,20),FIRE(1,90),
    FLYING(2,35),SLEEP(3,35),LEVEL_UP(4,60),ADVANCEMENT(4,80),VICTORY(1,70),FALL(1,65),CRAFTING(3,20),CHEST(3,15);
    public static final String[] GROUPS={"Weather and time","Combat and survival","Exploration and travel","Items and activities","Milestones"};
    public final int group,priority;
    VoiceEvent(int group,int priority){this.group=group;this.priority=priority;}
    public String id(){return name().toLowerCase(java.util.Locale.ROOT);}
    public boolean enabled(int groups){return (groups&(1<<group))!=0;}
}
