package client.astra;

import net.minecraft.resources.Identifier;

public enum SkyTheme {
    VANILLA("Minecraft sky", "vanilla"),
    NORTHERN_ECHOS("Northern Echo's", "northern_echos"),
    GALAXY("Galaxy", "galaxy"),
    NEBULA("Nebula", "nebula"),
    ASTRA("Astra", "astra"),
    SOLAR_DUSK("Solar Dusk", "solar_dusk"),
    MIDNIGHT("Midnight", "midnight");
    public static final SkyTheme[] CUSTOM={NORTHERN_ECHOS,GALAXY,NEBULA,ASTRA,SOLAR_DUSK,MIDNIGHT};
    public final String label,id;
    public final Identifier texture;
    SkyTheme(String label,String id){this.label=label;this.id=id;texture=Identifier.fromNamespaceAndPath(AstraClient.MOD_ID,"textures/sky/"+id+".png");}
}
