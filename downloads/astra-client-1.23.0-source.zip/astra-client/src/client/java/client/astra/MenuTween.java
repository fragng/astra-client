package client.astra;

/** Small reversible, elapsed-time tween shared by menu open/close and page transitions. */
public final class MenuTween {
    private float value;
    public MenuTween(float initial) {reset(initial);}
    public void reset(float value) {this.value=Math.clamp(value,0,1);}
    public void advance(float target,float seconds,float duration,boolean animated) {
        target=Math.clamp(target,0,1);
        if(!animated) {value=target;return;}
        float step=Math.max(0,seconds)/Math.max(.001f,duration);
        value=target>value?Math.min(target,value+step):Math.max(target,value-step);
    }
    public float secondsTo(float target,float duration) {return Math.abs(Math.clamp(target,0,1)-value)*duration;}
    public float eased() {return value*value*value*(value*(value*6-15)+10);}
    public boolean at(float target) {return Math.abs(value-target)<.0001f;}
}
