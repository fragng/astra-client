package client.astra;

import com.mojang.blaze3d.vertex.PoseStack;
import com.mojang.blaze3d.vertex.VertexConsumer;
import net.minecraft.client.model.geom.ModelPart;
import net.minecraft.core.Direction;
import java.util.EnumSet;
import java.util.List;

/** Native articulated primitive with a curved surface instead of six flat faces. */
final class CurvedCharacterCube extends ModelPart.Cube {
    private final float[] mesh;
    private final float u,v;
    private final int[] shades;
    CurvedCharacterCube(CharacterMesh.Mesh shape,int color,String material,List<CharacterSurface.Pore> pores){
        super(0,0,shape.minX(),shape.minY(),shape.minZ(),shape.maxX()-shape.minX(),shape.maxY()-shape.minY(),shape.maxZ()-shape.minZ(),0,0,0,false,512,512,EnumSet.allOf(Direction.class));
        mesh=shape.vertices().clone();shades=new int[mesh.length/6];for(int i=0;i<mesh.length;i+=6){shades[i/6]=CharacterSurface.shade(mesh[i],mesh[i+1],mesh[i+2],material,pores);mesh[i]/=16;mesh[i+1]/=16;mesh[i+2]/=16;}
        u=(color%8*64+32)/512f;v=(color/8*64+32)/512f;
    }
    @Override public void compile(PoseStack.Pose pose,VertexConsumer consumer,int light,int overlay,int tint){
        for(int i=0;i<mesh.length;i+=6){int shade=shades[i/6],color=(tint&0xFF000000)|(((tint>>16)&255)*shade/255<<16)|(((tint>>8)&255)*shade/255<<8)|((tint&255)*shade/255);consumer.addVertex(pose,mesh[i],mesh[i+1],mesh[i+2]).setColor(color).setUv(u,v).setOverlay(overlay).setLight(light).setNormal(pose,mesh[i+3],mesh[i+4],mesh[i+5]);}
    }
}
