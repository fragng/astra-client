package client.astra;

import net.minecraft.resources.Identifier;
import net.minecraft.world.item.*;
import net.minecraft.core.component.DataComponents;
import net.minecraft.client.Minecraft;
import net.minecraft.client.renderer.entity.state.AvatarRenderState;
import net.minecraft.client.renderer.entity.state.LivingEntityRenderState;

/** One saved, self-only cosmetic choice. NONE restores the native player. */
public enum CharacterStyle {
    NONE("Minecraft","none",""),
    SPONGEBOB("SpongeBob","spongebob","SquarePants"),
    DRDONUTT("DrDonutt","drdonutt","Real-life look"),
    PATRICK("Patrick","patrick","Star"),
    SQUIDWARD("Squidward","squidward","Tentacles"),
    MR_KRABS("Mr. Krabs","mr_krabs","Krusty Krab"),
    SANDY("Sandy","sandy","Cheeks");
    public static final CharacterStyle[] CHOICES={SPONGEBOB,DRDONUTT,PATRICK,SQUIDWARD,MR_KRABS,SANDY};
    public static final Identifier TEXTURE=Identifier.fromNamespaceAndPath(AstraClient.MOD_ID,"textures/entity/characters.png");
    public final String label,id,subtitle;
    private ItemStack preview,icon;
    CharacterStyle(String label,String id,String subtitle){this.label=label;this.id=id;this.subtitle=subtitle;}
    public static boolean applies(LivingEntityRenderState state){
        var mc=Minecraft.getInstance();return AstraConfig.characterStyle()!=NONE && mc.player!=null && state instanceof AvatarRenderState avatar && avatar.id==mc.player.getId();
    }
    public void preview(net.minecraft.client.gui.GuiGraphics g,int x,int y,int size){
        if(this==NONE)return;
        var pose=g.pose();float factor=(float)Math.hypot(pose.m00(),pose.m01());
        int left=Math.round(pose.m00()*x+pose.m10()*y+pose.m20()),top=Math.round(pose.m01()*x+pose.m11()*y+pose.m21());
        int right=Math.round(left+size*factor),bottom=Math.round(top+size*factor);
        g.submitSkinRenderState(CharacterModels.preview(this),TEXTURE,size*factor*.97f/2.125f,-5,20,-1.0625f,left,top,right,bottom);
    }
    public void icon(net.minecraft.client.gui.GuiGraphics g,int x,int y,int size){draw(g,x,y,size,true);}
    private void draw(net.minecraft.client.gui.GuiGraphics g,int x,int y,int size,boolean head){
        if(this==NONE)return;
        ItemStack stack;
        if(head){if(icon==null)icon=stack(true);stack=icon;}else{if(preview==null)preview=stack(false);stack=preview;}
        g.pose().pushMatrix();g.pose().translate(x,y);g.pose().scale(size/16f,size/16f);g.renderFakeItem(stack,0,0);g.pose().popMatrix();
    }
    private ItemStack stack(boolean head){var stack=new ItemStack(Items.PAPER);stack.set(DataComponents.ITEM_MODEL,Identifier.fromNamespaceAndPath(AstraClient.MOD_ID,"character/"+id+(head?"_icon":"")));return stack;}
}
