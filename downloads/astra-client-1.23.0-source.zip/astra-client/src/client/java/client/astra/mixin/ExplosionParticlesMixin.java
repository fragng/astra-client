package client.astra.mixin;

import client.astra.PvpSettings;
import net.minecraft.client.particle.*;
import net.minecraft.core.particles.*;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.*;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfoReturnable;

@Mixin(ParticleEngine.class)
public abstract class ExplosionParticlesMixin {
    @Inject(method="createParticle",at=@At("HEAD"),cancellable=true)
    private void astra$hideExplosion(ParticleOptions options,double x,double y,double z,double vx,double vy,double vz,CallbackInfoReturnable<Particle> ci){
        if(PvpSettings.Feature.EXPLOSIONS.enabled() && (options.getType()==ParticleTypes.EXPLOSION || options.getType()==ParticleTypes.EXPLOSION_EMITTER))ci.setReturnValue(null);
    }
}
