package client.astra;

import net.minecraft.world.item.*;
import static client.astra.PvpSettings.Feature.*;

public enum PvpMode {
    CRYSTAL("Crystal PvP",Items.END_CRYSTAL,LOW_FIRE,EXPLOSIONS,CRYSTALS,TOTEMS),
    SWORD("Sword PvP",Items.DIAMOND_SWORD,COOLDOWN,DURABILITY,ARMOR,null),
    SPEAR("Spear + Mace",Items.IRON_SPEAR,FALL,WIND,DURABILITY,USE),
    MACE("Mace",Items.MACE,FALL,WIND,COOLDOWN,ARMOR),
    UHC("UHC",Items.GOLDEN_APPLE,APPLES,EFFECTS,ABSORPTION,LOW_FIRE),
    AXE("Axe PvP",Items.DIAMOND_AXE,COOLDOWN,SHIELD,ARMOR,null),
    POT("Pot / SMP",Items.SPLASH_POTION,PEARLS,POTIONS,EFFECTS,FOOD),
    BOW("Bow PvP",Items.BOW,ARROWS,DRAW,CROSSBOW,DURABILITY);
    public final String label;
    public final ItemStack icon;
    public final PvpSettings.Feature[] features;
    PvpMode(String label,Item icon,PvpSettings.Feature... features){this.label=label;this.icon=new ItemStack(icon);this.features=features;}
    public static PvpMode find(String label){for(var mode:values())if(mode.label.equals(label))return mode;return null;}
}
