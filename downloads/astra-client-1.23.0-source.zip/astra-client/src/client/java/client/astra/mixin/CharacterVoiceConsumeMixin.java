package client.astra.mixin;
import client.astra.*;
import net.minecraft.client.Minecraft;
import net.minecraft.core.component.DataComponents;
import net.minecraft.world.entity.LivingEntity;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.*;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;
/** Native completion includes food eaten at full hunger, such as golden apples. */
@Mixin(LivingEntity.class)
public abstract class CharacterVoiceConsumeMixin {
    @Inject(method="completeUsingItem",at=@At(value="INVOKE",target="Lnet/minecraft/world/item/ItemStack;finishUsingItem(Lnet/minecraft/world/level/Level;Lnet/minecraft/world/entity/LivingEntity;)Lnet/minecraft/world/item/ItemStack;"))
    private void astra$finishedFood(CallbackInfo ci){
        var self=(LivingEntity)(Object)this;
        if(self==Minecraft.getInstance().player && self.getUseItem().has(DataComponents.FOOD))CharacterVoices.request(VoiceEvent.EATING);
    }
}
