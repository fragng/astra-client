package client.astra;

import net.minecraft.client.gui.GuiGraphics;
import net.minecraft.client.gui.screens.Screen;
import net.minecraft.client.input.MouseButtonEvent;
import net.minecraft.network.chat.Component;

/** Native cursor screen; drag hitbox uses the same bounds as the actual HUD. */
public final class PvpHudEditor extends Screen {
    private final Screen back;
    private boolean moving;
    private double dx,dy;
    public PvpHudEditor(Screen back){super(Component.literal("Move PvP HUD"));this.back=back;}
    @Override protected void init(){
        moving=false;
        addRenderableWidget(new MenuButton(width/2-115,height-39,110,26,"Reset position","",()->false,false,()->{PvpSettings.x=.02;PvpSettings.y=.86;AstraConfig.changed();}));
        addRenderableWidget(new MenuButton(width/2+5,height-39,110,26,"Done","",()->false,false,this::onClose));
    }
    @Override public void render(GuiGraphics g,int mx,int my,float delta){
        g.fill(0,0,width,height,0x35070A15);
        PvpHud.draw(g,true);
        int toolbar=Math.min(390,width-12);
        Ui.round(g,(width-toolbar)/2,height-91,toolbar,84,10,0xF0151424);
        String title="Drag your PvP HUD to move it";
        String hint=PvpSettings.anyHud()?"Position and size save automatically.":"Preview only / enable a PvP HUD setting in the menu.";
        Ui.centered(g,font,title,width/2,height-80,Math.min(.9f,(toolbar-16f)/font.width(Ui.text(title))),0xFFF1E5FF);
        Ui.centered(g,font,hint,width/2,height-63,Math.min(.75f,(toolbar-16f)/font.width(Ui.text(hint))),0xFFC1B5D2);
        super.render(g,mx,my,delta);
    }
    @Override public void renderBackground(GuiGraphics g,int mx,int my,float delta){}
    @Override public boolean mouseClicked(MouseButtonEvent e,boolean twice){
        if(super.mouseClicked(e,twice))return true;
        var b=PvpHud.bounds(width,height,true);
        if(e.button()==0 && e.x()>=b.x() && e.x()<=b.x()+b.width() && e.y()>=b.y() && e.y()<=b.y()+b.height()){moving=true;dx=e.x()-b.x();dy=e.y()-b.y();return true;}
        return false;
    }
    @Override public boolean mouseDragged(MouseButtonEvent e,double mx,double my){if(moving){PvpHud.place(e.x()-dx,e.y()-dy,width,height);return true;}return super.mouseDragged(e,mx,my);}
    @Override public boolean mouseReleased(MouseButtonEvent e){if(moving){moving=false;return true;}return super.mouseReleased(e);}
    @Override public void onClose(){AstraConfig.flush();minecraft.setScreen(back);}
    @Override public boolean isPauseScreen(){return false;}
}
