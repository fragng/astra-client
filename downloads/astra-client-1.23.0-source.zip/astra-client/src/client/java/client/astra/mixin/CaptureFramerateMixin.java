package client.astra.mixin;

import client.astra.DiscordCapture;
import com.mojang.blaze3d.platform.FramerateLimitTracker;
import com.mojang.blaze3d.platform.FramerateLimitTracker.FramerateThrottleReason;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfoReturnable;

@Mixin(FramerateLimitTracker.class)
public abstract class CaptureFramerateMixin {
    @Inject(method="getThrottleReason",at=@At("RETURN"),cancellable=true)
    private void astra$captureFrames(CallbackInfoReturnable<FramerateThrottleReason> cir){
        if(DiscordCapture.enabled() && (cir.getReturnValue()==FramerateThrottleReason.SHORT_AFK || cir.getReturnValue()==FramerateThrottleReason.LONG_AFK))
            cir.setReturnValue(FramerateThrottleReason.NONE);
    }
}
