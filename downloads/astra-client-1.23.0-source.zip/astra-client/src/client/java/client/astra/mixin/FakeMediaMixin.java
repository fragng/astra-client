package client.astra.mixin;

import client.astra.AstraConfig;
import net.minecraft.client.Minecraft;
import net.minecraft.client.renderer.entity.EntityRenderer;
import net.minecraft.client.renderer.entity.state.EntityRenderState;
import net.minecraft.network.chat.Component;
import net.minecraft.network.chat.FontDescription;
import net.minecraft.resources.Identifier;
import net.minecraft.world.entity.Entity;
import net.minecraft.world.entity.EntityAttachment;
import net.minecraft.world.phys.Vec3;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.Unique;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;

/** A self-only render-state decoration. Never modifies names, teams or packets. */
@Mixin(EntityRenderer.class)
public abstract class FakeMediaMixin {
    @Unique private static final FontDescription ASTRA_MEDIA_FONT=new FontDescription.Resource(Identifier.fromNamespaceAndPath("astra-client","media_badge"));
    @Inject(method="extractRenderState",at=@At("TAIL"))
    private void astra$selfBadge(Entity entity,EntityRenderState state,float partial,CallbackInfo ci) {
        var mc=Minecraft.getInstance();
        if(!AstraConfig.fakeMedia || entity!=mc.player || mc.screen!=null || mc.options.hideGui
                || mc.options.getCameraType().isFirstPerson() || entity.isInvisible() || entity.isSpectator())return;
        state.nameTag=Component.empty().append(Component.literal("\uE000").withStyle(s->s.withFont(ASTRA_MEDIA_FONT)))
            .append(" ").append(entity.getDisplayName());
        Vec3 attachment=entity.getAttachments().getNullable(EntityAttachment.NAME_TAG,0,entity.getYRot(partial));
        state.nameTagAttachment=attachment==null?new Vec3(0,state.boundingBoxHeight+.25,0):attachment;
    }
}
