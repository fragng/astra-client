package client.astra.mixin;

import client.astra.AstraConfig;
import client.astra.Ui;
import net.minecraft.client.gui.Font;
import net.minecraft.network.chat.FontDescription;
import net.minecraft.resources.Identifier;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.Unique;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.ModifyVariable;

/** Resolve both glyph drawing and measurement through the current font preference. */
@Mixin(Font.class)
public abstract class BubbleFontMixin {
    @Unique private static final FontDescription ASTRA_BUBBLE_DEFAULT = new FontDescription.Resource(
        Identifier.fromNamespaceAndPath("astra-client", "default-bubble"));

    @ModifyVariable(method = "getGlyphSource", at = @At("HEAD"), argsOnly = true)
    private FontDescription astra$selectedFont(FontDescription requested) {
        if (AstraConfig.bubbleFont && requested.equals(FontDescription.DEFAULT)) return ASTRA_BUBBLE_DEFAULT;
        if (!AstraConfig.bubbleFont && (requested.equals(Ui.FONT) || requested.equals(Ui.HEADING)
                || requested.equals(ASTRA_BUBBLE_DEFAULT))) return FontDescription.DEFAULT;
        return requested;
    }
}
