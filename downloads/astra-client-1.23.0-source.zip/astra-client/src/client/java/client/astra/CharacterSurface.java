package client.astra;

import java.util.List;

/** Small, closed surface recesses: the back of a sponge stays solid. Built once. */
public final class CharacterSurface {
    public record Pore(float x,float y,float radius,float depth){
        public Pore {if(!(radius>0 && depth>0 && depth<=radius))throw new IllegalArgumentException("pore dimensions");}
    }
    private CharacterSurface(){}
    public static CharacterMesh.Mesh recess(CharacterMesh.Mesh original,List<Pore> pores){
        if(pores.isEmpty())return original;
        float[] v=original.vertices().clone();float middle=(original.minZ()+original.maxZ())/2;
        for(int i=0;i<v.length;i+=6){
            if(v[i+2]>=middle || v[i+5]>-.5f)continue;
            double displacement=0,dx=0,dy=0;
            for(Pore p:pores){
                double x=v[i]-p.x,y=v[i+1]-p.y,r2=(x*x+y*y)/(p.radius*p.radius);
                if(r2>=1)continue;
                double f=1-r2;displacement+=p.depth*f*f;
                dx+=-4*p.depth*f*x/(p.radius*p.radius);dy+=-4*p.depth*f*y/(p.radius*p.radius);
            }
            // Always leave a solid back, even if a custom resource pack supplies large pores.
            displacement=Math.min(displacement,(original.maxZ()-v[i+2])*.2);
            v[i+2]+=(float)displacement;
            double nx=v[i+3]-v[i+5]*dx,ny=v[i+4]-v[i+5]*dy,nz=v[i+5],length=Math.sqrt(nx*nx+ny*ny+nz*nz);
            v[i+3]=(float)(nx/length);v[i+4]=(float)(ny/length);v[i+5]=(float)(nz/length);
        }
        return new CharacterMesh.Mesh(v,original.minX(),original.minY(),original.minZ(),original.maxX(),original.maxY(),original.maxZ());
    }
    public static int shade(float x,float y,float z,String material,List<Pore> pores){
        if(material.isEmpty())return 255;
        double grain=(Math.sin(x*41+y*29+z*53)*Math.sin(x*17-y*37+z*19)+1)*.5;
        double value=1-(material.equals("fabric")?.055:.035)*grain;
        if(material.equals("sponge") && z<0)for(Pore p:pores){
            double r2=((x-p.x)*(x-p.x)+(y-p.y)*(y-p.y))/(p.radius*p.radius);
            if(r2<1)value-=.23*(1-r2)*(1-r2);
        }
        return (int)Math.clamp(Math.round(value*255),0,255);
    }
}
