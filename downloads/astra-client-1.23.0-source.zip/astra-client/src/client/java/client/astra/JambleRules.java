package client.astra;

/** Exact anvil-name formats, using tenths to avoid floating-point comparisons. */
public final class JambleRules {
    private JambleRules(){}
    public enum Side {HOST,VIEWER}
    public record Number(Side side,int base){
        public int score(){return base*10+(side==Side.HOST?1:0);}
        public String label(){return base+(side==Side.HOST?".1":"");}
    }
    public static Number parse(String name){
        if(name==null)return null;String s=name.strip();
        if(s.isEmpty()||s.charAt(0)<'1'||s.charAt(0)>'9')return null;
        if(s.length()==1)return new Number(Side.VIEWER,s.charAt(0)-'0');
        if(s.length()==3&&s.charAt(1)=='.'&&s.charAt(2)=='1')return new Number(Side.HOST,s.charAt(0)-'0');
        return null;
    }
    public static Side winner(Number host,Number viewer){
        if(host==null||viewer==null||host.side!=Side.HOST||viewer.side!=Side.VIEWER)throw new IllegalArgumentException("One Host and one Viewer are required");
        return host.score()>viewer.score()?Side.HOST:Side.VIEWER;
    }
}
