package client.astra.mixin;
import client.astra.AstraConfig;
import com.mojang.blaze3d.vertex.PoseStack;
import net.minecraft.client.renderer.*;
import net.minecraft.world.entity.LivingEntity;
import net.minecraft.world.item.*;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.*;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;
@Mixin(ItemInHandRenderer.class)
public abstract class SmallTotemMixin {
    private static boolean astra$small(ItemStack stack,ItemDisplayContext context){return AstraConfig.smallTotem && stack.is(Items.TOTEM_OF_UNDYING) && (context==ItemDisplayContext.FIRST_PERSON_LEFT_HAND || context==ItemDisplayContext.FIRST_PERSON_RIGHT_HAND);}
    @Inject(method="renderItem",at=@At("HEAD"))
    private void astra$start(LivingEntity entity,ItemStack stack,ItemDisplayContext context,PoseStack poses,SubmitNodeCollector collector,int light,CallbackInfo ci){if(astra$small(stack,context)){poses.pushPose();poses.scale(.55f,.55f,.55f);}}
    @Inject(method="renderItem",at=@At("RETURN"))
    private void astra$end(LivingEntity entity,ItemStack stack,ItemDisplayContext context,PoseStack poses,SubmitNodeCollector collector,int light,CallbackInfo ci){if(astra$small(stack,context))poses.popPose();}
}
