package client.astra;

import com.google.gson.*;
import net.minecraft.client.model.player.PlayerModel;
import net.minecraft.client.model.geom.*;
import net.minecraft.client.renderer.entity.state.AvatarRenderState;
import java.io.*;
import java.nio.charset.StandardCharsets;
import java.util.*;

/** Cached native articulated models. Geometry is authored alongside matching 3D GUI previews. */
public final class CharacterModels {
    private static final EnumMap<CharacterStyle,PlayerModel> CACHE=new EnumMap<>(CharacterStyle.class);
    private static final EnumMap<CharacterStyle,PlayerModel> PREVIEWS=new EnumMap<>(CharacterStyle.class);
    private static final EnumMap<CharacterStyle,Map<String,List<ModelPart.Cube>>> GEOMETRY=new EnumMap<>(CharacterStyle.class);
    private static JsonObject definitions;
    public static PlayerModel preview(CharacterStyle style){return PREVIEWS.computeIfAbsent(style,CharacterModels::bake);}
    private CharacterModels(){}
    public static PlayerModel model(CharacterStyle style){
        if(style==CharacterStyle.NONE)throw new IllegalArgumentException("Native model has no replacement");
        return CACHE.computeIfAbsent(style,CharacterModels::bake);
    }
    private static PlayerModel bake(CharacterStyle style){
        if(definitions==null){
            try(var stream=CharacterModels.class.getResourceAsStream("/assets/astra-client/characters/models.json")){
                if(stream==null)throw new FileNotFoundException("Character geometry");
                definitions=JsonParser.parseReader(new InputStreamReader(stream,StandardCharsets.UTF_8)).getAsJsonObject().getAsJsonObject("models");
            }catch(IOException e){throw new IllegalStateException("Could not load character geometry",e);}
        }
        var parts=definitions.getAsJsonObject(style.id).getAsJsonObject("parts");
        var geometry=GEOMETRY.computeIfAbsent(style,key->{
            Map<String,List<ModelPart.Cube>> result=new LinkedHashMap<>();
            for(var entry:parts.entrySet()){
                List<ModelPart.Cube> cubes=new ArrayList<>();
                for(var value:entry.getValue().getAsJsonObject().getAsJsonArray("boxes")){
                    var box=value.getAsJsonObject();var from=box.getAsJsonArray("from");var size=box.getAsJsonArray("size");
                    var shape=CharacterMesh.build(from.get(0).getAsFloat(),from.get(1).getAsFloat(),from.get(2).getAsFloat(),size.get(0).getAsFloat(),size.get(1).getAsFloat(),size.get(2).getAsFloat(),box.has("power")?box.get("power").getAsDouble():.35,box.has("taper")?box.get("taper").getAsDouble():0,box.has("ring")&&box.get("ring").getAsBoolean(),box.has("band")?box.get("band").getAsDouble():.28,box.has("detail")?box.get("detail").getAsInt():0);
                    List<CharacterSurface.Pore> pores=new ArrayList<>();
                    if(box.has("pores"))for(var pore:box.getAsJsonArray("pores")){var p=pore.getAsJsonArray();pores.add(new CharacterSurface.Pore(p.get(0).getAsFloat(),p.get(1).getAsFloat(),p.get(2).getAsFloat(),p.get(3).getAsFloat()));}
                    shape=CharacterSurface.recess(shape,pores);
                    cubes.add(new CurvedCharacterCube(shape,box.get("color").getAsInt(),box.has("material")?box.get("material").getAsString():"",pores));
                }
                result.put(entry.getKey(),List.copyOf(cubes));
            }
            return result;
        });
        Map<String,ModelPart> children=new LinkedHashMap<>();
        for(var entry:parts.entrySet()){
            String overlay=switch(entry.getKey()){case "head"->"hat";case "body"->"jacket";case "right_arm"->"right_sleeve";case "left_arm"->"left_sleeve";case "right_leg"->"right_pants";default->"left_pants";};
            var part=new ModelPart(geometry.get(entry.getKey()),Map.of(overlay,new ModelPart(List.of(),Map.of())));
            var p=entry.getValue().getAsJsonObject().getAsJsonArray("pivot");var pose=PartPose.offset(p.get(0).getAsFloat(),p.get(1).getAsFloat(),p.get(2).getAsFloat());part.setInitialPose(pose);part.loadPose(pose);children.put(entry.getKey(),part);
        }
        return new CharacterPlayerModel(new ModelPart(List.of(),children));
    }

    private static final class CharacterPlayerModel extends PlayerModel {
        private final float armRadius;
        CharacterPlayerModel(ModelPart root){super(root,false);armRadius=Math.abs(rightArm.getInitialPose().x());}
        @Override public void setupAnim(AvatarRenderState state){
            super.setupAnim(state);
            // Vanilla attack poses use a five-unit arm radius; keep wider cartoon shoulders joined.
            if(state.attackTime>0 && armRadius!=5){rightArm.x*=armRadius/5;leftArm.x*=armRadius/5;}
        }
    }
}
