package client.astra;

import net.minecraft.client.Minecraft;
import net.minecraft.client.gui.GuiGraphics;
import net.minecraft.client.gui.components.AbstractSliderButton;
import net.minecraft.network.chat.Component;
import java.util.function.*;

public final class MenuSlider extends AbstractSliderButton {
    private final DoubleSupplier read;
    private final DoubleConsumer write;
    private final Function<Double,String> format;
    private double shown;
    private final double step;
    private long last=System.nanoTime();
    public MenuSlider(int x,int y,int w,DoubleSupplier read,DoubleConsumer write,Function<Double,String> format) {
        this(x,y,w,read,write,format,.01);
    }
    public MenuSlider(int x,int y,int w,DoubleSupplier read,DoubleConsumer write,Function<Double,String> format,double step) {
        super(x,y,w,47,Component.empty(),read.getAsDouble());
        this.step=step;
        this.read=read;this.write=write;this.format=format;shown=value;updateMessage();
    }
    @Override protected void updateMessage() { if(format!=null) setMessage(Ui.text(format.apply(value))); }
    @Override protected void applyValue() { if(write!=null) write.accept(Math.clamp(value,0,1));updateMessage(); }
    @Override public boolean keyPressed(net.minecraft.client.input.KeyEvent key) {
        if (isFocused()) {
            int k=key.key();
            if(k==org.lwjgl.glfw.GLFW.GLFW_KEY_LEFT || k==org.lwjgl.glfw.GLFW.GLFW_KEY_RIGHT
                    || k==org.lwjgl.glfw.GLFW.GLFW_KEY_HOME || k==org.lwjgl.glfw.GLFW.GLFW_KEY_END) {
                value=k==org.lwjgl.glfw.GLFW.GLFW_KEY_HOME?0:k==org.lwjgl.glfw.GLFW.GLFW_KEY_END?1:
                    Math.clamp(read.getAsDouble()+(k==org.lwjgl.glfw.GLFW.GLFW_KEY_LEFT?-step:step),0,1);
                applyValue();return true;
            }
        }
        return super.keyPressed(key);
    }
    @Override public void renderWidget(GuiGraphics g,int mx,int my,float delta) {
        value=Math.clamp(read.getAsDouble(),0,1);updateMessage();
        long now=System.nanoTime();double dt=Math.min(.1,(now-last)/1e9);last=now;
        shown=AstraConfig.animations?shown+(value-shown)*(1-Math.exp(-dt*22)):value;
        int x=getX(),y=getY(),w=getWidth();
        Ui.round(g,x,y,w,getHeight(),8,0x75353A58);
        var font=Minecraft.getInstance().font;
        String label=getMessage().getString();int split=label.lastIndexOf(':');
        if(split>=0) {
            String prefix=label.substring(0,split+1)+" ";
            Ui.animated(g,font,prefix,x+10,y+8,0xFFE9E4F7);
            Ui.animated(g,font,Ui.heading(label.substring(split+1).trim()),x+10+font.width(Ui.text(prefix)),y+7,0xFFF2DFFF);
        } else Ui.animated(g,font,getMessage(),x+10,y+8,0xFFE9E4F7);
        int tx=x+4,ty=y+32,tw=w-8;
        Ui.round(g,tx-1,ty-1,tw+2,9,4,0xFF130D28);
        Ui.round(g,tx,ty,tw,7,3,0xFFC8A2E8);
        Ui.round(g,tx+2,ty+2,tw-4,3,1,0xFF36284E);
        int knob=tx+(int)Math.round(shown*tw);
        Ui.round(g,tx+1,ty+1,Math.max(2,knob-tx),5,2,0xFFC394F0);
        if(knob>tx+4) g.fill(tx+3,ty+2,knob,ty+3,Ui.tint(0xFFF8DFFF));
        Ui.round(g,knob-8,ty-5,16,16,8,0xFF17102C);
        Ui.round(g,knob-7,ty-5,14,14,7,isHoveredOrFocused()?0xFFFFFFFF:0xFFF5DEFF);
        Ui.round(g,knob-5,ty-3,10,10,5,0xFFC18AE9);
        Ui.round(g,knob-3,ty-2,4,3,1,0xFFFFFFFF);

    }
}
