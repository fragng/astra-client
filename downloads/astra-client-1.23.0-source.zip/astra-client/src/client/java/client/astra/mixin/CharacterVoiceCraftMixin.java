package client.astra.mixin;
import client.astra.*;
import net.minecraft.client.Minecraft;
import net.minecraft.world.inventory.ResultSlot;
import net.minecraft.world.entity.player.Player;
import net.minecraft.world.item.ItemStack;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.*;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;
@Mixin(ResultSlot.class)
public abstract class CharacterVoiceCraftMixin {
    @Inject(method="onTake",at=@At("HEAD"))
    private void astra$craft(Player player,ItemStack stack,CallbackInfo ci){if(player==Minecraft.getInstance().player && !stack.isEmpty())CharacterVoices.request(VoiceEvent.CRAFTING);}
}
