package client.astra.mixin;

import client.astra.RoundedSprites;
import client.astra.Ui;
import com.mojang.blaze3d.pipeline.RenderPipeline;
import net.minecraft.client.gui.GuiGraphics;
import net.minecraft.resources.Identifier;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.Unique;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;

@Mixin(GuiGraphics.class)
public abstract class GuiGraphicsMixin {
    @Unique private boolean astra$roundingTexture;

    @Inject(method = "blitSprite(Lcom/mojang/blaze3d/pipeline/RenderPipeline;Lnet/minecraft/resources/Identifier;IIIII)V", at = @At("HEAD"), cancellable = true)
    private void astra$roundedWidgets(RenderPipeline pipeline, Identifier sprite, int x, int y, int w, int h, int tint, CallbackInfo ci) {
        if (RoundedSprites.draw((GuiGraphics) (Object) this, sprite, x, y, w, h, tint)) ci.cancel();
    }

    @Inject(method = "blit(Lcom/mojang/blaze3d/pipeline/RenderPipeline;Lnet/minecraft/resources/Identifier;IIFFIIIIIII)V", at = @At("HEAD"), cancellable = true)
    private void astra$roundedContainers(RenderPipeline pipeline, Identifier texture, int x, int y, float u, float v,
            int w, int h, int sourceW, int sourceH, int textureW, int textureH, int tint, CallbackInfo ci) {
        if (astra$roundingTexture || !texture.getNamespace().equals("minecraft")
                || !texture.getPath().startsWith("textures/gui/container/") || u != 0 || v != 0
                || w < 140 || h < 100 || sourceW != w || sourceH != h) return;
        GuiGraphics g = (GuiGraphics) (Object) this;
        astra$roundingTexture = true;
        try {
            int r = 7;
            g.blit(pipeline, texture, x, y + r, u, v + r, w, h - r * 2, w, h - r * 2, textureW, textureH, tint);
            for (int row = 0; row < r; row++) {
                int inset = Ui.inset(row, h, r);
                g.blit(pipeline, texture, x + inset, y + row, u + inset, v + row, w - inset * 2, 1, w - inset * 2, 1, textureW, textureH, tint);
                g.blit(pipeline, texture, x + inset, y + h - row - 1, u + inset, v + h - row - 1, w - inset * 2, 1, w - inset * 2, 1, textureW, textureH, tint);
            }
        } finally { astra$roundingTexture = false; }
        ci.cancel();
    }
}
