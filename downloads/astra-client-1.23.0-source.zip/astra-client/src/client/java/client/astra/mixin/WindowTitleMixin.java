package client.astra.mixin;

import client.astra.AstraClient;
import client.astra.DiscordCapture;
import net.minecraft.client.Minecraft;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfoReturnable;

@Mixin(Minecraft.class)
public abstract class WindowTitleMixin {
    @Inject(method="createTitle",at=@At("HEAD"),cancellable=true)
    private void astra$windowTitle(CallbackInfoReturnable<String> cir){
        cir.setReturnValue(DiscordCapture.enabled()?AstraClient.NAME+" | Minecraft 1.21.11":AstraClient.NAME);
    }
}
