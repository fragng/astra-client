package client.astra;

/** No backlog: quiet events are dropped; important events can interrupt a lesser reaction. */
public final class VoiceGate {
    private final long[] next=new long[VoiceEvent.values().length];
    private long quietUntil,busyUntil;
    private int priority;
    public boolean accept(VoiceEvent event,long now,double duration,int cadence){
        if(now<next[event.ordinal()])return false;
        if(now<busyUntil && (event.priority<80 || event.priority<=priority))return false;
        if(now<quietUntil && event.priority<80)return false;
        next[event.ordinal()]=now+(event.priority>=90?4:45)*1_000_000_000L;
        quietUntil=now+new long[]{30,16,8}[Math.clamp(cadence,0,2)]*1_000_000_000L;
        busyUntil=now+(long)((Math.clamp(duration,.1,12)+.25)*1_000_000_000L);priority=event.priority;return true;
    }
    public void clear(){java.util.Arrays.fill(next,0);quietUntil=busyUntil=0;priority=0;}
}
