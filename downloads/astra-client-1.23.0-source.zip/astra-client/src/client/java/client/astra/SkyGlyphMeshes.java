package client.astra;

import client.astra.mixin.RenderTypeAccess;
import com.mojang.blaze3d.buffers.GpuBuffer;
import com.mojang.blaze3d.pipeline.*;
import com.mojang.blaze3d.platform.DepthTestFunction;
import com.mojang.blaze3d.shaders.UniformType;
import com.mojang.blaze3d.systems.RenderSystem;
import com.mojang.blaze3d.textures.GpuTextureView;
import com.mojang.blaze3d.vertex.*;
import net.minecraft.client.Minecraft;
import net.minecraft.client.gui.Font;
import net.minecraft.client.renderer.MultiBufferSource;
import net.minecraft.client.renderer.rendertype.RenderType;
import net.minecraft.client.renderer.rendertype.RenderSetup;
import net.minecraft.resources.Identifier;
import org.joml.Matrix4f;
import org.joml.Vector3f;
import org.joml.Vector4f;
import java.util.*;

/** Native font glyphs cached as small sky meshes. No near-player billboard or HUD panel. */
final class SkyGlyphMeshes {
    private static RenderPipeline pipeline(boolean intensity){
        var builder=RenderPipeline.builder().withLocation(Identifier.fromNamespaceAndPath(AstraClient.MOD_ID,"pipeline/sky_lyrics"+(intensity?"_intensity":"")))
            .withVertexShader(Identifier.fromNamespaceAndPath(AstraClient.MOD_ID,"core/sky_lyrics"))
            .withFragmentShader(Identifier.fromNamespaceAndPath(AstraClient.MOD_ID,"core/sky_lyrics"))
            .withUniform("DynamicTransforms",UniformType.UNIFORM_BUFFER).withUniform("Projection",UniformType.UNIFORM_BUFFER).withSampler("Sampler0")
            .withVertexFormat(DefaultVertexFormat.POSITION_COLOR_TEX_LIGHTMAP,VertexFormat.Mode.QUADS)
            .withDepthTestFunction(DepthTestFunction.NO_DEPTH_TEST).withDepthWrite(false).withCull(false).withBlend(BlendFunction.TRANSLUCENT);
        if(intensity)builder.withShaderDefine("GLYPH_INTENSITY");
        return builder.build();
    }
    private static final RenderPipeline NORMAL=pipeline(false),INTENSITY=pipeline(true);
    private record Key(String text,boolean bubble){}
    private record Layer(RenderType nativeType,GpuBuffer vertices,int indices,GpuTextureView atlas) implements AutoCloseable {
        RenderSetup.TextureAndSampler texture(){return ((RenderTypeAccess)(Object)nativeType).astra$setup().getTextures().get("Sampler0");}
        public void close(){vertices.close();}
    }
    static final class Line implements AutoCloseable {
        final int width;final List<Layer> layers;
        Line(int width,List<Layer> layers){this.width=width;this.layers=layers;}
        boolean valid(){try{for(var layer:layers){var texture=layer.texture();if(texture==null || texture.textureView()!=layer.atlas)return false;}return true;}catch(RuntimeException e){return false;}}
        public void close(){for(var layer:layers)layer.close();}
    }
    private record Group(ByteBufferBuilder bytes,BufferBuilder builder) implements AutoCloseable {public void close(){bytes.close();}}
    private static final Map<Key,Line> CACHE=new LinkedHashMap<>(8,.75f,true);
    private SkyGlyphMeshes(){}
    static Line line(String text,boolean bubble){
        var key=new Key(text,bubble);var old=CACHE.get(key);if(old!=null && old.valid())return old;
        if(old!=null){old.close();CACHE.remove(key);}
        var font=Minecraft.getInstance().font;var value=Ui.text(text);int width=font.width(value);
        var groups=new LinkedHashMap<RenderType,Group>();var layers=new ArrayList<Layer>();
        try {
            MultiBufferSource capture=type->groups.computeIfAbsent(type,k->{var bytes=new ByteBufferBuilder(8192);return new Group(bytes,new BufferBuilder(bytes,k.mode(),k.format()));}).builder;
            font.drawInBatch(value,-width/2f,0,0xFFFFFFFF,false,new Matrix4f(),capture,Font.DisplayMode.NORMAL,0,15728880);
            for(var entry:groups.entrySet()){
                var type=entry.getKey();var texture=((RenderTypeAccess)(Object)type).astra$setup().getTextures().get("Sampler0");
                if(texture==null)throw new IllegalStateException("Missing sky lyric font atlas");
                try(var mesh=entry.getValue().builder.buildOrThrow()){
                    if(mesh.drawState().format()!=DefaultVertexFormat.POSITION_COLOR_TEX_LIGHTMAP || mesh.drawState().mode()!=VertexFormat.Mode.QUADS)throw new IllegalStateException("Unsupported sky lyric glyph format");
                    var vertices=RenderSystem.getDevice().createBuffer(()->"Astra sky lyric glyphs",GpuBuffer.USAGE_VERTEX,mesh.vertexBuffer());
                    layers.add(new Layer(type,vertices,mesh.drawState().indexCount(),texture.textureView()));
                }
            }
            var result=new Line(width,List.copyOf(layers));CACHE.put(key,result);
            while(CACHE.size()>6){var first=CACHE.keySet().iterator();var victim=first.next();CACHE.remove(victim).close();}
            return result;
        }catch(RuntimeException e){for(var layer:layers)layer.close();throw e;}
        finally{for(var group:groups.values())group.close();}
    }
    static void draw(Line line,Matrix4f transform,int color){
        if(line.layers.isEmpty() || color>>>24==0)return;
        var target=Minecraft.getInstance().getMainRenderTarget();
        var tint=new Vector4f((color>>16&255)/255f,(color>>8&255)/255f,(color&255)/255f,(color>>>24)/255f);
        var uniforms=RenderSystem.getDynamicUniforms().writeTransform(transform,tint,new Vector3f(),new Matrix4f());
        var indices=RenderSystem.getSequentialBuffer(VertexFormat.Mode.QUADS);
        for(var layer:line.layers){
            var texture=layer.texture();var indexBuffer=indices.getBuffer(layer.indices);
            try(var pass=RenderSystem.getDevice().createCommandEncoder().createRenderPass(()->"Astra fixed sky lyrics",target.getColorTextureView(),OptionalInt.empty(),target.getDepthTextureView(),OptionalDouble.empty())){
                boolean intensity=layer.nativeType.pipeline().getFragmentShader().getPath().contains("intensity");
                pass.setPipeline(intensity?INTENSITY:NORMAL);RenderSystem.bindDefaultUniforms(pass);pass.setUniform("DynamicTransforms",uniforms);
                pass.bindTexture("Sampler0",texture.textureView(),texture.sampler());pass.setVertexBuffer(0,layer.vertices);
                pass.setIndexBuffer(indexBuffer,indices.type());pass.drawIndexed(0,0,layer.indices,1);
            }
        }
    }
    static void clear(){for(var line:CACHE.values())line.close();CACHE.clear();}
}
