package client.astra.mixin;
import net.minecraft.client.model.EntityModel;
import net.minecraft.client.renderer.entity.LivingEntityRenderer;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.gen.Accessor;
@Mixin(LivingEntityRenderer.class)
public interface CharacterModelAccess {
    @Accessor("model") EntityModel<?> astra$getModel();
    @Accessor("model") void astra$setModel(EntityModel<?> model);
}
