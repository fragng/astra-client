package client.astra;

import java.util.ArrayList;

/** Curved surface definitions with analytic per-vertex normals, built once per shape. */
public final class CharacterMesh {
    public record Mesh(float[] vertices,float minX,float minY,float minZ,float maxX,float maxY,float maxZ){}
    private CharacterMesh(){}
    public static Mesh build(float x,float y,float z,float w,float h,float d,double power,double taper,boolean ring,double band){
        if(!(w>0 && h>0 && d>0 && power>0 && power<=1.3 && Math.abs(taper)<.95))throw new IllegalArgumentException("shape");
        return build(x,y,z,w,h,d,power,taper,ring,band,0);
    }
    public static Mesh build(float x,float y,float z,float w,float h,float d,double power,double taper,boolean ring,double band,int detail){
        if(!(w>0 && h>0 && d>0 && power>0 && power<=1.3 && Math.abs(taper)<.95))throw new IllegalArgumentException("shape");
        var output=new ArrayList<Float>();
        int steps=Math.max(w,Math.max(h,d))>=7?10:Math.max(w,Math.max(h,d))>=2.5?6:4;
        if(detail>0)steps=Math.clamp(detail,4,64);
        double[] center={x+w/2.0,y+h/2.0,z+d/2.0},half={w/2.0,h/2.0,d/2.0};
        if(ring){
            int around=40,sides=8;double tube=Math.min(band,Math.min(w,h)*.24);
            for(int a=0;a<around;a++)for(int b=0;b<sides;b++)for(int k=0;k<4;k++){
                double t=(a+(k==1||k==2?1:0))*Math.PI*2/around,p=(b+(k>=2?1:0))*Math.PI*2/sides;
                double ct=Math.cos(t),st=Math.sin(t),cp=Math.cos(p),sp=Math.sin(p),rx=half[0]-tube+tube*cp,ry=half[1]-tube+tube*cp;
                append(output,center[0]+rx*ct,center[1]+ry*st,center[2]+half[2]*sp,ry*ct*half[2]*cp,rx*st*half[2]*cp,tube*sp*(rx*st*st+ry*ct*ct));
            }
        }else{
            for(int axis=0;axis<3;axis++)for(int sign:new int[]{-1,1})for(int a=0;a<steps;a++)for(int b=0;b<steps;b++)for(int k=0;k<4;k++){
                int corner=sign==1?k:(k==0?0:4-k);
                double u=-1+2.0*(a+(corner==1||corner==2?1:0))/steps,v=-1+2.0*(b+(corner>=2?1:0))/steps;
                double[] q=new double[3];q[axis]=sign;q[(axis+1)%3]=Math.copySign(Math.pow(Math.abs(u),1/power),u);q[(axis+2)%3]=Math.copySign(Math.pow(Math.abs(v),1/power),v);
                double length=Math.sqrt(q[0]*q[0]+q[1]*q[1]+q[2]*q[2]);
                for(int i=0;i<3;i++)q[i]=Math.copySign(Math.pow(Math.abs(q[i]/length),power),q[i]);
                double px=q[0]*half[0],py=q[1]*half[1],pz=q[2]*half[2],f=1+taper*q[1];
                double nx=Math.copySign(Math.pow(Math.abs(q[0]),2/power-1),q[0])/half[0];
                double ny=Math.copySign(Math.pow(Math.abs(q[1]),2/power-1),q[1])/half[1];
                double nz=Math.copySign(Math.pow(Math.abs(q[2]),2/power-1),q[2])/half[2];
                ny-=(nx*px+nz*pz)*(taper/half[1])/f;nx/=f;nz/=f;
                append(output,center[0]+px*f,center[1]+py,center[2]+pz*f,nx,ny,nz);
            }
        }
        float[] vertices=new float[output.size()];float ax=Float.POSITIVE_INFINITY,ay=ax,az=ax,bx=Float.NEGATIVE_INFINITY,by=bx,bz=bx;
        for(int i=0;i<vertices.length;i++)vertices[i]=output.get(i);
        for(int i=0;i<vertices.length;i+=6){ax=Math.min(ax,vertices[i]);ay=Math.min(ay,vertices[i+1]);az=Math.min(az,vertices[i+2]);bx=Math.max(bx,vertices[i]);by=Math.max(by,vertices[i+1]);bz=Math.max(bz,vertices[i+2]);}
        return new Mesh(vertices,ax,ay,az,bx,by,bz);
    }
    private static void append(ArrayList<Float> out,double x,double y,double z,double nx,double ny,double nz){
        double length=Math.sqrt(nx*nx+ny*ny+nz*nz);
        if(!(length>0) || !Double.isFinite(x+y+z+length))throw new IllegalArgumentException("degenerate shape");
        out.add((float)x);out.add((float)y);out.add((float)z);out.add((float)(nx/length));out.add((float)(ny/length));out.add((float)(nz/length));
    }
}
