package client.astra;

import net.minecraft.client.Minecraft;

/** Local lightmap override. Native brightness options and world light data stay intact. */
public final class Fullbright {
    private Fullbright(){}
    public static void toggle(){set(!AstraConfig.fullbright);}
    public static void set(boolean enabled){
        AstraConfig.fullbright=enabled;AstraConfig.changed();
        var client=Minecraft.getInstance();
        if(client.gameRenderer!=null)client.gameRenderer.lightTexture().tick();
    }
}
