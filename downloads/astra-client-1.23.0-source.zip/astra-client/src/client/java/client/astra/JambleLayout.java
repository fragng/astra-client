package client.astra;

/** One small receipt below music, and a short-lived payout toast above the hotbar. */
public record JambleLayout(int cardX,int cardY,int cardWidth,int cardHeight,int toastX,int toastY,int toastWidth,int toastHeight,float musicScale) {
    public static final int CARD_H=44,TOAST_H=22;
    public static JambleLayout compute(int width,int height,boolean card,boolean music,boolean lyrics,double requestedScale){
        float scale=Math.min((float)requestedScale,(width-16f)/320);
        if(card && music)scale=Math.min(scale,Math.max(.25f,(height-148f)/(lyrics?130:70)));
        int musicBottom=music?12+(int)Math.ceil((lyrics?130:70)*scale):8;
        int cw=Math.min(228,width-24),tw=Math.min(208,width-24);
        return new JambleLayout((width-cw)/2,musicBottom+6,cw,CARD_H,(width-tw)/2,height-78,tw,TOAST_H,scale);
    }
}
