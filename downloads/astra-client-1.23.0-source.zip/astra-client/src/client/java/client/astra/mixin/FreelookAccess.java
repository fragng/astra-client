package client.astra.mixin;

import freelook.freelook.FreeLookMod;
import net.minecraft.client.KeyMapping;
import net.minecraft.client.Minecraft;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.gen.Accessor;
import org.spongepowered.asm.mixin.gen.Invoker;

@Mixin(value=FreeLookMod.class,remap=false)
public interface FreelookAccess {
    @Accessor(value="freeLookKeyBind",remap=false) KeyMapping astra$key();
    @Invoker(value="stopFreeLooking",remap=false) void astra$stop(Minecraft client);
}
