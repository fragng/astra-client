package client.astra;

import net.minecraft.client.Minecraft;
import net.minecraft.client.gui.Font;
import net.minecraft.client.gui.GuiGraphics;
import net.minecraft.client.gui.components.PlayerFaceRenderer;
import net.minecraft.client.resources.DefaultPlayerSkin;

public final class ProfileHeader {
    private ProfileHeader(){}
    public static void draw(GuiGraphics g,Font font,int x,int y){
        var mc=Minecraft.getInstance();boolean premium=PremiumEdition.premium();
        Ui.round(g,x-2,y-2,28,28,6,premium?0xFFFFD36C:0xFF9786B0);
        Ui.round(g,x-1,y-1,26,26,5,0xFF171627);
        var skin=mc.player==null?DefaultPlayerSkin.get(mc.getUser().getProfileId()):mc.player.getSkin();
        PlayerFaceRenderer.draw(g,skin,x,y,24,Ui.tint(0xFFFFFFFF));
        String rank=premium?"Premium":"Member";float scale=.8f;
        g.pose().pushMatrix();g.pose().translate(x+12,y+31);g.pose().scale(scale,scale);
        var label=Ui.heading(rank);Ui.animated(g,font,label,-font.width(label)/2f,0,premium?0xFFFFD16B:0xFFAAAAAA);g.pose().popMatrix();
        if(premium){double time=AstraConfig.animations && !PerformanceMode.enabled()?System.nanoTime()/1e9:0;for(int i=0;i<3;i++){
            int px=x-6+i*19,py=y+29+(i%2)*8;int color=Ui.alpha(0xFFFFDA79,.45f+.55f*(float)(.5+.5*Math.sin(time*2+i*2)));
            Ui.round(g,px-1,py-2,2,5,1,color);Ui.round(g,px-2,py-1,5,2,1,color);
        }}
    }
}
