package client.astra.mixin;
import client.astra.*;
import net.minecraft.client.Minecraft;
import net.minecraft.client.multiplayer.MultiPlayerGameMode;
import net.minecraft.core.BlockPos;
import net.minecraft.world.entity.*;
import net.minecraft.world.entity.player.Player;
import net.minecraft.world.level.block.state.BlockState;
import org.spongepowered.asm.mixin.*;
import org.spongepowered.asm.mixin.injection.*;
import org.spongepowered.asm.mixin.injection.callback.*;
@Mixin(MultiPlayerGameMode.class)
public abstract class CharacterVoiceActionMixin {
    @Unique private BlockState astra$broken;
    @Inject(method="destroyBlock",at=@At("HEAD"))
    private void astra$beforeBreak(BlockPos pos,CallbackInfoReturnable<Boolean> ci){var mc=Minecraft.getInstance();astra$broken=mc.level==null?null:mc.level.getBlockState(pos);}
    @Inject(method="destroyBlock",at=@At("RETURN"))
    private void astra$afterBreak(BlockPos pos,CallbackInfoReturnable<Boolean> ci){if(ci.getReturnValueZ() && astra$broken!=null)CharacterVoices.broken(astra$broken);astra$broken=null;}
    @Inject(method="attack",at=@At("RETURN"))
    private void astra$attack(Player player,Entity target,CallbackInfo ci){if(player==Minecraft.getInstance().player && target instanceof LivingEntity living)CharacterVoices.attacked(living);}
}
