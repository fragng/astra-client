package client.astra.mixin;

import client.astra.PvpSettings;
import net.minecraft.client.renderer.ScreenEffectRenderer;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.*;

@Mixin(ScreenEffectRenderer.class)
public abstract class LowFireMixin {
    @ModifyArg(method="renderFire",at=@At(value="INVOKE",target="Lcom/mojang/blaze3d/vertex/PoseStack;translate(FFF)V"),index=1)
    private static float astra$lowerFire(float y){return PvpSettings.Feature.LOW_FIRE.enabled()?y-.38f:y;}
}
