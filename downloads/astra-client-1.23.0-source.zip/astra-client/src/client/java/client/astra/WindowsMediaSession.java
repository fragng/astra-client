package client.astra;

import com.sun.jna.*;
import com.sun.jna.platform.win32.Guid;
import com.sun.jna.ptr.*;
import com.sun.jna.win32.StdCallLibrary;
import java.nio.charset.StandardCharsets;
import java.util.Locale;

/** Windows.Media.Control via the documented WinRT ABI, on one COM worker thread.
 * No child processes, scripts, downloaded native binaries or account credentials.
 * Interface layout follows Microsoft's Windows SDK Windows.Media.Control metadata.
 */
final class WindowsMediaSession implements AutoCloseable {
    interface RuntimeApi extends StdCallLibrary {
        int RoInitialize(int type);
        void RoUninitialize();
        int WindowsCreateString(WString text,int length,PointerByReference value);
        int WindowsDeleteString(Pointer value);
        Pointer WindowsGetStringRawBuffer(Pointer value,IntByReference length);
        int RoGetActivationFactory(Pointer name,Guid.GUID iid,PointerByReference result);
    }
    private static final class NativeRuntime {static final RuntimeApi API=Native.load("combase",RuntimeApi.class);}
    private static final String MANAGER="Windows.Media.Control.GlobalSystemMediaTransportControlsSessionManager";
    private static final String MANAGER_STATICS="2050C4EE-11A0-57DE-AED7-C97C70338245";
    private static final String ASYNC_INFO="00000036-0000-0000-C000-000000000046";
    private final RuntimeApi api;
    private final Thread owner=Thread.currentThread();
    private Com manager;
    private boolean initialized,closed;

    WindowsMediaSession(){this(NativeRuntime.API);}
    // Package-private runtime seam permits real COM-vtable tests without loading Windows DLLs.
    WindowsMediaSession(RuntimeApi api){
        this.api=api;
        check(api.RoInitialize(1),"Initialize Windows media");initialized=true;
        try {
            Pointer name=string(MANAGER);
            try {
                var out=new PointerByReference();var iid=new Guid.GUID(MANAGER_STATICS);iid.write();
                check(api.RoGetActivationFactory(name,iid,out),"Get Windows media manager");
                try(var factory=new Com(out.getValue());var operation=factory.reference(6)){
                    manager=awaitReference(operation);
                }
            } finally {api.WindowsDeleteString(name);}
        } catch(RuntimeException e){close();throw e;}
    }
    private void thread(){if(Thread.currentThread()!=owner || closed)throw new IllegalStateException("Windows media session is not available on this thread");}
    private Pointer string(String text){var out=new PointerByReference();check(api.WindowsCreateString(new WString(text),text.length(),out),"Create Windows string");return out.getValue();}
    private String text(Pointer hstring){
        if(hstring==null)return "";
        try {
            var length=new IntByReference();Pointer raw=api.WindowsGetStringRawBuffer(hstring,length);int n=length.getValue();
            if(n<0 || n>1_048_576 || raw==null && n!=0)throw new IllegalStateException("Invalid Windows media string");
            return n==0?"":new String(raw.getByteArray(0,Math.min(n,512)*2),StandardCharsets.UTF_16LE).replaceAll("[\\p{Cntrl}]"," ").strip();
        }finally{api.WindowsDeleteString(hstring);}
    }
    static void check(int result,String operation){if(result<0)throw new IllegalStateException(operation+" (Windows error 0x"+Integer.toHexString(result)+")");}
    private final class Com implements AutoCloseable {
        private Pointer self;
        Com(Pointer self){if(self==null)throw new IllegalStateException("Windows returned an empty media interface");this.self=self;}
        int invoke(int slot,Object... args){
            if(self==null)throw new IllegalStateException("Windows media interface is closed");
            Pointer function=self.getPointer(0).getPointer((long)slot*Native.POINTER_SIZE);
            Object[] full=new Object[args.length+1];full[0]=self;System.arraycopy(args,0,full,1,args.length);
            return Function.getFunction(function,Platform.isWindows()?Function.ALT_CONVENTION:Function.C_CONVENTION).invokeInt(full);
        }
        void call(int slot,Object... args){check(invoke(slot,args),"Read Windows media");}
        Com reference(int slot,Object... args){
            var out=new PointerByReference();Object[] all=new Object[args.length+1];System.arraycopy(args,0,all,0,args.length);all[args.length]=out;
            call(slot,all);return new Com(out.getValue());
        }
        String stringAt(int slot){var out=new PointerByReference();call(slot,out);return text(out.getValue());}
        int integer(int slot){var out=new IntByReference();call(slot,out);return out.getValue();}
        long ticks(int slot){var out=new LongByReference();call(slot,out);return out.getValue();}
        boolean bool(int slot){var out=new ByteByReference();call(slot,out);return out.getValue()!=0;}
        Com query(String id){var iid=new Guid.GUID(id);iid.write();var out=new PointerByReference();call(0,iid.getPointer(),out);return new Com(out.getValue());}
        @Override public void close(){if(self!=null){invoke(2);self=null;}}
    }
    private Com awaitReference(Com operation){
        var out=new PointerByReference();await(operation,out);return new Com(out.getValue());
    }
    private boolean awaitBoolean(Com operation){var out=new ByteByReference();await(operation,out);return out.getValue()!=0;}
    private void await(Com operation,Object result){
        try(var info=operation.query(ASYNC_INFO)){
            long end=System.nanoTime()+2_500_000_000L;
            try {
                while(true){
                    int status=info.integer(7);
                    if(status==1){operation.call(8,result);return;}
                    if(status==3){check(info.integer(8),"Windows media request failed");throw new IllegalStateException("Windows media request failed");}
                    if(status==2)throw new IllegalStateException("Windows media request was cancelled");
                    if(System.nanoTime()>=end || Thread.currentThread().isInterrupted()){
                        info.invoke(9);throw new IllegalStateException("Windows media request timed out");
                    }
                    try{Thread.sleep(20);}catch(InterruptedException e){Thread.currentThread().interrupt();info.invoke(9);throw new IllegalStateException("Windows media request interrupted",e);}
                }
            }finally{info.invoke(10);}
        }
    }
    private Com spotify(){
        try(var sessions=manager.reference(7)){
            int count=sessions.integer(7);
            if(count<0 || count>256)throw new IllegalStateException("Invalid Windows media session count");
            for(int i=0;i<count;i++){
                Com session=sessions.reference(6,i);boolean keep=false;
                try{keep=session.stringAt(6).toLowerCase(Locale.ROOT).contains("spotify");if(keep)return session;}
                finally{if(!keep)session.close();}
            }
        }
        return null;
    }
    SpotifyBridge.State poll(){
        thread();
        try(var session=spotify()){
            if(session==null)return SpotifyBridge.empty("Open the Spotify desktop app and play a song.");
            try(var operation=session.reference(7);var media=awaitReference(operation);var playback=session.reference(9);var controls=playback.reference(6)){
                String title=media.stringAt(6),artist=media.stringAt(9),album=media.stringAt(10);
                int playbackStatus=playback.integer(7);boolean playing=playbackStatus==4;
                double position=0,duration=0;
                try(var timeline=session.reference(8)){
                    long start=timeline.ticks(6),end=timeline.ticks(7),max=timeline.ticks(9),at=timeline.ticks(10),updated=timeline.ticks(11);
                    position=Math.max(0,((double)at-start)/10_000_000);
                    duration=Math.max(0,((double)(end>start?end:max)-start)/10_000_000);
                    if(playing){double advance=(System.currentTimeMillis()+11_644_473_600_000L)/1000.0-updated/10_000_000.0;if(advance>=0 && advance<=604800)position+=advance;}
                    duration=Math.min(duration,604800);position=Math.clamp(position,0,duration>0?duration:604800);
                }catch(RuntimeException ignored){/* Missing timeline must not hide valid metadata. */}
                return new SpotifyBridge.State(true,title,artist,playing?"Playing":playbackStatus==5?"Paused":"Ready",playing,controls.bool(16),controls.bool(12),controls.bool(13),album,position,duration,System.nanoTime(),"");
            }
        }
    }
    boolean command(String action){
        thread();int slot=switch(action){case "toggle"->20;case "next"->16;case "previous"->17;default->throw new IllegalArgumentException("Unsupported media command");};
        try(var session=spotify()){
            if(session==null)return false;
            try(var operation=session.reference(slot)){return awaitBoolean(operation);}
        }
    }
    @Override public void close(){
        if(closed)return;
        if(Thread.currentThread()!=owner)throw new IllegalStateException("Close Windows media on its worker thread");
        try{if(manager!=null){manager.close();manager=null;}}
        finally{if(initialized){api.RoUninitialize();initialized=false;}closed=true;}
    }
}
