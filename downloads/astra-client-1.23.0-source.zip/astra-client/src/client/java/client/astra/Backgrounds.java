package client.astra;

import net.minecraft.client.Minecraft;
import net.minecraft.client.gui.GuiGraphics;
import net.minecraft.resources.Identifier;

/** Shared six-theme travel for the title screen and the rounded in-game client menu. */
public final class Backgrounds {
    private static final Theme[] THEMES=Theme.values();
    private static final SceneTransition SCENE=new SceneTransition(THEMES.length);
    private static final Identifier MENU_ASTRA=Identifier.fromNamespaceAndPath(AstraClient.MOD_ID,"textures/background/menu-astra.png");
    private Backgrounds(){}
    public static void preload(){
        var textures=Minecraft.getInstance().getTextureManager();
        for(var theme:THEMES)if(theme!=Theme.NORMAL)textures.getTexture(theme.texture);
        textures.getTexture(MENU_ASTRA);
    }
    public static void prepare(){SCENE.frame(AstraConfig.theme().ordinal(),System.nanoTime()/1e9,AstraConfig.animations && !PerformanceMode.enabled());}
    public static boolean needsPanorama(){return SCENE.weight(Theme.NORMAL.ordinal())>1e-9;}
    public static void draw(GuiGraphics g,int width,int height){drawLayers(g,width,height,false);}
    public static void drawMenu(GuiGraphics g,int width,int height){
        prepare();Ui.gradient(g,0,0,width,height,18,0xFF161C32,0xFF0C1425);g.nextStratum();drawLayers(g,width,height,true);
    }
    private static void drawLayers(GuiGraphics g,int w,int h,boolean rounded){
        double accumulated=SCENE.weight(Theme.NORMAL.ordinal());
        double time=AstraConfig.animations && !PerformanceMode.enabled()?System.nanoTime()/1e9:0;
        for(var theme:THEMES){
            if(theme==Theme.NORMAL)continue;
            double weight=SCENE.weight(theme.ordinal());if(weight<1e-9)continue;
            // Source-over alpha normalized to total coverage gives an exact weighted blend.
            float opacity=(float)(weight/(accumulated+weight));accumulated+=weight;
            var texture=rounded && theme==Theme.ASTRA?MENU_ASTRA:theme.texture;
            drawLayer(g,texture,w,h,(float)SCENE.offset(theme.ordinal()),time,opacity,rounded);
            g.nextStratum();
        }
        float custom=(float)(1-SCENE.weight(Theme.NORMAL.ordinal()));
        if(rounded)Ui.round(g,0,0,w,h,18,Ui.alpha(0xFF0A1129,.14f*custom));
        else g.fill(0,0,w,h,Ui.alpha(0x38040815,custom));
        ReactiveBackdrop.draw(g,w,h);g.nextStratum();
    }
    private static void drawLayer(GuiGraphics g,Identifier texture,int w,int h,float offset,double time,float alpha,boolean rounded){
        var gpu=Minecraft.getInstance().getTextureManager().getTexture(texture).getTexture();
        int tw=gpu.getWidth(0),th=gpu.getHeight(0);float source=tw/(float)th,target=w/(float)h;
        float us=Math.min(1,target/source)*.82f,vs=Math.min(1,source/target)*.82f;
        float u=(1-us)/2-offset*us+(float)Math.sin(time*.035)*.008f;
        float v=(1-vs)/2+(float)Math.cos(time*.025)*.006f;
        u=Math.clamp(u,0,1-us);v=Math.clamp(v,0,1-vs);
        float old=Ui.pushOpacity(alpha);
        try{
            if(!rounded){Ui.texture(g,texture,0,0,w,h,u,u+us,v,v+vs,tw,th);return;}
            int radius=Math.min(18,h/2);
            for(int row=0;row<radius;row++){
                int pad=Ui.inset(row,h,radius);
                Ui.texture(g,texture,pad,row,w-pad*2,1,u+us*pad/w,u+us*(w-pad)/w,v+vs*row/h,v+vs*(row+1)/h,tw,th);
                int yy=h-row-1;Ui.texture(g,texture,pad,yy,w-pad*2,1,u+us*pad/w,u+us*(w-pad)/w,v+vs*yy/h,v+vs*(yy+1)/h,tw,th);
            }
            Ui.texture(g,texture,0,radius,w,h-radius*2,u,u+us,v+vs*radius/h,v+vs*(h-radius)/h,tw,th);
        }finally{Ui.restoreOpacity(old);}
    }
}
