package client.astra;

import net.minecraft.client.gui.GuiGraphics;
import net.minecraft.client.renderer.RenderPipelines;
import net.minecraft.resources.Identifier;

/** Replaces shared vanilla UI chrome while leaving item and functional icon artwork intact. */
public final class RoundedSprites {
    private static final Identifier TOOLTIP=Identifier.fromNamespaceAndPath("astra-client","widget/tooltip_panel");
    private static final Identifier SLOT_HIGHLIGHT=Identifier.fromNamespaceAndPath("astra-client","widget/slot_highlight");
    private RoundedSprites() {}
    public static boolean draw(GuiGraphics g, Identifier sprite, int x, int y, int w, int h, int tint) {
        if (!sprite.getNamespace().equals("minecraft")) return false;
        String path = sprite.getPath();
        float a = (tint >>> 24) / 255f;
        boolean highlighted = path.contains("highlighted") || (path.contains("selected") && !path.contains("unselected"));
        if (path.startsWith("widget/button") || path.startsWith("widget/slider") || path.startsWith("widget/text_field")
            || path.startsWith("container/creative_inventory/tab_") || path.startsWith("recipe_book/tab") || path.startsWith("widget/tab") || path.startsWith("container/beacon/button") || path.startsWith("recipe_book/button")) {
            Ui.control(g, x, y, w, h, highlighted, path.contains("disabled"), a);
            return true;
        }
        if (path.startsWith("widget/checkbox")) {
            Ui.control(g, x, y, w, h, highlighted, false, a);
            if (path.contains("selected")) {
                for (int i = 0; i < 4; i++) g.fill(x + 4 + i, y + h / 2 + i, x + 6 + i, y + h / 2 + i + 2, Ui.alpha(0xFFF2ECFF, a));
                for (int i = 0; i < 7; i++) g.fill(x + 7 + i, y + h / 2 + 3 - i, x + 9 + i, y + h / 2 + 5 - i, Ui.alpha(0xFFF2ECFF, a));
            }
            return true;
        }
        if (path.contains("scroller")) {
            Ui.round(g, x, y, w, h, Math.min(4, w / 2), Ui.alpha(path.endsWith("background") ? 0xA0151B2D : path.contains("disabled") ? 0xFF424B60 : 0xFF9C9BC7, a));
            return true;
        }
        if (path.equals("tooltip/background")) {
            // A stretched nine-slice preserves rounded corners without per-row shapes.
            g.blitSprite(RenderPipelines.GUI_TEXTURED,TOOLTIP,x,y,w,h,Ui.alpha(0xFFFFFFFF,a));
            return true;
        }
        if (path.equals("tooltip/frame")) return true;
        if (path.contains("slot_highlight")) {
            if (!path.endsWith("front")) g.blitSprite(RenderPipelines.GUI_TEXTURED,SLOT_HIGHLIGHT,x,y,w,h,Ui.alpha(0xFFFFFFFF,a));
            return true;
        }
        if (path.equals("hud/hotbar") || path.equals("hud/hotbar_selection")) {
            Ui.control(g, x, y, w, h, path.endsWith("selection"), false, a);
            if (path.equals("hud/hotbar")) {
                for (int i = 1; i < 9; i++) g.fill(x + 1 + i * 20, y + 4, x + 2 + i * 20, y + h - 4, Ui.alpha(0x775D6685, a));
            }
            return true;
        }
        return false;
    }
}
