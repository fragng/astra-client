package client.astra;

/** Shared geometry keeps the top stack and bottom payout panel apart at every supported GUI size. */
public record JambleLayout(float roleScale,float musicScale,int roleWidth,int roleHeight,int hostX,int viewerX,
                          int paymentY,int resultY,int payoutY,int payoutWidth) {
    public static final int ROLE_W=104,ROLE_H=78,PAYMENT_H=18,RESULT_H=22,PAYOUT_H=30;
    public static JambleLayout compute(int width,int height,boolean mode,boolean music,boolean lyrics,double requestedScale){
        float base=Math.min((float)requestedScale,(width-16f)/320);
        float musicHeight=(lyrics?130:70)*base;
        float scale=mode?Math.clamp(Math.min(1,Math.min((width-48f)/(ROLE_W*2+(music?320*base:0)),(height-157f)/Math.max(ROLE_H,music?musicHeight:0))),.25f,1):1;
        float musicScale=base*scale;int rw=Math.round(ROLE_W*scale),rh=Math.round(ROLE_H*scale),mw=music?Math.round(320*musicScale):0;
        int host=music?Math.round((width-mw)/2f)-rw-12:width/2-rw-6;
        int viewer=music?Math.round((width+mw)/2f)+12:width/2+6;
        int bottom=Math.max(10+rh,music?12+(int)Math.ceil((lyrics?130:70)*musicScale):0);
        return new JambleLayout(scale,musicScale,rw,rh,host,viewer,bottom+6,bottom+32,height-83,Math.min(280,width-16));
    }
}
