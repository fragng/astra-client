package client.astra;

import java.math.BigDecimal;
import java.math.RoundingMode;
import java.util.Locale;
import java.util.regex.Pattern;

/** Exact cents throughout; suffixes never pass through floating point. */
public final class JambleMoney {
    public static final long MAX_CENTS=Long.MAX_VALUE/2;
    public static final long DEFAULT_MIN=100_000L,DEFAULT_MAX=100_000_000_000L;
    private static final Pattern AMOUNT=Pattern.compile("\\$?((?:[0-9]+|[0-9]{1,3}(?:,[0-9]{3})+)(?:\\.[0-9]+)?)[ ]*([kmb]?)",Pattern.CASE_INSENSITIVE);
    private static final Pattern NOTICE=Pattern.compile("^([A-Za-z0-9_]{3,16})[ ]+paid[ ]+you[ ]+(.+?)[.!]?$",Pattern.CASE_INSENSITIVE);
    public record Payment(String username,long cents){}
    private JambleMoney(){}
    public static long parse(String input){
        if(input==null || input.length()>32)throw new IllegalArgumentException("Enter an amount such as 1K, 2.5M or 1B.");
        var match=AMOUNT.matcher(input.strip());if(!match.matches())throw new IllegalArgumentException("Use numbers with optional K, M or B.");
        try{
            int power=switch(match.group(2).toUpperCase(Locale.ROOT)){case "K"->3;case "M"->6;case "B"->9;default->0;};
            long cents=new BigDecimal(match.group(1).replace(",","")).movePointRight(power+2).longValueExact();
            if(cents<0 || cents>MAX_CENTS)throw new ArithmeticException();return cents;
        }catch(ArithmeticException e){throw new IllegalArgumentException("Amount is too large or has fractions of a cent.");}
    }
    public static boolean validRange(long min,long max){return min>=0 && min<=max && max>0 && max<=MAX_CENTS;}
    public static Payment notice(String text){
        if(text==null || text.length()>128)return null;
        var match=NOTICE.matcher(text.replaceAll("(?i)§[0-9A-FK-ORX]","").strip());if(!match.matches())return null;
        try{long cents=parse(match.group(2));return cents>0?new Payment(match.group(1),cents):null;}catch(IllegalArgumentException e){return null;}
    }
    public static boolean donutHost(String host){
        if(host==null)return false;String value=host.toLowerCase(Locale.ROOT);
        if(value.endsWith("."))value=value.substring(0,value.length()-1);
        return value.equals("donutsmp.net") || value.endsWith(".donutsmp.net");
    }
    public static String exact(long cents){return "$"+String.format(Locale.ROOT,cents%100==0?"%,.0f":"%,.2f",BigDecimal.valueOf(cents,2));}
    public static String compact(long cents){return display(cents,true);}
    public static String editable(long cents){return display(cents,false);}
    private static String display(long cents,boolean round){
        var value=BigDecimal.valueOf(cents,2);int power=cents>=100_000_000_000L?9:cents>=100_000_000L?6:cents>=100_000L?3:0;
        value=value.movePointLeft(power);if(round)value=value.setScale(2,RoundingMode.HALF_UP);
        return value.stripTrailingZeros().toPlainString()+switch(power){case 9->"B";case 6->"M";case 3->"K";default->"";};
    }
}
