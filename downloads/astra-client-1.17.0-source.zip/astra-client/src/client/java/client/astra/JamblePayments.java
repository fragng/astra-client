package client.astra;

import com.mojang.brigadier.arguments.StringArgumentType;
import net.fabricmc.fabric.api.client.command.v2.ClientCommandManager;
import net.fabricmc.fabric.api.client.command.v2.ClientCommandRegistrationCallback;
import net.fabricmc.fabric.api.client.message.v1.ClientReceiveMessageEvents;
import net.minecraft.client.Minecraft;
import net.minecraft.client.gui.Font;
import net.minecraft.client.gui.GuiGraphics;
import net.minecraft.client.gui.screens.ChatScreen;
import net.minecraft.client.multiplayer.resolver.ServerAddress;
import net.minecraft.network.chat.*;
import java.util.UUID;

/** DonutSMP server notices and local payout bookkeeping. No outgoing payment/chat packets. */
public final class JamblePayments {
    private static final JamblePaymentLedger LEDGER=new JamblePaymentLedger();
    private static Object connection;
    private static String paymentLabel="Jamble  Waiting for a payment",payoutLabel="Waiting for a confirmed viewer win",header="";
    private static long shownMin=-1,shownMax=-1;
    private JamblePayments(){}
    private static boolean authorized(){return PremiumEdition.premium() && AstraConfig.jambleEnabled;}
    public static boolean enabled(){var mc=Minecraft.getInstance();return authorized() && mc.player!=null && mc.level!=null;}
    public static void initialize(){
        ClientReceiveMessageEvents.MODIFY_GAME.register((message,overlay)->{
            if(overlay)return message;
            var server=Minecraft.getInstance().getCurrentServer();
            String host=server==null?"":ServerAddress.parseString(server.ip).getHost();
            return receive(message,host);
        });
        ClientCommandRegistrationCallback.EVENT.register((dispatcher,access)->dispatcher.register(
            ClientCommandManager.literal("astrajamble").then(ClientCommandManager.literal("win")
                .then(ClientCommandManager.argument("payment",StringArgumentType.word()).executes(context->{
                    JamblePaymentLedger.Payout payout=confirm(StringArgumentType.getString(context,"payment"));
                    if(payout==null){context.getSource().sendError(Component.literal("Jamble: this payment has no unconfirmed viewer win in this session."));return 0;}
                    context.getSource().sendFeedback(Component.literal("Jamble payout recorded: "+payout.username()+" won "+JambleMoney.exact(payout.cents())+" (2x).").withStyle(style->style.withColor(0xA9E8C0)));return 1;
                })))));
    }
    private static boolean sync(){
        var next=Minecraft.getInstance().getConnection();
        if(!authorized() || next==null){if(connection!=null || LEDGER.size()>0 || LEDGER.payout()!=null)clear();return false;}
        if(connection!=next){clear();connection=next;}return true;
    }
    public static void tick(Minecraft client){sync();}
    public static void clear(){connection=null;LEDGER.clear();refresh();}
    /** The hook supplies the actual connected host; exposed for isolated production-client tests. */
    public static Component receive(Component message,String host){
        if(!sync() || !JambleMoney.donutHost(host))return message;
        var paid=JambleMoney.notice(message.getString());if(paid==null)return message;
        var entry=LEDGER.receive(paid,AstraConfig.jambleMinPay,AstraConfig.jambleMaxPay);
        if(entry==null){
            if(paid.cents()>=AstraConfig.jambleMinPay && paid.cents()<=AstraConfig.jambleMaxPay)
                return message.copy().append(Component.literal(" [Jamble queue full]").withStyle(style->style.withColor(0xE1AF79)));
            return message;
        }
        refresh();return message.copy().append(Component.literal(" ")).append(winButton(entry));
    }
    private static Component winButton(JamblePaymentLedger.Entry entry){
        return Component.literal("[Viewer won]").withStyle(style->style.withColor(0xBCA2F5).withUnderlined(true)
            .withClickEvent(new ClickEvent.RunCommand("/astrajamble win "+entry.id()))
            .withHoverEvent(new HoverEvent.ShowText(Component.literal("Record "+entry.username()+" winning "+JambleMoney.exact(entry.payout())+" after their viewer-winning roll. Local record only; no transfer."))));
    }
    public static void onRound(JambleHud.Round round){
        if(!sync())return;var entry=LEDGER.resolve(round.sequence(),round.winner());refresh();
        if(entry!=null && entry.status()==JamblePaymentLedger.Status.VIEWER_WIN)
            Minecraft.getInstance().gui.getChat().addMessage(Component.literal("Jamble: "+entry.username()+" won their roll. ").append(winButton(entry)));
    }
    public static JamblePaymentLedger.Payout confirm(String value){
        if(!sync())return null;
        try{var payout=LEDGER.confirm(UUID.fromString(value));refresh();return payout;}catch(IllegalArgumentException e){return null;}
    }
    public static JamblePaymentLedger ledger(){return LEDGER;}
    private static void refresh(){
        var current=LEDGER.current();int pending=LEDGER.pending();
        paymentLabel=current==null?"Jamble  Waiting for a payment":current.username()+"  Jamble "+current.amount()+(pending>1?"  +"+(pending-1):"");
        payoutLabel=LEDGER.payout()==null?"Waiting for a confirmed viewer win":LEDGER.payout().label();
    }
    public static JambleLayout layout(int width,int height){return JambleLayout.compute(width,height,enabled(),AstraConfig.hudSpotify,AstraConfig.lyricsEnabled,AstraConfig.spotifyHudScale);}
    public static JambleLayout layout(int width){return layout(width,Minecraft.getInstance().getWindow().getGuiScaledHeight());}
    private static void line(GuiGraphics g,Font font,String text,int centre,int y,int room,float maxScale,int color){
        float scale=Math.min(maxScale,room/(float)Math.max(1,font.width(Ui.text(text))));
        g.pose().pushMatrix();g.pose().translate(centre,y);g.pose().scale(scale,scale);Ui.animated(g,font,text,-font.width(Ui.text(text))/2f,0,color);g.pose().popMatrix();
    }
    public static void draw(GuiGraphics g,Font font){
        var mc=Minecraft.getInstance();if(!enabled() || mc.options.hideGui || mc.getDebugOverlay().showDebugScreen() || mc.screen!=null && !(mc.screen instanceof ChatScreen))return;
        var box=layout(g.guiWidth(),g.guiHeight());int pw=Math.min(244,g.guiWidth()-16),px=(g.guiWidth()-pw)/2;
        Ui.round(g,px,box.paymentY(),pw,JambleLayout.PAYMENT_H,7,0xD51D172D);
        line(g,font,paymentLabel,g.guiWidth()/2,box.paymentY()+5,pw-14,.85f,0xFFE7D9F9);
        if(shownMin!=AstraConfig.jambleMinPay || shownMax!=AstraConfig.jambleMaxPay){shownMin=AstraConfig.jambleMinPay;shownMax=AstraConfig.jambleMaxPay;header="Jamble  Min "+JambleMoney.compact(shownMin)+" / Max "+JambleMoney.compact(shownMax);}
        int x=(g.guiWidth()-box.payoutWidth())/2,y=box.payoutY(),w=box.payoutWidth();
        Ui.round(g,x-1,y-1,w+2,JambleLayout.PAYOUT_H+2,10,0xAA9874C2);Ui.gradient(g,x,y,w,JambleLayout.PAYOUT_H,9,0xEA302541,0xEA151929);
        line(g,font,header,g.guiWidth()/2,y+4,w-16,.7f,0xFFB3A6CB);
        line(g,font,payoutLabel,g.guiWidth()/2,y+16,w-16,.85f,LEDGER.payout()==null?0xFFB9B2C5:0xFFFFDEA4);
    }
}
