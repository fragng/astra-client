package client.astra;

import java.util.*;

/** Session-local bookkeeping. Entries and roll associations can be confirmed only once. */
public final class JamblePaymentLedger {
    public enum Status {WAITING,VIEWER_WIN,HOST_WIN,CONFIRMED}
    public static final int MAX_ENTRIES=256;
    public static final class Entry {
        private final UUID id=UUID.randomUUID();
        private final String username,amount;
        private final long cents;
        private Status status=Status.WAITING;
        private long round;
        Entry(JambleMoney.Payment paid){username=paid.username();cents=paid.cents();amount=JambleMoney.compact(cents);}
        public UUID id(){return id;}
        public String username(){return username;}
        public long cents(){return cents;}
        public String amount(){return amount;}
        public Status status(){return status;}
        public long round(){return round;}
        public long payout(){return cents*2;}
    }
    public record Payout(String username,long cents,String label){}
    private final LinkedHashMap<UUID,Entry> entries=new LinkedHashMap<>();
    private long lastRound,confirmed;
    private Payout payout;
    public Entry receive(JambleMoney.Payment paid,long min,long max){
        if(paid==null || !JambleMoney.validRange(min,max) || paid.cents()<min || paid.cents()>max || paid.cents()<=0 || paid.cents()>JambleMoney.MAX_CENTS)return null;
        while(entries.size()>=MAX_ENTRIES){
            var iterator=entries.values().iterator();boolean removed=false;
            while(iterator.hasNext()){var next=iterator.next();if(next.status==Status.HOST_WIN || next.status==Status.CONFIRMED){iterator.remove();removed=true;break;}}
            if(!removed)return null;
        }
        var entry=new Entry(paid);entries.put(entry.id,entry);return entry;
    }
    public Entry resolve(long sequence,JambleRules.Side winner){
        if(sequence<=lastRound || winner==null)return null;lastRound=sequence;
        for(var entry:entries.values())if(entry.status==Status.WAITING){entry.round=sequence;entry.status=winner==JambleRules.Side.VIEWER?Status.VIEWER_WIN:Status.HOST_WIN;return entry;}
        return null;
    }
    public Payout confirm(UUID id){
        var entry=entries.get(id);if(entry==null || entry.status!=Status.VIEWER_WIN)return null;
        entry.status=Status.CONFIRMED;confirmed++;
        return payout=new Payout(entry.username,entry.payout(),entry.username+"  Won "+JambleMoney.compact(entry.payout()));
    }
    public Entry current(){
        for(var e:entries.values())if(e.status==Status.WAITING)return e;
        for(var e:entries.values())if(e.status==Status.VIEWER_WIN)return e;return null;
    }
    public Entry get(UUID id){return entries.get(id);}
    public int pending(){int count=0;for(var e:entries.values())if(e.status==Status.WAITING || e.status==Status.VIEWER_WIN)count++;return count;}
    public int size(){return entries.size();}
    public Payout payout(){return payout;}
    public long confirmed(){return confirmed;}
    public void clear(){entries.clear();payout=null;confirmed=0;lastRound=0;}
}
