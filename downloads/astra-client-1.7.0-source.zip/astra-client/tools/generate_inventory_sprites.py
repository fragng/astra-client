"""Author tiny antialiased GUI sprites used by Minecraft's cached GUI atlas.

Run with Python 3 and Pillow. This is a development asset generator, not a
Minecraft runtime dependency. Logical dimensions are independent of GUI scale.
"""
from pathlib import Path
import json
from PIL import Image, ImageDraw

ROOT = Path(__file__).resolve().parents[1] / 'src/main/resources/assets/astra-client/textures/gui/sprites/widget'
ROOT.mkdir(parents=True, exist_ok=True)
SAMPLE = 8


def rounded(draw, box, radius, color):
    # Half-open logical bounds, consistent with GuiGraphics.fill.
    x0, y0, x1, y1 = box
    draw.rounded_rectangle((x0*SAMPLE, y0*SAMPLE, x1*SAMPLE-1, y1*SAMPLE-1), radius=radius*SAMPLE, fill=color)


def save(name, size, background, layers, border=None):
    image = Image.new('RGBA', (size*SAMPLE, size*SAMPLE), background)
    draw = ImageDraw.Draw(image)
    for box, radius, color in layers:
        rounded(draw, box, radius, color)
    # Keep two source pixels per logical GUI pixel for smooth corners.
    image = image.resize((size*2, size*2), Image.Resampling.LANCZOS)
    path = ROOT / (name + '.png')
    image.save(path, optimize=True)
    if border is not None:
        path.with_suffix('.png.mcmeta').write_text(json.dumps({'gui': {'scaling': {
            'type': 'nine_slice', 'width': size, 'height': size,
            'border': border, 'stretch_inner': True,
        }}}, indent=2) + '\n')


save('inventory_slot', 18, '#C6C6C6', [
    ((0, 0, 18, 18), 4, '#5C6073'),
    ((1, 1, 17, 17), 3, '#9093A1'),
])
save('slot_highlight', 18, (0, 0, 0, 0), [
    ((0, 0, 18, 18), 4, (224, 211, 255, 85)),
], border=4)
save('tooltip_panel', 16, (0, 0, 0, 0), [
    ((0, 0, 16, 16), 7, '#8C79B7'),
    # Previous UI composited a 245-alpha inner fill over the opaque purple
    # border. Bake that resulting opaque colour so items cannot show through.
    ((1, 1, 15, 15), 6, (21, 24, 42, 255)),
], border=7)
