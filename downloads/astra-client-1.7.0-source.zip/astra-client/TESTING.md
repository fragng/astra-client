# Astra Client 1.7.0 validation

- Built with Java 21 for Minecraft 1.21.11 / Fabric Loader 0.19.3.
- Removed the standalone Music category, its music-volume and mute controls, and the unused restoreMusic preference. Native Minecraft sound settings are untouched.
- Opened the real Minecraft client with a separate development-only chest fixture containing 54 named items and multiline lore (90 rendered slots including player inventory).
- Measured the same chest before/after the rendering change, hovering one item and sweeping across all 54 items. The test fixture counted GuiRenderState.submitGuiElement submissions per frame; these are GUI elements, not GPU draw calls or a universal FPS measurement.

| Scenario | Before elements/frame | After elements/frame |
| --- | ---: | ---: |
| Pointer outside slots | 8651 | 868 |
| Hover one item | 8810 | 881 |
| Sweep across items | 8810 | 881 |

The hover scenario submitted 90% fewer GUI elements. This is a diagnostic measurement from a software-rendered Linux development environment, not a hardware FPS guarantee. Item/tooltip content, styles and rounded corners were visually compared.

- Checked cached sprites after F3+T resource reload. No missing sprites or metadata errors appeared, and the tooltip remained opaque over items.
- Navigated all seven remaining categories, including Spotify HUD and General. Verified the existing Spotify HUD theme preference remains saved.
- The atlas sprites use fixed/stretch and stretched-nine-slice scaling; stretch_inner is explicitly enabled to avoid tiling the small panel centre into many quads.
- The optional Python/Pillow asset generator is included; Pillow is not a Minecraft runtime dependency.

The chest fixture and performance instrumentation are outside the project and excluded from the jar/source archive. Spotify playback and lyric handling are unchanged; live Windows Spotify remains unverified from this Linux host.

## Menu transitions and reactive scene (1.7.0)

- Built on Java 21 and exercised the title screen and a real singleplayer world with Mod Menu installed, without a media/performance fixture.
- Verified the title Reactive Background toggle saves and causes visible scene/background movement; the world-menu toggle reads the same saved preference.
- Checked the exact requested description and controls fit below Menu Background on Visuals.
- Exercised all seven categories, Spotify customisation, FOV input and the shared reactive toggle after page transitions.
- Checked open/close paths through Right Shift, Escape and X. Captured transition frames and rapid category retargeting; verified the final page remains usable.
- Disabled Smooth animations and compared static Astra background captures: no movement. Closing/reopening and category changes are immediate with the preference Off.
- Menu tween tests covered elapsed time, smooth midpoint, reversals, settling without overshoot, reduced motion, frame-rate independence and a long frame spanning the page-swap boundary.
- Rechecked rapid page retargeting after the long-frame fix by toggling a control on the final HUD page; it remained interactive.
- Checked Normal title mode with the optional reactive overlay and a 640×480 title window. Main controls and the new panel no longer overlap, and the compact title toggle saves correctly.

Inventory caching from 1.6.1 is preserved. Live Windows Spotify remains unverified; that bridge is unchanged in this release.
