package client.astra;

import net.minecraft.resources.Identifier;

public enum Theme {
    NORMAL("Normal", 0xFFABB9DB),
    GALAXY("Galaxy", 0xFFBA99FF),
    NEBULA("Nebula", 0xFFF0A3D4),
    ASTRA("Astra", 0xFFFFD18D);

    public final String label;
    public final int accent;
    public final Identifier texture;

    Theme(String label, int accent) {
        this.label = label;
        this.accent = accent;
        this.texture = Identifier.fromNamespaceAndPath(AstraClient.MOD_ID, "textures/background/" + name().toLowerCase(java.util.Locale.ROOT) + ".png");
    }
}
