package client.astra;

import com.mojang.blaze3d.vertex.PoseStack;
import net.fabricmc.fabric.api.client.rendering.v1.RenderStateDataKey;
import net.fabricmc.fabric.api.client.rendering.v1.world.WorldRenderEvents;
import net.minecraft.client.Minecraft;
import net.minecraft.client.gui.Font;
import net.minecraft.util.FormattedCharSequence;
import net.minecraft.world.effect.MobEffects;
import net.minecraft.world.level.material.FogType;
import org.joml.Quaternionf;
import org.joml.Vector3f;
import java.util.List;
import java.util.ArrayList;

/** Depth-tested text in world space above the horizon, independent of the Spotify HUD. */
public final class SkyLyrics {
    private record Line(FormattedCharSequence text,int width,float y,int color){}
    private record Frame(Vector3f anchor,Quaternionf rotation,List<Line> lines,float scale){}
    private static final RenderStateDataKey<Frame> KEY=RenderStateDataKey.create(()->"Astra sky lyrics");
    private static final LyricMotion MOTION=new LyricMotion();
    private static long last=System.nanoTime();
    private SkyLyrics(){}
    public static boolean enabled(){return PremiumEdition.premium() && AstraConfig.lyricsInSky;}
    public static void initialize(){
        WorldRenderEvents.END_EXTRACTION.register(context->{
            var mc=Minecraft.getInstance();var world=context.worldState();
            world.setData(KEY,null);
            long now=System.nanoTime();double dt=(now-last)/1e9;last=now;
            var media=SpotifyBridge.state();var lyrics=LyricsService.current();
            if(!enabled() || mc.player==null || mc.screen!=null || mc.options.hideGui || mc.getDebugOverlay().showDebugScreen()
                || mc.level.dimensionType().skybox()!=net.minecraft.world.level.dimension.DimensionType.Skybox.OVERWORLD
                || mc.player.hasEffect(MobEffects.BLINDNESS) || mc.player.hasEffect(MobEffects.DARKNESS)
                || mc.gameRenderer.getMainCamera().getFluidInCamera()!=FogType.NONE
                || !media.connected() || media.duration()<=0 || !lyrics.synced() || lyrics.lines().isEmpty()) {MOTION.reset();return;}
            int index=lyrics.index(media.elapsed());if(index<0){MOTION.reset();return;}
            double shown=MOTION.update(lyrics,index,dt,AstraConfig.animations);
            var lines=new ArrayList<Line>();int maxWidth=1;
            for(int i=java.lang.Math.max(0,(int)java.lang.Math.floor(shown));i<java.lang.Math.min(lyrics.lines().size(),(int)java.lang.Math.floor(shown)+2);i++){
                String raw=lyrics.lines().get(i).text();if(raw.isBlank())continue;
                if(raw.length()>120)raw=raw.substring(0,raw.offsetByCodePoints(0,java.lang.Math.min(100,raw.codePointCount(0,raw.length()))))+"...";
                var text=Ui.text(raw);int width=mc.font.width(text);maxWidth=java.lang.Math.max(maxWidth,width);
                float distance=(float)(i-shown),fade=java.lang.Math.clamp(1-java.lang.Math.abs(distance)*.65f,0,1);
                lines.add(new Line(text.getVisualOrderText(),width,distance*15,Ui.alpha(i==index?0xFFF1E3FF:0xFFAAA4D4,fade)));
            }
            if(lines.isEmpty())return;
            double yaw=java.lang.Math.toRadians(mc.gameRenderer.getMainCamera().yRot());
            Vector3f forward=new Vector3f(-(float)java.lang.Math.sin(yaw),0,(float)java.lang.Math.cos(yaw));
            var cam=world.cameraRenderState;
            world.setData(KEY,new Frame(forward.mul(96).add(0,64,0),new Quaternionf(cam.orientation),List.copyOf(lines),java.lang.Math.min(.45f,100f/maxWidth)));
        });
        WorldRenderEvents.BEFORE_ENTITIES.register(context->{
            Frame f=context.worldState().getData(KEY);if(f==null || !enabled())return;
            PoseStack pose=context.matrices();pose.pushPose();
            try{
                pose.translate(f.anchor.x,f.anchor.y,f.anchor.z);pose.mulPose(f.rotation);pose.scale(f.scale,-f.scale,f.scale);
                var font=Minecraft.getInstance().font;
                for(Line line:f.lines)font.drawInBatch(line.text,-line.width/2f,line.y,line.color,true,pose.last().pose(),context.consumers(),Font.DisplayMode.NORMAL,0,15728880);
            }finally{pose.popPose();}
        });
    }
}
