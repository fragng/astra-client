package client.astra.mixin;

import client.astra.CustomSkyRenderer;
import net.minecraft.client.renderer.SkyRenderer;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;

@Mixin(SkyRenderer.class)
public abstract class CustomSkyMixin {
    @Inject(method="renderSkyDisc",at=@At("TAIL"))
    private void astra$sky(int color,CallbackInfo ci){CustomSkyRenderer.draw();}
    @Inject(method="close",at=@At("TAIL"))
    private void astra$closeSky(CallbackInfo ci){CustomSkyRenderer.close();}
}
