package client.astra;

import net.minecraft.client.Minecraft;
import net.minecraft.client.gui.GuiGraphics;
import net.minecraft.client.gui.components.Button;
import net.minecraft.network.chat.Component;

/** Compact two-line label for the narrow title-screen background selector. */
public final class ReactiveToggleButton extends Button {
    public ReactiveToggleButton(int x,int y,int w,int h) {
        super(x,y,w,h,Ui.text("Reactive Background"),b->{AstraConfig.reactiveBackground=!AstraConfig.reactiveBackground;AstraConfig.changed();},DEFAULT_NARRATION);
    }
    @Override protected void renderContents(GuiGraphics g,int mx,int my,float delta) {
        int x=getX(),y=getY(),w=getWidth(),h=getHeight();float a=getAlpha();boolean on=AstraConfig.reactiveBackground;
        Ui.control(g,x,y,w,h,on||isHoveredOrFocused(),false,a);
        var font=Minecraft.getInstance().font;
        float s=Math.min(.85f,(w-35f)/Math.max(font.width(Ui.text("Background")),1));
        g.pose().pushMatrix();g.pose().translate(x+7,y+5);g.pose().scale(s,s);
        Ui.animated(g,font,"Reactive",0,0,Ui.alpha(0xFFF3EAFF,a));
        Ui.animated(g,font,"Background",0,12,Ui.alpha(0xFFF3EAFF,a));g.pose().popMatrix();
        int tx=x+w-26,ty=y+(h-13)/2;
        Ui.round(g,tx,ty,21,13,6,Ui.alpha(on?0xFFBD8AF0:0xFF66647B,a));
        Ui.round(g,tx+(on?10:2),ty+2,9,9,4,Ui.alpha(0xFFF8EEFF,a));
    }
    @Override protected net.minecraft.network.chat.MutableComponent createNarrationMessage() {
        return Component.literal("Reactive Background, "+(AstraConfig.reactiveBackground?"on":"off"));
    }
}
