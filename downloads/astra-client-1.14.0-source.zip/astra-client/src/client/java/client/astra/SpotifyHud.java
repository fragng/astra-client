package client.astra;

import net.minecraft.client.gui.Font;
import net.minecraft.client.gui.GuiGraphics;
import net.minecraft.client.renderer.RenderPipelines;

/** Compact text-only Spotify HUD. Themes and lyric motion use cached local state. */
public final class SpotifyHud {
    private static final int W=320,H=70;
    private static final LyricMotion LYRIC_MOTION=new LyricMotion();
    private static float visibility,layoutY=12;
    private static long lastFrame;
    private SpotifyHud() {}
    public static void tick() {if(!AstraConfig.hudSpotify || !AstraConfig.lyricsEnabled)LYRIC_MOTION.reset();}
    private static float hudScale(int width) {return Math.min((float)AstraConfig.spotifyHudScale,(width-16f)/W);}
    public static int watermarkY(int screenWidth,Font font) {
        int watermarkWidth=font.width(Ui.heading(AstraClient.NAME))+(AstraConfig.hudLogo?27:9)+10;
        float scale=hudScale(screenWidth);
        int y=JambleHud.watermarkY(screenWidth,watermarkWidth,8);
        if((screenWidth-W*scale)/2>=watermarkWidth+16 || !AstraConfig.hudSpotify)return y;
        return Math.max(y,Math.round(JambleHud.spotifyTop(screenWidth)+(H+(AstraConfig.lyricsEnabled?60:0))*scale)+8);
    }
    public static void draw(GuiGraphics g,Font font) {
        var media=SpotifyBridge.state();long now=System.nanoTime();
        float dt=Math.min(.1f,(now-lastFrame)/1e9f);
        if(now-lastFrame>600_000_000L) {visibility=0;LYRIC_MOTION.reset();}
        lastFrame=now;
        float target=AstraConfig.hudSpotify?1:0;
        visibility=AstraConfig.animations?visibility+(target-visibility)*(1-(float)Math.exp(-dt*12)):target;
        if(visibility<.01f)return;
        float scale=hudScale(g.guiWidth());
        float targetY=JambleHud.spotifyTop(g.guiWidth());layoutY=AstraConfig.animations?layoutY+(targetY-layoutY)*(1-(float)Math.exp(-dt*12)):targetY;
        g.pose().pushMatrix();g.pose().translate((g.guiWidth()-W*scale)/2,layoutY-(1-visibility)*10);g.pose().scale(scale,scale);
        drawCard(g,font,media,visibility,false);
        if(AstraConfig.lyricsEnabled)drawLyrics(g,font,media,dt,visibility);
        g.pose().popMatrix();
    }
    public static void drawPreview(GuiGraphics g,Font font,int centre,int y) {
        float scale=(float)AstraConfig.spotifyHudScale;
        g.pose().pushMatrix();g.pose().translate(centre-W*scale/2,y);g.pose().scale(scale,scale);
        drawCard(g,font,SpotifyBridge.state(),1,true);g.pose().popMatrix();
    }
    private static void drawCard(GuiGraphics g,Font font,SpotifyBridge.State media,float opacity,boolean preview) {
        boolean song=media.connected() && !media.title().isBlank();
        var theme=AstraConfig.spotifyTheme();
        background(g,0,0,W,H,11,opacity);
        double time=AstraConfig.animations?System.nanoTime()/1e9:0;
        String title=song?media.title():preview?"Spotify HUD preview":"Spotify HUD";
        String artist=song?media.artist():preview?theme.label+" theme • song and artist appear here":media.connected()?"Choose a song in Spotify":media.status();
        marquee(g,font,title,14,11,W-28,0xFFF4F0FF,time,opacity);
        marquee(g,font,artist,14,29,W-28,0xFFC5C4D4,time,opacity);
        if(song || preview) {
            double elapsed=song?media.elapsed():0,duration=song?media.duration():0;
            String stamp=duration>0?format(elapsed)+" / "+format(duration):"--:-- / --:--";
            int right=W-14-font.width(Ui.text(stamp)),barWidth=Math.max(28,right-24);
            Ui.round(g,14,55,barWidth,4,2,Ui.alpha(0xFF545460,opacity*.7f));
            if(duration>0)Ui.round(g,14,55,(int)Math.round(barWidth*Math.clamp(elapsed/duration,0,1)),4,2,Ui.alpha(theme.accent,opacity));
            Ui.animated(g,font,stamp,right,50,Ui.alpha(0xFFD7D4E0,opacity));
        } else marquee(g,font,"Right Shift > Spotify HUD > Reconnect",14,50,W-28,0xFFD7D4E0,time,opacity);
    }
    private static void background(GuiGraphics g,int x,int y,int w,int h,int radius,float opacity) {
        var theme=AstraConfig.spotifyTheme();
        Ui.round(g,x+1,y+2,w,h,radius,Ui.alpha(0xFF050509,opacity*.5f));
        Ui.round(g,x,y,w,h,radius,Ui.alpha(theme.accent,opacity*.9f));
        Ui.gradient(g,x+2,y+2,w-4,h-4,radius-2,Ui.alpha(theme.top,opacity*.98f),Ui.alpha(theme.bottom,opacity*.98f));
        if(theme.texture!=null) {
            g.nextStratum();
            int iw=w-4,ih=h-4,r=radius-2;
            for(int row=0;row<r;row++) {
                int pad=Ui.inset(row,ih,r);
                texturePiece(g,x+2,y+2,iw,ih,pad,row,iw-pad*2,1,opacity);
                texturePiece(g,x+2,y+2,iw,ih,pad,ih-row-1,iw-pad*2,1,opacity);
            }
            texturePiece(g,x+2,y+2,iw,ih,0,r,iw,ih-r*2,opacity);
            g.nextStratum();
            Ui.round(g,x+2,y+2,iw,ih,r,Ui.alpha(0xFF101021,opacity*.65f));
        }
    }
    private static void texturePiece(GuiGraphics g,int x,int y,int w,int h,int dx,int dy,int dw,int dh,float opacity) {
        var theme=AstraConfig.spotifyTheme();
        int tw=theme==SpotifyHudTheme.ASTRA?1586:1672,th=theme==SpotifyHudTheme.ASTRA?992:941;
        float regionW=tw*.96f,regionH=th*.35f;
        g.blit(RenderPipelines.GUI_TEXTURED,theme.texture,x+dx,y+dy,tw*.02f+regionW*dx/w,th*.10f+regionH*dy/h,
            dw,dh,Math.max(1,Math.round(regionW*dw/w)),Math.max(1,Math.round(regionH*dh/h)),tw,th,Ui.tint(Ui.alpha(0xFFFFFFFF,opacity*.8f)));
    }
    private static void drawLyrics(GuiGraphics g,Font font,SpotifyBridge.State media,float dt,float opacity) {
        boolean song=media.connected() && !media.title().isBlank();
        var lyrics=song?LyricsService.current():null;
        int index=lyrics==null?-1:lyrics.index(media.elapsed());
        background(g,7,H+6,W-14,54,9,opacity);
        String credit=lyrics==null || lyrics.lines().isEmpty()?"Lyrics":lyrics.synced()?"LRCLIB":"LRCLIB • unsynced";
        Ui.animated(g,font,credit,18,H+11,Ui.alpha(0xFFA5A2B5,opacity));
        String status=lyrics==null?"Play a song to show lyrics":lyrics.lines().isEmpty()?lyrics.status():
            media.duration()<=0 && lyrics.synced()?"Waiting for Spotify playback timing":index<0?"…":null;
        if(status!=null) {
            LYRIC_MOTION.reset();centredLine(g,font,status,H+29,0xFFEAE5F5,opacity);return;
        }
        double shown=LYRIC_MOTION.update(lyrics,index,dt,AstraConfig.animations);
        int base=(int)Math.floor(shown);
        g.enableScissor(14,H+24,W-14,H+55);
        for(int i=Math.max(0,base-1);i<Math.min(lyrics.lines().size(),base+4);i++) {
            float distance=(float)(i-shown),y=H+26+distance*15;
            float emphasis=Math.clamp(1-Math.abs(distance),0,1);
            float fade=Math.clamp((y-(H+16))/10f,0,1)*Math.clamp((H+60-y)/10f,0,1);
            if(fade<.01f)continue;
            int color=Ui.blend(0xFF918AA4,0xFFF6F0FF,emphasis);
            String line=lyrics.lines().get(i).text();
            centredLine(g,font,line.isBlank()?"…":line,y,color,opacity*fade);
        }
        g.disableScissor();
    }
    private static void centredLine(GuiGraphics g,Font font,String value,float y,int color,float opacity) {
        var text=Ui.text(value);float scale=Math.clamp((W-36)/(float)Math.max(1,font.width(text)),.65f,1);
        g.enableScissor(14,(int)y-1,W-14,(int)y+13);
        g.pose().pushMatrix();g.pose().translate(W/2f,y);g.pose().scale(scale,scale);
        Ui.animated(g,font,text,-font.width(text)/2f,0,Ui.alpha(color,opacity));g.pose().popMatrix();g.disableScissor();
    }
    private static void marquee(GuiGraphics g,Font font,String value,int x,int y,int max,int color,double time,float opacity) {
        int width=font.width(Ui.text(value));
        float offset=width>max && AstraConfig.animations?(float)((Math.sin(time*.22-Math.PI/2)+1)*.5*(width-max)):0;
        g.enableScissor(x,y-2,x+max,y+13);
        Ui.animated(g,font,value,x-offset,y,Ui.alpha(color,opacity));g.disableScissor();
    }
    public static String format(double seconds) {long value=(long)Math.max(0,seconds);return value/60+":"+String.format(java.util.Locale.ROOT,"%02d",value%60);}
    public static void close() {LYRIC_MOTION.reset();visibility=0;}
}
