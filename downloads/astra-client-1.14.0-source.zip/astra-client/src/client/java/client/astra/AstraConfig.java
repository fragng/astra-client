package client.astra;

import com.google.gson.*;
import net.fabricmc.loader.api.FabricLoader;
import net.minecraft.client.Minecraft;
import java.nio.file.*;
import java.util.Locale;
import org.slf4j.LoggerFactory;

public final class AstraConfig {
    private static final Path FILE = FabricLoader.getInstance().getConfigDir().resolve("astra-client.json");
    private static Theme theme = Theme.GALAXY;
    private static TotemStyle totemStyle=TotemStyle.NONE;
    private static SkyTheme skyTheme=SkyTheme.VANILLA;
    public static SkyTheme skyTheme(){return skyTheme;}
    public static boolean lyricsInSky=false;
    public static void selectSky(SkyTheme sky){if(sky==SkyTheme.VANILLA || PremiumEdition.premium()){skyTheme=sky;changed();}}
    public static TotemStyle totemStyle(){return totemStyle;}
    public static void selectTotem(TotemStyle style){if(style==TotemStyle.NONE || PremiumEdition.premium()){totemStyle=style;changed();}}
    private static SpotifyHudTheme spotifyTheme=SpotifyHudTheme.BLACK;
    public static double menuBrightness = 1;
    public static double spotifyHudScale = .7;
    public static boolean reactiveBackground=false,fakeMedia=false,freelookEnabled=false;
    public static String freelookKey;
    public static boolean jambleEnabled=false;
    public static boolean animations = true, sounds = true, hudVisible = true, hudLogo = true;
    public static boolean spotifyEnabled=true, hudSpotify=true, lyricsEnabled=true, bubbleFont=true;
    private static boolean dirty, nativeDirty;
    private static long changed;
    private AstraConfig() {}
    public static Theme theme() { return theme; }
    public static SpotifyHudTheme spotifyTheme() {return spotifyTheme;}
    public static void selectSpotifyTheme(SpotifyHudTheme next) {spotifyTheme=next;changed();}
    private static double number(JsonObject j, String key, double fallback) {
        try { double v=j.get(key).getAsDouble(); return Double.isFinite(v) ? Math.clamp(v,0,1) : fallback; }
        catch (Exception e) { return fallback; }
    }
    private static boolean bool(JsonObject j, String key, boolean fallback) {
        try { return j.get(key).getAsBoolean(); } catch(Exception e) { return fallback; }
    }
    public static void load() {
        if (!Files.exists(FILE)) return;
        try {
            var j=JsonParser.parseString(Files.readString(FILE)).getAsJsonObject();
            try { theme=Theme.valueOf(j.get("background").getAsString().toUpperCase(Locale.ROOT)); } catch(Exception e) { theme=Theme.NORMAL; }
            try {spotifyTheme=SpotifyHudTheme.valueOf(j.get("spotifyHudTheme").getAsString().toUpperCase(Locale.ROOT));} catch(Exception e) {spotifyTheme=SpotifyHudTheme.BLACK;}
            try {totemStyle=TotemStyle.valueOf(j.get("totemStyle").getAsString().toUpperCase(Locale.ROOT));}catch(Exception ignored){totemStyle=TotemStyle.NONE;}
            PerformanceMode.load(j.get("performanceMode"));
            menuBrightness=number(j,"menuBrightness",1);
            spotifyHudScale=Math.clamp(number(j,"spotifyHudScale",.7),.5,1);
            jambleEnabled=bool(j,"jambleEnabled",false);
            try {skyTheme=SkyTheme.valueOf(j.get("customSky").getAsString().toUpperCase(Locale.ROOT));}catch(Exception ignored){skyTheme=SkyTheme.VANILLA;}
            lyricsInSky=bool(j,"lyricsInSky",false);
            reactiveBackground=bool(j,"reactiveBackground",false);
            fakeMedia=bool(j,"fakeMedia",false);freelookEnabled=bool(j,"freelookEnabled",false);
            try {freelookKey=j.get("freelookKey").getAsString();} catch(Exception ignored) {freelookKey=null;}
            animations=bool(j,"animations",true); sounds=bool(j,"sounds",true);
            hudVisible=bool(j,"hudVisible",true); hudLogo=bool(j,"hudLogo",true);
            bubbleFont=bool(j,"bubbleFont",true);
            spotifyEnabled=bool(j,"spotifyEnabled",true);hudSpotify=bool(j,"hudSpotify",true);
            lyricsEnabled=bool(j,"lyricsEnabled",true);
        } catch(Exception e) { LoggerFactory.getLogger("Astra Client").warn("Could not read Astra preferences; using defaults.",e); }
    }
    public static void select(Theme next) { theme=next; changed(); }
    public static void changed() { dirty=true; changed=System.nanoTime(); }
    public static void nativeChanged() { nativeDirty=true; changed=System.nanoTime(); }
    public static void tick(Minecraft client) { if ((dirty || nativeDirty) && System.nanoTime()-changed>400_000_000L) flush(); }
    public static void reset() {
        PerformanceMode.disable();jambleEnabled=false;JambleHud.reset();
        skyTheme=SkyTheme.VANILLA;lyricsInSky=false;
        totemStyle=TotemStyle.NONE;reactiveBackground=false;fakeMedia=false;freelookEnabled=false;freelookKey="key.keyboard.left.alt";theme=Theme.GALAXY;spotifyTheme=SpotifyHudTheme.BLACK;menuBrightness=1;spotifyHudScale=.7;animations=true;sounds=true;hudVisible=true;hudLogo=true;
        spotifyEnabled=true;hudSpotify=true;lyricsEnabled=true;bubbleFont=true;changed(); flush();
    }
    public static void flush() {
        if(nativeDirty) { Minecraft.getInstance().options.save();nativeDirty=false; }
        if(!dirty) return;
        try {
            Files.createDirectories(FILE.getParent());
            var j=new JsonObject();
            j.addProperty("jambleEnabled",jambleEnabled);
            j.addProperty("customSky",skyTheme.name().toLowerCase(Locale.ROOT));
            j.addProperty("lyricsInSky",lyricsInSky);
            j.add("performanceMode",PerformanceMode.json());
            j.addProperty("totemStyle",totemStyle.name().toLowerCase(Locale.ROOT));
            j.addProperty("reactiveBackground",reactiveBackground);
            j.addProperty("fakeMedia",fakeMedia);j.addProperty("freelookEnabled",freelookEnabled);
            if(freelookKey!=null)j.addProperty("freelookKey",freelookKey);
            j.addProperty("spotifyHudScale",spotifyHudScale);
            j.addProperty("spotifyHudTheme",spotifyTheme.name().toLowerCase(Locale.ROOT));
            j.addProperty("bubbleFont",bubbleFont);j.addProperty("lyricsEnabled",lyricsEnabled);
            j.addProperty("spotifyEnabled",spotifyEnabled);j.addProperty("hudSpotify",hudSpotify);
            j.addProperty("background",theme.name().toLowerCase(Locale.ROOT));
            j.addProperty("menuBrightness",menuBrightness);j.addProperty("animations",animations);j.addProperty("sounds",sounds);
            j.addProperty("hudVisible",hudVisible);j.addProperty("hudLogo",hudLogo);
            var temp=FILE.resolveSibling("astra-client.json.tmp");Files.writeString(temp,new GsonBuilder().setPrettyPrinting().create().toJson(j));
            try { Files.move(temp,FILE,StandardCopyOption.ATOMIC_MOVE,StandardCopyOption.REPLACE_EXISTING); }
            catch(AtomicMoveNotSupportedException e) { Files.move(temp,FILE,StandardCopyOption.REPLACE_EXISTING); }
            dirty=false;
        } catch(Exception e) { LoggerFactory.getLogger("Astra Client").warn("Could not save Astra preferences.",e); }
    }
}
