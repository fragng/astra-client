package client.netheritefinder;

import net.minecraft.client.Minecraft;
import net.minecraft.core.*;
import net.minecraft.tags.FluidTags;
import net.minecraft.world.level.block.Blocks;
import net.minecraft.world.phys.shapes.CollisionContext;

/** Every route and every actual mining action is checked against current world data. */
public final class MiningTerrain implements RouteSearch.Terrain {
    private final Minecraft mc=Minecraft.getInstance();
    public static BlockPos pos(RouteSearch.Cell cell){return new BlockPos(cell.x(),cell.y(),cell.z());}
    public static RouteSearch.Cell cell(BlockPos pos){return new RouteSearch.Cell(pos.getX(),pos.getY(),pos.getZ());}
    public boolean loaded(BlockPos p){return mc.level!=null&&p.getY()>=mc.level.getMinY()&&p.getY()<mc.level.getMaxY()&&mc.level.hasChunkAt(p);}
    public boolean danger(BlockPos p){
        if(!loaded(p))return true;
        for(var d:Direction.values())if(!loaded(p.relative(d))||mc.level.getFluidState(p.relative(d)).is(FluidTags.LAVA))return true;
        var state=mc.level.getBlockState(p);
        return !state.getFluidState().isEmpty()||state.is(Blocks.FIRE)||state.is(Blocks.SOUL_FIRE)||state.is(Blocks.MAGMA_BLOCK)||state.is(Blocks.CAMPFIRE)||state.is(Blocks.SOUL_CAMPFIRE);
    }
    public boolean solidFloor(BlockPos p){return loaded(p)&&!danger(p)&&mc.level.getBlockState(p).isCollisionShapeFullBlock(mc.level,p);}
    public boolean clear(BlockPos p){return loaded(p)&&mc.level.getBlockState(p).getCollisionShape(mc.level,p).isEmpty();}
    public boolean safeBreak(BlockPos p){
        if(!loaded(p)||danger(p)||mc.level.getBlockState(p).hasBlockEntity())return false;
        var feet=mc.player.blockPosition();if(p.equals(feet.below()))return false;
        var state=mc.level.getBlockState(p);return state.getDestroySpeed(mc.level,p)>=0&&!state.is(Blocks.BEDROCK)&&!state.is(Blocks.OBSIDIAN)&&!state.is(Blocks.CRYING_OBSIDIAN);
    }
    public boolean cellSafe(BlockPos feet){return loaded(feet)&&!danger(feet)&&!danger(feet.above())&&solidFloor(feet.below())&&(clear(feet)||safeBreak(feet))&&(clear(feet.above())||safeBreak(feet.above()));}
    public boolean walkable(BlockPos feet){return cellSafe(feet)&&clear(feet)&&clear(feet.above());}
    private double breakCost(BlockPos p){if(clear(p))return 0;var state=mc.level.getBlockState(p);return state.is(Blocks.NETHERRACK)?1.1:Math.min(18,2+state.getDestroySpeed(mc.level,p)*2);}
    public double cost(RouteSearch.Cell from,RouteSearch.Cell to){
        var dest=pos(to);if(!cellSafe(dest))return Double.POSITIVE_INFINITY;
        // A stair requires space above the old cell as well as the destination.
        if(to.y()>from.y()&&(!loaded(pos(from).above(2))||danger(pos(from).above(2))||!clear(pos(from).above(2))&&!safeBreak(pos(from).above(2))))return Double.POSITIVE_INFINITY;
        return 1+breakCost(dest)+breakCost(dest.above())+(to.y()!=from.y()?1.5:0);
    }
}
