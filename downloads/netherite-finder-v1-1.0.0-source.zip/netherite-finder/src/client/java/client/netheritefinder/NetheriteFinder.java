package client.netheritefinder;

import net.fabricmc.api.ClientModInitializer;
import net.fabricmc.fabric.api.client.event.lifecycle.v1.*;
import net.fabricmc.fabric.api.client.networking.v1.ClientPlayConnectionEvents;
import net.fabricmc.fabric.api.client.keybinding.v1.KeyBindingHelper;
import net.fabricmc.fabric.api.client.rendering.v1.hud.*;
import net.minecraft.client.KeyMapping;
import net.minecraft.client.Minecraft;
import net.minecraft.resources.Identifier;

public final class NetheriteFinder implements ClientModInitializer {
    public static final MiningEngine ENGINE=new MiningEngine();
    public void onInitializeClient(){
        var key=KeyBindingHelper.registerKeyBinding(new KeyMapping("Netherite Finder controls",org.lwjgl.glfw.GLFW.GLFW_KEY_F8,KeyMapping.Category.MISC));
        ClientTickEvents.END_CLIENT_TICK.register(mc->{while(key.consumeClick())if(mc.player!=null){if(mc.screen instanceof FinderScreen)mc.setScreen(null);else{ENGINE.menuOpened();mc.setScreen(new FinderScreen(ENGINE));}}ENGINE.tick();});
        ClientPlayConnectionEvents.DISCONNECT.register((handler,mc)->{ENGINE.disconnect();DebrisHighlight.close();});
        ClientLifecycleEvents.CLIENT_STOPPING.register(mc->ENGINE.disconnect());DebrisHighlight.initialize(ENGINE);
        HudElementRegistry.attachElementBefore(VanillaHudElements.CHAT,Identifier.fromNamespaceAndPath("netherite-finder","status"),(g,dt)->{
            var mc=Minecraft.getInstance();if(!ENGINE.enabled()||mc.player==null||mc.screen!=null||mc.getDebugOverlay().showDebugScreen())return;
            String status=ENGINE.status();if(status.length()>61)status=status.substring(0,58)+"...";int w=Math.min(g.guiWidth()-16,Math.max(190,mc.font.width(status)+16));
            FinderUi.round(g,8,8,w,39,8,0xDE10131E);g.drawString(mc.font,"Netherite Finder V1 / F8",15,14,0xFFFF7384,false);g.drawString(mc.font,status,15,29,0xFFE2E5ED,false);
        });
    }
}
