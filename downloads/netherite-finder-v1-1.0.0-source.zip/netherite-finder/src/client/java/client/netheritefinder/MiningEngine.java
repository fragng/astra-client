package client.netheritefinder;

import net.minecraft.client.Minecraft;
import net.minecraft.core.*;
import net.minecraft.network.chat.Component;
import net.minecraft.util.Mth;
import net.minecraft.world.InteractionHand;
import net.minecraft.world.entity.item.ItemEntity;
import net.minecraft.world.item.*;
import net.minecraft.world.level.*;
import net.minecraft.world.level.block.Blocks;
import net.minecraft.world.phys.*;
import java.util.*;

public final class MiningEngine {
    final Minecraft mc=Minecraft.getInstance();
    final InventoryActions inventory=new InventoryActions();
    final MiningTerrain terrain=new MiningTerrain();
    final DebrisScanner scanner=new DebrisScanner();
    final StorageTask storage=new StorageTask(this);
    private boolean enabled,repairing,sawTotem;
    private String status="Off — press F8 for controls";
    private RouteSearch search;private List<RouteSearch.Cell> route=List.of();private int waypoint;
    private BlockPos ore,goal,mining,collect;private boolean expectingOre,exploring;
    private long tick,miningSince,collectUntil,lastBottle,lastDrop;private int countBeforeCollect,missedPickups;
    private final Map<BlockPos,Long> avoid=new HashMap<>();
    private int exploreDirection,failures;private Vec3 progress=Vec3.ZERO;private long progressTick;
    private int repairDamage,repairBottles;private long bottleReturnTick;
    public int stored,thrownBottles,discarded;
    public boolean enabled(){return enabled;}
    public String status(){return status;}
    public long ticks(){return tick;}
    public BlockPos target(){return ore;}
    public void status(String value){status=value;}
    public void toggle(){setEnabled(!enabled);}
    public void setEnabled(boolean on){
        release();enabled=on;resetRoute();ore=goal=mining=collect=null;expectingOre=repairing=false;storage.reset();avoid.clear();failures=missedPickups=0;
        if(on){sawTotem=mc.player!=null&&mc.player.getOffhandItem().is(Items.TOTEM_OF_UNDYING);exploreDirection=mc.player==null?0:Math.floorMod(Math.round(mc.player.getYRot()/90f),4);status="Ready — close the menu to start";}
        else{scanner.clear();status="Off";}
    }
    public void stop(String reason){setEnabled(false);status=reason;if(mc.player!=null)mc.player.displayClientMessage(Component.literal("Netherite Finder: "+reason),false);}
    public void disconnect(){setEnabled(false);status="Disconnected — automation is off";}
    public void menuOpened(){release();if(mc.player!=null&&mc.player.containerMenu!=mc.player.inventoryMenu)mc.player.closeContainer();storage.reset();resetRoute();}
    public void release(){
        mc.options.keyUp.setDown(false);mc.options.keyDown.setDown(false);mc.options.keyLeft.setDown(false);mc.options.keyRight.setDown(false);mc.options.keyJump.setDown(false);mc.options.keySprint.setDown(false);mc.options.keyShift.setDown(false);
        mc.options.keyAttack.setDown(false);
        if(mc.gameMode!=null)mc.gameMode.stopDestroyBlock();mining=null;
    }
    private void clearMovement(){mc.options.keyUp.setDown(false);mc.options.keyDown.setDown(false);mc.options.keyLeft.setDown(false);mc.options.keyRight.setDown(false);mc.options.keyShift.setDown(false);mc.options.keyJump.setDown(false);mc.options.keySprint.setDown(false);}
    void stopMining(){mc.options.keyAttack.setDown(false);if(mining!=null&&mc.gameMode!=null)mc.gameMode.stopDestroyBlock();mining=null;}
    void resetRoute(){search=null;route=List.of();waypoint=0;goal=null;}
    public void tick(){
        tick++;
        if(!enabled)return;
        if(mc.player==null||mc.level==null||mc.gameMode==null){setEnabled(false);return;}
        clearMovement();
        if(!mc.level.dimension().equals(Level.NETHER)){stopMining();status="Waiting for the Nether";scanner.clear();return;}
        if(!mc.player.isAlive()){stop("Player is not alive");return;}
        for(var player:mc.level.players())if(player!=mc.player&&!player.isSpectator()&&Math.hypot(player.getX()-mc.player.getX(),player.getZ()-mc.player.getZ())<=128){
            String name=player.getName().getString();stop("Nearby player: "+name+" — logging out");var connection=mc.getConnection();if(connection!=null)connection.getConnection().disconnect(Component.literal("Netherite Finder: player "+name+" detected within 8 chunks."));return;
        }
        scanner.tick();avoid.entrySet().removeIf(e->e.getValue()<=tick);
        if(mc.player.isInLava()||mc.player.fallDistance>3){stop("Unsafe lava or fall — stopped");return;}
        if(mc.screen!=null&&!storage.running()){stopMining();status="Paused while a menu is open";return;}
        if(mc.gameMode.isSpectator()){stop("Spectator mode cannot mine");return;}
        if(!mc.player.getOffhandItem().is(Items.TOTEM_OF_UNDYING)){
            if(inventory.count(Items.TOTEM_OF_UNDYING)>0){stopMining();status="Equipping a spare totem";inventory.refillTotem(tick);sawTotem=true;return;}
            if(sawTotem){stop("Totem used — no spare totems remain");return;}
        }else sawTotem=true;
        if(storage.running()){storage.tick();return;}
        if(inventory.bestPick()<0){stopMining();status="Need a usable diamond or netherite pickaxe";return;}
        if(bottleReturnTick>0){if(tick>=bottleReturnTick&&inventory.equipPick(tick))bottleReturnTick=0;status="Repairing: collecting XP";return;}
        // Secure a full stack before waiting for repair supplies.
        if(inventory.count(Items.ANCIENT_DEBRIS)>=64){stopMining();resetRoute();storage.start();storage.tick();return;}
        int best=inventory.bestPick();var pick=mc.player.getInventory().getItem(best);double damage=InventoryActions.damage(pick);
        if(damage>=.30&&InventoryActions.mending(pick)){
            if(!repairing){repairing=true;repairDamage=pick.getDamageValue();repairBottles=0;resetRoute();}
        }
        if(repairing){
            stopMining();if(damage<=.08){repairing=false;inventory.equipPick(tick);}else{repair(pick);return;}
        }
        if(pick.isDamageableItem()&&pick.getMaxDamage()-pick.getDamageValue()<64){stopMining();status="Pickaxe nearly broken — need Mending and XP bottles";return;}
        if(ore!=null&&expectingOre&&!mc.level.getBlockState(ore).is(Blocks.ANCIENT_DEBRIS)){
            collect=ore;collectUntil=tick+90;countBeforeCollect=inventory.count(Items.ANCIENT_DEBRIS);ore=null;expectingOre=false;resetRoute();stopMining();
        }
        if(collect!=null){collect();return;}
        if(ore!=null&&!mc.level.getBlockState(ore).is(Blocks.ANCIENT_DEBRIS)){ore=null;resetRoute();}
        if(ore==null){
            ore=scanner.positions().stream().filter(p->!avoid.containsKey(p)&&p.distSqr(mc.player.blockPosition())<48*48&&Math.abs(p.getY()-mc.player.getY())<=22&&!terrain.danger(p)).min(Comparator.comparingDouble(p->p.distToCenterSqr(mc.player.position()))).orElse(null);
            if(ore!=null){resetRoute();exploring=false;}
        }
        if(ore!=null){
            if(reachable(ore)&&terrain.safeBreak(ore)&&visibleFirst(ore).equals(ore)){expectingOre=true;mine(ore,false);return;}
            planOrFollow(ore,true);return;
        }
        // Continue safe branch tunnelling near Y15 to reveal more loaded terrain.
        if(goal==null){int[][] dirs={{0,1},{-1,0},{0,-1},{1,0}};int[] d=dirs[exploreDirection];var feet=mc.player.blockPosition();goal=feet.offset(d[0]*10,Mth.clamp(15-feet.getY(),-3,3),d[1]*10);exploring=true;}
        planOrFollow(goal,false);
    }
    private void repair(ItemStack pick){
        status="Repairing pickaxe with XP bottles";int bottles=inventory.find(s->s.is(Items.EXPERIENCE_BOTTLE));
        if(bottles<0){status="Repair paused — add XP bottles to inventory";return;}
        if(!InventoryActions.mending(pick)){repairing=false;return;}
        if(repairBottles>=24&&pick.getDamageValue()>=repairDamage){stop("No repair progress — check Mending and other damaged gear");return;}
        if(tick-lastBottle<20){inventory.equipPick(tick);return;}
        if(!inventory.equip(bottles,tick))return;
        if(!aim(mc.player.getEyePosition().add(0,-4,.10),4))return;
        mc.gameMode.useItem(mc.player,InteractionHand.MAIN_HAND);mc.player.swing(InteractionHand.MAIN_HAND);lastBottle=tick;bottleReturnTick=tick+1;repairBottles++;thrownBottles++;
    }
    private void collect(){
        stopMining();status="Collecting ancient debris";
        if(inventory.count(Items.ANCIENT_DEBRIS)>countBeforeCollect){collect=null;missedPickups=failures=0;resetRoute();return;}
        if(!inventory.hasPickupReserve()){
            status="Making room for debris — plain mining blocks only";
            if(inventory.find(InventoryActions::disposable)<0){status="Inventory full — remove items manually";return;}
            if(tick-lastDrop>=20&&inventory.discardOne(tick)){lastDrop=tick;discarded++;collectUntil=tick+70;}return;
        }
        if(tick>collectUntil){collect=null;resetRoute();if(++missedPickups>=3)stop("No debris pickup confirmed — check the route or server permissions");return;}
        var items=mc.level.getEntitiesOfClass(ItemEntity.class,mc.player.getBoundingBox().inflate(6),e->e.getItem().is(Items.ANCIENT_DEBRIS));
        var closest=items.stream().min(Comparator.comparingDouble(e->e.distanceToSqr(mc.player))).orElse(null);
        BlockPos destination=closest==null?collect:closest.blockPosition();
        if(destination.distToCenterSqr(mc.player.position())>1.1)planOrFollow(destination,false);
    }
    private void planOrFollow(BlockPos target,boolean adjacent){
        if(search==null&&route.isEmpty()){
            goal=target;search=new RouteSearch(terrain,MiningTerrain.cell(mc.player.blockPosition()),MiningTerrain.cell(target),adjacent);progress=mc.player.position();progressTick=tick;
        }
        if(search!=null){
            stopMining();
            status="Planning a lava-safe route";
            if(!search.step(160))return;
            route=search.route();search=null;waypoint=0;
            if(route.isEmpty()){
                if(!adjacent&&mc.player.blockPosition().distManhattan(target)<=1){resetRoute();return;}
                failedRoute(target);return;
            }
        }
        if(waypoint>=route.size()){resetRoute();if(exploring)status="Scanning the next tunnel section";return;}
        var cell=route.get(waypoint);var p=MiningTerrain.pos(cell);var feet=mc.player.blockPosition();
        double horizontal=Math.hypot(mc.player.getX()-(p.getX()+.5),mc.player.getZ()-(p.getZ()+.5));
        if(horizontal<.28&&Math.abs(mc.player.getY()-p.getY())<.6){waypoint++;stopMining();return;}
        if(!terrain.cellSafe(p)){failedRoute(target);return;}
        if(p.getY()>feet.getY()&&!terrain.clear(feet.above(2))){mine(feet.above(2),false);return;}
        if(!terrain.clear(p.above())){mine(p.above(),false);return;}
        if(!terrain.clear(p)){mine(p,false);return;}
        stopMining();status=exploring?"Branch mining toward Y15":"Moving toward debris";
        if(!terrain.walkable(p)){failedRoute(target);return;}
        boolean aligned=aim(new Vec3(p.getX()+.5,mc.player.getEyeY(),p.getZ()+.5),15);
        if(aligned){mc.options.keyUp.setDown(true);mc.options.keyJump.setDown(p.getY()>mc.player.getY()+.4&&horizontal<1.1);mc.options.keySprint.setDown(waypoint+2<route.size()&&p.getY()==feet.getY()&&terrain.walkable(MiningTerrain.pos(route.get(waypoint+1)))&&terrain.walkable(MiningTerrain.pos(route.get(waypoint+2))));}
        if(tick-progressTick>=50){if(mc.player.position().distanceToSqr(progress)<.16){failedRoute(target);return;}progress=mc.player.position();progressTick=tick;}
    }
    private void failedRoute(BlockPos target){
        stopMining();clearMovement();if(ore!=null){avoid.put(ore,tick+600);ore=null;expectingOre=false;}resetRoute();exploreDirection=(exploreDirection+1)%4;status="Route blocked — trying another tunnel";
        if(++failures>20){stop("No safe route — move to solid ground and enable again");}
    }
    boolean reachable(BlockPos target){return target.distToCenterSqr(mc.player.getEyePosition())<Math.pow(Math.min(4.2,mc.player.blockInteractionRange()-.2),2);}
    BlockPos visibleFirst(BlockPos target){return mc.level.clip(new ClipContext(mc.player.getEyePosition(),Vec3.atCenterOf(target),ClipContext.Block.COLLIDER,ClipContext.Fluid.NONE,mc.player)).getBlockPos();}
    boolean aim(Vec3 point,float tolerance){
        var delta=point.subtract(mc.player.getEyePosition());float yaw=(float)Math.toDegrees(Math.atan2(delta.z,delta.x))-90,pitch=(float)-Math.toDegrees(Math.atan2(delta.y,Math.hypot(delta.x,delta.z)));
        float dy=Mth.wrapDegrees(yaw-mc.player.getYRot()),dp=pitch-mc.player.getXRot();mc.player.setYRot(mc.player.getYRot()+Mth.clamp(dy,-12,12));mc.player.setXRot(Mth.clamp(mc.player.getXRot()+Mth.clamp(dp,-10,10),-89.5f,89.5f));
        return Math.abs(dy)<tolerance&&Math.abs(dp)<tolerance;
    }
    void mine(BlockPos target,boolean recoverChest){
        if(!reachable(target)){resetRoute();return;}
        BlockPos first=visibleFirst(target);
        if(!first.equals(target)){if(terrain.safeBreak(first)&&reachable(first))target=first;else{failedRoute(target);return;}}
        if(recoverChest?terrain.danger(target):!terrain.safeBreak(target)){failedRoute(target);return;}
        if(!inventory.equipPick(tick)){status="Moving pickaxe into the hotbar";return;}
        if(!aim(Vec3.atCenterOf(target),5)){stopMining();return;}
        if(!(mc.hitResult instanceof BlockHitResult crosshair)||!crosshair.getBlockPos().equals(target)){stopMining();return;}
        if(!target.equals(mining)){stopMining();mining=target;miningSince=tick;}
        if(tick-miningSince>240){failedRoute(target);return;}
        // Hold the native attack input; Minecraft performs one normal mining update.
        mc.options.keyAttack.setDown(true);status=recoverChest?"Recovering the ender chest":"Mining "+(mc.level.getBlockState(target).is(Blocks.ANCIENT_DEBRIS)?"ancient debris":"a clear tunnel");
    }
}
