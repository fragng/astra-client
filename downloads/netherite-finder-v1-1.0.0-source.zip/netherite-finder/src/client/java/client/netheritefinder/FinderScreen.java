package client.netheritefinder;

import net.minecraft.client.gui.GuiGraphics;
import net.minecraft.client.gui.components.Button;
import net.minecraft.client.gui.screens.Screen;
import net.minecraft.client.input.MouseButtonEvent;
import net.minecraft.network.chat.Component;
import net.minecraft.util.FormattedCharSequence;
import java.util.*;

public final class FinderScreen extends Screen {
    private static final int W=500,H=380;
    private final MiningEngine engine;private boolean instructions;private int scroll;
    private float scale,ox,oy;
    private final List<FormattedCharSequence> lines=new ArrayList<>();
    private static final String[] HELP={
        "You must have XP bottles in your inventory and a good diamond or netherite pickaxe. Mending is required for automatic repair.",
        "Carry spare Totems of Undying and an ender chest. Silk Touch on your pickaxe lets the mod recover its placed ender chest.",
        "Enter the Nether, press F8, switch ON and close this menu. F8 or opening another menu pauses mining. Switch OFF to release the controls.",
        "Loaded ancient debris is highlighted glowing red through terrain. The miner follows a checked route and uses normal Minecraft movement, reach and tool mining speed.",
        "If no reachable debris is known, it branch-mines toward Y15 to reveal more terrain. Lava-adjacent blocks, unsafe floors and unloaded paths are rejected.",
        "At 64 debris it opens or places a real ender chest and transfers the debris. A full chest, rejected interaction or missing supplies pauses or stops the miner.",
        "Mending repair starts below 70% durability. XP bottles are thrown at normal intervals, with the pickaxe held again to collect the XP. Keep bottles stocked.",
        "After a totem is used, a spare is equipped using a normal paced inventory swap. If no spare remains, automation stops.",
        "For pickup space it may discard plain netherrack, basalt, blackstone, gravel, soul sand or soul soil. Named or customised items, tools, supplies and debris are not discarded.",
        "Another loaded, non-spectator player within 128 horizontal blocks (8 chunks) triggers logout. Reconnecting never restarts automation automatically.",
        "A client cannot reveal ore or players a server does not send. Lava can change or be hidden; avoidance is not a guarantee. No anti-cheat bypass or flag-free guarantee is included.",
        "This takes over movement, aim, mining and the listed inventory actions while ON. Monitor supplies and use F8 to stop it. Mining automation must be permitted by the server you use."
    };
    public FinderScreen(MiningEngine engine){super(Component.literal("Netherite Finder V1"));this.engine=engine;}
    private void fit(){scale=Math.max(.1f,Math.min(1.15f,Math.min((width-24f)/W,(height-20f)/H)));ox=(width-W*scale)/2;oy=(height-H*scale)/2;}
    @Override protected void init(){fit();lines.clear();for(String text:HELP){lines.addAll(font.split(Component.literal(text),438));lines.add(FormattedCharSequence.EMPTY);}
        if(instructions)addRenderableWidget(new Control(24,332,220,"Back",()->{instructions=false;rebuildWidgets();}));
        else{
            addRenderableWidget(new Control(24,112,452,engine.enabled()?"ON — click to turn OFF":"OFF — click to turn ON",()->{engine.toggle();rebuildWidgets();}));
            addRenderableWidget(new Control(24,288,220,"Instructions",()->{instructions=true;scroll=0;rebuildWidgets();}));
        }
        addRenderableWidget(new Control(instructions?256:256,instructions?332:288,220,"Close",this::onClose));
    }
    @Override public void renderBackground(GuiGraphics g,int x,int y,float d){}
    @Override public void render(GuiGraphics g,int mx,int my,float delta){fit();g.fill(0,0,width,height,0xA0060811);g.pose().pushMatrix();g.pose().translate(ox,oy);g.pose().scale(scale,scale);
        FinderUi.round(g,0,0,W,H,18,0xFF48222D);FinderUi.round(g,1,1,W-2,H-2,17,0xFF111420);
        g.drawString(font,"NETHERITE FINDER V1",24,24,0xFFFF6679,false);g.drawString(font,instructions?"Instructions — scroll to read":"Ancient debris / Nether automation",24,46,0xFFAAAEBF,false);
        g.fill(24,69,476,70,0xFF313443);
        if(instructions){g.enableScissor(24,82,476,317);for(int i=0;i<lines.size();i++)g.drawString(font,lines.get(i),28,84+i*11-scroll,0xFFE2E4ED,false);g.disableScissor();}
        else{
            g.drawString(font,"Mining control",24,88,0xFFF2F3FA,false);
            FinderUi.round(g,24,160,452,106,12,0xFF1B2030);
            g.drawWordWrap(font,Component.literal(engine.status()),38,175,424,0xFFF1F2F6);
            g.drawString(font,"Debris found: "+engine.scanner.positions().size()+"   Stored this run: "+engine.stored,38,218,0xFFB2B7CA,false);
            g.drawString(font,"F8 opens this menu. Close it to resume while ON.",24,341,0xFF8E94AA,false);
        }
        for(var child:children())if(child instanceof net.minecraft.client.gui.components.Renderable r)r.render(g,(int)((mx-ox)/scale),(int)((my-oy)/scale),delta);
        g.pose().popMatrix();
    }
    @Override public boolean mouseClicked(MouseButtonEvent e,boolean doubled){return super.mouseClicked(new MouseButtonEvent((e.x()-ox)/scale,(e.y()-oy)/scale,e.buttonInfo()),doubled);}
    @Override public boolean mouseReleased(MouseButtonEvent e){return super.mouseReleased(new MouseButtonEvent((e.x()-ox)/scale,(e.y()-oy)/scale,e.buttonInfo()));}
    @Override public boolean mouseScrolled(double x,double y,double dx,double dy){if(instructions){scroll=Math.clamp(scroll-(int)(dy*25),0,Math.max(0,lines.size()*11-220));return true;}return super.mouseScrolled(x,y,dx,dy);}
    @Override public boolean isPauseScreen(){return false;}
    @Override public void onClose(){minecraft.setScreen(null);}
    private static class Control extends Button {
        Control(int x,int y,int w,String title,Runnable action){super(x,y,w,32,Component.literal(title),b->action.run(),DEFAULT_NARRATION);}
        @Override protected void renderContents(GuiGraphics g,int mx,int my,float dt){FinderUi.round(g,getX(),getY(),width,height,10,isHoveredOrFocused()?0xFFB44059:0xFF642F43);var f=net.minecraft.client.Minecraft.getInstance().font;g.drawCenteredString(f,getMessage(),getX()+width/2,getY()+12,0xFFFFFFFF);}
    }
}
