package client.astra;

import net.minecraft.client.gui.GuiGraphics;

public final class MenuArt {
    private MenuArt() {}
    private static void line(GuiGraphics g,float x,float y,float x2,float y2,int color) {
        int steps=Math.max(1,(int)Math.ceil(Math.hypot(x2-x,y2-y)*2));
        for(int i=0;i<=steps;i++) {
            float t=i/(float)steps;int px=Math.round(x+(x2-x)*t),py=Math.round(y+(y2-y)*t);
            g.fill(px,py,px+1,py+1,color);
        }
    }
    public static void icon(GuiGraphics g,String name,int x,int y,int size,int color) {
        g.pose().pushMatrix();g.pose().translate(x,y);g.pose().scale(size/16f,size/16f);
        switch(name) {
            case "Visuals" -> {line(g,0,8,5,3,color);line(g,5,3,11,3,color);line(g,11,3,16,8,color);line(g,16,8,11,13,color);line(g,11,13,5,13,color);line(g,5,13,0,8,color);Ui.round(g,6,6,5,5,2,color);}
            case "Settings" -> {Ui.round(g,3,3,10,10,5,color);Ui.round(g,5,5,6,6,3,0xFF23213A);for(int i=0;i<8;i++){double a=i*Math.PI/4;line(g,8+(float)Math.cos(a)*5,8+(float)Math.sin(a)*5,8+(float)Math.cos(a)*8,8+(float)Math.sin(a)*8,color);}}
            case "Jamble" -> {for(int i=0;i<3;i++){line(g,1,5+i*4,8,1+i*4,color);line(g,8,1+i*4,15,5+i*4,color);line(g,15,5+i*4,8,9+i*4,color);line(g,8,9+i*4,1,5+i*4,color);}}
            case "Best Buds" -> {Ui.round(g,1,1,6,6,3,color);Ui.round(g,10,2,5,5,2,color);line(g,0,15,1,10,color);line(g,1,10,7,10,color);line(g,7,10,9,15,color);line(g,11,10,15,10,color);line(g,15,10,16,15,color);}
            case "Music" -> {line(g,5,1,5,12,color);line(g,5,1,14,0,color);line(g,14,0,14,11,color);Ui.round(g,0,10,6,5,2,color);Ui.round(g,9,9,6,5,2,color);}
            case "HUD" -> {line(g,0,1,15,1,color);line(g,15,1,15,11,color);line(g,15,11,0,11,color);line(g,0,11,0,1,color);line(g,8,11,8,15,color);line(g,4,15,12,15,color);}
            case "General" -> {for(int i=0;i<3;i++){line(g,0,3+i*5,16,3+i*5,color);Ui.round(g,i==1?9:3,1+i*5,4,4,2,color);}}
            default -> {line(g,8,0,8,16,color);line(g,0,8,16,8,color);line(g,3,3,13,13,color);line(g,3,13,13,3,color);}
        }
        g.pose().popMatrix();
    }
    public static void background(GuiGraphics g,int w,int h) {
        Theme theme=AstraConfig.theme();
        Ui.gradient(g,0,0,w,h,18,0xFF161C32,0xFF0C1425);
        g.nextStratum();
        double time=AstraConfig.animations?System.nanoTime()/1e9:0;
        if(theme!=Theme.NORMAL) {
            var texture=theme==Theme.ASTRA?net.minecraft.resources.Identifier.fromNamespaceAndPath(AstraClient.MOD_ID,"textures/background/menu-astra.png"):theme.texture;
            float u=.012f+(float)Math.sin(time*.045)*.008f,v=.012f+(float)Math.cos(time*.035)*.008f;
            // Rounded clipping retains the underlying game at the corners.
            for(int row=0;row<18;row++) {
                int pad=Ui.inset(row,h,18);
                float u0=u+pad/(float)w*.96f,u1=u+(w-pad)/(float)w*.96f;
                g.blit(texture,pad,row,w-pad,row+1,u0,u1,v+row/(float)h*.96f,v+(row+1)/(float)h*.96f);
                g.blit(texture,pad,h-row-1,w-pad,h-row,u0,u1,v+(h-row-1)/(float)h*.96f,v+(h-row)/(float)h*.96f);
            }
            g.blit(texture,0,18,w,h-18,u,u+.96f,v+18f/h*.96f,v+(h-18f)/h*.96f);
            g.nextStratum();
            Ui.round(g,0,0,w,h,18,theme==Theme.NEBULA?0x552F2455:0x250A1129);
        }
        g.nextStratum();
    }
}
