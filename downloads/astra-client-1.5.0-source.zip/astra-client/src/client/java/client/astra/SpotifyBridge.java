package client.astra;

import com.google.gson.*;
import java.io.*;
import java.nio.charset.StandardCharsets;
import java.util.*;
import java.util.concurrent.*;

/** Windows desktop media integration. Artwork and timeline come from the local media session. */
public final class SpotifyBridge {
    public record State(boolean connected,String title,String artist,String status,boolean playing,boolean toggle,boolean next,boolean previous, String album, double position, double duration, long receivedAt, String artwork) {
        public double elapsed() {
            double delta=playing?Math.min(5,Math.max(0,(System.nanoTime()-receivedAt)/1e9)):0;
            return duration>0?Math.clamp(position+delta,0,duration):Math.max(0,position+delta);
        }
        public String trackKey() { return title+"\u0000"+artist+"\u0000"+album; }
    }
    private static volatile State state=empty("Spotify link is starting...");
    private static volatile Process process;
    private static volatile BufferedWriter commands;
    private static volatile long lastUpdate;
    private static volatile boolean attempted;
    private static volatile int generation;
    private static final ScheduledExecutorService WATCH=Executors.newSingleThreadScheduledExecutor(r->{Thread t=new Thread(r,"Astra media watchdog");t.setDaemon(true);return t;});
    private static final ExecutorService IO=Executors.newSingleThreadExecutor(r->{Thread t=new Thread(r,"Astra media commands");t.setDaemon(true);return t;});
    private static final java.util.concurrent.atomic.AtomicBoolean pending=new java.util.concurrent.atomic.AtomicBoolean();
    private SpotifyBridge() {}
    private static State empty(String status) { return new State(false,"","",status,false,false,false,false,"",0,0,System.nanoTime(),""); }
    public static State state() { return state; }
    public static boolean windows() { return System.getProperty("os.name","").toLowerCase(Locale.ROOT).startsWith("windows"); }
    public static void tick() {
        if(!AstraConfig.spotifyEnabled) { if(process!=null) stop();state=empty("Spotify desktop link is disabled.");attempted=false;return; }
        if(!windows()) { state=empty("Spotify desktop link requires Windows 10/11.");return; }
        if(!attempted) start();
    }
    public static synchronized void reconnect() {stop();attempted=false;tick();}
    private static synchronized void start() {
        if(attempted) return;
        attempted=true;int token=++generation;state=empty("Connecting to Windows desktop media...");
        Thread worker=new Thread(()->{
            Process local=null;
            try {
                String script;
                try(InputStream in=SpotifyBridge.class.getResourceAsStream("/assets/astra-client/media/spotify.ps1")) {
                    if(in==null) throw new IOException("Missing bridge resource");
                    script=new String(in.readAllBytes(),StandardCharsets.UTF_8);
                }
                String encoded=Base64.getEncoder().encodeToString(script.getBytes(StandardCharsets.UTF_16LE));
                local=new ProcessBuilder("powershell.exe","-NoLogo","-NoProfile","-NonInteractive","-STA","-WindowStyle","Hidden","-EncodedCommand",encoded)
                    .redirectError(ProcessBuilder.Redirect.DISCARD).start();
                if(token!=generation) {local.destroyForcibly();return;}
                process=local;commands=new BufferedWriter(new OutputStreamWriter(local.getOutputStream(),StandardCharsets.UTF_8));
                lastUpdate=System.nanoTime();
                try(BufferedReader reader=new BufferedReader(new InputStreamReader(local.getInputStream(),StandardCharsets.UTF_8))) {
                    String line;
                    while(token==generation && (line=reader.readLine())!=null) {
                        if(token!=generation) break;
                        try { state=parse(line);lastUpdate=System.nanoTime(); } catch(RuntimeException ignored) { /* Non-protocol host output. */ }
                    }
                }
                if(token==generation) state=empty("Spotify link stopped. Use Reconnect; Windows media access is required.");
            } catch(Exception e) {
                if(token==generation) state=empty("Cannot start Spotify link. Check Windows PowerShell and media access.");
            } finally {
                if(local!=null) local.destroyForcibly();
                if(token==generation) {process=null;commands=null;}
            }
        },"Astra Spotify desktop bridge");
        worker.setDaemon(true);worker.start();
    }
    static {
        WATCH.scheduleAtFixedRate(()->{
            Process p=process;
            if(p!=null && System.nanoTime()-lastUpdate>15_000_000_000L) {
                state=empty("Windows media session timed out. Use Reconnect.");p.destroyForcibly();
            }
        },2,2,TimeUnit.SECONDS);
    }
    public static State parse(String line) {
        JsonObject j=JsonParser.parseString(line).getAsJsonObject();
        boolean connected=j.has("connected")&&j.get("connected").getAsBoolean();
        return new State(connected,string(j,"title"),string(j,"artist"),string(j,"status"),bool(j,"playing"),bool(j,"toggle"),bool(j,"next"),bool(j,"previous"),string(j,"album"),seconds(j,"position"),seconds(j,"duration"),System.nanoTime(),artwork(j));
    }
    private static double seconds(JsonObject j,String k) {
        try {double value=j.get(k).getAsDouble();return Double.isFinite(value)?Math.clamp(value,0,604800):0;} catch(Exception e) {return 0;}
    }
    private static String artwork(JsonObject j) {
        String value=j.has("artwork")&&!j.get("artwork").isJsonNull()?j.get("artwork").getAsString():"";
        return value.length()<=700000?value:"";
    }
    private static String string(JsonObject j,String k) {String s=j.has(k)&&!j.get(k).isJsonNull()?j.get(k).getAsString().replaceAll("[\\p{Cntrl}]"," "):"";return s.length()>512?s.substring(0,512):s;}
    private static boolean bool(JsonObject j,String k) {return j.has(k)&&j.get(k).getAsBoolean();}
    public static synchronized void send(String command) {
        if(!Set.of("toggle","next","previous").contains(command) || !state.connected()) return;
        // Write through a background task; an unresponsive pipe never stalls Minecraft.
        if(!pending.compareAndSet(false,true)) return;
        IO.execute(()->{
            try {BufferedWriter out=commands;if(out!=null) {synchronized(out) {out.write(command);out.newLine();out.flush();}}}
            catch(IOException e) {state=empty("Playback command failed. Use Reconnect.");}
            finally {pending.set(false);}
        });
    }
    public static synchronized void stop() {
        generation++;Process p=process;process=null;commands=null;
        if(p!=null) p.destroyForcibly();
    }
}
