package client.astra.mixin;

import client.astra.Ui;
import net.minecraft.client.gui.GuiGraphics;
import net.minecraft.client.gui.screens.inventory.AbstractContainerScreen;
import net.minecraft.world.inventory.Slot;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;

@Mixin(AbstractContainerScreen.class)
public abstract class ContainerScreenMixin {
    @Inject(method = "renderSlot", at = @At("HEAD"))
    private void astra$roundSlot(GuiGraphics g, Slot slot, int mouseX, int mouseY, CallbackInfo ci) {
        if (!getClass().getName().startsWith("net.minecraft.")) return;
        int x = slot.x - 1, y = slot.y - 1;
        g.fill(x, y, x + 18, y + 18, 0xFFC6C6C6);
        Ui.round(g, x, y, 18, 18, 4, 0xFF5C6073);
        Ui.round(g, x + 1, y + 1, 16, 16, 3, 0xFF9093A1);
    }
}
