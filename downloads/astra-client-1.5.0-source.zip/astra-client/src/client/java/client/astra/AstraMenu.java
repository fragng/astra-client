package client.astra;

import net.fabricmc.fabric.api.client.screen.v1.Screens;
import net.minecraft.client.Minecraft;
import net.minecraft.client.gui.GuiGraphics;
import net.minecraft.client.gui.components.AbstractWidget;
import net.minecraft.client.gui.screens.TitleScreen;
import java.util.ArrayList;

public final class AstraMenu {
    private AstraMenu() {}
    public static int margin(int width) { return width < 480 ? 12 : 20; }
    public static int panelWidth(int width) { return width < 480 ? 104 : 124; }
    public static int panelX(int width) { return width - margin(width) - panelWidth(width); }
    public static int center(int width) { return (panelX(width) - 18) / 2; }
    public static int menuTop(int height) { return height / 4 + 32; }
    private static int panelHeight(int height) { return 36 + Theme.values().length * rowHeight(height) + (Theme.values().length - 1) * 8 + 12; }
    private static int panelTop(int height) { return (height - panelHeight(height)) / 2; }
    private static int rowHeight(int height) { return height < 270 ? 26 : 28; }

    private static final java.util.Map<TitleScreen, Integer> SHIFTS = new java.util.WeakHashMap<>();
    private static String key(AbstractWidget widget) {
        return widget.getMessage().getContents() instanceof net.minecraft.network.chat.contents.TranslatableContents t ? t.getKey() : "";
    }
    private static boolean vanilla(AbstractWidget widget) {
        return java.util.Set.of("menu.singleplayer", "menu.multiplayer", "menu.online", "menu.options", "menu.quit",
            "options.language", "options.accessibility", "narrator.button.language", "narrator.button.accessibility").contains(key(widget));
    }
    private static AbstractWidget mods(TitleScreen screen) {
        for (AbstractWidget widget : Screens.getButtons(screen)) {
            if (key(widget).equals("modmenu.title") || key(widget).startsWith("modmenu.mods") || widget.getMessage().getString().equalsIgnoreCase("Mods")) return widget;
        }
        return null;
    }
    public static void alignToMods(TitleScreen screen) {
        int row = 0;
        for (AbstractWidget widget : Screens.getButtons(screen)) {
            if (widget instanceof ModeButton) {
                widget.setX(panelX(screen.width) + 9);
                widget.setY(panelTop(screen.height) + 36 + row++ * (rowHeight(screen.height) + 8));
                widget.setSize(panelWidth(screen.width) - 18, rowHeight(screen.height));
            }
        }
        AbstractWidget anchor = mods(screen);
        int shift = anchor == null ? 0 : anchor.getX() + anchor.getWidth() / 2 - center(screen.width);
        if (anchor != null) {
            for (AbstractWidget widget : Screens.getButtons(screen)) {
                switch (key(widget)) {
                    case "menu.singleplayer" -> widget.setY(anchor.getY() - 78);
                    case "menu.multiplayer" -> widget.setY(anchor.getY() - 52);
                    case "menu.online" -> widget.setY(anchor.getY() - 26);
                    case "menu.options", "menu.quit" -> widget.setY(anchor.getY() + anchor.getHeight() + 10);
                    case "options.language", "options.accessibility", "narrator.button.language", "narrator.button.accessibility" -> widget.setY(anchor.getY() + anchor.getHeight() + 38);
                }
            }
        }
        int previous = SHIFTS.getOrDefault(screen, 0);
        if (shift != previous) {
            for (AbstractWidget widget : Screens.getButtons(screen)) if (vanilla(widget)) widget.setX(widget.getX() + shift - previous);
            SHIFTS.put(screen, shift);
        }
    }
    public static void initialize(TitleScreen screen) {
        SHIFTS.remove(screen);
        int center = center(screen.width), menuWidth = Math.min(200, center * 2 - 24);
        int oldTop = screen.height / 4 + 48, top = menuTop(screen.height);
        var buttons = Screens.getButtons(screen);
        for (AbstractWidget widget : new ArrayList<>(buttons)) {
            int oldX = widget.getX(), oldY = widget.getY(), oldWidth = widget.getWidth();
            if (oldY >= screen.height - 30 || !vanilla(widget)) continue;
            if (oldWidth >= 200) {
                widget.setX(center - menuWidth / 2);
                widget.setWidth(menuWidth);
                widget.setHeight(22);
                widget.setY(top + Math.round((oldY - oldTop) / 24f) * 26);
            } else if (oldWidth >= 90) {
                int half = (menuWidth - 6) / 2;
                widget.setX(oldX < screen.width / 2 ? center - menuWidth / 2 : center + 3);
                widget.setWidth(half);
                widget.setHeight(22);
                widget.setY(top + 82);
            } else if (oldWidth == 20) {
                widget.setX(oldX < screen.width / 2 ? center - 24 : center + 4);
                widget.setY(top + 110);
            }
            if (oldWidth >= 90) widget.setMessage(widget.getMessage().copy().withStyle(s -> s.withFont(Ui.FONT)));
        }
        int rowY = panelTop(screen.height) + 36;
        for (Theme theme : Theme.values()) {
            buttons.add(new ModeButton(panelX(screen.width) + 9, rowY, panelWidth(screen.width) - 18, rowHeight(screen.height), theme));
            rowY += rowHeight(screen.height) + 8;
        }
    }

    public static void drawPanel(GuiGraphics g, int width, int height) {
        int x = panelX(width), y = panelTop(height), w = panelWidth(width), h = panelHeight(height);
        int accent = AstraConfig.theme().accent;
        Ui.round(g, x - 4, y - 4, w + 8, h + 8, 19, Ui.alpha(accent, .07f));
        Ui.gradient(g, x, y, w, h, 16, 0xFFBFB1EC, 0xFF6C98DD);
        Ui.gradient(g, x + 1, y + 1, w - 2, h - 2, 15, 0xF2151A32, 0xF21A1834);
        var font = Minecraft.getInstance().font;
        Ui.animated(g,font,"Appearance",x+12,y+13,0xFFEAE6FA);
        int starX = x + w - 17;
        g.fill(starX, y + 11, starX + 1, y + 19, 0xFFD9C7FF);
        g.fill(starX - 3, y + 14, starX + 4, y + 15, 0xFFD9C7FF);
    }

    public static void drawHeading(GuiGraphics g, int width, int height, float alpha) {
        var font = Minecraft.getInstance().font;
        int center = center(width);
        if (Minecraft.getInstance().screen instanceof TitleScreen title) {
            AbstractWidget anchor = mods(title);
            if (anchor != null) center = anchor.getX() + anchor.getWidth() / 2;
        }
        int y = Math.max(12, menuTop(height) - 90);
        Ui.centered(g, font, AstraClient.NAME, center, y, width < 400 ? 1.9f : 2.5f, Ui.alpha(0xFFF7F5FF, alpha));
        Ui.centered(g, font, "Get Client Free at", center, y + 33, 1f, Ui.alpha(0xFFC2C5D9, alpha));
        Ui.centered(g, font, ".gg/gazebo", center, y + 47, 1.15f, Ui.alpha(AstraConfig.theme().accent, alpha));
    }
}
