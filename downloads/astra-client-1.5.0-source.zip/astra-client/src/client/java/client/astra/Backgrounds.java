package client.astra;

import net.minecraft.client.Minecraft;
import net.minecraft.client.gui.GuiGraphics;

public final class Backgrounds {
    private Backgrounds() {}

    public static void draw(GuiGraphics g, int width, int height) {
        var texture = AstraConfig.theme().texture;
        var gpu = Minecraft.getInstance().getTextureManager().getTexture(texture).getTexture();
        float sourceAspect = gpu.getWidth(0) / (float) gpu.getHeight(0);
        float targetAspect = width / (float) height;
        float uSpan = Math.min(1f, targetAspect / sourceAspect);
        float vSpan = Math.min(1f, sourceAspect / targetAspect);
        g.blit(texture, 0, 0, width, height, (1 - uSpan) / 2, (1 + uSpan) / 2, (1 - vSpan) / 2, (1 + vSpan) / 2);
        g.fill(0, 0, width, height, 0x38040815);
    }
}
