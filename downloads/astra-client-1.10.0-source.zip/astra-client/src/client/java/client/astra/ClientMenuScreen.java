package client.astra;

import net.minecraft.client.gui.GuiGraphics;
import net.minecraft.client.gui.screens.Screen;
import net.minecraft.client.input.KeyEvent;
import net.minecraft.client.input.MouseButtonEvent;
import net.minecraft.network.chat.Component;
import org.lwjgl.glfw.GLFW;
import java.util.function.*;

public final class ClientMenuScreen extends Screen {
    private static final int W=640,H=400,X=142,CW=484;
    private static final String[] TABS={"Visuals","Settings","Jamble","Customize Totem","HUD","Spotify HUD","Essentials"};
    private String tab="Visuals";
    private boolean customiseSpotify,donutPack,bindingFreelook;
    private final MenuTween openMotion=new MenuTween(0),pageMotion=new MenuTween(1);
    private boolean closing,pendingCustomise;
    private String pendingTab;
    private float scale,originX,originY,pageOffset,brightness=(float)AstraConfig.menuBrightness;
    private long lastFrame=System.nanoTime();
    public ClientMenuScreen() { super(Component.literal("Astra Client")); }
    private void fit() {
        scale=Math.min(1.3f,Math.min((width-18f)/W,(height-18f)/H))*(.975f+.025f*openMotion.eased());
        originX=(width-W*scale)/2;originY=(height-H*scale)/2+(1-openMotion.eased())*6;
    }
    @Override protected void init() {
        fit();
        addRenderableWidget(new MenuButton(566,15,25,26,"","Settings",()->tab.equals("Profile"),false,()->navigate("Profile",false)));
        addRenderableWidget(new MenuButton(601,15,25,26,"X","",()->false,false,this::onClose));
        for(int i=0;i<TABS.length;i++) {
            String next=TABS[i];
            addRenderableWidget(new MenuButton(14,74+i*37,112,31,next,next,()->(pendingTab==null?tab:pendingTab).equals(next),false,()->{
                if(!tab.equals(next) || customiseSpotify || donutPack || pendingTab!=null)navigate(next,false);
            }));
        }
        switch(tab) {
            case "Visuals" -> {
                addRenderableWidget(new MenuButton(455,72,160,25,"Bubble Font","",()->AstraConfig.bubbleFont,true,()->{
                    AstraConfig.bubbleFont=!AstraConfig.bubbleFont;AstraConfig.changed();
                }));
                slider(153,129,462,()->AstraConfig.menuBrightness,v->{AstraConfig.menuBrightness=v;AstraConfig.changed();},v->"Brightness: "+Math.round(v*100)+"%");
                addRenderableWidget(new MenuSlider(153,190,462,()->(minecraft.options.fov().get()-30)/80.0,v->{minecraft.options.fov().set((int)Math.round(30+v*80));AstraConfig.nativeChanged();},v->"Field of view: "+minecraft.options.fov().get(),1.0/80));
                for(int i=0;i<Theme.values().length;i++) {
                    Theme theme=Theme.values()[i];
                    addRenderableWidget(new MenuButton(153+i*117,296,111,25,theme.label,"",()->AstraConfig.theme()==theme,true,()->AstraConfig.select(theme)));
                }
                addRenderableWidget(new MenuButton(153,324,462,23,"Reactive Background","",()->AstraConfig.reactiveBackground,true,()->{
                    AstraConfig.reactiveBackground=!AstraConfig.reactiveBackground;AstraConfig.changed();
                }));
                addRenderableWidget(new MenuButton(153,366,462,23,"Fake Media (local)","",()->AstraConfig.fakeMedia,true,()->{
                    AstraConfig.fakeMedia=!AstraConfig.fakeMedia;AstraConfig.changed();
                }));
            }
            case "Settings" -> {
                toggle(153,137,462,"Smooth animations",()->AstraConfig.animations,()->{AstraConfig.animations=!AstraConfig.animations;AstraConfig.changed();});
                toggle(153,191,462,"Button sounds",()->AstraConfig.sounds,()->{AstraConfig.sounds=!AstraConfig.sounds;AstraConfig.changed();});
                addRenderableWidget(new MenuButton(153,258,240,29,"Reset Astra preferences","",()->false,false,()->{
                    AstraConfig.reset();FreelookBridge.initialize();AstraConfig.nativeChanged();brightness=1;pageMotion.reset(0);rebuildWidgets();
                }));

            }
            case "HUD" -> {
                toggle(153,137,462,"Show Astra watermark",()->AstraConfig.hudVisible,()->{AstraConfig.hudVisible=!AstraConfig.hudVisible;AstraConfig.changed();});
                toggle(153,191,462,"Show moon logo",()->AstraConfig.hudLogo,()->{AstraConfig.hudLogo=!AstraConfig.hudLogo;AstraConfig.changed();});
            }
            case "Spotify HUD" -> {
                if(customiseSpotify) {
                    for(int i=0;i<SpotifyHudTheme.values().length;i++) {
                        SpotifyHudTheme theme=SpotifyHudTheme.values()[i];
                        addRenderableWidget(new MenuButton(153+i*117,177,111,33,theme.label,"",()->AstraConfig.spotifyTheme()==theme,true,()->AstraConfig.selectSpotifyTheme(theme)));
                    }
                    addRenderableWidget(new MenuButton(153,226,160,27,"Back to Spotify HUD","",()->false,false,()->spotifyPage(false)));
                } else {
                    addRenderableWidget(new MenuButton(153,137,224,29,"Enable Spotify HUD","",()->AstraConfig.hudSpotify,true,this::toggleSpotifyHud));
                    addRenderableWidget(new MenuButton(389,137,226,29,"Enable Lyrics","",()->AstraConfig.lyricsEnabled,true,()->{AstraConfig.lyricsEnabled=!AstraConfig.lyricsEnabled;AstraConfig.changed();}));
                    addRenderableWidget(new MenuButton(153,174,224,29,"Desktop link","",()->AstraConfig.spotifyEnabled,true,()->{AstraConfig.spotifyEnabled=!AstraConfig.spotifyEnabled;AstraConfig.changed();SpotifyBridge.tick();}));
                    addRenderableWidget(new MenuButton(389,174,226,29,"Reconnect","",()->false,false,SpotifyBridge::reconnect)
                        .available(()->SpotifyBridge.windows() && AstraConfig.spotifyEnabled));
                    addRenderableWidget(new MenuSlider(153,211,462,()->(AstraConfig.spotifyHudScale-.5)/.5,v->{
                        AstraConfig.spotifyHudScale=Math.round((.5+v*.5)*100)/100.0;AstraConfig.changed();
                    },v->"Spotify HUD size: "+Math.round(AstraConfig.spotifyHudScale*100)+"%",.02));
                    addRenderableWidget(new MenuButton(153,321,143,28,"Previous","",()->false,false,()->SpotifyBridge.send("previous"))
                        .available(()->SpotifyBridge.state().connected() && SpotifyBridge.state().previous()));
                    addRenderableWidget(new MenuButton(307,321,153,28,"Play / pause","",()->SpotifyBridge.state().playing(),false,()->SpotifyBridge.send("toggle"))
                        .available(()->SpotifyBridge.state().connected() && SpotifyBridge.state().toggle()));
                    addRenderableWidget(new MenuButton(471,321,144,28,"Next","",()->false,false,()->SpotifyBridge.send("next"))
                        .available(()->SpotifyBridge.state().connected() && SpotifyBridge.state().next()));
                    addRenderableWidget(new MenuButton(153,357,462,26,"Customise Spotify HUD","General",()->false,false,()->spotifyPage(true)));
                }
            }
            case "Customize Totem" -> {
                if(donutPack) {
                    addRenderableWidget(new MenuButton(515,72,100,25,"Back to packs","",()->false,false,()->totemPage(false)));
                    for(int i=0;i<TotemStyle.PACK.length;i++) {
                        TotemStyle style=TotemStyle.PACK[i];int tx=153+i%3*158,ty=109+i/3*130;
                        addRenderableWidget(new MenuButton(tx+9,ty+90,128,24,AstraConfig.totemStyle()==style?"Unequip":"Equip","",()->AstraConfig.totemStyle()==style,false,()->{
                            AstraConfig.selectTotem(AstraConfig.totemStyle()==style?TotemStyle.NONE:style);rebuildWidgets();
                        }));
                    }
                } else {
                    addRenderableWidget(new MenuButton(457,295,158,31,"Open Pack","",()->false,false,()->totemPage(true)));
                    addRenderableWidget(new MenuButton(153,350,192,27,"Unequip Totem","",()->false,false,()->{AstraConfig.selectTotem(TotemStyle.NONE);rebuildWidgets();}).available(()->AstraConfig.totemStyle()!=TotemStyle.NONE));
                }
            }
            case "Essentials" -> {
                toggle(153,137,462,"Freelook",()->AstraConfig.freelookEnabled,()->{AstraConfig.freelookEnabled=!AstraConfig.freelookEnabled;AstraConfig.changed();});
                addRenderableWidget(new MenuButton(153,207,462,35,bindingFreelook?"Press a key or mouse button...":"Set a key: "+FreelookBridge.keyName(),"",()->bindingFreelook,false,()->{bindingFreelook=true;rebuildWidgets();}));
            }
        }
    }
    private void totemPage(boolean open){navigate("Customize Totem",open);}
    private void spotifyPage(boolean customise) {navigate("Spotify HUD",customise);}
    private void navigate(String next,boolean customise) {
        pendingTab=next;pendingCustomise=customise;
        if(!AstraConfig.animations)applyPendingPage();
    }
    private void applyPendingPage() {
        tab=pendingTab;customiseSpotify=pendingCustomise && tab.equals("Spotify HUD");donutPack=pendingCustomise && tab.equals("Customize Totem");pendingTab=null;bindingFreelook=false;
        pageMotion.reset(AstraConfig.animations?0:1);setDragging(false);rebuildWidgets();
    }
    private boolean content(net.minecraft.client.gui.components.Renderable r) {
        return r instanceof net.minecraft.client.gui.components.AbstractWidget w && w.getX()>=X && w.getY()>=70;
    }
    private void slider(int x,int y,int w,DoubleSupplier read,DoubleConsumer write,Function<Double,String> format) {
        addRenderableWidget(new MenuSlider(x,y,w,read,write,format));
    }
    private void toggle(int x,int y,int w,String label,BooleanSupplier read,Runnable write) {
        addRenderableWidget(new MenuButton(x,y,w,35,label,"",read,true,write));
    }
    private void toggleSpotifyHud() {
        AstraConfig.hudSpotify=!AstraConfig.hudSpotify;
        if(AstraConfig.hudSpotify) {
            AstraConfig.spotifyEnabled=true;
            if(!SpotifyBridge.state().connected())SpotifyBridge.reconnect();
        }
        AstraConfig.changed();
    }
    private String fitText(String value,int maxWidth) {
        if(font.width(Ui.text(value))<=maxWidth) return value;
        String trim=value;
        while(!trim.isEmpty() && font.width(Ui.text(trim+"..."))>maxWidth) trim=trim.substring(0,trim.offsetByCodePoints(trim.length(),-1));
        return trim+"...";
    }
    private void text(GuiGraphics g,String label,int x,int y,int color) {Ui.animated(g,font,label,x,y,color);}
    private void card(GuiGraphics g,int x,int y,int w,int h,String title,String icon) {
        Ui.round(g,x-2,y-2,w+4,h+4,19,0x299A55EA);
        Ui.round(g,x,y,w,h,17,0xFFE4C2FA);
        Ui.gradient(g,x+2,y+2,w-4,h-4,15,0xF13D305B,0xF01C1935);
        MenuArt.icon(g,icon,x+12,y+12,14,0xFFC5A6F4);
        Ui.animated(g,font,Ui.heading(title),x+35,y+12,0xFFF2E6FF);
    }
    @Override public void render(GuiGraphics g,int mouseX,int mouseY,float delta) {
        long now=System.nanoTime();float elapsed=Math.clamp((now-lastFrame)/1e9f,0,1),dt=Math.min(.1f,elapsed);lastFrame=now;
        openMotion.advance(closing?0:1,elapsed,closing?.24f:.30f,AstraConfig.animations);
        if(closing && openMotion.at(0)) {minecraft.setScreen(null);return;}
        if(pendingTab!=null) {
            float outgoing=pageMotion.secondsTo(0,.11f);
            pageMotion.advance(0,elapsed,.11f,AstraConfig.animations);
            if(pageMotion.at(0)) {
                applyPendingPage();
                pageMotion.advance(1,Math.max(0,elapsed-outgoing),.18f,AstraConfig.animations);
            }
        } else pageMotion.advance(1,elapsed,.18f,AstraConfig.animations);
        pageOffset=(pendingTab==null?1:-1)*14*(1-pageMotion.eased());
        fit();
        float target=(float)AstraConfig.menuBrightness;
        brightness=AstraConfig.animations?brightness+(target-brightness)*(1-(float)Math.exp(-dt*24)):target;
        g.pose().pushMatrix();g.pose().translate(originX,originY);g.pose().scale(scale,scale);
        float oldRoot=Ui.pushOpacity(openMotion.eased());
        try {
        Ui.round(g,-2,-2,W+4,H+4,20,0x457F55D7);
        Ui.round(g,-1,-1,W+2,H+2,19,0xFFD3A5FF);
        MenuArt.background(g,W,H);
        MenuArt.icon(g,"star",24,19,23,0xFFC6A2FF);
        Ui.centered(g,font,"Astra Client",64+(int)(font.width(Ui.heading("Astra Client"))*.85f),14,1.7f,0xFFF0E9FF);
        text(g,"Minecraft Client",64,40,0xFFA2A2C1);
        ProfileHeader.draw(g,font,523,10);
        g.fill(12,61,W-12,62,Ui.tint(0x7F766498));
        g.fill(133,71,134,H-20,Ui.tint(0x554D4B70));
        for(var child:children())if(child instanceof net.minecraft.client.gui.components.Renderable r && !content(r))r.render(g,(int)((mouseX-originX)/scale),(int)((mouseY-originY)/scale),delta);
        g.enableScissor(X-3,69,W-5,H-5);
        g.pose().pushMatrix();g.pose().translate(pageOffset,0);
        float oldPage=Ui.pushOpacity(pageMotion.eased());
        try {
            renderPage(g);
            for(var child:children())if(child instanceof net.minecraft.client.gui.components.Renderable r && content(r))r.render(g,(int)((mouseX-originX)/scale-pageOffset),(int)((mouseY-originY)/scale),delta);
        } finally {Ui.restoreOpacity(oldPage);g.pose().popMatrix();g.disableScissor();}

        Ui.round(g,0,0,W,H,18,Ui.alpha(0xFF000000,(1-brightness)*.90f));
        } finally {Ui.restoreOpacity(oldRoot);g.pose().popMatrix();}
    }
    private void renderPage(GuiGraphics g) {
        String title=donutPack?"DonutSMP Pack":tab;
        Ui.centered(g,font,title,X+font.width(Ui.heading(title))*3/4,76,1.5f,0xFFF1EAFF);
        switch(tab) {
            case "Visuals" -> {
                card(g,X,105,CW,147,"Appearance","Visuals");
                text(g,"Adjusts menu brightness only; the world is unchanged.",163,177,0xFFA4A3BE);
                card(g,X,265,CW,130,"Menu Background","General");
                text(g,"Makes the Menu Look 100X Better.",163,351,0xFFB1ABC8);
            }
            case "Settings" -> {
                card(g,X,105,CW,230,"Client preferences","Settings");
                text(g,"Gentle motion, hover transitions and animated sliders.",163,177,0xFFA4A3BE);
                text(g,"Soft UI clicks. Respects Minecraft's sound volume.",163,231,0xFFA4A3BE);
                
                
                text(g,"Preferences are saved automatically.",156,309,0xFFB8A6D9);
            }
            case "HUD" -> {
                card(g,X,105,CW,195,"Astra HUD elements","HUD");
                text(g,"A compact pill with smooth entry and resizing.",163,177,0xFFA4A3BE);
                text(g,"The moon gently breathes while animations are on.",163,231,0xFFA4A3BE);
                text(g,"Spotify options are in the Spotify HUD category.",156,271,0xFFB8A6D9);
            }
            case "Spotify HUD" -> {
                if(customiseSpotify) {
                    card(g,X,105,CW,160,"Customise Spotify HUD","General");
                    text(g,"Choose a theme for your Spotify HUD.",156,148,0xFFB8A6D9);
                    text(g,"Saves automatically.",331,236,0xFFB8A6D9);
                    card(g,X,278,CW,105,"Live preview","Visuals");
                    SpotifyHud.drawPreview(g,font,X+CW/2,310);
                } else {
                    card(g,X,105,CW,282,"Playback and HUD","Music");
                    var media=SpotifyBridge.state();
                    text(g,media.connected()?media.playing()?"Connected / Playing":"Connected / Paused":fitText(media.status(),445),156,267,media.connected()?0xFFC8B0F3:0xFFA4A3BE);
                    text(g,fitText(media.connected()?media.title():"Open Spotify on Windows and play a song.",445),156,285,0xFFF0E8FF);
                    text(g,fitText(media.connected()?media.artist():"Close this menu to view the HUD. Lyrics use LRCLIB online.",445),156,303,0xFFB6B2CD);
                }
            }
            case "Jamble" -> {
                card(g,X,105,CW,195,"Jamble","Jamble");
                text(g,"Coming later",162,157,0xFFE7DCF9);
                text(g,"A dedicated page for future Jamble features.",162,182,0xFFA9A9C2);
            }
            case "Customize Totem" -> {
                if(donutPack) {
                    for(int i=0;i<TotemStyle.PACK.length;i++) {
                        TotemStyle style=TotemStyle.PACK[i];int tx=153+i%3*158,ty=109+i/3*130;
                        boolean equipped=AstraConfig.totemStyle()==style;
                        if(equipped)Ui.round(g,tx-2,ty-2,150,126,13,0x557D43DA);
                        Ui.round(g,tx,ty,146,122,11,equipped?0xFFD8B5FF:0xFF6C5A88);
                        Ui.gradient(g,tx+1,ty+1,144,120,10,equipped?0xFF40305B:0xFF302A43,0xFF19182F);
                        var label=Ui.text(style.label());float small=Math.min(1,130f/font.width(label));
                        g.pose().pushMatrix();g.pose().translate(tx+73,ty+8);g.pose().scale(small,small);Ui.animated(g,font,label,-font.width(label)/2f,0,equipped?0xFFF0D9FF:0xFFE2DAED);g.pose().popMatrix();
                        style.preview(g,tx+43,ty+24,60);
                    }
                    text(g,"One totem equipped at a time. Unequip restores Minecraft's.",156,381,0xFFB5AACB);
                } else {
                    card(g,X,105,CW,232,"DonutSMP Pack","Customize Totem");
                    text(g,"Five creator totems. Choose your favourite inside the pack.",163,145,0xFFB5AACB);
                    for(int i=0;i<TotemStyle.PACK.length;i++) {
                        TotemStyle style=TotemStyle.PACK[i];int tx=163+i*90;style.preview(g,tx,171,64);
                        var label=Ui.text(style.creator);Ui.animated(g,font,label,tx+32-font.width(label)/2f,245,0xFFE2DAED);
                    }
                    text(g,"Equipped: "+AstraConfig.totemStyle().creator,163,307,0xFFE0CCF2);
                    text(g,"Restores the original totem.",362,359,0xFFA9A9C2);
                }
            }
            case "Profile" -> {
                card(g,X,105,CW,228,"Minecraft profile","Settings");
                var skin=minecraft.player==null?net.minecraft.client.resources.DefaultPlayerSkin.get(minecraft.getUser().getProfileId()):minecraft.player.getSkin();
                net.minecraft.client.gui.components.PlayerFaceRenderer.draw(g,skin,163,151,42,Ui.tint(0xFFFFFFFF));
                text(g,minecraft.getUser().getName(),220,154,0xFFF0E8FF);
                text(g,PremiumEdition.premium()?"Premium":"Member",220,179,PremiumEdition.premium()?0xFFFFD26F:0xFFAAAAAA);
                text(g,PremiumEdition.description(),163,222,0xFFB5AACB);
                if(PremiumEdition.premium()) {
                    text(g,"Time remaining: "+PremiumEdition.timeLeft(),163,249,0xFFFFD26F);
                    text(g,"Expires: "+PremiumEdition.expiry(),163,275,0xFFB5AACB);
                } else text(g,PremiumEdition.edition()?"Your Premium period has ended. Member mode remains available.":"The separate Premium download includes a 30-day cosmetic rank.",163,249,0xFFA9A9C2);
                text(g,"Astra cosmetic rank. DonutSMP server ranks are separate.",163,310,0xFFA9A9C2);
            }
            case "Essentials" -> {
                card(g,X,105,CW,225,"Freelook","Essentials");
                text(g,"Use your bind to look around. F5 is not required.",163,181,0xFFA4A3BE);
                text(g,bindingFreelook?"Escape or Delete: clear binding.":FreelookBridge.instruction(),163,255,0xFFB8A6D9);
                String conflict=FreelookBridge.conflict();
                text(g,fitText(conflict.isBlank()?FreelookBridge.status():"Also bound to: "+conflict,440),163,285,conflict.isBlank()?0xFFA4A3BE:0xFFE4C48F);
            }
        }
    }
    @Override public void onClose() {
        if(closing)return;
        closing=true;
        if(!AstraConfig.animations)minecraft.setScreen(null);
    }
    private MouseButtonEvent local(MouseButtonEvent e) {return new MouseButtonEvent((e.x()-originX)/scale,(e.y()-originY)/scale,e.buttonInfo());}
    @Override public boolean mouseClicked(MouseButtonEvent e,boolean twice) {
        if(bindingFreelook) {
            FreelookBridge.bind(com.mojang.blaze3d.platform.InputConstants.Type.MOUSE.getOrCreate(e.button()));bindingFreelook=false;rebuildWidgets();return true;
        }
        if(closing)return true;
        var hit=local(e);
        if((pendingTab!=null || !pageMotion.at(1)) && hit.x()>=X && hit.y()>=70)return true;
        return super.mouseClicked(hit,twice);
    }
    @Override public boolean mouseReleased(MouseButtonEvent e) {return !closing && pendingTab==null && pageMotion.at(1) && super.mouseReleased(local(e));}
    @Override public boolean mouseDragged(MouseButtonEvent e,double dx,double dy) {return !closing && pendingTab==null && pageMotion.at(1) && super.mouseDragged(local(e),dx/scale,dy/scale);}
    @Override public boolean keyPressed(KeyEvent key) {
        if(bindingFreelook) {
            FreelookBridge.bind(key.key()==GLFW.GLFW_KEY_DELETE || key.key()==GLFW.GLFW_KEY_ESCAPE?com.mojang.blaze3d.platform.InputConstants.UNKNOWN:com.mojang.blaze3d.platform.InputConstants.getKey(key));
            bindingFreelook=false;rebuildWidgets();return true;
        }
        if(key.key()==GLFW.GLFW_KEY_RIGHT_SHIFT) {onClose();return true;}
        if(key.key()==GLFW.GLFW_KEY_ESCAPE) {onClose();return true;}
        if(closing || pendingTab!=null || !pageMotion.at(1))return true;
        return super.keyPressed(key);
    }
    @Override public void removed() {AstraConfig.flush();super.removed();}
    @Override public boolean isPauseScreen() {return false;}
}
