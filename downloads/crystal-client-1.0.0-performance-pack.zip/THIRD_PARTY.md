# Third-party components

The performance ZIP is an aggregation of original, unmodified mod JARs. Their code is not claimed as Crystal code. Install only one version of each.

| Component | Author/project | License/source |
|---|---|---|
| Sodium 0.8.14 for 1.21.11 | CaffeineMC | PolyForm Shield 1.0.0; https://github.com/CaffeineMC/sodium |
| Lithium 0.21.4 for 1.21.11 | CaffeineMC | LGPL-3.0; https://github.com/CaffeineMC/lithium-fabric/tree/mc1.21.11-0.21.4 |
| FerriteCore 8.2.0 | malte0811 | MIT; https://github.com/malte0811/FerriteCore |
| ImmediatelyFast 1.14.3 | RaphiMC | LGPL-3.0-or-later; https://github.com/RaphiMC/ImmediatelyFast/tree/v1.14.3 |
| Fabric API 0.141.6+1.21.11 | FabricMC contributors | Apache-2.0; https://github.com/FabricMC/fabric |

Original notices remain in the JARs. Extracted license texts and the corresponding Lithium/ImmediatelyFast source archives are in the third-party directory of the pack/source ZIP. The manifest records exact versions, original download links, SHA-256 and SHA-512 hashes. Files obtained from Modrinth were checked against its published SHA-512 before inclusion. Fabric API is the original official Maven artifact.

You can replace these separate LGPL mod JARs with compatible versions for your own use, subject to their licenses and Minecraft compatibility. Nothing is encrypted or linked into Crystal's own JAR. Retain notices when sharing any permitted component. Sodium's PolyForm Shield terms still apply; this is a private personal pack, not a new Sodium implementation or public commercial distribution.

Crystal UI Medium is a static weight-550 derivative of the SIL-OFL Quicksand font. Its reserved family name was replaced with Crystal UI / CrystalUI-Medium. Original attribution, license, font source and the FontTools authoring script are supplied. FontTools is a build/authoring tool and is not used by the client at runtime.

The logo asset was prepared from Jack's supplied reference. Minecraft, Java, Fabric and the listed projects retain their own names and rights; Crystal is an independent personal mod.
