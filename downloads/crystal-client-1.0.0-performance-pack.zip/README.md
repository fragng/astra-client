# Crystal Client 1.0.0 — Jack's personal performance client

Minecraft Java **1.21.11**, **Fabric Loader 0.19.3 or newer**, **Java 21**.

Use the **performance-pack ZIP** for the complete client. The separate Crystal JAR supplies the interface, branding and video presets; the ZIP also supplies the actual performance mods and Fabric API.

## Install the complete pack

1. Use a separate Minecraft instance/game directory for Crystal so your Astra installation stays separate.
2. Install/select Fabric for Minecraft 1.21.11 in that instance.
3. Extract the ZIP. Copy its **mods** folder into that instance's game directory. There should be six JAR files directly inside the instance's mods folder.
4. Launch the Fabric profile using Java 21. Do not install duplicate versions of these mods or combine the two clients.

On a fresh Minecraft setup, its standard accessibility/language welcome may appear once. Continue from it to reach Crystal's white home screen.

## Personal interface

The white home screen has soft lavender controls, the supplied logo reference at the top right and footer, and Crystal Client window branding. Its local-time greeting includes **Good afternoon, Jack** from 12:00–17:59, plus morning/evening welcomes. There are **28 additional personalised welcome lines**, rotating on menu visits.

Singleplayer, Multiplayer, Minecraft Settings and Quit use real Minecraft actions. Multiplayer retains Minecraft's account restrictions and native safety prompt. The logo is also applied to the game window/Alt-Tab icon where GLFW supports it. Windows pinned launcher shortcuts are managed by Windows/the launcher and are not rewritten by a mod.

Use **Performance settings** on the home screen or **Right Shift** in a world. The small in-game footer shows Crystal's logo and the actual Minecraft FPS counter; it can be disabled.

## Graphics presets

Fast applies automatically once, after startup has finished and the existing settings have been backed up.

| Preset | Effect |
|---|---|
| Balanced | Restores your earlier video values; the performance mods remain active. |
| Fast | Up to 8 render / 5 simulation chunks, entity distance up to 75%, fewer particles, clouds/shadows/ambient occlusion off, simpler leaves/transparency, texture mipmaps at most 2, VSync off. Keeps your existing world FPS limit. |
| Maximum FPS | Up to 4 render / 5 simulation chunks, entity distance up to 50%, minimal effects, mipmaps 0, VSync off and Minecraft's unlimited world FPS option. |

Existing lower distance, particle and mipmap settings are retained. FOV, world brightness, audio, controls and server gameplay are not changed. Switching texture/mipmap quality may briefly reload Minecraft's resources. Presets do not require a restart.

Preferences and the video backup save in **config/crystal-client.json**. Restoration compares against the values Minecraft actually accepted; deliberate video-setting edits made while a preset was active are preserved.

**Quiet menus** caps Crystal's own menus at 60 FPS and an inactive window at 30 FPS. It does not limit an active world to 60. The option can be disabled. Both this option and the FPS footer are saved.

## What provides the performance improvements

The pack uses unmodified stable releases, selected specifically for Fabric 1.21.11:

- Sodium **0.8.14**: faster world rendering.
- Lithium **0.21.4**: reduced game/simulation CPU work.
- FerriteCore **8.2.0**: lower memory use.
- ImmediatelyFast **1.14.3**: more efficient immediate/UI rendering.
- Fabric API **0.141.6+1.21.11**: shared Fabric APIs.

Crystal's own menu uses a static background, cached text, compact rounded geometry and no continuous decorative effects. Those choices keep its interface lightweight. The pack does not promise a particular FPS increase: hardware, drivers, world complexity, shaders, VSync and frame limits affect the result. Maximum FPS deliberately reduces visible distance and effects.

See **THIRD_PARTY.md**, the supplied notices and **performance-mods.json** for original authors, licenses, sources and verified hashes. This personal build is supplied as local files; it has not been uploaded to a public repository.
