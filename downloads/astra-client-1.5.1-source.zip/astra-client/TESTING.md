# Astra Client 1.5.1 validation

- Built on Java 21 for Minecraft 1.21.11 / Fabric Loader 0.19.3.
- Exercised the Right Shift menu in singleplayer with Mod Menu installed.
- Checked Settings → Enable Spotify HUD and Enable Lyrics independently: both update immediately and save to config/astra-client.json. Hiding the Spotify HUD keeps the existing Astra watermark.
- Rendered the top-centre card inside Minecraft with a separate development-only media fixture, including decoded album artwork, title, artist, timeline and a real LRCLIB lyrics response.
- The first visual check found enhanced LRC word-timing tags; the parser now strips them and a regression check covers the format.
- Reopened the client after saving preferences; Spotify HUD and lyrics remained enabled.
- Checked the 640×480 window: card and lyrics fit, and the watermark moves below them without overlap. F1 hides both HUD elements. Missing artwork uses a music icon; missing timing shows placeholders and a timing status.
- Java protocol checks covered timeline extrapolation, paused playhead, invalid times, Unicode metadata, idle state and playback command whitelist.
- Lyrics checks covered timestamp offsets, repeated timestamps, seeks, plain-lyrics fallback, instrumental/missing lyrics and URL encoding.
- A production asynchronous LRCLIB lookup succeeded; cached reuse, disabling/re-enabling and cancellation of stale requests passed.
- The production PowerShell poll/JSON/command loop passed with mocked Windows sessions: app detection, artwork field, timeline, album, play/pause, next/previous and shutdown. The complete PowerShell file passed syntax validation.

The media fixture and synthetic cover are outside the project and excluded from the mod. Live Windows Spotify playback, thumbnail extraction and native timeline reporting remain unverified on this Linux development host. No hardware FPS improvement is claimed.

## Visibility regression check (1.5.1)

Ran the actual Minecraft client with no media fixture and Spotify unavailable. The enabled card remained visible with the real platform status, including when Desktop link was disabled. Both Settings and HUD switches hid/showed the card, and enabling it automatically enabled Desktop link. Preferences were checked in the saved JSON file. The page now explains that the HUD appears after closing the client menu. Earlier song/artwork/lyrics tests above describe the 1.5.0 base; the Windows bridge implementation is unchanged by this visibility patch.
