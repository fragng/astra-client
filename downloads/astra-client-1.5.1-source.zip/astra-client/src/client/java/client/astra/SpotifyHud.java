package client.astra;

import com.mojang.blaze3d.platform.NativeImage;
import net.minecraft.client.Minecraft;
import net.minecraft.client.gui.Font;
import net.minecraft.client.gui.GuiGraphics;
import net.minecraft.client.renderer.RenderPipelines;
import net.minecraft.client.renderer.texture.DynamicTexture;
import net.minecraft.resources.Identifier;
import java.awt.image.BufferedImage;
import java.io.*;
import java.util.Base64;
import java.util.concurrent.*;
import javax.imageio.ImageIO;

/** Top-centre now-playing card. Only ready textures and cached lyrics are read during rendering. */
public final class SpotifyHud {
    private static final int W=350,H=86;
    private static final Identifier COVER=Identifier.fromNamespaceAndPath(AstraClient.MOD_ID,"spotify-cover");
    private static final ExecutorService ART=Executors.newSingleThreadExecutor(r->{var t=new Thread(r,"Astra album artwork");t.setDaemon(true);return t;});
    private static SpotifyBridge.State lastMedia;
    private static String artwork="",track="";
    private static boolean coverReady;
    private static int generation;
    private static float visibility;
    private static long lastFrame;
    private SpotifyHud() {}
    public static void tick() {
        var media=SpotifyBridge.state();if(media==lastMedia)return;lastMedia=media;
        String next=media.connected()?media.trackKey():"",nextArt=media.connected()?media.artwork():"";
        if(next.equals(track) && nextArt.equals(artwork))return;
        track=next;artwork=nextArt;int token=++generation;
        if(coverReady) {Minecraft.getInstance().getTextureManager().release(COVER);coverReady=false;}
        if(nextArt.isBlank())return;
        ART.submit(()->{
            try {
                byte[] bytes=Base64.getDecoder().decode(nextArt);
                BufferedImage source=ImageIO.read(new ByteArrayInputStream(bytes));if(source==null)return;
                var resized=new BufferedImage(64,64,BufferedImage.TYPE_INT_ARGB);var paint=resized.createGraphics();
                paint.setRenderingHint(java.awt.RenderingHints.KEY_INTERPOLATION,java.awt.RenderingHints.VALUE_INTERPOLATION_BILINEAR);
                int edge=Math.min(source.getWidth(),source.getHeight());
                int x=(source.getWidth()-edge)/2,y=(source.getHeight()-edge)/2;
                paint.drawImage(source,0,0,64,64,x,y,x+edge,y+edge,null);paint.dispose();source.flush();
                var png=new ByteArrayOutputStream();ImageIO.write(resized,"png",png);resized.flush();
                NativeImage image=NativeImage.read(new ByteArrayInputStream(png.toByteArray()));
                Minecraft.getInstance().execute(()->{
                    if(token!=generation) {image.close();return;}
                    try {Minecraft.getInstance().getTextureManager().register(COVER,new DynamicTexture(()->"Astra Spotify album",image));coverReady=true;}
                    catch(Exception e) {image.close();}
                });
            } catch(Exception ignored) { /* Local thumbnail may be missing or have an unsupported format. */ }
        });
    }
    public static int watermarkY(int screenWidth,Font font) {
        int watermarkWidth=font.width(Ui.heading(AstraClient.NAME))+(AstraConfig.hudLogo?27:9)+10;
        if((screenWidth-W)/2>=watermarkWidth+16 || !AstraConfig.hudSpotify)return 8;
        float scale=Math.min(1,(screenWidth-16f)/W);
        return Math.round(12+(H+(AstraConfig.lyricsEnabled?54:0))*scale)+8;
    }
    public static void draw(GuiGraphics g,Font font) {
        var media=SpotifyBridge.state();long now=System.nanoTime();
        float dt=Math.min(.1f,(now-lastFrame)/1e9f);if(now-lastFrame>600_000_000L)visibility=0;lastFrame=now;
        float target=AstraConfig.hudSpotify?1:0;
        boolean song=media.connected() && !media.title().isBlank();
        visibility=AstraConfig.animations?visibility+(target-visibility)*(1-(float)Math.exp(-dt*12)):target;
        if(visibility<.01f)return;
        float scale=Math.min(1,(g.guiWidth()-16f)/W),x=(g.guiWidth()-W*scale)/2;
        g.pose().pushMatrix();g.pose().translate(x,12-(1-visibility)*10);g.pose().scale(scale,scale);
        Ui.round(g,1,3,W,H,12,color(0xFF060707,.55f));
        Ui.round(g,0,0,W,H,12,color(0xFFC0BDA0,1));
        Ui.round(g,2,2,W-4,H-4,10,color(0xFF666654,1));
        Ui.round(g,4,4,W-8,H-8,8,color(0xFF22231F,.98f));
        Ui.round(g,10,10,66,66,6,color(0xFF55594B,1));
        if(song && coverReady)g.blit(RenderPipelines.GUI_TEXTURED,COVER,11,11,0f,0f,64,64,64,64,64,64,color(0xFFFFFFFF,1));
        else MenuArt.icon(g,"Music",27,27,32,color(0xFFBCBDA4,1));
        double time=AstraConfig.animations?now/1e9:0;
        for(int i=0;i<3;i++) {
            int bar=song && media.playing() && AstraConfig.animations?4+(int)((Math.sin(time*3+i*1.6)+1)*3):5;
            g.fill(88+i*4,26-bar,91+i*4,26,color(0xFFC0BDA0,1));
        }
        marquee(g,font,song?media.title():"Spotify HUD",105,15,230,0xFFF3F2E9,time);
        marquee(g,font,song?media.artist():media.connected()?"Choose a song in Spotify":media.status(),87,36,248,0xFFAEAEA3,time);
        double elapsed=song?media.elapsed():0,duration=song?media.duration():0;
        if(song) {
            String stamp=duration>0?format(elapsed)+" / "+format(duration):"--:-- / --:--";
            int stampWidth=font.width(Ui.text(stamp)),right=337-stampWidth;
            int barWidth=Math.max(28,right-97);
            Ui.round(g,87,67,barWidth,4,2,color(0xFF3E4038,1));
            if(duration>0)Ui.round(g,87,67,(int)Math.round(barWidth*Math.clamp(elapsed/duration,0,1)),4,2,color(0xFFC0BDA0,1));
            Ui.animated(g,font,stamp,right,62,color(0xFFC0BFB1,1));
        } else marquee(g,font,"Right Shift > Music > Reconnect",87,62,248,0xFFC0BFB1,time);
        if(AstraConfig.lyricsEnabled)drawLyrics(g,font,elapsed,duration>0,song);
        g.pose().popMatrix();
    }
    private static void drawLyrics(GuiGraphics g,Font font,double seconds,boolean timing,boolean song) {
        Ui.round(g,10,H+6,W-20,48,9,color(0xFF161914,.88f));
        var lyrics=song?LyricsService.current():new LyricsService.Lyrics("Play a song to show lyrics",java.util.List.of(),true);int index=lyrics.index(seconds);
        String first=lyrics.lines().isEmpty()?lyrics.status():index<0?"…":lyrics.lines().get(index).text();
        if(first.isBlank())first="♪";
        String second=index>=0 && index+1<lyrics.lines().size()?lyrics.lines().get(index+1).text():"";
        if(!timing && lyrics.synced() && !lyrics.lines().isEmpty()) {first="Waiting for Spotify playback timing";second="";}
        String credit=lyrics.synced()?"LRCLIB":"LRCLIB • unsynced";
        if(lyrics.lines().isEmpty())credit="Lyrics";
        Ui.animated(g,font,credit,20,H+10,color(0xFF858C7D,1));
        centredLine(g,font,first,H+23,310,0xFFF1F0E4);
        if(!second.isBlank())centredLine(g,font,second,H+37,310,0xFF9C9F90);
    }
    private static void centredLine(GuiGraphics g,Font font,String value,int y,int max,int color) {
        var text=Ui.text(value);float scale=Math.min(1,max/(float)Math.max(1,font.width(text)));
        scale=Math.max(.65f,scale);
        g.enableScissor(18,y,W-18,y+12);
        g.pose().pushMatrix();g.pose().translate(W/2f,y);g.pose().scale(scale,scale);
        Ui.animated(g,font,text,-font.width(text)/2f,0,color(color,1));g.pose().popMatrix();g.disableScissor();
    }
    private static void marquee(GuiGraphics g,Font font,String value,int x,int y,int max,int color,double time) {
        int width=font.width(Ui.text(value));
        float offset=width>max && AstraConfig.animations?(float)((Math.sin(time*.22-Math.PI/2)+1)*.5*(width-max)):0;
        g.enableScissor(x,y-2,x+max,y+13);
        Ui.animated(g,font,value,x-offset,y,color(color,1));g.disableScissor();
    }
    private static int color(int argb,float alpha) {return Ui.alpha(argb,visibility*alpha);}
    public static String format(double seconds) {long value=(long)Math.max(0,seconds);return value/60+":"+String.format(java.util.Locale.ROOT,"%02d",value%60);}
    public static void close() {generation++;ART.shutdownNow();if(coverReady)Minecraft.getInstance().getTextureManager().release(COVER);coverReady=false;}
}
